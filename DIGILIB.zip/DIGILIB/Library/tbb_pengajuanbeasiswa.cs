﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbb_pengajuanbeasiswa
    {
        private String m_pengajuanbeasiswaid;
        private String m_mahasiswaid;
        private String m_noregistrasi;
        private String m_alamat;
        private String m_kodepos;
        private String m_telp;
        private String m_namapemohon;
        private DateTime m_tanggal;
        private String m_tempat;
        private String m_photo;
        private String m_captcha;
        private String m_tahun;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_statustempattinggal;
        private String m_statustempattinggal_lainnya;
        private String m_programstudiid;
        private decimal m_ip1;
        private decimal m_ip2;
        private decimal m_ip3;
        private decimal m_ip4;
        private decimal m_ip5;
        private decimal m_ip6;
        private decimal m_ipk;
        private String m_sp;
        private String m_dosenwaliid;
        private String m_statusortu;
        private String m_namaortu;
        private decimal m_jmlanak;
        private String m_jmltanggungan;
        private String m_pekerjaanortu;
        private String m_alamatortu;
        private String m_pendapatan_perbulan;
        private String m_jenisbeasiswa;
        private String m_semester;
        private String m_jadwalpengajuanid;
        private String m_status;
        private String m_surat_tidak_mampu;
        private String m_sertifikat2;
        private String m_bukti_pembayaran_kuliah;
        private String m_ktm_ktp;
        private String m_buku_rek;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pengajuanbeasiswaid
        {
            get { return m_pengajuanbeasiswaid; }
            set { m_pengajuanbeasiswaid = value; }
        }
        public String mahasiswaid
        {
            get { return m_mahasiswaid; }
            set { m_mahasiswaid = value; }
        }
        public String noregistrasi
        {
            get { return m_noregistrasi; }
            set { m_noregistrasi = value; }
        }
        public String alamat
        {
            get { return m_alamat; }
            set { m_alamat = value; }
        }
        public String kodepos
        {
            get { return m_kodepos; }
            set { m_kodepos = value; }
        }
        public String telp
        {
            get { return m_telp; }
            set { m_telp = value; }
        }
        public String namapemohon
        {
            get { return m_namapemohon; }
            set { m_namapemohon = value; }
        }
        public DateTime tanggal
        {
            get { return m_tanggal; }
            set { m_tanggal = value; }
        }
        public String tempat
        {
            get { return m_tempat; }
            set { m_tempat = value; }
        }
        public String photo
        {
            get { return m_photo; }
            set { m_photo = value; }
        }
        public String captcha
        {
            get { return m_captcha; }
            set { m_captcha = value; }
        }
        public String tahun
        {
            get { return m_tahun; }
            set { m_tahun = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String statustempattinggal
        {
            get { return m_statustempattinggal; }
            set { m_statustempattinggal = value; }
        }
        public String statustempattinggal_lainnya
        {
            get { return m_statustempattinggal_lainnya; }
            set { m_statustempattinggal_lainnya = value; }
        }
        public String programstudiid
        {
            get { return m_programstudiid; }
            set { m_programstudiid = value; }
        }
        public decimal ip1
        {
            get { return m_ip1; }
            set { m_ip1 = value; }
        }
        public decimal ip2
        {
            get { return m_ip2; }
            set { m_ip2 = value; }
        }
        public decimal ip3
        {
            get { return m_ip3; }
            set { m_ip3 = value; }
        }
        public decimal ip4
        {
            get { return m_ip4; }
            set { m_ip4 = value; }
        }
        public decimal ip5
        {
            get { return m_ip5; }
            set { m_ip5 = value; }
        }
        public decimal ip6
        {
            get { return m_ip6; }
            set { m_ip6 = value; }
        }
        public decimal ipk
        {
            get { return m_ipk; }
            set { m_ipk = value; }
        }
        public String sp
        {
            get { return m_sp; }
            set { m_sp = value; }
        }
        public String dosenwaliid
        {
            get { return m_dosenwaliid; }
            set { m_dosenwaliid = value; }
        }
        public String statusortu
        {
            get { return m_statusortu; }
            set { m_statusortu = value; }
        }
        public String namaortu
        {
            get { return m_namaortu; }
            set { m_namaortu = value; }
        }
        public decimal jmlanak
        {
            get { return m_jmlanak; }
            set { m_jmlanak = value; }
        }
        public String jmltanggungan
        {
            get { return m_jmltanggungan; }
            set { m_jmltanggungan = value; }
        }
        public String pekerjaanortu
        {
            get { return m_pekerjaanortu; }
            set { m_pekerjaanortu = value; }
        }
        public String alamatortu
        {
            get { return m_alamatortu; }
            set { m_alamatortu = value; }
        }
        public String pendapatan_perbulan
        {
            get { return m_pendapatan_perbulan; }
            set { m_pendapatan_perbulan = value; }
        }
        public String jenisbeasiswa
        {
            get { return m_jenisbeasiswa; }
            set { m_jenisbeasiswa = value; }
        }
        public String semester
        {
            get { return m_semester; }
            set { m_semester = value; }
        }
        public String jadwalpengajuanid
        {
            get { return m_jadwalpengajuanid; }
            set { m_jadwalpengajuanid = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }

        public String surat_tidak_mampu
        {
            get { return m_surat_tidak_mampu; }
            set { m_surat_tidak_mampu = value; }
        }
        public String sertifikat2
        {
            get { return m_sertifikat2; }
            set { m_sertifikat2 = value; }
        }
        public String bukti_pembayaran_kuliah
        {
            get { return m_bukti_pembayaran_kuliah; }
            set { m_bukti_pembayaran_kuliah = value; }
        }
        public String ktm_ktp
        {
            get { return m_ktm_ktp; }
            set { m_ktm_ktp = value; }
        }
        public String buku_rek
        {
            get { return m_buku_rek; }
            set { m_buku_rek = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbb_pengajuanbeasiswa(pengajuanbeasiswaid,mahasiswaid,noregistrasi,alamat,kodepos,telp,namapemohon,tanggal,tempat,photo,captcha,tahun,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt,statustempattinggal,statustempattinggal_lainnya,programstudiid,ip1,ip2,ip3,ip4,ip5,ip6,ipk,sp,dosenwaliid,statusortu,namaortu,jmlanak,jmltanggungan,pekerjaanortu,alamatortu,pendapatan_perbulan,jenisbeasiswa,semester,jadwalpengajuanid,status,surat_tidak_mampu,sertifikat2,bukti_pembayaran_kuliah,ktm_ktp,buku_rek)" +
                            "VALUES"+
                            "(@pengajuanbeasiswaid,@mahasiswaid,@noregistrasi,@alamat,@kodepos,@telp,@namapemohon,@tanggal,@tempat,@photo,@captcha,@tahun,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0',@statustempattinggal,@statustempattinggal_lainnya,@programstudiid,@ip1,@ip2,@ip3,@ip4,@ip5,@ip6,@ipk,@sp,@dosenwaliid,@statusortu,@namaortu,@jmlanak,@jmltanggungan,@pekerjaanortu,@alamatortu,@pendapatan_perbulan,@jenisbeasiswa,@semester,@jadwalpengajuanid,@status,@surat_tidak_mampu,@sertifikat2,@bukti_pembayaran_kuliah,@ktm_ktp,@buku_rek)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengajuanbeasiswaid != null )
            {
               cmd.Parameters.Add("@pengajuanbeasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengajuanbeasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@pengajuanbeasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (mahasiswaid != null )
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noregistrasi != null )
            {
               cmd.Parameters.Add("@noregistrasi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noregistrasi;
            }
            else
            {
               cmd.Parameters.Add("@noregistrasi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamat != null )
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamat;
            }
            else
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kodepos != null )
            {
               cmd.Parameters.Add("@kodepos", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kodepos;
            }
            else
            {
               cmd.Parameters.Add("@kodepos", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (telp != null )
            {
               cmd.Parameters.Add("@telp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = telp;
            }
            else
            {
               cmd.Parameters.Add("@telp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (namapemohon != null )
            {
               cmd.Parameters.Add("@namapemohon", NpgsqlTypes.NpgsqlDbType.Varchar).Value = namapemohon;
            }
            else
            {
               cmd.Parameters.Add("@namapemohon", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggal != null && tanggal != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggal;
            }
            else
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tempat != null )
            {
               cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempat;
            }
            else
            {
               cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (photo != null )
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = photo;
            }
            else
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (captcha != null )
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = captcha;
            }
            else
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahun != null )
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (statustempattinggal != null )
            {
               cmd.Parameters.Add("@statustempattinggal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statustempattinggal;
            }
            else
            {
               cmd.Parameters.Add("@statustempattinggal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statustempattinggal_lainnya != null )
            {
               cmd.Parameters.Add("@statustempattinggal_lainnya", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statustempattinggal_lainnya;
            }
            else
            {
               cmd.Parameters.Add("@statustempattinggal_lainnya", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (programstudiid != null )
            {
               cmd.Parameters.Add("@programstudiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = programstudiid;
            }
            else
            {
               cmd.Parameters.Add("@programstudiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@ip1", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip1;
               cmd.Parameters.Add("@ip2", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip2;
               cmd.Parameters.Add("@ip3", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip3;
               cmd.Parameters.Add("@ip4", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip4;
               cmd.Parameters.Add("@ip5", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip5;
               cmd.Parameters.Add("@ip6", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip6;
               cmd.Parameters.Add("@ipk", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ipk;
            if (sp != null )
            {
               cmd.Parameters.Add("@sp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = sp;
            }
            else
            {
               cmd.Parameters.Add("@sp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenwaliid != null )
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statusortu != null )
            {
               cmd.Parameters.Add("@statusortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statusortu;
            }
            else
            {
               cmd.Parameters.Add("@statusortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (namaortu != null )
            {
               cmd.Parameters.Add("@namaortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = namaortu;
            }
            else
            {
               cmd.Parameters.Add("@namaortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jmlanak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jmlanak;
            if (jmltanggungan != null )
            {
               cmd.Parameters.Add("@jmltanggungan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jmltanggungan;
            }
            else
            {
               cmd.Parameters.Add("@jmltanggungan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pekerjaanortu != null )
            {
               cmd.Parameters.Add("@pekerjaanortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pekerjaanortu;
            }
            else
            {
               cmd.Parameters.Add("@pekerjaanortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamatortu != null )
            {
               cmd.Parameters.Add("@alamatortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamatortu;
            }
            else
            {
               cmd.Parameters.Add("@alamatortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pendapatan_perbulan != null )
            {
               cmd.Parameters.Add("@pendapatan_perbulan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pendapatan_perbulan;
            }
            else
            {
               cmd.Parameters.Add("@pendapatan_perbulan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenisbeasiswa != null )
            {
               cmd.Parameters.Add("@jenisbeasiswa", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenisbeasiswa;
            }
            else
            {
               cmd.Parameters.Add("@jenisbeasiswa", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (semester != null )
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = semester;
            }
            else
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jadwalpengajuanid != null )
            {
               cmd.Parameters.Add("@jadwalpengajuanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jadwalpengajuanid;
            }
            else
            {
               cmd.Parameters.Add("@jadwalpengajuanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }

            if (surat_tidak_mampu != null)
            {
                cmd.Parameters.Add("@surat_tidak_mampu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = surat_tidak_mampu;
            }
            else
            {
                cmd.Parameters.Add("@surat_tidak_mampu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (sertifikat2 != null)
            {
                cmd.Parameters.Add("@sertifikat2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = sertifikat2;
            }
            else
            {
                cmd.Parameters.Add("@sertifikat2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (bukti_pembayaran_kuliah != null)
            {
                cmd.Parameters.Add("@bukti_pembayaran_kuliah", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukti_pembayaran_kuliah;
            }
            else
            {
                cmd.Parameters.Add("@bukti_pembayaran_kuliah", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ktm_ktp != null)
            {
                cmd.Parameters.Add("@ktm_ktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ktm_ktp;
            }
            else
            {
                cmd.Parameters.Add("@ktm_ktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (buku_rek != null)
            {
                cmd.Parameters.Add("@buku_rek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = buku_rek;
            }
            else
            {
                cmd.Parameters.Add("@buku_rek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbb_pengajuanbeasiswa SET "+
                            " pengajuanbeasiswaid=@pengajuanbeasiswaid,mahasiswaid=@mahasiswaid,noregistrasi=@noregistrasi,alamat=@alamat,kodepos=@kodepos,telp=@telp,namapemohon=@namapemohon,tanggal=@tanggal,tempat=@tempat,photo=@photo,captcha=@captcha,tahun=@tahun,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0',statustempattinggal=@statustempattinggal,statustempattinggal_lainnya=@statustempattinggal_lainnya,programstudiid=@programstudiid,ip1=@ip1,ip2=@ip2,ip3=@ip3,ip4=@ip4,ip5=@ip5,ip6=@ip6,ipk=@ipk,sp=@sp,dosenwaliid=@dosenwaliid,statusortu=@statusortu,namaortu=@namaortu,jmlanak=@jmlanak,jmltanggungan=@jmltanggungan,pekerjaanortu=@pekerjaanortu,alamatortu=@alamatortu,pendapatan_perbulan=@pendapatan_perbulan,jenisbeasiswa=@jenisbeasiswa,semester=@semester,jadwalpengajuanid=@jadwalpengajuanid,status=@status,surat_tidak_mampu=@surat_tidak_mampu,sertifikat2=@sertifikat2,bukti_pembayaran_kuliah=@bukti_pembayaran_kuliah,ktm_ktp=@ktm_ktp,buku_rek=@buku_rek" +
                            " WHERE pengajuanbeasiswaid=@pengajuanbeasiswaid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengajuanbeasiswaid != null )
            {
               cmd.Parameters.Add("@pengajuanbeasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengajuanbeasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@pengajuanbeasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (mahasiswaid != null )
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noregistrasi != null )
            {
               cmd.Parameters.Add("@noregistrasi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noregistrasi;
            }
            else
            {
               cmd.Parameters.Add("@noregistrasi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamat != null )
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamat;
            }
            else
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kodepos != null )
            {
               cmd.Parameters.Add("@kodepos", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kodepos;
            }
            else
            {
               cmd.Parameters.Add("@kodepos", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (telp != null )
            {
               cmd.Parameters.Add("@telp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = telp;
            }
            else
            {
               cmd.Parameters.Add("@telp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (namapemohon != null )
            {
               cmd.Parameters.Add("@namapemohon", NpgsqlTypes.NpgsqlDbType.Varchar).Value = namapemohon;
            }
            else
            {
               cmd.Parameters.Add("@namapemohon", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggal != null && tanggal != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggal;
            }
            else
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tempat != null )
            {
               cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempat;
            }
            else
            {
               cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (photo != null )
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = photo;
            }
            else
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (captcha != null )
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = captcha;
            }
            else
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahun != null )
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (statustempattinggal != null )
            {
               cmd.Parameters.Add("@statustempattinggal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statustempattinggal;
            }
            else
            {
               cmd.Parameters.Add("@statustempattinggal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statustempattinggal_lainnya != null )
            {
               cmd.Parameters.Add("@statustempattinggal_lainnya", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statustempattinggal_lainnya;
            }
            else
            {
               cmd.Parameters.Add("@statustempattinggal_lainnya", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (programstudiid != null )
            {
               cmd.Parameters.Add("@programstudiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = programstudiid;
            }
            else
            {
               cmd.Parameters.Add("@programstudiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@ip1", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip1;
               cmd.Parameters.Add("@ip2", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip2;
               cmd.Parameters.Add("@ip3", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip3;
               cmd.Parameters.Add("@ip4", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip4;
               cmd.Parameters.Add("@ip5", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip5;
               cmd.Parameters.Add("@ip6", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ip6;
               cmd.Parameters.Add("@ipk", NpgsqlTypes.NpgsqlDbType.Numeric).Value = ipk;
            if (sp != null )
            {
               cmd.Parameters.Add("@sp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = sp;
            }
            else
            {
               cmd.Parameters.Add("@sp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenwaliid != null )
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statusortu != null )
            {
               cmd.Parameters.Add("@statusortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statusortu;
            }
            else
            {
               cmd.Parameters.Add("@statusortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (namaortu != null )
            {
               cmd.Parameters.Add("@namaortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = namaortu;
            }
            else
            {
               cmd.Parameters.Add("@namaortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jmlanak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jmlanak;
            if (jmltanggungan != null )
            {
               cmd.Parameters.Add("@jmltanggungan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jmltanggungan;
            }
            else
            {
               cmd.Parameters.Add("@jmltanggungan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pekerjaanortu != null )
            {
               cmd.Parameters.Add("@pekerjaanortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pekerjaanortu;
            }
            else
            {
               cmd.Parameters.Add("@pekerjaanortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamatortu != null )
            {
               cmd.Parameters.Add("@alamatortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamatortu;
            }
            else
            {
               cmd.Parameters.Add("@alamatortu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pendapatan_perbulan != null )
            {
               cmd.Parameters.Add("@pendapatan_perbulan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pendapatan_perbulan;
            }
            else
            {
               cmd.Parameters.Add("@pendapatan_perbulan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenisbeasiswa != null )
            {
               cmd.Parameters.Add("@jenisbeasiswa", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenisbeasiswa;
            }
            else
            {
               cmd.Parameters.Add("@jenisbeasiswa", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (semester != null )
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = semester;
            }
            else
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jadwalpengajuanid != null )
            {
               cmd.Parameters.Add("@jadwalpengajuanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jadwalpengajuanid;
            }
            else
            {
               cmd.Parameters.Add("@jadwalpengajuanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }

            if (surat_tidak_mampu != null)
            {
                cmd.Parameters.Add("@surat_tidak_mampu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = surat_tidak_mampu;
            }
            else
            {
                cmd.Parameters.Add("@surat_tidak_mampu", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (sertifikat2 != null)
            {
                cmd.Parameters.Add("@sertifikat2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = sertifikat2;
            }
            else
            {
                cmd.Parameters.Add("@sertifikat2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (bukti_pembayaran_kuliah != null)
            {
                cmd.Parameters.Add("@bukti_pembayaran_kuliah", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukti_pembayaran_kuliah;
            }
            else
            {
                cmd.Parameters.Add("@bukti_pembayaran_kuliah", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ktm_ktp != null)
            {
                cmd.Parameters.Add("@ktm_ktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ktm_ktp;
            }
            else
            {
                cmd.Parameters.Add("@ktm_ktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (buku_rek != null)
            {
                cmd.Parameters.Add("@buku_rek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = buku_rek;
            }
            else
            {
                cmd.Parameters.Add("@buku_rek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbb_pengajuanbeasiswa WHERE pengajuanbeasiswaid=@pengajuanbeasiswaid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pengajuanbeasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengajuanbeasiswaid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbb_pengajuanbeasiswa SET DLT='1', op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now() WHERE pengajuanbeasiswaid=@pengajuanbeasiswaid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@pengajuanbeasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengajuanbeasiswaid;
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbb_pengajuanbeasiswa WHERE pengajuanbeasiswaid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengajuanbeasiswaid"))) 
            {
              m_pengajuanbeasiswaid = rdr.GetString(rdr.GetOrdinal("pengajuanbeasiswaid"));
            }
            else
            {
              m_pengajuanbeasiswaid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("mahasiswaid"))) 
            {
              m_mahasiswaid = rdr.GetString(rdr.GetOrdinal("mahasiswaid"));
            }
            else
            {
              m_mahasiswaid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("noregistrasi"))) 
            {
              m_noregistrasi = rdr.GetString(rdr.GetOrdinal("noregistrasi"));
            }
            else
            {
              m_noregistrasi = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("alamat"))) 
            {
              m_alamat = rdr.GetString(rdr.GetOrdinal("alamat"));
            }
            else
            {
              m_alamat = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("kodepos"))) 
            {
              m_kodepos = rdr.GetString(rdr.GetOrdinal("kodepos"));
            }
            else
            {
              m_kodepos = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("telp"))) 
            {
              m_telp = rdr.GetString(rdr.GetOrdinal("telp"));
            }
            else
            {
              m_telp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("namapemohon"))) 
            {
              m_namapemohon = rdr.GetString(rdr.GetOrdinal("namapemohon"));
            }
            else
            {
              m_namapemohon = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggal"))) 
            {
              m_tanggal = rdr.GetDateTime(rdr.GetOrdinal("tanggal"));
            }
            else
            {
              m_tanggal = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tempat"))) 
            {
              m_tempat = rdr.GetString(rdr.GetOrdinal("tempat"));
            }
            else
            {
              m_tempat = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("photo"))) 
            {
              m_photo = rdr.GetString(rdr.GetOrdinal("photo"));
            }
            else
            {
              m_photo = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("captcha"))) 
            {
              m_captcha = rdr.GetString(rdr.GetOrdinal("captcha"));
            }
            else
            {
              m_captcha = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tahun"))) 
            {
              m_tahun = rdr.GetString(rdr.GetOrdinal("tahun"));
            }
            else
            {
              m_tahun = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("statustempattinggal"))) 
            {
              m_statustempattinggal = rdr.GetString(rdr.GetOrdinal("statustempattinggal"));
            }
            else
            {
              m_statustempattinggal = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("statustempattinggal_lainnya"))) 
            {
              m_statustempattinggal_lainnya = rdr.GetString(rdr.GetOrdinal("statustempattinggal_lainnya"));
            }
            else
            {
              m_statustempattinggal_lainnya = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("programstudiid"))) 
            {
              m_programstudiid = rdr.GetString(rdr.GetOrdinal("programstudiid"));
            }
            else
            {
              m_programstudiid = "";
            };
            m_ip1 = rdr.GetDecimal(rdr.GetOrdinal("ip1"));
            m_ip2 = rdr.GetDecimal(rdr.GetOrdinal("ip2"));
            m_ip3 = rdr.GetDecimal(rdr.GetOrdinal("ip3"));
            m_ip4 = rdr.GetDecimal(rdr.GetOrdinal("ip4"));
            m_ip5 = rdr.GetDecimal(rdr.GetOrdinal("ip5"));
            m_ip6 = rdr.GetDecimal(rdr.GetOrdinal("ip6"));
            m_ipk = rdr.GetDecimal(rdr.GetOrdinal("ipk"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("sp"))) 
            {
              m_sp = rdr.GetString(rdr.GetOrdinal("sp"));
            }
            else
            {
              m_sp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dosenwaliid"))) 
            {
              m_dosenwaliid = rdr.GetString(rdr.GetOrdinal("dosenwaliid"));
            }
            else
            {
              m_dosenwaliid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("statusortu"))) 
            {
              m_statusortu = rdr.GetString(rdr.GetOrdinal("statusortu"));
            }
            else
            {
              m_statusortu = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("namaortu"))) 
            {
              m_namaortu = rdr.GetString(rdr.GetOrdinal("namaortu"));
            }
            else
            {
              m_namaortu = "";
            };
            m_jmlanak = rdr.GetDecimal(rdr.GetOrdinal("jmlanak"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("jmltanggungan"))) 
            {
              m_jmltanggungan = rdr.GetString(rdr.GetOrdinal("jmltanggungan"));
            }
            else
            {
              m_jmltanggungan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pekerjaanortu"))) 
            {
              m_pekerjaanortu = rdr.GetString(rdr.GetOrdinal("pekerjaanortu"));
            }
            else
            {
              m_pekerjaanortu = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("alamatortu"))) 
            {
              m_alamatortu = rdr.GetString(rdr.GetOrdinal("alamatortu"));
            }
            else
            {
              m_alamatortu = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pendapatan_perbulan"))) 
            {
              m_pendapatan_perbulan = rdr.GetString(rdr.GetOrdinal("pendapatan_perbulan"));
            }
            else
            {
              m_pendapatan_perbulan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jenisbeasiswa"))) 
            {
              m_jenisbeasiswa = rdr.GetString(rdr.GetOrdinal("jenisbeasiswa"));
            }
            else
            {
              m_jenisbeasiswa = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("semester"))) 
            {
              m_semester = rdr.GetString(rdr.GetOrdinal("semester"));
            }
            else
            {
              m_semester = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jadwalpengajuanid"))) 
            {
              m_jadwalpengajuanid = rdr.GetString(rdr.GetOrdinal("jadwalpengajuanid"));
            }
            else
            {
              m_jadwalpengajuanid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("status"))) 
            {
              m_status = rdr.GetString(rdr.GetOrdinal("status"));
            }
            else
            {
              m_status = "";
            };

            if (!rdr.IsDBNull(rdr.GetOrdinal("surat_tidak_mampu")))
            {
                m_surat_tidak_mampu = rdr.GetString(rdr.GetOrdinal("surat_tidak_mampu"));
            }
            else
            {
                m_surat_tidak_mampu = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("sertifikat2")))
            {
                m_sertifikat2 = rdr.GetString(rdr.GetOrdinal("sertifikat2"));
            }
            else
            {
                m_sertifikat2 = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("bukti_pembayaran_kuliah")))
            {
                m_bukti_pembayaran_kuliah = rdr.GetString(rdr.GetOrdinal("bukti_pembayaran_kuliah"));
            }
            else
            {
                m_bukti_pembayaran_kuliah = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("ktm_ktp")))
            {
                m_ktm_ktp = rdr.GetString(rdr.GetOrdinal("ktm_ktp"));
            }
            else
            {
                m_ktm_ktp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("buku_rek")))
            {
                m_buku_rek = rdr.GetString(rdr.GetOrdinal("buku_rek"));
            }
            else
            {
                m_buku_rek = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbb_pengajuanbeasiswa");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbb_pengajuanbeasiswa");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbb_pengajuanbeasiswa";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbb_pengajuanbeasiswa");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbb_pengajuanbeasiswa");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbb_pengajuanbeasiswa_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
