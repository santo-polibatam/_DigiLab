﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbm_pengadaandetails
    {
        private String m_pengadaandetailsid;
        private String m_pengadaanid;
        private String m_nopo;
        private String m_judul;
        private String m_pengarang;
        private String m_edisi;
        private String m_penerbit;
        private String m_tempatterbit;
        private String m_tahunterbit;
        private String m_isbn;
        private String m_supplemen;
        private String m_pengusul;
        private decimal m_jumlah;
        private String m_status;
        private decimal m_harga;
        private decimal m_nourut;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pengadaandetailsid
        {
            get { return m_pengadaandetailsid; }
            set { m_pengadaandetailsid = value; }
        }
        public String pengadaanid
        {
            get { return m_pengadaanid; }
            set { m_pengadaanid = value; }
        }
        public String nopo
        {
            get { return m_nopo; }
            set { m_nopo = value; }
        }
        public String judul
        {
            get { return m_judul; }
            set { m_judul = value; }
        }
        public String pengarang
        {
            get { return m_pengarang; }
            set { m_pengarang = value; }
        }
        public String edisi
        {
            get { return m_edisi; }
            set { m_edisi = value; }
        }
        public String penerbit
        {
            get { return m_penerbit; }
            set { m_penerbit = value; }
        }
        public String tempatterbit
        {
            get { return m_tempatterbit; }
            set { m_tempatterbit = value; }
        }
        public String tahunterbit
        {
            get { return m_tahunterbit; }
            set { m_tahunterbit = value; }
        }
        public String isbn
        {
            get { return m_isbn; }
            set { m_isbn = value; }
        }
        public String supplemen
        {
            get { return m_supplemen; }
            set { m_supplemen = value; }
        }
        public String pengusul
        {
            get { return m_pengusul; }
            set { m_pengusul = value; }
        }
        public decimal jumlah
        {
            get { return m_jumlah; }
            set { m_jumlah = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }
        public decimal harga
        {
            get { return m_harga; }
            set { m_harga = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_pengadaandetails(pengadaandetailsid,pengadaanid,nopo,judul,pengarang,edisi,penerbit,tempatterbit,tahunterbit,isbn,supplemen,pengusul,jumlah,status,harga,nourut,opadd,pcadd,luadd,opedit,pcedit,luedit,dlt)"+
                            "VALUES"+
                            "(@pengadaandetailsid,@pengadaanid,@nopo,@judul,@pengarang,@edisi,@penerbit,@tempatterbit,@tahunterbit,@isbn,@supplemen,@pengusul,@jumlah,@status,@harga,@nourut,@opadd,@pcadd,now(),@opedit,@pcedit,@luedit,'0')";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengadaandetailsid != null )
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengadaanid != null )
            {
               cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaanid;
            }
            else
            {
               cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nopo != null )
            {
               cmd.Parameters.Add("@nopo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nopo;
            }
            else
            {
               cmd.Parameters.Add("@nopo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (judul != null )
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judul;
            }
            else
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengarang != null )
            {
               cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengarang;
            }
            else
            {
               cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (edisi != null )
            {
               cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = edisi;
            }
            else
            {
               cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (penerbit != null )
            {
               cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = penerbit;
            }
            else
            {
               cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tempatterbit != null )
            {
               cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatterbit;
            }
            else
            {
               cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahunterbit != null )
            {
               cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunterbit;
            }
            else
            {
               cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (isbn != null )
            {
               cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = isbn;
            }
            else
            {
               cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (supplemen != null )
            {
               cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = supplemen;
            }
            else
            {
               cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengusul != null )
            {
               cmd.Parameters.Add("@pengusul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengusul;
            }
            else
            {
               cmd.Parameters.Add("@pengusul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jumlah", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlah;
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@harga", NpgsqlTypes.NpgsqlDbType.Numeric).Value = harga;
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_pengadaandetails SET "+
                            " pengadaandetailsid=@pengadaandetailsid,pengadaanid=@pengadaanid,nopo=@nopo,judul=@judul,pengarang=@pengarang,edisi=@edisi,penerbit=@penerbit,tempatterbit=@tempatterbit,tahunterbit=@tahunterbit,isbn=@isbn,supplemen=@supplemen,pengusul=@pengusul,jumlah=@jumlah,status=@status,harga=@harga,nourut=@nourut,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt='0'"+
                            " WHERE pengadaandetailsid=@pengadaandetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengadaandetailsid != null )
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengadaanid != null )
            {
               cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaanid;
            }
            else
            {
               cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nopo != null )
            {
               cmd.Parameters.Add("@nopo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nopo;
            }
            else
            {
               cmd.Parameters.Add("@nopo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (judul != null )
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judul;
            }
            else
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengarang != null )
            {
               cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengarang;
            }
            else
            {
               cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (edisi != null )
            {
               cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = edisi;
            }
            else
            {
               cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (penerbit != null )
            {
               cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = penerbit;
            }
            else
            {
               cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tempatterbit != null )
            {
               cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatterbit;
            }
            else
            {
               cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahunterbit != null )
            {
               cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunterbit;
            }
            else
            {
               cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (isbn != null )
            {
               cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = isbn;
            }
            else
            {
               cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (supplemen != null )
            {
               cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = supplemen;
            }
            else
            {
               cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengusul != null )
            {
               cmd.Parameters.Add("@pengusul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengusul;
            }
            else
            {
               cmd.Parameters.Add("@pengusul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jumlah", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlah;
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@harga", NpgsqlTypes.NpgsqlDbType.Numeric).Value = harga;
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbm_pengadaandetails WHERE pengadaandetailsid=@pengadaandetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaandetailsid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbm_pengadaandetails SET DLT='1', opedit=@opedit,pcedit=@pcedit,luedit=now() WHERE pengadaandetailsid=@pengadaandetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaandetailsid;
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbm_pengadaandetails WHERE pengadaandetailsid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengadaandetailsid"))) 
            {
              m_pengadaandetailsid = rdr.GetString(rdr.GetOrdinal("pengadaandetailsid"));
            }
            else
            {
              m_pengadaandetailsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengadaanid"))) 
            {
              m_pengadaanid = rdr.GetString(rdr.GetOrdinal("pengadaanid"));
            }
            else
            {
              m_pengadaanid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nopo"))) 
            {
              m_nopo = rdr.GetString(rdr.GetOrdinal("nopo"));
            }
            else
            {
              m_nopo = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("judul"))) 
            {
              m_judul = rdr.GetString(rdr.GetOrdinal("judul"));
            }
            else
            {
              m_judul = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengarang"))) 
            {
              m_pengarang = rdr.GetString(rdr.GetOrdinal("pengarang"));
            }
            else
            {
              m_pengarang = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("edisi"))) 
            {
              m_edisi = rdr.GetString(rdr.GetOrdinal("edisi"));
            }
            else
            {
              m_edisi = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("penerbit"))) 
            {
              m_penerbit = rdr.GetString(rdr.GetOrdinal("penerbit"));
            }
            else
            {
              m_penerbit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tempatterbit"))) 
            {
              m_tempatterbit = rdr.GetString(rdr.GetOrdinal("tempatterbit"));
            }
            else
            {
              m_tempatterbit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tahunterbit"))) 
            {
              m_tahunterbit = rdr.GetString(rdr.GetOrdinal("tahunterbit"));
            }
            else
            {
              m_tahunterbit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("isbn"))) 
            {
              m_isbn = rdr.GetString(rdr.GetOrdinal("isbn"));
            }
            else
            {
              m_isbn = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("supplemen"))) 
            {
              m_supplemen = rdr.GetString(rdr.GetOrdinal("supplemen"));
            }
            else
            {
              m_supplemen = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengusul"))) 
            {
              m_pengusul = rdr.GetString(rdr.GetOrdinal("pengusul"));
            }
            else
            {
              m_pengusul = "";
            };
            m_jumlah = rdr.GetDecimal(rdr.GetOrdinal("jumlah"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("status"))) 
            {
              m_status = rdr.GetString(rdr.GetOrdinal("status"));
            }
            else
            {
              m_status = "";
            };
            m_harga = rdr.GetDecimal(rdr.GetOrdinal("harga"));
            m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("opadd"))) 
            {
              m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
            }
            else
            {
              m_opadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd"))) 
            {
              m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
            }
            else
            {
              m_pcadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luadd"))) 
            {
              m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
            }
            else
            {
              m_luadd = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opedit"))) 
            {
              m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
            }
            else
            {
              m_opedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit"))) 
            {
              m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
            }
            else
            {
              m_pcedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luedit"))) 
            {
              m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
            }
            else
            {
              m_luedit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_pengadaandetails");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_pengadaandetails");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbm_pengadaandetails";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_pengadaandetails");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_pengadaandetails");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbm_pengadaandetails_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
