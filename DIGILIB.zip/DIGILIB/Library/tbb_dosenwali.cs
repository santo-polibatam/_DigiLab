﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbb_dosenwali
    {
        private String m_dosenwaliid;
        private String m_nik;
        private String m_nama;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_prodiid;
        private String m_username;
        private String m__password;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String dosenwaliid
        {
            get { return m_dosenwaliid; }
            set { m_dosenwaliid = value; }
        }
        public String nik
        {
            get { return m_nik; }
            set { m_nik = value; }
        }
        public String nama
        {
            get { return m_nama; }
            set { m_nama = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String username
        {
            get { return m_username; }
            set { m_username = value; }
        }
        public String _password
        {
            get { return m__password; }
            set { m__password = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbb_dosenwali(dosenwaliid,nik,nama,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt,prodiid,username,_password)" +
                            "VALUES" +
                            "(@dosenwaliid,@nik,@nama,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0',@prodiid,@username," +
                            "convert_from(encrypt((@_password)::bytea, '1234', 'aes'),'SQL_ASCII'))";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (dosenwaliid != null )
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nik != null )
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nik;
            }
            else
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nama != null )
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nama;
            }
            else
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (username != null )
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = username;
            }
            else
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (_password != null )
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = _password;
            }
            else
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbb_dosenwali SET " +
                            " dosenwaliid=@dosenwaliid,nik=@nik,nama=@nama,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0',prodiid=@prodiid,username=@username," +
                            "_password=(convert_from(encrypt((@_password)::bytea, '1234', 'aes'),'SQL_ASCII'))" +
                            " WHERE dosenwaliid=@dosenwaliid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (dosenwaliid != null )
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nik != null )
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nik;
            }
            else
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nama != null )
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nama;
            }
            else
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (username != null )
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = username;
            }
            else
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (_password != null )
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = _password;
            }
            else
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbb_dosenwali WHERE dosenwaliid=@dosenwaliid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbb_dosenwali SET DLT='1',op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now() WHERE dosenwaliid=@dosenwaliid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbb_dosenwali WHERE dosenwaliid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("dosenwaliid"))) 
            {
              m_dosenwaliid = rdr.GetString(rdr.GetOrdinal("dosenwaliid"));
            }
            else
            {
              m_dosenwaliid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nik"))) 
            {
              m_nik = rdr.GetString(rdr.GetOrdinal("nik"));
            }
            else
            {
              m_nik = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nama"))) 
            {
              m_nama = rdr.GetString(rdr.GetOrdinal("nama"));
            }
            else
            {
              m_nama = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid"))) 
            {
              m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
            }
            else
            {
              m_prodiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("username"))) 
            {
              m_username = rdr.GetString(rdr.GetOrdinal("username"));
            }
            else
            {
              m_username = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("_password"))) 
            {
              m__password = rdr.GetString(rdr.GetOrdinal("_password"));
            }
            else
            {
              m__password = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbb_dosenwali");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbb_dosenwali");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbb_dosenwali";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbb_dosenwali");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbb_dosenwali");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbb_dosenwali_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
