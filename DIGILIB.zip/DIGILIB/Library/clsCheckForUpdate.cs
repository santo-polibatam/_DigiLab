﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Xml;
using System.IO;
using Npgsql;
using System.Data;
using Microsoft.Win32;
using System.Diagnostics;
using System.ComponentModel;
using System.Reflection;

namespace Library
{
    public class clsCheckForUpdate
    {
        #region "Declaration"

        private System.ComponentModel.BackgroundWorker bgwCheckUpdate = new System.ComponentModel.BackgroundWorker();
        private string m_Sender;
        private clsConnection oConnection = new clsConnection();
        private NpgsqlDataReader dr;

        public Int32 iThreadStatus;
        private string m_RemoteURI, m_ManifestFile;
        private string m_ApplicationInstance;
        private Int32 m_TotalUpdatedFile;
        private string m_AppStartupPath = Environment.CurrentDirectory.ToString();

        #endregion

        #region "Property"
        public string AppStartupPath
        {
            get { return m_AppStartupPath; }
            set { m_AppStartupPath = value; }
        }
        public string ApplicationInstance
        {
            get { return m_ApplicationInstance; }
            set { m_ApplicationInstance = value; }
        }
        public string RemoteURI
        {
            get { return m_RemoteURI; }
            set { m_RemoteURI = value; }
        }

        public string ManifestFile
        {
            get { return m_ManifestFile; }
            set { m_ManifestFile = value; }
        }
        
        #endregion

        public clsCheckForUpdate()
        {
            InitializeComponent();

            InitializeBackgoundWorker();
        }
        private void InitializeComponent()
        {
            this.bgwCheckUpdate = new BackgroundWorker();
        }
        private void InitializeBackgoundWorker()
        {
            bgwCheckUpdate.DoWork += new DoWorkEventHandler(bgwCheckUpdate_DoWork);
            bgwCheckUpdate.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bgwCheckUpdate_RunWorkerCompleted);
        }

        public void StartCheckUpdate()
        {
            if (!bgwCheckUpdate.IsBusy)
            {
                bgwCheckUpdate.WorkerReportsProgress = true;
                bgwCheckUpdate.RunWorkerAsync();
            }
        }

        private void bgwCheckUpdate_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            bgwCheckUpdate.Dispose();
            onUpdate(bIsNeedUpdate);
        }

        public void bgwCheckUpdate_DoWork(object sender, DoWorkEventArgs e)
        {
            //clsemaillog oemaillog = new clsemaillog();

            try
            {
                if (IsConnect(RemoteURI))
                    IsNeedUpdate();

            }
            catch (Exception ex)
            {
                clsTextGenerator oTextGenerator = new clsTextGenerator();

                string sMessage = ("======================================================================================\n" +
                         "Error occured at //" + ex.Source + "// on " + DateTime.Now.ToString() + " - " + DateTime.Now.ToString() + ":\n" +
                         ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                         "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");
                oTextGenerator.AppendTLog(sMessage);

            }
            finally
            {

            }
        }

        private double getVersion(string sVersion)
        {
            if (sVersion == "") sVersion = "0.0.0.0";
            double intResult = 0;
            try
            {
                string[] arrString = sVersion.Split('.');
                string strResult = String.Format("{0:00000}{1:00000}{2:00000}{3:00000}", Convert.ToInt32(arrString[0]), Convert.ToInt32(arrString[1]), Convert.ToInt32(arrString[2]), Convert.ToInt32(arrString[3]));
                intResult = Convert.ToDouble(strResult);
            }
            catch { }
            return intResult;
        }

        public void RetrieveConfiguration()
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = "select remoteuri, manifestfile, applicationinstance, remoteuri_user from tserverinfo";
            dr = oConnection.ReadData(cmd);
            dr.Read();

            if (clsGlobal.strUserName.ToLower() == "superadmin")
            {
                RemoteURI = dr["remoteuri"].ToString();
            }
            else
            {
                RemoteURI = dr["remoteuri_user"].ToString();
            }
            
            ManifestFile = dr["manifestfile"].ToString();
            if (ApplicationInstance == null || ApplicationInstance == "")
            {
                ApplicationInstance = dr["applicationinstance"].ToString();
            }
            oConnection.Close();

        }

        public bool IsConnect(string sRemoteURI)
        {
            WebRequest oRequest = null;
            try
            {

                //'===========================================================
                //'CHECK the URI path :D
                oRequest = WebRequest.Create(sRemoteURI);
                oRequest.Method = WebRequestMethods.Http.Head;
                oRequest.Timeout = 20000;
                oRequest.GetResponse();
                //===========================================================
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                //'updated 16June09
                if (oRequest != null)
                {
                    oRequest.Abort();
                }
            }


        }

        bool bIsNeedUpdate = false;
        private bool IsNeedUpdate()
        {
            //'-note : only for 4 level directory
            //'for more level please customize

            WebClient oWebClient = new WebClient();
            string sOutput = "";

            try
            {
                //' Download manifest file
                //' get { the update file content in manifest file
                oWebClient.DownloadFile(RemoteURI + ManifestFile, m_AppStartupPath + ManifestFile);

                XmlDocument m_xmld;
                XmlNodeList m_nodelist;
                XmlNodeList m_nodelist2;
                XmlNodeList m_nodelist3;
                XmlNodeList m_nodelist4;

                //XmlNode m_node;
                //XmlNode m_node2;
                //XmlNode m_node3;
                //XmlNode m_node4;

                //'Create the XML Document
                m_xmld = new XmlDocument();
                //'Load the Xml file
                m_xmld.Load(m_AppStartupPath + ManifestFile);

                //'get { the list of name nodes 
                m_nodelist = m_xmld.SelectNodes("/update/name");
                int iLoop = 0;

                //'Loop through the nodes

                string sFileAttribute = "";
                string sFileAttribute2 = "";
                string sFileAttribute3 = "";
                string sFileAttribute4 = "";

                string sDir = "";
                string sDir2 = "";
                string sDir3 = "";
                string sDir4 = "";

                //'get { the isdir Element Value
                string bIsDir = "";
                //'get { the fileName Element Value
                string sFileNameValue = "";

                //'get { the fileVersion Element Value
                string sFileVersionValue = "";
                // 'get { the fileLastModified Value
                string sFileLastModiValue = "";

                //'Temp file name
                string sTempFileName = "";
                bool bIsToUpgrade = false;
                string sRealFileName = "";
                DateTime dtLastModified;
                DateTime dateOut;
                bool bIsFileExists = false;

                foreach (XmlNode m_node in m_nodelist)
                {

                    // 'get { the file Attribute Value
                    sFileAttribute = m_node.Attributes.GetNamedItem("file").Value;

                    if (sFileAttribute.ToLower() != ApplicationInstance.ToLower())
                        continue;


                    //'get { the isdir Element Value
                    bIsDir = m_node.ChildNodes.Item(3).InnerText;

                    if (bIsDir.ToLower() == "true")
                    {
                        m_nodelist2 = m_xmld.SelectNodes("/update/name/name");
                        sDir2 = sFileAttribute;
                        foreach (XmlNode m_node2 in m_nodelist2)
                        {
                            if (m_node2.ParentNode.Attributes.GetNamedItem("file").Value == sDir2)
                            {
                                sFileAttribute2 = m_node2.Attributes.GetNamedItem("file").Value;
                                bIsDir = m_node2.ChildNodes.Item(3).InnerText;
                                if (bIsDir.ToLower() == "true")
                                {
                                    sDir3 = sFileAttribute2;
                                    m_nodelist3 = m_xmld.SelectNodes("/update/name/name/name");

                                    foreach (XmlNode m_node3 in m_nodelist3)
                                    {

                                        if (m_node3.ParentNode.Attributes.GetNamedItem("file").Value == sDir3)
                                        {
                                            sFileAttribute3 = m_node3.Attributes.GetNamedItem("file").Value;
                                            bIsDir = m_node3.ChildNodes.Item(3).InnerText;
                                            if (bIsDir.ToLower() == "true")
                                            {
                                                sDir4 = sFileAttribute3;
                                                m_nodelist4 = m_xmld.SelectNodes("/update/name/name/name/name");

                                                foreach (XmlNode m_node4 in m_nodelist4)

                                                    if (m_node4.ParentNode.Attributes.GetNamedItem("file").Value == sDir4)
                                                    {
                                                        sFileAttribute4 = m_node4.Attributes.GetNamedItem("file").Value;
                                                        bIsDir = m_node4.ChildNodes.Item(3).InnerText;
                                                        if ((bIsDir).ToLower() == "true")
                                                        {
                                                            //''sDir5 = sFileAttribute4
                                                        }
                                                        else
                                                        {
                                                            //'get { the fileName Element Value
                                                            sFileNameValue = m_node4.ChildNodes.Item(0).InnerText;
                                                            //'get { the fileVersion Element Value
                                                            sFileVersionValue = m_node4.ChildNodes.Item(1).InnerText;
                                                            //'get { the fileLastModified Value
                                                            sFileLastModiValue = m_node4.ChildNodes.Item(2).InnerText;

                                                            sRealFileName = m_AppStartupPath + sDir2 + "\\" + sDir3 + "\\" + sDir4 + "\\" + sFileNameValue;
                                                            dtLastModified = Convert.ToDateTime(sFileLastModiValue);

                                                            //'Download upgrade file
                                                            if (isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput))
                                                            {
                                                                iLoop += 1;
                                                                bIsNeedUpdate = true;
                                                                return bIsNeedUpdate;
                                                            }

                                                        }
                                                    }
                                            }

                                            else
                                            {
                                                //'get { the fileName Element Value
                                                sFileNameValue = m_node3.ChildNodes.Item(0).InnerText;
                                                //'get { the fileVersion Element Value
                                                sFileVersionValue = m_node3.ChildNodes.Item(1).InnerText;
                                                //'get { the fileLastModified Value
                                                sFileLastModiValue = m_node3.ChildNodes.Item(2).InnerText;

                                                sRealFileName = m_AppStartupPath + sDir2 + "\\" + sDir3 + "\\" + sFileNameValue;
                                                dtLastModified = Convert.ToDateTime(sFileLastModiValue);

                                                //'Download upgrade file
                                                if (isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput))
                                                {
                                                    iLoop += 1;
                                                    bIsNeedUpdate = true;
                                                    return bIsNeedUpdate;
                                                }
                                            }

                                        }
                                    }
                                }
                                else
                                {
                                    //'get { the fileName Element Value
                                    sFileNameValue = m_node2.ChildNodes.Item(0).InnerText;
                                    //'get { the fileVersion Element Value
                                    sFileVersionValue = m_node2.ChildNodes.Item(1).InnerText;
                                    //'get { the fileLastModified Value
                                    sFileLastModiValue = m_node2.ChildNodes.Item(2).InnerText;

                                    //'Temp file name
                                    sTempFileName = m_AppStartupPath + sDir2 + "\\" + DateTime.Now.TimeOfDay.TotalMilliseconds;
                                    bIsToUpgrade = false;
                                    sRealFileName = m_AppStartupPath + sDir2 + "\\" + sFileNameValue;
                                    dtLastModified = Convert.ToDateTime(sFileLastModiValue);

                                    if (isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput))
                                    {
                                        iLoop += 1;
                                        bIsNeedUpdate = true;
                                        return bIsNeedUpdate;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        //'get { the fileName Element Value
                        sFileNameValue = m_node.ChildNodes.Item(0).InnerText;
                        //'get { the fileVersion Element Value
                        sFileVersionValue = m_node.ChildNodes.Item(1).InnerText;
                        //'get { the fileLastModified Value
                        sFileLastModiValue = m_node.ChildNodes.Item(2).InnerText;

                        //'Temp file name
                        sTempFileName = m_AppStartupPath + DateTime.Now.TimeOfDay.TotalMilliseconds;
                        bIsToUpgrade = false;
                        sRealFileName = m_AppStartupPath + sFileNameValue;
                        if (DateTime.TryParse(sFileLastModiValue, out dateOut))
                            dtLastModified = dateOut;// Convert.ToDateTime(sFileLastModiValue);
                        else
                            dtLastModified = DateTime.MinValue;

                        if (isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput))
                        {
                            iLoop += 1;
                            bIsNeedUpdate = true;
                            return bIsNeedUpdate;
                        }
                    }
                }


                if (bIsNeedUpdate)
                {
                    m_TotalUpdatedFile = iLoop;
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (Exception ex)
            {
                throw (new Exception("======================================================================================\n" +
                      "Error occured at '" + ex.Source + "' on " + DateTime.Now.ToShortDateString() + " - " + DateTime.Now.ToLongTimeString() + ": \n" +
                     ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                     "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================"));
            }
            finally
            {

                if (File.Exists(m_AppStartupPath + ManifestFile))
                {
                    File.Delete(m_AppStartupPath + ManifestFile);
                }

                if (oWebClient != null)
                {
                    oWebClient.Dispose();
                }

            }
        }


        private bool isFileUpdated(string sRealFileName, DateTime dtLastModified, string sFileVersionValue, string sFileNameValue, string sOutput)
        {
            bool bIsToUpgrade = false;
            bool bIsFileExists = false;
            string sfileversion=""; 
            //'If file not exist then download file
            bIsFileExists = File.Exists(sRealFileName);
            if (!bIsFileExists)
                bIsToUpgrade = true;
            else if (sFileVersionValue != "" && sFileVersionValue != "0.0.0.0")
            {
                //'verify the file version'
                if (!sFileNameValue.ToLower().Contains("setup"))
                {
                    sfileversion = getAssemblyInfo(sRealFileName);
                    if (sfileversion == "")
                        sfileversion = getVersionInfo(sRealFileName);
 
                    bIsToUpgrade = (getVersion(sFileVersionValue) > getVersion(sfileversion));
                }
                else
                {
                    bIsToUpgrade = false;
                }
                //'check if version not upgrade then check last modified
                //if (!bIsToUpgrade)
                //    bIsToUpgrade = (dtLastModified > File.GetLastWriteTimeUtc(sRealFileName));

                if (bIsToUpgrade)
                    return bIsToUpgrade;

            }
            else
            {
                //'check last modified file
                DateTime dtLastMdf = File.GetLastWriteTimeUtc(sRealFileName);
                int result = DateTime.Compare(dtLastModified, dtLastMdf);
                if (result > 0)
                    bIsToUpgrade = true;//(dtLastModified > File.GetLastWriteTimeUtc(sRealFileName));
                else
                    bIsToUpgrade = false;
            }
            //if (bIsToUpgrade)
            //{

            //    if (!bIsFileExists)
            //    {
            //        sOutput += "Filename: " + sFileNameValue + " - " +
            //         "(Missing File) - V " + sFileVersionValue + " (New)";
            //    }
            //    else
            //    {
            //        try
            //        {
            //            fvInfo = FileVersionInfo.GetVersionInfo(sRealFileName);
            //            if (fvInfo != null)
            //            {

            //                string sNewVersion = fvInfo.FileMajorPart + "." + fvInfo.FileMinorPart + "." + fvInfo.FileBuildPart + "." + fvInfo.FilePrivatePart;
            //                sOutput += "Filename: " + sFileNameValue + " - V " +
            //                sNewVersion +
            //                " (Old) - V " + sFileVersionValue + " (New)";

            //            }
            //        }
            //        catch { }
            //    }
            //}
            return bIsToUpgrade;

        }

        private string getVersionInfo(string assemblyFile)
        {
            string strVersion = "";
            try
            {
                AssemblyName asbInfo = AssemblyName.GetAssemblyName(assemblyFile);

                strVersion = asbInfo.Version.Major + "." + asbInfo.Version.MajorRevision + "." + asbInfo.Version.Minor + "." + asbInfo.Version.MinorRevision;
            }
            catch
            {
                strVersion = "";
            }
            return strVersion;
        }

        private string getAssemblyInfo(string fileName)
        {
            string strVersion = "";
            try
            {
                FileVersionInfo fvInfo = FileVersionInfo.GetVersionInfo(fileName);
                strVersion = fvInfo.FileMajorPart + "." + fvInfo.FileMinorPart + "." + fvInfo.FileBuildPart + "." + fvInfo.FilePrivatePart;

            }
            catch
            {
                strVersion = "";
            }
            return strVersion;
        }

        public delegate void checkUpdateApp(object sender, bool msg);
        public event checkUpdateApp checkUpdateEventMsg;

        protected void onUpdate(bool msg)
        {
            if (msg != null)
            {
                checkUpdateEventMsg(this, msg);

                //System.Windows.Forms.Control target = checkUpdateEventMsg.Target as System.Windows.Forms.Control;
                //if (target != null && target.InvokeRequired)
                //{
                //    object[] args = new object[] { msg };
                //    target.Invoke(checkUpdateEventMsg);
                //}
                //else
                //{
                //    checkUpdateEventMsg( msg);
                //}
            }
        }
    }

}