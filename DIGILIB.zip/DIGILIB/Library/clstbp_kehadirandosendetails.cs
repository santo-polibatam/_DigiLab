﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstbp_kehadirandosendetails
    {
        private String m_kehadirandosendetailsid;
        private String m_kehadirandosenid;
        private String m_dosenid;
        private String m_matapelajaranid;
        private decimal m_jumlahmahasiswa;
        private String m_kelas;
        private decimal m_jumlahsesi1;
        private decimal m_jumlahsesi2;
        private decimal m_jumlahsesi3;
        private decimal m_jumlahsesi4;
        private decimal m_jumlahsesi5;
        private String m_remarks;
        private decimal m_nourut;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private decimal m_tarif;
        private decimal m_tarif_pajak;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String kehadirandosendetailsid
        {
            get { return m_kehadirandosendetailsid; }
            set { m_kehadirandosendetailsid = value; }
        }
        public String kehadirandosenid
        {
            get { return m_kehadirandosenid; }
            set { m_kehadirandosenid = value; }
        }
        public String dosenid
        {
            get { return m_dosenid; }
            set { m_dosenid = value; }
        }
        public String matapelajaranid
        {
            get { return m_matapelajaranid; }
            set { m_matapelajaranid = value; }
        }
        public decimal jumlahmahasiswa
        {
            get { return m_jumlahmahasiswa; }
            set { m_jumlahmahasiswa = value; }
        }
        public String kelas
        {
            get { return m_kelas; }
            set { m_kelas = value; }
        }
        public decimal jumlahsesi1
        {
            get { return m_jumlahsesi1; }
            set { m_jumlahsesi1 = value; }
        }
        public decimal jumlahsesi2
        {
            get { return m_jumlahsesi2; }
            set { m_jumlahsesi2 = value; }
        }
        public decimal jumlahsesi3
        {
            get { return m_jumlahsesi3; }
            set { m_jumlahsesi3 = value; }
        }
        public decimal jumlahsesi4
        {
            get { return m_jumlahsesi4; }
            set { m_jumlahsesi4 = value; }
        }
        public decimal jumlahsesi5
        {
            get { return m_jumlahsesi5; }
            set { m_jumlahsesi5 = value; }
        }
        public String remarks
        {
            get { return m_remarks; }
            set { m_remarks = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public decimal tarif
        {
            get { return m_tarif; }
            set { m_tarif = value; }
        }
        public decimal tarif_pajak
        {
            get { return m_tarif_pajak; }
            set { m_tarif_pajak = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_kehadirandosendetails(kehadirandosendetailsid,kehadirandosenid,dosenid,matapelajaranid,jumlahmahasiswa,kelas,jumlahsesi1,jumlahsesi2,jumlahsesi3,jumlahsesi4,jumlahsesi5,remarks,nourut,op_add,pc_add,lu_add,dlt,tarif,tarif_pajak)" +
                            "VALUES" +
                            "(@kehadirandosendetailsid,@kehadirandosenid,@dosenid,@matapelajaranid,@jumlahmahasiswa,@kelas,@jumlahsesi1,@jumlahsesi2,@jumlahsesi3,@jumlahsesi4,@jumlahsesi5,@remarks,@nourut,@op_add,@pc_add,now(),@dlt,@tarif,@tarif_pajak)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (kehadirandosendetailsid != null)
            {
                cmd.Parameters.Add("@kehadirandosendetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kehadirandosendetailsid;
            }
            else
            {
                cmd.Parameters.Add("@kehadirandosendetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kehadirandosenid != null)
            {
                cmd.Parameters.Add("@kehadirandosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kehadirandosenid;
            }
            else
            {
                cmd.Parameters.Add("@kehadirandosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenid != null)
            {
                cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenid;
            }
            else
            {
                cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (matapelajaranid != null)
            {
                cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = matapelajaranid;
            }
            else
            {
                cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@jumlahmahasiswa", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahmahasiswa;
            if (kelas != null)
            {
                cmd.Parameters.Add("@kelas", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kelas;
            }
            else
            {
                cmd.Parameters.Add("@kelas", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@jumlahsesi1", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi1;
            cmd.Parameters.Add("@jumlahsesi2", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi2;
            cmd.Parameters.Add("@jumlahsesi3", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi3;
            cmd.Parameters.Add("@jumlahsesi4", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi4;
            cmd.Parameters.Add("@jumlahsesi5", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi5;
            if (remarks != null)
            {
                cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
                cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null)
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null)
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.Parameters.Add("@tarif", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif;
            cmd.Parameters.Add("@tarif_pajak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pajak;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_kehadirandosendetails SET " +
                            " kehadirandosendetailsid=@kehadirandosendetailsid,kehadirandosenid=@kehadirandosenid,dosenid=@dosenid,matapelajaranid=@matapelajaranid,jumlahmahasiswa=@jumlahmahasiswa,kelas=@kelas,jumlahsesi1=@jumlahsesi1,jumlahsesi2=@jumlahsesi2,jumlahsesi3=@jumlahsesi3,jumlahsesi4=@jumlahsesi4,jumlahsesi5=@jumlahsesi5,remarks=@remarks,nourut=@nourut,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt=@dlt,tarif=@tarif,tarif_pajak=@tarif_pajak" +
                            " WHERE kehadirandosendetailsid=@kehadirandosendetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (kehadirandosendetailsid != null)
            {
                cmd.Parameters.Add("@kehadirandosendetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kehadirandosendetailsid;
            }
            else
            {
                cmd.Parameters.Add("@kehadirandosendetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kehadirandosenid != null)
            {
                cmd.Parameters.Add("@kehadirandosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kehadirandosenid;
            }
            else
            {
                cmd.Parameters.Add("@kehadirandosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenid != null)
            {
                cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenid;
            }
            else
            {
                cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (matapelajaranid != null)
            {
                cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = matapelajaranid;
            }
            else
            {
                cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@jumlahmahasiswa", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahmahasiswa;
            if (kelas != null)
            {
                cmd.Parameters.Add("@kelas", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kelas;
            }
            else
            {
                cmd.Parameters.Add("@kelas", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@jumlahsesi1", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi1;
            cmd.Parameters.Add("@jumlahsesi2", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi2;
            cmd.Parameters.Add("@jumlahsesi3", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi3;
            cmd.Parameters.Add("@jumlahsesi4", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi4;
            cmd.Parameters.Add("@jumlahsesi5", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahsesi5;
            if (remarks != null)
            {
                cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
                cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null)
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null)
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.Parameters.Add("@tarif", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif;
            cmd.Parameters.Add("@tarif_pajak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pajak;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tbp_kehadirandosendetails WHERE kehadirandosendetailsid=@kehadirandosendetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@kehadirandosendetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kehadirandosendetailsid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbp_kehadirandosendetails SET DLT=true , op_edit=@op_edit, pc_edit=@pc_edit, lu_edit=now() WHERE kehadirandosendetailsid=@kehadirandosendetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@kehadirandosendetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kehadirandosendetailsid;
            cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
            cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tbp_kehadirandosendetails WHERE kehadirandosendetailsid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("kehadirandosendetailsid")))
                    {
                        m_kehadirandosendetailsid = rdr.GetString(rdr.GetOrdinal("kehadirandosendetailsid"));
                    }
                    else
                    {
                        m_kehadirandosendetailsid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("kehadirandosenid")))
                    {
                        m_kehadirandosenid = rdr.GetString(rdr.GetOrdinal("kehadirandosenid"));
                    }
                    else
                    {
                        m_kehadirandosenid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dosenid")))
                    {
                        m_dosenid = rdr.GetString(rdr.GetOrdinal("dosenid"));
                    }
                    else
                    {
                        m_dosenid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("matapelajaranid")))
                    {
                        m_matapelajaranid = rdr.GetString(rdr.GetOrdinal("matapelajaranid"));
                    }
                    else
                    {
                        m_matapelajaranid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahmahasiswa")))
                    {
                        m_jumlahmahasiswa = rdr.GetDecimal(rdr.GetOrdinal("jumlahmahasiswa"));
                    }
                    else
                    {
                        m_jumlahmahasiswa = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("kelas")))
                    {
                        m_kelas = rdr.GetString(rdr.GetOrdinal("kelas"));
                    }
                    else
                    {
                        m_kelas = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahsesi1")))
                    {
                        m_jumlahsesi1 = rdr.GetDecimal(rdr.GetOrdinal("jumlahsesi1"));
                    }
                    else
                    {
                        m_jumlahsesi1 = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahsesi2")))
                    {
                        m_jumlahsesi2 = rdr.GetDecimal(rdr.GetOrdinal("jumlahsesi2"));
                    }
                    else
                    {
                        m_jumlahsesi2 = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahsesi3")))
                    {
                        m_jumlahsesi3 = rdr.GetDecimal(rdr.GetOrdinal("jumlahsesi3"));
                    }
                    else
                    {
                        m_jumlahsesi3 = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahsesi4")))
                    {
                        m_jumlahsesi4 = rdr.GetDecimal(rdr.GetOrdinal("jumlahsesi4"));
                    }
                    else
                    {
                        m_jumlahsesi4 = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahsesi5")))
                    {
                        m_jumlahsesi5 = rdr.GetDecimal(rdr.GetOrdinal("jumlahsesi5"));
                    }
                    else
                    {
                        m_jumlahsesi5 = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("remarks")))
                    {
                        m_remarks = rdr.GetString(rdr.GetOrdinal("remarks"));
                    }
                    else
                    {
                        m_remarks = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("nourut")))
                    {
                        m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
                    }
                    else
                    {
                        m_nourut = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("op_add")))
                    {
                        m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
                    }
                    else
                    {
                        m_op_add = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add")))
                    {
                        m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
                    }
                    else
                    {
                        m_pc_add = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add")))
                    {
                        m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
                    }
                    else
                    {
                        m_lu_add = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit")))
                    {
                        m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
                    }
                    else
                    {
                        m_op_edit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit")))
                    {
                        m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
                    }
                    else
                    {
                        m_pc_edit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit")))
                    {
                        m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
                    }
                    else
                    {
                        m_lu_edit = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dlt")))
                    {
                        m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                    }
                    else
                    {
                        m_dlt = false;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif")))
                    {
                        m_tarif = rdr.GetDecimal(rdr.GetOrdinal("tarif"));
                    }
                    else
                    {
                        m_tarif = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_pajak")))
                    {
                        m_tarif_pajak = rdr.GetDecimal(rdr.GetOrdinal("tarif_pajak"));
                    }
                    else
                    {
                        m_tarif_pajak = 0;
                    };
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbp_kehadirandosendetails");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbp_kehadirandosendetails");
            return dt;
        }

        public System.Data.DataTable GetData(string strSQL)
        {
            if (strSQL == "")
            {
                strSQL = "select * from tbp_kehadirandosendetails where dlt='0' ";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbp_kehadirandosendetails");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbp_kehadirandosendetails");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_kehadirandosendetails_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}