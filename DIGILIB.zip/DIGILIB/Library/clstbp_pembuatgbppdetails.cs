﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstbp_pembuatgbppdetails
    {
        private String m_pembuatgbppdetailsid;
        private String m_pembuatgbppid;
        private String m_dosenid;
        private String m_matapelajaranid;
        private String m_judulgbpp;
        private String m_remarks;
        private decimal m_nourut;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private decimal m_tarif;
        private decimal m_tarif_pajak;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pembuatgbppdetailsid
        {
            get { return m_pembuatgbppdetailsid; }
            set { m_pembuatgbppdetailsid = value; }
        }
        public String pembuatgbppid
        {
            get { return m_pembuatgbppid; }
            set { m_pembuatgbppid = value; }
        }
        public String dosenid
        {
            get { return m_dosenid; }
            set { m_dosenid = value; }
        }
        public String matapelajaranid
        {
            get { return m_matapelajaranid; }
            set { m_matapelajaranid = value; }
        }
        public String judulgbpp
        {
            get { return m_judulgbpp; }
            set { m_judulgbpp = value; }
        }
        public String remarks
        {
            get { return m_remarks; }
            set { m_remarks = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public decimal tarif
        {
            get { return m_tarif; }
            set { m_tarif = value; }
        }
        public decimal tarif_pajak
        {
            get { return m_tarif_pajak; }
            set { m_tarif_pajak = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_pembuatgbppdetails(pembuatgbppdetailsid,pembuatgbppid,dosenid,matapelajaranid,judulgbpp,remarks,nourut,op_add,pc_add,lu_add,dlt,tarif,tarif_pajak)"+
                            "VALUES"+
                            "(@pembuatgbppdetailsid,@pembuatgbppid,@dosenid,@matapelajaranid,@judulgbpp,@remarks,@nourut,@op_add,@pc_add,now(),@dlt,@tarif,@tarif_pajak)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pembuatgbppdetailsid != null )
            {
               cmd.Parameters.Add("@pembuatgbppdetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppdetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pembuatgbppdetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pembuatgbppid != null )
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppid;
            }
            else
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenid != null )
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenid;
            }
            else
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (matapelajaranid != null )
            {
               cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = matapelajaranid;
            }
            else
            {
               cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (judulgbpp != null )
            {
               cmd.Parameters.Add("@judulgbpp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judulgbpp;
            }
            else
            {
               cmd.Parameters.Add("@judulgbpp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
               cmd.Parameters.Add("@tarif", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif;
               cmd.Parameters.Add("@tarif_pajak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pajak;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_pembuatgbppdetails SET "+
                            " pembuatgbppdetailsid=@pembuatgbppdetailsid,pembuatgbppid=@pembuatgbppid,dosenid=@dosenid,matapelajaranid=@matapelajaranid,judulgbpp=@judulgbpp,remarks=@remarks,nourut=@nourut,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt=@dlt,tarif=@tarif,tarif_pajak=@tarif_pajak"+
                            " WHERE pembuatgbppdetailsid=@pembuatgbppdetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pembuatgbppdetailsid != null )
            {
               cmd.Parameters.Add("@pembuatgbppdetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppdetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pembuatgbppdetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pembuatgbppid != null )
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppid;
            }
            else
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenid != null )
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenid;
            }
            else
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (matapelajaranid != null )
            {
               cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = matapelajaranid;
            }
            else
            {
               cmd.Parameters.Add("@matapelajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (judulgbpp != null )
            {
               cmd.Parameters.Add("@judulgbpp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judulgbpp;
            }
            else
            {
               cmd.Parameters.Add("@judulgbpp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
               cmd.Parameters.Add("@tarif", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif;
               cmd.Parameters.Add("@tarif_pajak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pajak;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_pembuatgbppdetails WHERE pembuatgbppdetailsid=@pembuatgbppdetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pembuatgbppdetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppdetailsid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbp_pembuatgbppdetails SET DLT=true , op_edit=@op_edit, pc_edit=@pc_edit, lu_edit=now() WHERE pembuatgbppdetailsid=@pembuatgbppdetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
               cmd.Parameters.Add("@pembuatgbppdetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppdetailsid;
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_pembuatgbppdetails WHERE pembuatgbppdetailsid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pembuatgbppdetailsid"))) 
            {
              m_pembuatgbppdetailsid = rdr.GetString(rdr.GetOrdinal("pembuatgbppdetailsid"));
            }
            else
            {
              m_pembuatgbppdetailsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pembuatgbppid"))) 
            {
              m_pembuatgbppid = rdr.GetString(rdr.GetOrdinal("pembuatgbppid"));
            }
            else
            {
              m_pembuatgbppid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dosenid"))) 
            {
              m_dosenid = rdr.GetString(rdr.GetOrdinal("dosenid"));
            }
            else
            {
              m_dosenid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("matapelajaranid"))) 
            {
              m_matapelajaranid = rdr.GetString(rdr.GetOrdinal("matapelajaranid"));
            }
            else
            {
              m_matapelajaranid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("judulgbpp"))) 
            {
              m_judulgbpp = rdr.GetString(rdr.GetOrdinal("judulgbpp"));
            }
            else
            {
              m_judulgbpp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("remarks"))) 
            {
              m_remarks = rdr.GetString(rdr.GetOrdinal("remarks"));
            }
            else
            {
              m_remarks = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nourut"))) 
            {
              m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
            }
            else
            {
              m_nourut = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dlt"))) 
            {
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            }
            else
            {
              m_dlt = false;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tarif"))) 
            {
              m_tarif = rdr.GetDecimal(rdr.GetOrdinal("tarif"));
            }
            else
            {
              m_tarif = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_pajak"))) 
            {
              m_tarif_pajak = rdr.GetDecimal(rdr.GetOrdinal("tarif_pajak"));
            }
            else
            {
              m_tarif_pajak = 0;
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pembuatgbppdetails");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pembuatgbppdetails");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbp_pembuatgbppdetails where dlt='0' ";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi); 
         cmd.CommandTimeout = 0; 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pembuatgbppdetails");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pembuatgbppdetails");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         cmd.CommandTimeout = 0;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_pembuatgbppdetails_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
