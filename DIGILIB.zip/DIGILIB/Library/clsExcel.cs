﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using Npgsql;
using System.Windows.Forms;
using System.Security;

namespace Library
{
    public class clsExcel : clsExcelTransporter
    {
        private string m_TableName;
        private clsConnection oConnection = new clsConnection();
        public String TableName
        {
            get { return m_TableName; }
            set { m_TableName = value; }
        }


        public override int GetTotalColumnOfDB()
        {
            int iTotalColumn;
            DataTable dt;
            NpgsqlCommand cmd = new NpgsqlCommand();

            cmd.CommandText = @"SELECT * FROM " + m_TableName + " limit 1";
            dt = oConnection.GetData(cmd);
            iTotalColumn = dt.Columns.Count;//7 default fields, including recordid,ipaddress
            return iTotalColumn;
        }


        public override int GetTotalRowOfDB()
        {
            int iTotalRow;

            NpgsqlCommand cmd = new NpgsqlCommand();
            //        If m_MultiThread = 1 Then
            //            // If bIsMultiThread Then
            //            cmd.CommandText = "SELECT COUNT(*) FROM " & m_MultiThreadTable & _
            //" WHERE OriginalFileName=@OriginalFileName AND MacAddress=@MacAddress"
            //            //Else
            //            //    cmd.CommandText = "SELECT COUNT(*) FROM " & oSetting.GetTableName & _
            //            // " WHERE OriginalFileName=@OriginalFileName"
            //            //End If
            //        Else
            cmd.CommandText = "SELECT COUNT(*) FROM " + m_TableName;
            //" WHERE OriginalFileName=@OriginalFileName AND IPAddress=@IPAddress"
            //End If
            //cmd.Parameters.Add("OriginalFileName", MySqlDbType.Text).Value = m_OriginalFileName
            //cmd.Parameters.Add("IPAddress", MySqlDbType.VarChar).Value = m_IPAddress
            NpgsqlDataReader dr;
            dr = oConnection.ReadData(cmd);
            dr.Read();
            iTotalRow = Convert.ToInt32(dr[0].ToString());
            if (iTotalRow <= 0)
            {
                iTotalRow = 0;
            }
            dr.Close();
            oConnection.Close();
            return iTotalRow;
        }
        public override void UpdateDB()
        {
            //no implementation
        }

    }
}

public delegate void updateProgressBar(object sender, string msg);
