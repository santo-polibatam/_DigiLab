﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstbp_dosenwalidetails
    {
        private String m_dosenwalidetailsid;
        private String m_dosenwaliid;
        private String m_dosenid;
        private String m_angkatan;
        private String m_mahasiswaid;
        private String m_remarks;
        private decimal m_nourut;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_range_nim;
        private decimal m_jmlmahasiswa;
        private DateTime m_tanggalmulai;
        private DateTime m_tanggalselesai;
        private decimal m_tarif;
        private decimal m_tarif_pajak;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String dosenwalidetailsid
        {
            get { return m_dosenwalidetailsid; }
            set { m_dosenwalidetailsid = value; }
        }
        public String dosenwaliid
        {
            get { return m_dosenwaliid; }
            set { m_dosenwaliid = value; }
        }
        public String dosenid
        {
            get { return m_dosenid; }
            set { m_dosenid = value; }
        }
        public String angkatan
        {
            get { return m_angkatan; }
            set { m_angkatan = value; }
        }
        public String mahasiswaid
        {
            get { return m_mahasiswaid; }
            set { m_mahasiswaid = value; }
        }
        public String remarks
        {
            get { return m_remarks; }
            set { m_remarks = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String range_nim
        {
            get { return m_range_nim; }
            set { m_range_nim = value; }
        }
        public decimal jmlmahasiswa
        {
            get { return m_jmlmahasiswa; }
            set { m_jmlmahasiswa = value; }
        }
        public DateTime tanggalmulai
        {
            get { return m_tanggalmulai; }
            set { m_tanggalmulai = value; }
        }
        public DateTime tanggalselesai
        {
            get { return m_tanggalselesai; }
            set { m_tanggalselesai = value; }
        }
        public decimal tarif
        {
            get { return m_tarif; }
            set { m_tarif = value; }
        }
        public decimal tarif_pajak
        {
            get { return m_tarif_pajak; }
            set { m_tarif_pajak = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_dosenwalidetails(dosenwalidetailsid,dosenwaliid,dosenid,angkatan,mahasiswaid,remarks,nourut,op_add,pc_add,lu_add,dlt,range_nim,jmlmahasiswa,tanggalmulai,tanggalselesai,tarif,tarif_pajak)"+
                            "VALUES"+
                            "(@dosenwalidetailsid,@dosenwaliid,@dosenid,@angkatan,@mahasiswaid,@remarks,@nourut,@op_add,@pc_add,now(),@dlt,@range_nim,@jmlmahasiswa,@tanggalmulai,@tanggalselesai,@tarif,@tarif_pajak)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (dosenwalidetailsid != null )
            {
               cmd.Parameters.Add("@dosenwalidetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwalidetailsid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwalidetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenwaliid != null )
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenid != null )
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenid;
            }
            else
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (angkatan != null )
            {
               cmd.Parameters.Add("@angkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = angkatan;
            }
            else
            {
               cmd.Parameters.Add("@angkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (mahasiswaid != null )
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (range_nim != null )
            {
               cmd.Parameters.Add("@range_nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = range_nim;
            }
            else
            {
               cmd.Parameters.Add("@range_nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jmlmahasiswa", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jmlmahasiswa;
            if (tanggalmulai != null && tanggalmulai != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalmulai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalmulai;
            }
            else
            {
               cmd.Parameters.Add("@tanggalmulai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tanggalselesai != null && tanggalselesai != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalselesai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalselesai;
            }
            else
            {
               cmd.Parameters.Add("@tanggalselesai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@tarif", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif;
               cmd.Parameters.Add("@tarif_pajak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pajak;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_dosenwalidetails SET "+
                            " dosenwalidetailsid=@dosenwalidetailsid,dosenwaliid=@dosenwaliid,dosenid=@dosenid,angkatan=@angkatan,mahasiswaid=@mahasiswaid,remarks=@remarks,nourut=@nourut,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt=@dlt,range_nim=@range_nim,jmlmahasiswa=@jmlmahasiswa,tanggalmulai=@tanggalmulai,tanggalselesai=@tanggalselesai,tarif=@tarif,tarif_pajak=@tarif_pajak"+
                            " WHERE dosenwalidetailsid=@dosenwalidetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (dosenwalidetailsid != null )
            {
               cmd.Parameters.Add("@dosenwalidetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwalidetailsid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwalidetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenwaliid != null )
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwaliid;
            }
            else
            {
               cmd.Parameters.Add("@dosenwaliid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (dosenid != null )
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenid;
            }
            else
            {
               cmd.Parameters.Add("@dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (angkatan != null )
            {
               cmd.Parameters.Add("@angkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = angkatan;
            }
            else
            {
               cmd.Parameters.Add("@angkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (mahasiswaid != null )
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (range_nim != null )
            {
               cmd.Parameters.Add("@range_nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = range_nim;
            }
            else
            {
               cmd.Parameters.Add("@range_nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jmlmahasiswa", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jmlmahasiswa;
            if (tanggalmulai != null && tanggalmulai != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalmulai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalmulai;
            }
            else
            {
               cmd.Parameters.Add("@tanggalmulai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tanggalselesai != null && tanggalselesai != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalselesai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalselesai;
            }
            else
            {
               cmd.Parameters.Add("@tanggalselesai", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@tarif", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif;
               cmd.Parameters.Add("@tarif_pajak", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pajak;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_dosenwalidetails WHERE dosenwalidetailsid=@dosenwalidetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@dosenwalidetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwalidetailsid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbp_dosenwalidetails SET DLT=true , op_edit=@op_edit, pc_edit=@pc_edit, lu_edit=now() WHERE dosenwalidetailsid=@dosenwalidetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
               cmd.Parameters.Add("@dosenwalidetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = dosenwalidetailsid;
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_dosenwalidetails WHERE dosenwalidetailsid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("dosenwalidetailsid"))) 
            {
              m_dosenwalidetailsid = rdr.GetString(rdr.GetOrdinal("dosenwalidetailsid"));
            }
            else
            {
              m_dosenwalidetailsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dosenwaliid"))) 
            {
              m_dosenwaliid = rdr.GetString(rdr.GetOrdinal("dosenwaliid"));
            }
            else
            {
              m_dosenwaliid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dosenid"))) 
            {
              m_dosenid = rdr.GetString(rdr.GetOrdinal("dosenid"));
            }
            else
            {
              m_dosenid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("angkatan"))) 
            {
              m_angkatan = rdr.GetString(rdr.GetOrdinal("angkatan"));
            }
            else
            {
              m_angkatan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("mahasiswaid"))) 
            {
              m_mahasiswaid = rdr.GetString(rdr.GetOrdinal("mahasiswaid"));
            }
            else
            {
              m_mahasiswaid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("remarks"))) 
            {
              m_remarks = rdr.GetString(rdr.GetOrdinal("remarks"));
            }
            else
            {
              m_remarks = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nourut"))) 
            {
              m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
            }
            else
            {
              m_nourut = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dlt"))) 
            {
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            }
            else
            {
              m_dlt = false;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("range_nim"))) 
            {
              m_range_nim = rdr.GetString(rdr.GetOrdinal("range_nim"));
            }
            else
            {
              m_range_nim = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jmlmahasiswa"))) 
            {
              m_jmlmahasiswa = rdr.GetDecimal(rdr.GetOrdinal("jmlmahasiswa"));
            }
            else
            {
              m_jmlmahasiswa = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggalmulai"))) 
            {
              m_tanggalmulai = rdr.GetDateTime(rdr.GetOrdinal("tanggalmulai"));
            }
            else
            {
              m_tanggalmulai = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggalselesai"))) 
            {
              m_tanggalselesai = rdr.GetDateTime(rdr.GetOrdinal("tanggalselesai"));
            }
            else
            {
              m_tanggalselesai = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tarif"))) 
            {
              m_tarif = rdr.GetDecimal(rdr.GetOrdinal("tarif"));
            }
            else
            {
              m_tarif = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_pajak"))) 
            {
              m_tarif_pajak = rdr.GetDecimal(rdr.GetOrdinal("tarif_pajak"));
            }
            else
            {
              m_tarif_pajak = 0;
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_dosenwalidetails");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_dosenwalidetails");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbp_dosenwalidetails where dlt='0' ";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi); 
         cmd.CommandTimeout = 0; 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_dosenwalidetails");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_dosenwalidetails");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         cmd.CommandTimeout = 0;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_dosenwalidetails_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}