﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstbp_pembuatgbpp
    {
        private String m_pembuatgbppid;
        private String m_tahunajaranid;
        private String m_prodiid;
        private String m_program;
        private String m_semester;
        private String m_noborang;
        private String m_disiapkanolehid;
        private String m_diperiksaolehid;
        private String m_diketahuiolehid;
        private DateTime m_tanggalrekap;
        private String m_lampiran;
        private String m_remarks;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private DateTime m_tanggalborang;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pembuatgbppid
        {
            get { return m_pembuatgbppid; }
            set { m_pembuatgbppid = value; }
        }
        public String tahunajaranid
        {
            get { return m_tahunajaranid; }
            set { m_tahunajaranid = value; }
        }
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String program
        {
            get { return m_program; }
            set { m_program = value; }
        }
        public String semester
        {
            get { return m_semester; }
            set { m_semester = value; }
        }
        public String noborang
        {
            get { return m_noborang; }
            set { m_noborang = value; }
        }
        public String disiapkanolehid
        {
            get { return m_disiapkanolehid; }
            set { m_disiapkanolehid = value; }
        }
        public String diperiksaolehid
        {
            get { return m_diperiksaolehid; }
            set { m_diperiksaolehid = value; }
        }
        public String diketahuiolehid
        {
            get { return m_diketahuiolehid; }
            set { m_diketahuiolehid = value; }
        }
        public DateTime tanggalrekap
        {
            get { return m_tanggalrekap; }
            set { m_tanggalrekap = value; }
        }
        public String lampiran
        {
            get { return m_lampiran; }
            set { m_lampiran = value; }
        }
        public String remarks
        {
            get { return m_remarks; }
            set { m_remarks = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public DateTime tanggalborang
        {
            get { return m_tanggalborang; }
            set { m_tanggalborang = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_pembuatgbpp(pembuatgbppid,tahunajaranid,prodiid,program,semester,noborang,disiapkanolehid,diperiksaolehid,diketahuiolehid,tanggalrekap,lampiran,remarks,op_add,pc_add,lu_add,dlt,tanggalborang)"+
                            "VALUES"+
                            "(@pembuatgbppid,@tahunajaranid,@prodiid,@program,@semester,@noborang,@disiapkanolehid,@diperiksaolehid,@diketahuiolehid,@tanggalrekap,@lampiran,@remarks,@op_add,@pc_add,now(),@dlt,@tanggalborang)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pembuatgbppid != null )
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppid;
            }
            else
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahunajaranid != null )
            {
               cmd.Parameters.Add("@tahunajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunajaranid;
            }
            else
            {
               cmd.Parameters.Add("@tahunajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (program != null )
            {
               cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = program;
            }
            else
            {
               cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (semester != null )
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = semester;
            }
            else
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noborang != null )
            {
               cmd.Parameters.Add("@noborang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noborang;
            }
            else
            {
               cmd.Parameters.Add("@noborang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (disiapkanolehid != null )
            {
               cmd.Parameters.Add("@disiapkanolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = disiapkanolehid;
            }
            else
            {
               cmd.Parameters.Add("@disiapkanolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (diperiksaolehid != null )
            {
               cmd.Parameters.Add("@diperiksaolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = diperiksaolehid;
            }
            else
            {
               cmd.Parameters.Add("@diperiksaolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (diketahuiolehid != null )
            {
               cmd.Parameters.Add("@diketahuiolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = diketahuiolehid;
            }
            else
            {
               cmd.Parameters.Add("@diketahuiolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggalrekap != null && tanggalrekap != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalrekap", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalrekap;
            }
            else
            {
               cmd.Parameters.Add("@tanggalrekap", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (lampiran != null )
            {
               cmd.Parameters.Add("@lampiran", NpgsqlTypes.NpgsqlDbType.Varchar).Value = lampiran;
            }
            else
            {
               cmd.Parameters.Add("@lampiran", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tanggalborang != null && tanggalborang != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalborang", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalborang;
            }
            else
            {
               cmd.Parameters.Add("@tanggalborang", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_pembuatgbpp SET "+
                            " pembuatgbppid=@pembuatgbppid,tahunajaranid=@tahunajaranid,prodiid=@prodiid,program=@program,semester=@semester,noborang=@noborang,disiapkanolehid=@disiapkanolehid,diperiksaolehid=@diperiksaolehid,diketahuiolehid=@diketahuiolehid,tanggalrekap=@tanggalrekap,lampiran=@lampiran,remarks=@remarks,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt=@dlt,tanggalborang=@tanggalborang"+
                            " WHERE pembuatgbppid=@pembuatgbppid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pembuatgbppid != null )
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppid;
            }
            else
            {
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahunajaranid != null )
            {
               cmd.Parameters.Add("@tahunajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunajaranid;
            }
            else
            {
               cmd.Parameters.Add("@tahunajaranid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (program != null )
            {
               cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = program;
            }
            else
            {
               cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (semester != null )
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = semester;
            }
            else
            {
               cmd.Parameters.Add("@semester", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noborang != null )
            {
               cmd.Parameters.Add("@noborang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noborang;
            }
            else
            {
               cmd.Parameters.Add("@noborang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (disiapkanolehid != null )
            {
               cmd.Parameters.Add("@disiapkanolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = disiapkanolehid;
            }
            else
            {
               cmd.Parameters.Add("@disiapkanolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (diperiksaolehid != null )
            {
               cmd.Parameters.Add("@diperiksaolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = diperiksaolehid;
            }
            else
            {
               cmd.Parameters.Add("@diperiksaolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (diketahuiolehid != null )
            {
               cmd.Parameters.Add("@diketahuiolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = diketahuiolehid;
            }
            else
            {
               cmd.Parameters.Add("@diketahuiolehid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggalrekap != null && tanggalrekap != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalrekap", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalrekap;
            }
            else
            {
               cmd.Parameters.Add("@tanggalrekap", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (lampiran != null )
            {
               cmd.Parameters.Add("@lampiran", NpgsqlTypes.NpgsqlDbType.Varchar).Value = lampiran;
            }
            else
            {
               cmd.Parameters.Add("@lampiran", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tanggalborang != null && tanggalborang != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggalborang", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggalborang;
            }
            else
            {
               cmd.Parameters.Add("@tanggalborang", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_pembuatgbpp WHERE pembuatgbppid=@pembuatgbppid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbp_pembuatgbpp SET DLT=true , op_edit=@op_edit, pc_edit=@pc_edit, lu_edit=now() WHERE pembuatgbppid=@pembuatgbppid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
               cmd.Parameters.Add("@pembuatgbppid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pembuatgbppid;
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_pembuatgbpp WHERE pembuatgbppid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pembuatgbppid"))) 
            {
              m_pembuatgbppid = rdr.GetString(rdr.GetOrdinal("pembuatgbppid"));
            }
            else
            {
              m_pembuatgbppid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tahunajaranid"))) 
            {
              m_tahunajaranid = rdr.GetString(rdr.GetOrdinal("tahunajaranid"));
            }
            else
            {
              m_tahunajaranid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid"))) 
            {
              m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
            }
            else
            {
              m_prodiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("program"))) 
            {
              m_program = rdr.GetString(rdr.GetOrdinal("program"));
            }
            else
            {
              m_program = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("semester"))) 
            {
              m_semester = rdr.GetString(rdr.GetOrdinal("semester"));
            }
            else
            {
              m_semester = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("noborang"))) 
            {
              m_noborang = rdr.GetString(rdr.GetOrdinal("noborang"));
            }
            else
            {
              m_noborang = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("disiapkanolehid"))) 
            {
              m_disiapkanolehid = rdr.GetString(rdr.GetOrdinal("disiapkanolehid"));
            }
            else
            {
              m_disiapkanolehid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("diperiksaolehid"))) 
            {
              m_diperiksaolehid = rdr.GetString(rdr.GetOrdinal("diperiksaolehid"));
            }
            else
            {
              m_diperiksaolehid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("diketahuiolehid"))) 
            {
              m_diketahuiolehid = rdr.GetString(rdr.GetOrdinal("diketahuiolehid"));
            }
            else
            {
              m_diketahuiolehid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggalrekap"))) 
            {
              m_tanggalrekap = rdr.GetDateTime(rdr.GetOrdinal("tanggalrekap"));
            }
            else
            {
              m_tanggalrekap = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lampiran"))) 
            {
              m_lampiran = rdr.GetString(rdr.GetOrdinal("lampiran"));
            }
            else
            {
              m_lampiran = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("remarks"))) 
            {
              m_remarks = rdr.GetString(rdr.GetOrdinal("remarks"));
            }
            else
            {
              m_remarks = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggalborang"))) 
            {
              m_tanggalborang = rdr.GetDateTime(rdr.GetOrdinal("tanggalborang"));
            }
            else
            {
              m_tanggalborang = System.DateTime.MinValue;
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pembuatgbpp");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pembuatgbpp");
         return dt;
      }

        public System.Data.DataTable GetData(string strSQL)
        {
            if (strSQL == "")
            {
                string strWhere = "";
                if (clsGlobal.strUserName.ToLower() != "superadmin")
                {
                    strWhere = @" and exists (select upr.prodiid from tbp_userprodi upr where upr.dlt='0' and upr.prodiid=pro.prodiid and upr.userid='" + clsGlobal.strUserID + @"'
                        and (upr.isread='1' or isadd='1' or isedit='1' or isdelete='1' or isprint='1' or isdownload='1' or isupload='1'))";
                }
                strSQL = @"select ta.tahunajaran, pro.prodiid, pro.prodicode, pro.prodidesc as prodi, pro.prodicode || ' - ' || pro.prodidesc as prodiview,
                    kar.nik as disiapkanoleh_nik, kar.namakaryawan as disiapkanoleh,
                    kar2.nik as diperiksaoleh_nik, kar2.namakaryawan as diperiksaoleh,
                    kar3.nik as diketahuioleh_nik, kar3.namakaryawan as diketahuioleh,
                    getMyTgl(pba.tanggalborang,'dd MMMM yyyy') as tanggalrekap_indo, 
                    prog.programid, prog.namaprogram, pba.*
                    from tbp_pembuatgbpp pba
                    inner join tba_tahunajaran ta on ta.tahunajaranid=pba.tahunajaranid and ta.dlt='0'
                    inner join tbp_prodi pro on pro.prodiid=pba.prodiid and pro.dlt='0' " + strWhere + @"
                    left outer join tbp_program prog on prog.programid=pba.program and prog.dlt='0' 
                    left outer join 
                    (
                        select peg.pegawai_pendid as karyawanid, peg.pegawai_pendid, '' as pegawai_kependid, peg.nik, peg.nama as namakaryawan, peg.nama||' - ' || peg.nik as karyawan
                        from tbp_pegawai_pend peg	
                        where peg.dlt='0'
                        union
                        select pegawai_kependid  as karyawanid, '' as pegawai_pendid, pegawai_kependid, nik, nama as namakaryawan, nama||' - ' || nik as karyawan
                        from tbp_pegawai_kepend peg
                        where peg.dlt='0'
                    ) kar on kar.karyawanid=pba.disiapkanolehid 
                    left outer join 
                    (
                        select peg.pegawai_pendid as karyawanid, peg.pegawai_pendid, '' as pegawai_kependid, peg.nik, peg.nama as namakaryawan, peg.nama||' - ' || peg.nik as karyawan
                        from tbp_pegawai_pend peg	
                        where peg.dlt='0'
                        union
                        select pegawai_kependid  as karyawanid, '' as pegawai_pendid, pegawai_kependid, nik, nama as namakaryawan, nama||' - ' || nik as karyawan
                        from tbp_pegawai_kepend peg
                        where peg.dlt='0'
                    ) kar2 on kar2.karyawanid=pba.diperiksaolehid 
                    left outer join 
                    (
                        select peg.pegawai_pendid as karyawanid, peg.pegawai_pendid, '' as pegawai_kependid, peg.nik, peg.nama as namakaryawan, peg.nama||' - ' || peg.nik as karyawan
                        from tbp_pegawai_pend peg	
                        where peg.dlt='0'
                        union
                        select pegawai_kependid  as karyawanid, '' as pegawai_pendid, pegawai_kependid, nik, nama as namakaryawan, nama||' - ' || nik as karyawan
                        from tbp_pegawai_kepend peg
                        where peg.dlt='0'
                    ) kar3 on kar3.karyawanid=pba.diketahuiolehid 
                    where pba.dlt='0' ; 
                    ";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbp_pembuatgbpp");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbp_pembuatgbpp");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" +clsGlobal.str_serverCode + "'||nextval('tbp_pembuatgbpp_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}
