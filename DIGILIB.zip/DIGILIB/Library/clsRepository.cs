﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clsRepository
    {
        public System.Data.DataTable GetDataTable(Npgsql.NpgsqlCommand cmd, string tblName)
        {
            clsConnection oconn = new clsConnection();
            oconn.Open();
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add(tblName);
            cmd.Connection = oconn.Conn;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, tblName);
            oconn.Close();
            return dt;
        }

        public System.Data.DataTable GetDataTable(string strSQL, string tblName)
        {
            clsConnection oconn = new clsConnection();
            oconn.Open();
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, oconn.Conn);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add(tblName);
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, tblName);
            oconn.Close();
            return dt;
        }
        public System.Data.DataTable GetDataPetugas()
        {
//            string strSQL = @"
//                select peg.anggotaid as petugasid, peg.rfid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, 
//                peg.photo, peg.alamat, peg.jenis, peg.statusaktif
//                from tbm_anggota peg                     
//                where peg.dlt='0' and lower(peg.jenis)='staff'
//                ORDER BY petugas, nik";
            string strSQL = @"
                select peg.anggotaid as petugasid, peg.rfid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, '' as hak_akses,
                peg.photo, peg.alamat, peg.jenis, peg.statusaktif
                from tbm_anggota peg                     
                where peg.dlt='0'  and lower(peg.jenis)='staff'
                union all
                select usr.userid, usr.rfid, usr.nik, usr.nama as namapetugas, usr.nama||' - ' || usr.nik petugas, usr.hak_akses,
                usr.photo, '' as alamat, 'tbp_user' as jenis, '' as statusaktif
                from tbp_user usr
                where usr.dlt='0' and usr.userid='" + clsGlobal.strUserID + @"'                
                ORDER BY petugas, nik";
            System.Data.DataTable dtanggota = GetDataTable(strSQL, "tbm_anggota");
            clsEncryption oEncrypt = new clsEncryption();
            foreach (System.Data.DataRow row in dtanggota.Select("jenis='tbp_user'"))
            {
                row["namapetugas"] = oEncrypt.Decrypt(Convert.ToString(row["namapetugas"]));
                row["petugas"] = row["petugas"];
            }
            
            oEncrypt = null;

            return dtanggota;
        }
        public System.Data.DataTable GetDataKaryawan(string jabatan, string prodiid, string pegawai_kependid_edit)
        {
            string strSQL = @"select peg.pegawai_pendid as karyawanid, peg.nik, peg.nama as namakaryawan, peg.nama||' - ' || peg.nik as karyawan, 
            pro.prodiid,
            jrs.jurusanid
            from tbp_pegawai_jab_struktural jab 
            inner join tbp_pegawai_pend peg on peg.pegawai_pendid=jab.pegawai_pendid and peg.dlt='0' 
            inner join tbp_tunj_jabatan_struktural tunj on tunj.tunj_jabatan_strukturalid=peg.tunj_jabatan_strukturalid and tunj.dlt='0' 
            inner join tbp_prodi pro on pro.prodiid=peg.prodiid and pro.dlt='0'
            inner join tbp_jurusan jrs on jrs.jurusanid=pro.jurusanid and jrs.dlt='0'
            where jab.dlt='0' and (lower(jab.jenis_tenaga)=lower('Tenaga Pendidik')	or peg.pegawai_pendid=@pegawai_kependid_edit)
            and lower(tunj.jabatan)=lower(@jabatan) and pro.prodiid=@prodiid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL);
            cmd.Parameters.Add("@jabatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jabatan;//eg:Ketua Jurusan, Ketua Program Studi
            cmd.Parameters.Add("@pegawai_kependid_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_kependid_edit;//on edit
            cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;//on edit
            return GetDataTable(cmd, "tbm_karyawan");
        }
        public System.Data.DataTable GetDataKaryawan_Fungsional(string fungsional, string pegawai_kependid_edit)
        {
            string strSQL = @"select peg.pegawai_kependid as karyawanid, peg.nik, peg.nama as namakaryawan, peg.nama||' - ' || peg.nik as karyawan, 
                un.unitid, un.fungsional, un.unitcode, un.unitdesc
                from tbp_pegawai_kepend peg 
                inner join tbp_unit un on un.unitid=peg.unitid and un.dlt='0' 
                where peg.dlt='0' and (lower(un.fungsional)=lower(@fungsional) or peg.pegawai_kependid=@pegawai_kependid_edit)
            ";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL);
            cmd.Parameters.Add("@fungsional", NpgsqlTypes.NpgsqlDbType.Varchar).Value = fungsional;//eg:Tata Usaha Prodi
            cmd.Parameters.Add("@pegawai_kependid_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_kependid_edit;//on edit
            return GetDataTable(cmd, "tbm_karyawan");
        }
        	

        public System.Data.DataTable GetDataKaryawanAndTarif(string strprogram, string strprodi, string field_tarif)
        {
            
            string strSQL = @"
                    select peg.*, coalesce(trf.tarif,0) as tarif, coalesce(pjk.tarif_pajak,0) as tarif_pajak
                    FROM
                    (
	                    select peg.pegawai_pendid as karyawanid, peg.nik, peg.nama as namakaryawan, peg.nama||' - ' || peg.nik as karyawan,
	                    ja.jenjangakademikid, 
	                    sk.status
	                    from tbp_pegawai_pend peg
	                    inner join tbp_pegawai_statuskerja sk on sk.dlt='0' and sk.pegawai_pendid=peg.pegawai_pendid and sk.isaktif='1' and lower(sk.jenis_tenaga)=lower('Tenaga Pendidik')
	                    inner join tbp_pegawai_jenjang ja on ja.dlt='0' and ja.pegawai_pendid=peg.pegawai_pendid and ja.isaktif='1' and lower(ja.jenis_tenaga)=lower('Tenaga Pendidik')
	                    where peg.dlt='0'
	                    union
	                    select pegawai_kependid  as karyawanid, nik, nama as namakaryawan, nama||' - ' || nik as karyawan,
	                    ja.jenjangakademikid,
	                    sk.status

	                    from tbp_pegawai_kepend peg
	                    left outer join tbp_pegawai_statuskerja sk on sk.dlt='0' and sk.pegawai_pendid=peg.pegawai_kependid and sk.isaktif='1' and lower(sk.jenis_tenaga)=lower('Tenaga Kependidikan')
	                    left outer join tbp_pegawai_jenjang ja on ja.pegawai_pendid=peg.pegawai_kependid and ja.isaktif='1' and lower(ja.jenis_tenaga)=lower('Tenaga Kependidikan')
	                    where peg.dlt='0'
                    )peg
                    inner join
                    (
                        select trf.program, coalesce(pro.prodiid,'') as prodiid, coalesce(trf.jurusanid,'') as jurusanid, trf.jenjangakademikid, trf.status, trf." + field_tarif + @" as tarif 
                        from tbp_tarif_honor trf 
                        left outer join tbp_prodi pro on trf.jurusanid=pro.jurusanid and pro.dlt='0' 
                        where trf.dlt='0' and coalesce(pro.prodiid,'')='" + strprodi + @"'
                    ) trf on lower(trf.jenjangakademikid)=lower(peg.jenjangakademikid) and lower(trf.status)=lower(peg.status) and lower(trf.program)=lower('" + strprogram.Replace("'", "''") + @"') and coalesce(trf.prodiid,'')='" + strprodi + @"'

                    inner join
                    (
	                    select trf.tarif_pajakid, trfpeg.pegawai_pendid, trf.tarif_pajak 
	                    from tbp_tarif_pajak trf 
	                    inner join tbp_pegawai_tarifpajak trfpeg on trfpeg.tarif_pajakid=trf.tarif_pajakid and trfpeg.dlt='0' and trfpeg.isaktif='1'
	                    where trf.dlt='0'
                    ) pjk on pjk.pegawai_pendid=peg.karyawanid 
                    ORDER BY karyawan, nik
                ";
            return GetDataTable(strSQL, "tbm_karyawan");
        }
        public System.Data.DataTable GetDataProdi()
        {
            string strWhere = "";
            if (clsGlobal.strUserName.ToLower() != "superadmin")
            {
                strWhere = @" and exists (select upr.prodiid from tbp_userprodi upr where upr.dlt='0' and upr.prodiid=pro.prodiid and upr.userid='" + clsGlobal.strUserID + @"'
                and (upr.isread='1' or isadd='1' or isedit='1' or isdelete='1' or isprint='1' or isdownload='1' or isupload='1'))";
            }
            string strSQL = @"select '' as prodiid, '' as prodicode, '' as prodi, '' as prodiview, '' as jurusanid, '' as jurusancode, '' as jurusan
                union
                select pro.prodiid, pro.prodicode, pro.prodidesc as prodi, pro.prodicode || ' - ' || pro.prodidesc as prodiview, 
                jr.jurusanid, jr.jurusancode, jr.jurusandesc as jurusan
                from tbp_prodi pro
                inner join tbp_jurusan jr on jr.jurusanid=pro.jurusanid  and jr.dlt='0'
                where pro.dlt='0'" + strWhere + @"
                ORDER BY jurusan, prodiview
                ";
            return GetDataTable(strSQL, "tbp_prodi");
        }
        public System.Data.DataTable GetDataJurusan()
        {
            string strSQL = @"select '' as jurusanid, '' as jurusancode, '' as jurusan, '' as jurusanview
                union
                select jr.jurusanid, jr.jurusancode, jr.jurusandesc as jurusan, jr.jurusancode || ' - ' || jr.jurusandesc as jurusanview
                from tbp_jurusan jr
                where jr.dlt='0' 
                ORDER BY jurusan, jurusanview
                ";
            return GetDataTable(strSQL, "tbp_jurusan");
        }
        public System.Data.DataTable GetDataMataKuliah()
        {
            string strSQL = @"
                select '' matapelajaranid,'' kode, '' nama, '' as matapelajaran,
                '' tahunajaranid,'' tahunajaran
                union
                select mp.matapelajaranid, mp.kode, mp.nama, mp.nama || ' - ' || mp.kode as matapelajaran,
                ta.tahunajaranid, ta.tahunajaran
                from tbp_matapelajaran mp
                inner join tba_tahunajaran ta on ta.tahunajaranid=mp.tahun and ta.dlt='0'
                where mp.dlt='0' and coalesce(mp.nama,'') <>''
                ORDER BY tahunajaran, matapelajaran
                ";
            return GetDataTable(strSQL, "tbp_matapelajaran");
        }

        public System.Data.DataTable GetDataTahunAjaran()
        {
            string strSQL = @"
                select ta.tahunajaranid, ta.tahunajaran, ta.isactive
                from tba_tahunajaran ta
                where ta.dlt='0'
                ORDER BY tahunajaran
                ";
            return GetDataTable(strSQL, "tba_tahunajaran");
        }

        public System.Data.DataTable GetDataMahasiswa()
        {
            string strSQL = @"
                select mhs.*, mhs.namalengkap as namamahasiswa
                from tbb_mahasiswa mhs
                where mhs.dlt='0'
                ORDER BY namalengkap, nim
                ";
            return GetDataTable(strSQL, "tbb_mahasiswa");
        }
        public System.Data.DataTable GetDataModul_lib()
        {
            string strSQL = @"
                select lib.modul_libid as pkid, lib.*
                from tbp_modul_lib lib
                where lib.dlt='0'
                ORDER BY deskripsi
                ";
            return GetDataTable(strSQL, "tbp_modul_lib");
        }
        public System.Data.DataTable GetDataJenisUjian()
        {
            string strSQL = @"
                select lib.jenisujianid as pkid, lib.*
                from tbp_jenisujian lib
                where lib.dlt='0'
                ORDER BY deskripsi
                ";
            return GetDataTable(strSQL, "tbp_modul_lib");
        }
        public System.Data.DataTable GetDataProgram()
        {
            string strSQL = @"
                select lib.programid as pkid, lib.*
                from tbp_program lib
                where lib.dlt='0'
                ORDER BY namaprogram
                ";
            return GetDataTable(strSQL, "tbp_modul_lib");
        }
        public System.Data.DataTable GetDataJenjangAkademik()
        {
            string strSQL = @"
                select lib.*
                from tbp_jenjangakademik lib
                where lib.dlt='0'
                ORDER BY jenjang
                ";
            return GetDataTable(strSQL, "tbp_modul_lib");
        }

        public System.Data.DataTable GetDataJenisBahanAjar()
        {
            string strSQL = @"
                select lib.jenisbahanajarid as pkid, lib.*
                from tbp_jenisbahanajar lib
                where lib.dlt='0'
                ORDER BY deskripsi
                ";
            return GetDataTable(strSQL, "tbp_modul_lib");
        }

        public System.Data.DataTable GetDataGolongan()
        {
            string strSQL = @"select golongan_pnsid, golongan, remarks, nourut from tbp_golongan_pns where dlt='0' order by nourut;";
            return GetDataTable(strSQL, "tbp_modul_lib");
        }
        public System.Data.DataTable GetDataAnggota()
        {
            string strSQL = @"select peg.anggotaid, peg.rfid, peg.nim, peg.nama,
                peg.photo, peg.alamat, peg.jenis, peg.statusaktif 
                from tbm_anggota peg
                where dlt='0' order by nama;";
            return GetDataTable(strSQL, "tbm_anggota");
        }
        public System.Data.DataTable GetDataBuku_Tersedia()
        {
            string strSQL = @"select inv.inventarisid, inv.nib, inv.rfid,
                bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, 
                bk.penerbit, bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, bk.keterangan
                
                from tbm_buku bk
                inner join tbm_inventaris inv on inv.bukuid=bk.bukuid and inv.dlt='0'
                where bk.dlt='0' 
                and not exists 
                (
	                select invx.inventarisid, invx.nib, invx.rfid
	                from tblpeminjaman pj
	                inner join tblpeminjamandetails pjdet on pjdet.peminjamanid=pj.peminjamanid and pjdet.dlt='0'
	                inner join tbm_inventaris invx on invx.inventarisid=pjdet.inventarisid and invx.dlt='0'
	                inner join tbm_buku bk on invx.bukuid=bk.bukuid and bk.dlt='0'
	                inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
	                left outer join 
	                (
		                select pb.pengembalianid, pb.regno, pb.petugasid, pb.nopengembalian,
		                pbdet.pengembaliandetailsid, pbdet.peminjamandetailsid, pbdet.tglkembali, pbdet.jumlah, pbdet.jumlahdenda, pbdet.keterangan, pbdet.dendadibayar, pbdet.status
		                from tblpengembalian pb
		                inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
		                where pb.dlt='0'
	                ) pbdet on pbdet.peminjamandetailsid=pjdet.peminjamandetailsid 

	                where pj.dlt='0' and pbdet.pengembalianid is null
	                and inv.inventarisid=invx.inventarisid
                )
                order by noinduk, kodepanggil, judul";
            return GetDataTable(strSQL, "tbm_buku");
        }

        public System.Data.DataTable GetDataKetentuanPeminjaman()
        {
            string strSQL = @"select ketentuanpeminjamanid, lamapeminjaman, dendaperhari, maksbukudipinjam, ketentuanpeminjaman 
                from tblketentuanpeminjaman
                where dlt='0'";
            return GetDataTable(strSQL, "tbm_anggota");
        }

    }
}
