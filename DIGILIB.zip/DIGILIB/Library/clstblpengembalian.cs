﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstblpengembalian
    {

        private String m_pengembalianid;
        private String m_petugasid;
        private String m_nopengembalian;
        private DateTime m_tglkembali;
        private String m_keterangan;
        private decimal m_regno;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private DateTime m_tgldendadibayar;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pengembalianid
        {
            get { return m_pengembalianid; }
            set { m_pengembalianid = value; }
        }
        public String petugasid
        {
            get { return m_petugasid; }
            set { m_petugasid = value; }
        }
        public String nopengembalian
        {
            get { return m_nopengembalian; }
            set { m_nopengembalian = value; }
        }
        public DateTime tglkembali
        {
            get { return m_tglkembali; }
            set { m_tglkembali = value; }
        }
        public String keterangan
        {
            get { return m_keterangan; }
            set { m_keterangan = value; }
        }
        public decimal regno
        {
            get { return m_regno; }
            set { m_regno = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public DateTime tgldendadibayar
        {
            get { return m_tgldendadibayar; }
            set { m_tgldendadibayar = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tblpengembalian(pengembalianid,petugasid,nopengembalian,tglkembali,keterangan,regno,opadd,pcadd,luadd,dlt,tgldendadibayar)" +
                            "VALUES" +
                            "(@pengembalianid,@petugasid,@nopengembalian,@tglkembali,@keterangan,@regno,@opadd,@pcadd,now(),@dlt,@tgldendadibayar)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengembalianid != null)
            {
                cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembalianid;
            }
            else
            {
                cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (petugasid != null)
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = petugasid;
            }
            else
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nopengembalian != null)
            {
                cmd.Parameters.Add("@nopengembalian", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nopengembalian;
            }
            else
            {
                cmd.Parameters.Add("@nopengembalian", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglkembali != null && tglkembali != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglkembali;
            }
            else
            {
                cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (keterangan != null)
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@regno", NpgsqlTypes.NpgsqlDbType.Numeric).Value = regno;
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tgldendadibayar != null && tgldendadibayar != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tgldendadibayar", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgldendadibayar;
            }
            else
            {
                cmd.Parameters.Add("@tgldendadibayar", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tblpengembalian SET " +
                            " pengembalianid=@pengembalianid,petugasid=@petugasid,nopengembalian=@nopengembalian,tglkembali=@tglkembali,keterangan=@keterangan,regno=@regno,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt=@dlt,tgldendadibayar=@tgldendadibayar" +
                            " WHERE pengembalianid=@pengembalianid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengembalianid != null)
            {
                cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembalianid;
            }
            else
            {
                cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (petugasid != null)
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = petugasid;
            }
            else
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nopengembalian != null)
            {
                cmd.Parameters.Add("@nopengembalian", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nopengembalian;
            }
            else
            {
                cmd.Parameters.Add("@nopengembalian", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglkembali != null && tglkembali != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglkembali;
            }
            else
            {
                cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (keterangan != null)
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@regno", NpgsqlTypes.NpgsqlDbType.Numeric).Value = regno;
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tgldendadibayar != null && tgldendadibayar != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tgldendadibayar", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgldendadibayar;
            }
            else
            {
                cmd.Parameters.Add("@tgldendadibayar", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tblpengembalian WHERE pengembalianid=@pengembalianid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembalianid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tblpengembalian SET DLT=true , opedit=@opedit, pcedit=@pcedit, luedit=now() WHERE pengembalianid=@pengembalianid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembalianid;
            cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
            cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tblpengembalian WHERE pengembalianid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pengembalianid")))
                    {
                        m_pengembalianid = rdr.GetString(rdr.GetOrdinal("pengembalianid"));
                    }
                    else
                    {
                        m_pengembalianid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("petugasid")))
                    {
                        m_petugasid = rdr.GetString(rdr.GetOrdinal("petugasid"));
                    }
                    else
                    {
                        m_petugasid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("nopengembalian")))
                    {
                        m_nopengembalian = rdr.GetString(rdr.GetOrdinal("nopengembalian"));
                    }
                    else
                    {
                        m_nopengembalian = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tglkembali")))
                    {
                        m_tglkembali = rdr.GetDateTime(rdr.GetOrdinal("tglkembali"));
                    }
                    else
                    {
                        m_tglkembali = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("keterangan")))
                    {
                        m_keterangan = rdr.GetString(rdr.GetOrdinal("keterangan"));
                    }
                    else
                    {
                        m_keterangan = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("regno")))
                    {
                        m_regno = rdr.GetDecimal(rdr.GetOrdinal("regno"));
                    }
                    else
                    {
                        m_regno = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opadd")))
                    {
                        m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
                    }
                    else
                    {
                        m_opadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd")))
                    {
                        m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
                    }
                    else
                    {
                        m_pcadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luadd")))
                    {
                        m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
                    }
                    else
                    {
                        m_luadd = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opedit")))
                    {
                        m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
                    }
                    else
                    {
                        m_opedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit")))
                    {
                        m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
                    }
                    else
                    {
                        m_pcedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luedit")))
                    {
                        m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
                    }
                    else
                    {
                        m_luedit = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dlt")))
                    {
                        m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                    }
                    else
                    {
                        m_dlt = false;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tgldendadibayar")))
                    {
                        m_tgldendadibayar = rdr.GetDateTime(rdr.GetOrdinal("tgldendadibayar"));
                    }
                    else
                    {
                        m_tgldendadibayar = System.DateTime.MinValue;
                    };
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tblpengembalian");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tblpengembalian");
            return dt;
        }


        public System.Data.DataTable GetData(string strSQL, string strFilter = "")
        {
            if (strSQL == "")
            {
                strSQL = @"select inv.inventarisid, inv.nib, inv.rfid,
                    bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                    bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, 
                    ag.anggotaid, ag.rfid, ag.nim as nimanggota, ag.nama as namaanggota, ag.photo, ag.alamat, ag.jenis, ag.statusaktif,
                    peg.anggotaid as petugasid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, peg.photo as photopetugas,
                    pj.peminjamanid, pj.anggotaid as anggotaid_pinjam, pj.petugasid as petugasid_pinjam, pj.nopeminjaman, pj.tglpinjam, pj.tgljatuhtempo, pj.maksbukudipinjam, pj.lamapeminjaman, pj.dendaperhari,
                    pjdet.peminjamandetailsid, pjdet.jumlah, pjdet.status, pjdet.tglpinjam, pjdet.tgljatuhtempo,
                    
                    pb.pengembalianid, pb.nopengembalian, pb.tglkembali as tglkembalimaster, pb.petugasid, pb.keterangan as keteranganmaster, pb.regno,
                    pbdet.pengembaliandetailsid, pbdet.tglkembali, pbdet.jumlah as jumlahpengembalian, pbdet.jumlahdenda, pbdet.keterangan, pbdet.dendadibayar, pbdet.status,
                    case when (pbdet.tglkembali::date-pj.tgljatuhtempo::date) <0 then 0 else (pbdet.tglkembali::date-pj.tgljatuhtempo::date) end as terlambat,
                    case when coalesce(pbdet.pengembalianid,'')='' then false else true end  as kembalikan,
                    pb.tgldendadibayar

                    from tblpengembalian pb
                    inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
                    inner join tblpeminjamandetails pjdet on pjdet.peminjamandetailsid=pbdet.peminjamandetailsid and pjdet.dlt='0'
                    inner join tblpeminjaman pj on pj.peminjamanid=pjdet.peminjamanid and pj.dlt='0'                    
                    inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                    inner join tbm_buku bk on inv.bukuid=bk.bukuid and bk.dlt='0'
                    inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                    left outer join tbm_anggota peg on peg.anggotaid=pb.petugasid and peg.dlt='0'
                    
                    where pb.dlt='0' " + strFilter + @"
                    order by nopengembalian desc, noinduk, judul
                    ";

            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tblpengembalian");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tblpengembalian");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tblpengembalian_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}