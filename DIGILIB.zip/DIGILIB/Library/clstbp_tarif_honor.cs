﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstbp_tarif_honor
    {
        private String m_tarif_honorid;
        private String m_program;
        private String m_jurusanid;
        private String m_jenjangakademikid;
        private String m_status;
        private decimal m_tarif_mengajar;
        private decimal m_tarif_praktikummesin;
        private decimal m_tarif_penyusunsoal;
        private decimal m_tarif_koreksi;
        private decimal m_tarif_mengawas;
        private decimal m_tarif_membimbingta;
        private decimal m_tarif_membimbingpa;
        private decimal m_tarif_pengampu;
        private decimal m_tarif_menyiapkansapgbpp;
        private decimal m_tarif_mengujita_seminarproposal;
        private decimal m_tarif_mengujita_seminarprogress;
        private decimal m_tarif_mengujita_sidang;
        private decimal m_tarif_mengujipa_seminarproposal;
        private decimal m_tarif_mengujipa_seminarakhir;
        private decimal m_tarif_mengujita_kompre;
        private decimal m_tarif_menyusunbahanajar;
        private decimal m_tarif_menyusunmodul;
        private String m_tahun;
        private decimal m_nourut;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private decimal m_tarif_dosenwali;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String tarif_honorid
        {
            get { return m_tarif_honorid; }
            set { m_tarif_honorid = value; }
        }
        public String program
        {
            get { return m_program; }
            set { m_program = value; }
        }
        public String jurusanid
        {
            get { return m_jurusanid; }
            set { m_jurusanid = value; }
        }
        public String jenjangakademikid
        {
            get { return m_jenjangakademikid; }
            set { m_jenjangakademikid = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }
        public decimal tarif_mengajar
        {
            get { return m_tarif_mengajar; }
            set { m_tarif_mengajar = value; }
        }
        public decimal tarif_praktikummesin
        {
            get { return m_tarif_praktikummesin; }
            set { m_tarif_praktikummesin = value; }
        }
        public decimal tarif_penyusunsoal
        {
            get { return m_tarif_penyusunsoal; }
            set { m_tarif_penyusunsoal = value; }
        }
        public decimal tarif_koreksi
        {
            get { return m_tarif_koreksi; }
            set { m_tarif_koreksi = value; }
        }
        public decimal tarif_mengawas
        {
            get { return m_tarif_mengawas; }
            set { m_tarif_mengawas = value; }
        }
        public decimal tarif_membimbingta
        {
            get { return m_tarif_membimbingta; }
            set { m_tarif_membimbingta = value; }
        }
        public decimal tarif_membimbingpa
        {
            get { return m_tarif_membimbingpa; }
            set { m_tarif_membimbingpa = value; }
        }
        public decimal tarif_pengampu
        {
            get { return m_tarif_pengampu; }
            set { m_tarif_pengampu = value; }
        }
        public decimal tarif_menyiapkansapgbpp
        {
            get { return m_tarif_menyiapkansapgbpp; }
            set { m_tarif_menyiapkansapgbpp = value; }
        }
        public decimal tarif_mengujita_seminarproposal
        {
            get { return m_tarif_mengujita_seminarproposal; }
            set { m_tarif_mengujita_seminarproposal = value; }
        }
        public decimal tarif_mengujita_seminarprogress
        {
            get { return m_tarif_mengujita_seminarprogress; }
            set { m_tarif_mengujita_seminarprogress = value; }
        }
        public decimal tarif_mengujita_sidang
        {
            get { return m_tarif_mengujita_sidang; }
            set { m_tarif_mengujita_sidang = value; }
        }
        public decimal tarif_mengujipa_seminarproposal
        {
            get { return m_tarif_mengujipa_seminarproposal; }
            set { m_tarif_mengujipa_seminarproposal = value; }
        }
        public decimal tarif_mengujipa_seminarakhir
        {
            get { return m_tarif_mengujipa_seminarakhir; }
            set { m_tarif_mengujipa_seminarakhir = value; }
        }
        public decimal tarif_mengujita_kompre
        {
            get { return m_tarif_mengujita_kompre; }
            set { m_tarif_mengujita_kompre = value; }
        }
        public decimal tarif_menyusunbahanajar
        {
            get { return m_tarif_menyusunbahanajar; }
            set { m_tarif_menyusunbahanajar = value; }
        }
        public decimal tarif_menyusunmodul
        {
            get { return m_tarif_menyusunmodul; }
            set { m_tarif_menyusunmodul = value; }
        }
        public String tahun
        {
            get { return m_tahun; }
            set { m_tahun = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public decimal tarif_dosenwali
        {
            get { return m_tarif_dosenwali; }
            set { m_tarif_dosenwali = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_tarif_honor(tarif_honorid,program,jurusanid,jenjangakademikid,status,tarif_mengajar,tarif_praktikummesin,tarif_penyusunsoal,tarif_koreksi,tarif_mengawas,tarif_membimbingta,tarif_membimbingpa,tarif_pengampu,tarif_menyiapkansapgbpp,tarif_mengujita_seminarproposal,tarif_mengujita_seminarprogress,tarif_mengujita_sidang,tarif_mengujipa_seminarproposal,tarif_mengujipa_seminarakhir,tarif_mengujita_kompre,tarif_menyusunbahanajar,tarif_menyusunmodul,tahun,nourut,op_add,pc_add,lu_add,dlt,tarif_dosenwali)" +
                            "VALUES" +
                            "(@tarif_honorid,@program,@jurusanid,@jenjangakademikid,@status,@tarif_mengajar,@tarif_praktikummesin,@tarif_penyusunsoal,@tarif_koreksi,@tarif_mengawas,@tarif_membimbingta,@tarif_membimbingpa,@tarif_pengampu,@tarif_menyiapkansapgbpp,@tarif_mengujita_seminarproposal,@tarif_mengujita_seminarprogress,@tarif_mengujita_sidang,@tarif_mengujipa_seminarproposal,@tarif_mengujipa_seminarakhir,@tarif_mengujita_kompre,@tarif_menyusunbahanajar,@tarif_menyusunmodul,@tahun,@nourut,@op_add,@pc_add,now(),@dlt,@tarif_dosenwali)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (tarif_honorid != null)
            {
                cmd.Parameters.Add("@tarif_honorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tarif_honorid;
            }
            else
            {
                cmd.Parameters.Add("@tarif_honorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (program != null)
            {
                cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = program;
            }
            else
            {
                cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jurusanid != null)
            {
                cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jurusanid;
            }
            else
            {
                cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenjangakademikid != null)
            {
                cmd.Parameters.Add("@jenjangakademikid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenjangakademikid;
            }
            else
            {
                cmd.Parameters.Add("@jenjangakademikid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null)
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@tarif_mengajar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengajar;
            cmd.Parameters.Add("@tarif_praktikummesin", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_praktikummesin;
            cmd.Parameters.Add("@tarif_penyusunsoal", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_penyusunsoal;
            cmd.Parameters.Add("@tarif_koreksi", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_koreksi;
            cmd.Parameters.Add("@tarif_mengawas", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengawas;
            cmd.Parameters.Add("@tarif_membimbingta", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_membimbingta;
            cmd.Parameters.Add("@tarif_membimbingpa", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_membimbingpa;
            cmd.Parameters.Add("@tarif_pengampu", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pengampu;
            cmd.Parameters.Add("@tarif_menyiapkansapgbpp", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_menyiapkansapgbpp;
            cmd.Parameters.Add("@tarif_mengujita_seminarproposal", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_seminarproposal;
            cmd.Parameters.Add("@tarif_mengujita_seminarprogress", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_seminarprogress;
            cmd.Parameters.Add("@tarif_mengujita_sidang", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_sidang;
            cmd.Parameters.Add("@tarif_mengujipa_seminarproposal", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujipa_seminarproposal;
            cmd.Parameters.Add("@tarif_mengujipa_seminarakhir", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujipa_seminarakhir;
            cmd.Parameters.Add("@tarif_mengujita_kompre", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_kompre;
            cmd.Parameters.Add("@tarif_menyusunbahanajar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_menyusunbahanajar;
            cmd.Parameters.Add("@tarif_menyusunmodul", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_menyusunmodul;
            if (tahun != null)
            {
                cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
                cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null)
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null)
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.Parameters.Add("@tarif_dosenwali", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_dosenwali;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_tarif_honor SET " +
                            " tarif_honorid=@tarif_honorid,program=@program,jurusanid=@jurusanid,jenjangakademikid=@jenjangakademikid,status=@status,tarif_mengajar=@tarif_mengajar,tarif_praktikummesin=@tarif_praktikummesin,tarif_penyusunsoal=@tarif_penyusunsoal,tarif_koreksi=@tarif_koreksi,tarif_mengawas=@tarif_mengawas,tarif_membimbingta=@tarif_membimbingta,tarif_membimbingpa=@tarif_membimbingpa,tarif_pengampu=@tarif_pengampu,tarif_menyiapkansapgbpp=@tarif_menyiapkansapgbpp,tarif_mengujita_seminarproposal=@tarif_mengujita_seminarproposal,tarif_mengujita_seminarprogress=@tarif_mengujita_seminarprogress,tarif_mengujita_sidang=@tarif_mengujita_sidang,tarif_mengujipa_seminarproposal=@tarif_mengujipa_seminarproposal,tarif_mengujipa_seminarakhir=@tarif_mengujipa_seminarakhir,tarif_mengujita_kompre=@tarif_mengujita_kompre,tarif_menyusunbahanajar=@tarif_menyusunbahanajar,tarif_menyusunmodul=@tarif_menyusunmodul,tahun=@tahun,nourut=@nourut,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt=@dlt,tarif_dosenwali=@tarif_dosenwali" +
                            " WHERE tarif_honorid=@tarif_honorid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (tarif_honorid != null)
            {
                cmd.Parameters.Add("@tarif_honorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tarif_honorid;
            }
            else
            {
                cmd.Parameters.Add("@tarif_honorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (program != null)
            {
                cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = program;
            }
            else
            {
                cmd.Parameters.Add("@program", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jurusanid != null)
            {
                cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jurusanid;
            }
            else
            {
                cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenjangakademikid != null)
            {
                cmd.Parameters.Add("@jenjangakademikid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenjangakademikid;
            }
            else
            {
                cmd.Parameters.Add("@jenjangakademikid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null)
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@tarif_mengajar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengajar;
            cmd.Parameters.Add("@tarif_praktikummesin", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_praktikummesin;
            cmd.Parameters.Add("@tarif_penyusunsoal", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_penyusunsoal;
            cmd.Parameters.Add("@tarif_koreksi", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_koreksi;
            cmd.Parameters.Add("@tarif_mengawas", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengawas;
            cmd.Parameters.Add("@tarif_membimbingta", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_membimbingta;
            cmd.Parameters.Add("@tarif_membimbingpa", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_membimbingpa;
            cmd.Parameters.Add("@tarif_pengampu", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_pengampu;
            cmd.Parameters.Add("@tarif_menyiapkansapgbpp", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_menyiapkansapgbpp;
            cmd.Parameters.Add("@tarif_mengujita_seminarproposal", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_seminarproposal;
            cmd.Parameters.Add("@tarif_mengujita_seminarprogress", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_seminarprogress;
            cmd.Parameters.Add("@tarif_mengujita_sidang", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_sidang;
            cmd.Parameters.Add("@tarif_mengujipa_seminarproposal", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujipa_seminarproposal;
            cmd.Parameters.Add("@tarif_mengujipa_seminarakhir", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujipa_seminarakhir;
            cmd.Parameters.Add("@tarif_mengujita_kompre", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_mengujita_kompre;
            cmd.Parameters.Add("@tarif_menyusunbahanajar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_menyusunbahanajar;
            cmd.Parameters.Add("@tarif_menyusunmodul", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_menyusunmodul;
            if (tahun != null)
            {
                cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
                cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null)
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
                cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null)
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
                cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
                cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
                cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.Parameters.Add("@tarif_dosenwali", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tarif_dosenwali;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tbp_tarif_honor WHERE tarif_honorid=@tarif_honorid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@tarif_honorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tarif_honorid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbp_tarif_honor SET DLT=true , op_edit=@op_edit, pc_edit=@pc_edit, lu_edit=now() WHERE tarif_honorid=@tarif_honorid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@tarif_honorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tarif_honorid;
            cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
            cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tbp_tarif_honor WHERE tarif_honorid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_honorid")))
                    {
                        m_tarif_honorid = rdr.GetString(rdr.GetOrdinal("tarif_honorid"));
                    }
                    else
                    {
                        m_tarif_honorid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("program")))
                    {
                        m_program = rdr.GetString(rdr.GetOrdinal("program"));
                    }
                    else
                    {
                        m_program = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jurusanid")))
                    {
                        m_jurusanid = rdr.GetString(rdr.GetOrdinal("jurusanid"));
                    }
                    else
                    {
                        m_jurusanid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jenjangakademikid")))
                    {
                        m_jenjangakademikid = rdr.GetString(rdr.GetOrdinal("jenjangakademikid"));
                    }
                    else
                    {
                        m_jenjangakademikid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("status")))
                    {
                        m_status = rdr.GetString(rdr.GetOrdinal("status"));
                    }
                    else
                    {
                        m_status = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengajar")))
                    {
                        m_tarif_mengajar = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengajar"));
                    }
                    else
                    {
                        m_tarif_mengajar = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_praktikummesin")))
                    {
                        m_tarif_praktikummesin = rdr.GetDecimal(rdr.GetOrdinal("tarif_praktikummesin"));
                    }
                    else
                    {
                        m_tarif_praktikummesin = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_penyusunsoal")))
                    {
                        m_tarif_penyusunsoal = rdr.GetDecimal(rdr.GetOrdinal("tarif_penyusunsoal"));
                    }
                    else
                    {
                        m_tarif_penyusunsoal = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_koreksi")))
                    {
                        m_tarif_koreksi = rdr.GetDecimal(rdr.GetOrdinal("tarif_koreksi"));
                    }
                    else
                    {
                        m_tarif_koreksi = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengawas")))
                    {
                        m_tarif_mengawas = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengawas"));
                    }
                    else
                    {
                        m_tarif_mengawas = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_membimbingta")))
                    {
                        m_tarif_membimbingta = rdr.GetDecimal(rdr.GetOrdinal("tarif_membimbingta"));
                    }
                    else
                    {
                        m_tarif_membimbingta = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_membimbingpa")))
                    {
                        m_tarif_membimbingpa = rdr.GetDecimal(rdr.GetOrdinal("tarif_membimbingpa"));
                    }
                    else
                    {
                        m_tarif_membimbingpa = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_pengampu")))
                    {
                        m_tarif_pengampu = rdr.GetDecimal(rdr.GetOrdinal("tarif_pengampu"));
                    }
                    else
                    {
                        m_tarif_pengampu = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_menyiapkansapgbpp")))
                    {
                        m_tarif_menyiapkansapgbpp = rdr.GetDecimal(rdr.GetOrdinal("tarif_menyiapkansapgbpp"));
                    }
                    else
                    {
                        m_tarif_menyiapkansapgbpp = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengujita_seminarproposal")))
                    {
                        m_tarif_mengujita_seminarproposal = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengujita_seminarproposal"));
                    }
                    else
                    {
                        m_tarif_mengujita_seminarproposal = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengujita_seminarprogress")))
                    {
                        m_tarif_mengujita_seminarprogress = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengujita_seminarprogress"));
                    }
                    else
                    {
                        m_tarif_mengujita_seminarprogress = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengujita_sidang")))
                    {
                        m_tarif_mengujita_sidang = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengujita_sidang"));
                    }
                    else
                    {
                        m_tarif_mengujita_sidang = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengujipa_seminarproposal")))
                    {
                        m_tarif_mengujipa_seminarproposal = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengujipa_seminarproposal"));
                    }
                    else
                    {
                        m_tarif_mengujipa_seminarproposal = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengujipa_seminarakhir")))
                    {
                        m_tarif_mengujipa_seminarakhir = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengujipa_seminarakhir"));
                    }
                    else
                    {
                        m_tarif_mengujipa_seminarakhir = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_mengujita_kompre")))
                    {
                        m_tarif_mengujita_kompre = rdr.GetDecimal(rdr.GetOrdinal("tarif_mengujita_kompre"));
                    }
                    else
                    {
                        m_tarif_mengujita_kompre = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_menyusunbahanajar")))
                    {
                        m_tarif_menyusunbahanajar = rdr.GetDecimal(rdr.GetOrdinal("tarif_menyusunbahanajar"));
                    }
                    else
                    {
                        m_tarif_menyusunbahanajar = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_menyusunmodul")))
                    {
                        m_tarif_menyusunmodul = rdr.GetDecimal(rdr.GetOrdinal("tarif_menyusunmodul"));
                    }
                    else
                    {
                        m_tarif_menyusunmodul = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tahun")))
                    {
                        m_tahun = rdr.GetString(rdr.GetOrdinal("tahun"));
                    }
                    else
                    {
                        m_tahun = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("nourut")))
                    {
                        m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
                    }
                    else
                    {
                        m_nourut = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("op_add")))
                    {
                        m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
                    }
                    else
                    {
                        m_op_add = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add")))
                    {
                        m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
                    }
                    else
                    {
                        m_pc_add = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add")))
                    {
                        m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
                    }
                    else
                    {
                        m_lu_add = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit")))
                    {
                        m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
                    }
                    else
                    {
                        m_op_edit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit")))
                    {
                        m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
                    }
                    else
                    {
                        m_pc_edit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit")))
                    {
                        m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
                    }
                    else
                    {
                        m_lu_edit = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dlt")))
                    {
                        m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                    }
                    else
                    {
                        m_dlt = false;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tarif_dosenwali")))
                    {
                        m_tarif_dosenwali = rdr.GetDecimal(rdr.GetOrdinal("tarif_dosenwali"));
                    }
                    else
                    {
                        m_tarif_dosenwali = 0;
                    };
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbp_tarif_honor");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbp_tarif_honor");
            return dt;
        }

        public System.Data.DataTable GetData(string strSQL)
        {
            if (strSQL == "")
            {
                strSQL = "select * from tbp_tarif_honor where dlt='0' ";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbp_tarif_honor");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbp_tarif_honor");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_tarif_honor_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}