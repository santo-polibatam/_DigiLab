﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstblpengembaliandetails
    {
        private String m_pengembaliandetailsid;
        private String m_pengembalianid;
        private String m_peminjamandetailsid;
        private DateTime m_tglkembali;
        private decimal m_jumlah;
        private String m_status;
        private String m_keterangan;
        private decimal m_jumlahdenda;
        private decimal m_dendadibayar;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pengembaliandetailsid
        {
            get { return m_pengembaliandetailsid; }
            set { m_pengembaliandetailsid = value; }
        }
        public String pengembalianid
        {
            get { return m_pengembalianid; }
            set { m_pengembalianid = value; }
        }
        public String peminjamandetailsid
        {
            get { return m_peminjamandetailsid; }
            set { m_peminjamandetailsid = value; }
        }
        public DateTime tglkembali
        {
            get { return m_tglkembali; }
            set { m_tglkembali = value; }
        }
        public decimal jumlah
        {
            get { return m_jumlah; }
            set { m_jumlah = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }
        public String keterangan
        {
            get { return m_keterangan; }
            set { m_keterangan = value; }
        }
        public decimal jumlahdenda
        {
            get { return m_jumlahdenda; }
            set { m_jumlahdenda = value; }
        }
        public decimal dendadibayar
        {
            get { return m_dendadibayar; }
            set { m_dendadibayar = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tblpengembaliandetails(pengembaliandetailsid,pengembalianid,peminjamandetailsid,tglkembali,jumlah,status,keterangan,jumlahdenda,dendadibayar,opadd,pcadd,luadd,dlt)"+
                            "VALUES"+
                            "(@pengembaliandetailsid,@pengembalianid,@peminjamandetailsid,@tglkembali,@jumlah,@status,@keterangan,@jumlahdenda,@dendadibayar,@opadd,@pcadd,now(),@dlt)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengembaliandetailsid != null )
            {
               cmd.Parameters.Add("@pengembaliandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembaliandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pengembaliandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengembalianid != null )
            {
               cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembalianid;
            }
            else
            {
               cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (peminjamandetailsid != null )
            {
               cmd.Parameters.Add("@peminjamandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = peminjamandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@peminjamandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglkembali != null && tglkembali != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglkembali;
            }
            else
            {
               cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jumlah", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlah;
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null )
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jumlahdenda", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahdenda;
               cmd.Parameters.Add("@dendadibayar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = dendadibayar;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tblpengembaliandetails SET "+
                            " pengembaliandetailsid=@pengembaliandetailsid,pengembalianid=@pengembalianid,peminjamandetailsid=@peminjamandetailsid,tglkembali=@tglkembali,jumlah=@jumlah,status=@status,keterangan=@keterangan,jumlahdenda=@jumlahdenda,dendadibayar=@dendadibayar,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt=@dlt"+
                            " WHERE pengembaliandetailsid=@pengembaliandetailsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengembaliandetailsid != null )
            {
               cmd.Parameters.Add("@pengembaliandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembaliandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pengembaliandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengembalianid != null )
            {
               cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembalianid;
            }
            else
            {
               cmd.Parameters.Add("@pengembalianid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (peminjamandetailsid != null )
            {
               cmd.Parameters.Add("@peminjamandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = peminjamandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@peminjamandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglkembali != null && tglkembali != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglkembali;
            }
            else
            {
               cmd.Parameters.Add("@tglkembali", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jumlah", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlah;
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null )
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@jumlahdenda", NpgsqlTypes.NpgsqlDbType.Numeric).Value = jumlahdenda;
               cmd.Parameters.Add("@dendadibayar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = dendadibayar;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tblpengembaliandetails WHERE pengembaliandetailsid=@pengembaliandetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pengembaliandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembaliandetailsid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tblpengembaliandetails SET DLT=true , opedit=@opedit, pcedit=@pcedit, luedit=now() WHERE pengembaliandetailsid=@pengembaliandetailsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
               cmd.Parameters.Add("@pengembaliandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengembaliandetailsid;
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tblpengembaliandetails WHERE pengembaliandetailsid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengembaliandetailsid"))) 
            {
              m_pengembaliandetailsid = rdr.GetString(rdr.GetOrdinal("pengembaliandetailsid"));
            }
            else
            {
              m_pengembaliandetailsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengembalianid"))) 
            {
              m_pengembalianid = rdr.GetString(rdr.GetOrdinal("pengembalianid"));
            }
            else
            {
              m_pengembalianid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("peminjamandetailsid"))) 
            {
              m_peminjamandetailsid = rdr.GetString(rdr.GetOrdinal("peminjamandetailsid"));
            }
            else
            {
              m_peminjamandetailsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tglkembali"))) 
            {
              m_tglkembali = rdr.GetDateTime(rdr.GetOrdinal("tglkembali"));
            }
            else
            {
              m_tglkembali = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jumlah"))) 
            {
              m_jumlah = rdr.GetDecimal(rdr.GetOrdinal("jumlah"));
            }
            else
            {
              m_jumlah = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("status"))) 
            {
              m_status = rdr.GetString(rdr.GetOrdinal("status"));
            }
            else
            {
              m_status = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("keterangan"))) 
            {
              m_keterangan = rdr.GetString(rdr.GetOrdinal("keterangan"));
            }
            else
            {
              m_keterangan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jumlahdenda"))) 
            {
              m_jumlahdenda = rdr.GetDecimal(rdr.GetOrdinal("jumlahdenda"));
            }
            else
            {
              m_jumlahdenda = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dendadibayar"))) 
            {
              m_dendadibayar = rdr.GetDecimal(rdr.GetOrdinal("dendadibayar"));
            }
            else
            {
              m_dendadibayar = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opadd"))) 
            {
              m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
            }
            else
            {
              m_opadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd"))) 
            {
              m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
            }
            else
            {
              m_pcadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luadd"))) 
            {
              m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
            }
            else
            {
              m_luadd = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opedit"))) 
            {
              m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
            }
            else
            {
              m_opedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit"))) 
            {
              m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
            }
            else
            {
              m_pcedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luedit"))) 
            {
              m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
            }
            else
            {
              m_luedit = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dlt"))) 
            {
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            }
            else
            {
              m_dlt = false;
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tblpengembaliandetails");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tblpengembaliandetails");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tblpengembaliandetails where dlt='0' ";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi); 
         cmd.CommandTimeout = 0; 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tblpengembaliandetails");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tblpengembaliandetails");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         cmd.CommandTimeout = 0;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tblpengembaliandetails_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
