﻿using Microsoft.Win32;
using System.Net;
using System;

namespace Library
{
    public class clsAutoUpdate
    {
        private string m_DateUpdate;
        private string m_IsUpdated;//1=Yes; 2=No

        public string DateUpdate
        {
            get { return m_DateUpdate; }
            set { m_DateUpdate = value; }
        }

        public string IsUpdated
        {
            get { return m_IsUpdated; }
            set { m_IsUpdated = value; }
        }

        private void saveUpdatingInfo()
        {
            RegistryKey regKey;
            regKey = Registry.CurrentUser.OpenSubKey(clsGlobal.s_FullRegKey, true);
            if (regKey == null)
            {
                regKey = Registry.CurrentUser.OpenSubKey(clsGlobal.s_RegKey, true);
                regKey.CreateSubKey(clsGlobal.s_SubKey);
                regKey.Close();
            }

            regKey = Registry.CurrentUser.OpenSubKey(clsGlobal.s_FullRegKey, true);
            regKey.SetValue("dateupdate", DateUpdate);
            regKey.SetValue("isupdated", IsUpdated);

            regKey.Flush();
            regKey.Close();
        }

        private void getUpdatingInfo()
        {
            RegistryKey regKey;
            regKey = Registry.CurrentUser.OpenSubKey(clsGlobal.s_FullRegKey, true);
            if (regKey != null)
            {
                DateUpdate = (regKey.GetValue("dateupdate") == null ? "" : regKey.GetValue("dateupdate").ToString());
                IsUpdated = (regKey.GetValue("isupdated") == null ? "" : regKey.GetValue("isupdated").ToString());
            }
            else
            {
                DateUpdate = "";
                IsUpdated = "";
            }
        }

        public bool IsAppUpdatedToday()
        {
            bool bIsUpdated = false;
            string sDateToday;
            sDateToday = DateTime.Now.ToShortDateString();
            getUpdatingInfo();

            if (DateUpdate != "")
            {
                if (DateUpdate != sDateToday)
                {
                    bIsUpdated = false; //maybe wrong date = not updated yet
                }
                else
                {
                    bIsUpdated = false;
                    switch (IsUpdated)
                    {
                        case "": //missing information = not updated yet
                            bIsUpdated = false;
                            break;
                        case "1": //updated already
                            bIsUpdated = true;
                            break;
                        case "2": //not updated yet
                            bIsUpdated = false;
                            break;
                    }
                }
            }
            else //dateupdate ="" -> so missing information when app has been updated
            // this is similar to not updated yet :)
            {
                bIsUpdated = false;
            }
            return bIsUpdated;
        }

        public void DoUpdateApp(string cmdLine, string updateFilename)
        {
            try
            {
                //Dim startInfo As New ProcessStartInfo(Application.StartupPath & "\" & "updateapp.exe")
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo(Environment.CurrentDirectory.ToString() + "\\" + updateFilename);

                string variable = Environment.GetEnvironmentVariable("myEnv");

                //System.Windows.Forms.MessageBox.Show(variable + startInfo.EnvironmentVariables.ContainsKey("myEnv").ToString());
                if (!startInfo.EnvironmentVariables.ContainsKey("myEnv"))
                {
                    startInfo.EnvironmentVariables.Add("myEnv", cmdLine);
                    startInfo.UseShellExecute = false;

                } 
                System.Diagnostics.Process.Start(startInfo);
                
            }
            catch(Exception e)
            {
                //System.Windows.Forms.MessageBox.Show(e.Message);
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo(Environment.CurrentDirectory.ToString() + "\\" + updateFilename);
                
                startInfo.UseShellExecute = false;
                System.Diagnostics.Process.Start(startInfo);
            }
            finally
            {
                DateUpdate = DateTime.Now.ToShortDateString();
                IsUpdated = "1";

                saveUpdatingInfo(); 
                Environment.Exit(1);
            }
        }
    }
}