﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbm_prodi
    {
        private String m_prodiid;
        private String m_jurusanid;
        private String m_inisial;
        private String m_prodicode;
        private String m_prodidesc;
        private String m_remarks;
        private decimal m_nourut;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String jurusanid
        {
            get { return m_jurusanid; }
            set { m_jurusanid = value; }
        }
        public String inisial
        {
            get { return m_inisial; }
            set { m_inisial = value; }
        }
        public String prodicode
        {
            get { return m_prodicode; }
            set { m_prodicode = value; }
        }
        public String prodidesc
        {
            get { return m_prodidesc; }
            set { m_prodidesc = value; }
        }
        public String remarks
        {
            get { return m_remarks; }
            set { m_remarks = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_prodi(prodiid,jurusanid,inisial,prodicode,prodidesc,remarks,nourut,opadd,pcadd,luadd,dlt)"+
                            "VALUES"+
                            "(@prodiid,@jurusanid,@inisial,@prodicode,@prodidesc,@remarks,@nourut,@opadd,@pcadd,now(),'0')";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jurusanid != null )
            {
               cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jurusanid;
            }
            else
            {
               cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (inisial != null )
            {
               cmd.Parameters.Add("@inisial", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inisial;
            }
            else
            {
               cmd.Parameters.Add("@inisial", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodicode != null )
            {
               cmd.Parameters.Add("@prodicode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodicode;
            }
            else
            {
               cmd.Parameters.Add("@prodicode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodidesc != null )
            {
               cmd.Parameters.Add("@prodidesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodidesc;
            }
            else
            {
               cmd.Parameters.Add("@prodidesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_prodi SET "+
                            " prodiid=@prodiid,jurusanid=@jurusanid,inisial=@inisial,prodicode=@prodicode,prodidesc=@prodidesc,remarks=@remarks,nourut=@nourut,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt='0'"+
                            " WHERE prodiid=@prodiid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jurusanid != null )
            {
               cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jurusanid;
            }
            else
            {
               cmd.Parameters.Add("@jurusanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (inisial != null )
            {
               cmd.Parameters.Add("@inisial", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inisial;
            }
            else
            {
               cmd.Parameters.Add("@inisial", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodicode != null )
            {
               cmd.Parameters.Add("@prodicode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodicode;
            }
            else
            {
               cmd.Parameters.Add("@prodicode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodidesc != null )
            {
               cmd.Parameters.Add("@prodidesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodidesc;
            }
            else
            {
               cmd.Parameters.Add("@prodidesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbm_prodi WHERE prodiid=@prodiid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbm_prodi SET DLT='1', opedit=@opedit,pcedit=@pcedit,luedit=now() WHERE prodiid=@prodiid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbm_prodi WHERE prodiid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid"))) 
            {
              m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
            }
            else
            {
              m_prodiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jurusanid"))) 
            {
              m_jurusanid = rdr.GetString(rdr.GetOrdinal("jurusanid"));
            }
            else
            {
              m_jurusanid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("inisial"))) 
            {
              m_inisial = rdr.GetString(rdr.GetOrdinal("inisial"));
            }
            else
            {
              m_inisial = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodicode"))) 
            {
              m_prodicode = rdr.GetString(rdr.GetOrdinal("prodicode"));
            }
            else
            {
              m_prodicode = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodidesc"))) 
            {
              m_prodidesc = rdr.GetString(rdr.GetOrdinal("prodidesc"));
            }
            else
            {
              m_prodidesc = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("remarks"))) 
            {
              m_remarks = rdr.GetString(rdr.GetOrdinal("remarks"));
            }
            else
            {
              m_remarks = "";
            };
            m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("opadd"))) 
            {
              m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
            }
            else
            {
              m_opadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd"))) 
            {
              m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
            }
            else
            {
              m_pcadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luadd"))) 
            {
              m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
            }
            else
            {
              m_luadd = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opedit"))) 
            {
              m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
            }
            else
            {
              m_opedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit"))) 
            {
              m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
            }
            else
            {
              m_pcedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luedit"))) 
            {
              m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
            }
            else
            {
              m_luedit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_prodi");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_prodi");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbm_prodi";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_prodi");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_prodi");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbm_prodi_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
