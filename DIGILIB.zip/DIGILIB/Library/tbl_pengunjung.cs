﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbl_pengunjung
    {
        private String m_pengunjungid;
        private String m_anggotaid;
        private String m_cardno;
        private String m_pin;
        private String m_verified;
        private String m_doorid;
        private String m_eventtype;
        private String m_inoutstate;
        private decimal m_time_second;
        private DateTime m_time_second2;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pengunjungid
        {
            get { return m_pengunjungid; }
            set { m_pengunjungid = value; }
        }
        public String anggotaid
        {
            get { return m_anggotaid; }
            set { m_anggotaid = value; }
        }
        public String cardno
        {
            get { return m_cardno; }
            set { m_cardno = value; }
        }
        public String pin
        {
            get { return m_pin; }
            set { m_pin = value; }
        }
        public String verified
        {
            get { return m_verified; }
            set { m_verified = value; }
        }
        public String doorid
        {
            get { return m_doorid; }
            set { m_doorid = value; }
        }
        public String eventtype
        {
            get { return m_eventtype; }
            set { m_eventtype = value; }
        }
        public String inoutstate
        {
            get { return m_inoutstate; }
            set { m_inoutstate = value; }
        }
        public decimal time_second
        {
            get { return m_time_second; }
            set { m_time_second = value; }
        }
        public DateTime time_second2
        {
            get { return m_time_second2; }
            set { m_time_second2 = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbl_pengunjung(pengunjungid,anggotaid,cardno,pin,verified,doorid,eventtype,inoutstate,time_second,time_second2,opadd,pcadd,luadd,dlt)" +
                            "VALUES" +
                            "(@pengunjungid,@anggotaid,@cardno,@pin,@verified,@doorid,@eventtype,@inoutstate,@time_second,@time_second2,@opadd,@pcadd,now(),'0')";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengunjungid != null)
            {
                cmd.Parameters.Add("@pengunjungid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengunjungid;
            }
            else
            {
                cmd.Parameters.Add("@pengunjungid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anggotaid != null)
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
            }
            else
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (cardno != null)
            {
                cmd.Parameters.Add("@cardno", NpgsqlTypes.NpgsqlDbType.Varchar).Value = cardno;
            }
            else
            {
                cmd.Parameters.Add("@cardno", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pin != null)
            {
                cmd.Parameters.Add("@pin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pin;
            }
            else
            {
                cmd.Parameters.Add("@pin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (verified != null)
            {
                cmd.Parameters.Add("@verified", NpgsqlTypes.NpgsqlDbType.Varchar).Value = verified;
            }
            else
            {
                cmd.Parameters.Add("@verified", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (doorid != null)
            {
                cmd.Parameters.Add("@doorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = doorid;
            }
            else
            {
                cmd.Parameters.Add("@doorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (eventtype != null)
            {
                cmd.Parameters.Add("@eventtype", NpgsqlTypes.NpgsqlDbType.Varchar).Value = eventtype;
            }
            else
            {
                cmd.Parameters.Add("@eventtype", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (inoutstate != null)
            {
                cmd.Parameters.Add("@inoutstate", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inoutstate;
            }
            else
            {
                cmd.Parameters.Add("@inoutstate", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@time_second", NpgsqlTypes.NpgsqlDbType.Numeric).Value = time_second;
            if (time_second2 != null && time_second2 != DateTime.MinValue)
            {
                cmd.Parameters.Add("@time_second2", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = time_second2;
            }
            else
            {
                cmd.Parameters.Add("@time_second2", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbl_pengunjung SET " +
                            " pengunjungid=@pengunjungid,anggotaid=@anggotaid,cardno=@cardno,pin=@pin,verified=@verified,doorid=@doorid,eventtype=@eventtype,inoutstate=@inoutstate,time_second=@time_second,time_second2=@time_second2,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt='0'" +
                            " WHERE pengunjungid=@pengunjungid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pengunjungid != null)
            {
                cmd.Parameters.Add("@pengunjungid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengunjungid;
            }
            else
            {
                cmd.Parameters.Add("@pengunjungid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anggotaid != null)
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
            }
            else
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (cardno != null)
            {
                cmd.Parameters.Add("@cardno", NpgsqlTypes.NpgsqlDbType.Varchar).Value = cardno;
            }
            else
            {
                cmd.Parameters.Add("@cardno", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pin != null)
            {
                cmd.Parameters.Add("@pin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pin;
            }
            else
            {
                cmd.Parameters.Add("@pin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (verified != null)
            {
                cmd.Parameters.Add("@verified", NpgsqlTypes.NpgsqlDbType.Varchar).Value = verified;
            }
            else
            {
                cmd.Parameters.Add("@verified", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (doorid != null)
            {
                cmd.Parameters.Add("@doorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = doorid;
            }
            else
            {
                cmd.Parameters.Add("@doorid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (eventtype != null)
            {
                cmd.Parameters.Add("@eventtype", NpgsqlTypes.NpgsqlDbType.Varchar).Value = eventtype;
            }
            else
            {
                cmd.Parameters.Add("@eventtype", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (inoutstate != null)
            {
                cmd.Parameters.Add("@inoutstate", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inoutstate;
            }
            else
            {
                cmd.Parameters.Add("@inoutstate", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@time_second", NpgsqlTypes.NpgsqlDbType.Numeric).Value = time_second;
            if (time_second2 != null && time_second2 != DateTime.MinValue)
            {
                cmd.Parameters.Add("@time_second2", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = time_second2;
            }
            else
            {
                cmd.Parameters.Add("@time_second2", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tbl_pengunjung WHERE pengunjungid=@pengunjungid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pengunjungid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengunjungid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbl_pengunjung SET DLT=true,opedit=@opedit,pcedit=@pcedit,luedit=now() " +
                             " WHERE pengunjungid=@pengunjungid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@pengunjungid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengunjungid;
            cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strEmployeeName;
            cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tbl_pengunjung WHERE pengunjungid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pengunjungid")))
                    {
                        m_pengunjungid = rdr.GetString(rdr.GetOrdinal("pengunjungid"));
                    }
                    else
                    {
                        m_pengunjungid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("anggotaid")))
                    {
                        m_anggotaid = rdr.GetString(rdr.GetOrdinal("anggotaid"));
                    }
                    else
                    {
                        m_anggotaid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("cardno")))
                    {
                        m_cardno = rdr.GetString(rdr.GetOrdinal("cardno"));
                    }
                    else
                    {
                        m_cardno = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pin")))
                    {
                        m_pin = rdr.GetString(rdr.GetOrdinal("pin"));
                    }
                    else
                    {
                        m_pin = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("verified")))
                    {
                        m_verified = rdr.GetString(rdr.GetOrdinal("verified"));
                    }
                    else
                    {
                        m_verified = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("doorid")))
                    {
                        m_doorid = rdr.GetString(rdr.GetOrdinal("doorid"));
                    }
                    else
                    {
                        m_doorid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("eventtype")))
                    {
                        m_eventtype = rdr.GetString(rdr.GetOrdinal("eventtype"));
                    }
                    else
                    {
                        m_eventtype = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("inoutstate")))
                    {
                        m_inoutstate = rdr.GetString(rdr.GetOrdinal("inoutstate"));
                    }
                    else
                    {
                        m_inoutstate = "";
                    };
                    m_time_second = rdr.GetDecimal(rdr.GetOrdinal("time_second"));
                    if (!rdr.IsDBNull(rdr.GetOrdinal("time_second2")))
                    {
                        m_time_second2 = rdr.GetDateTime(rdr.GetOrdinal("time_second2"));
                    }
                    else
                    {
                        m_time_second2 = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opadd")))
                    {
                        m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
                    }
                    else
                    {
                        m_opadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd")))
                    {
                        m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
                    }
                    else
                    {
                        m_pcadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luadd")))
                    {
                        m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
                    }
                    else
                    {
                        m_luadd = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opedit")))
                    {
                        m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
                    }
                    else
                    {
                        m_opedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit")))
                    {
                        m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
                    }
                    else
                    {
                        m_pcedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luedit")))
                    {
                        m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
                    }
                    else
                    {
                        m_luedit = System.DateTime.MinValue;
                    };
                    m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbl_pengunjung");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbl_pengunjung");
            return dt;
        }

        public System.Data.DataTable GetData(string strSQL)
        {
            if (strSQL == "")
            {
                strSQL = "select * from tbl_pengunjung";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbl_pengunjung");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbl_pengunjung");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.pstrservercode + "'||nextval('tbl_pengunjung_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}
