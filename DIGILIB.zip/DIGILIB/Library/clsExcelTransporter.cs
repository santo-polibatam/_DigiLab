﻿using System.Data.OleDb;
using GemBox.Spreadsheet;
using System.IO;
using System.Data;
using System;

namespace Library
{
    public abstract class clsExcelTransporter
    {

        protected string m_ExcelType;
        private string m_FileSource, m_SheetName;
        private int m_MultiThread;
        private string m_OriginalFileName, m_TranStatus;

        private string m_IPAddress;

        public int MultiThread
        {
            get { return m_MultiThread; }
            set { m_MultiThread = value; }
        }

        public string FileSource
        {
            get { return m_FileSource; }
            set { m_FileSource = value; }
        }

        public string ExcelType
        {
            get { return m_ExcelType; }
            set { m_ExcelType = value; }
        }

        public string SheetName
        {
            get { return m_SheetName; }
            set { m_SheetName = value; }
        }

        protected string m_FirstSheetName;
        public string FirstSheetName
        {
            get { return m_FirstSheetName; }
            set { m_FirstSheetName = value; }
        }


        protected DataTable GetDataTemporary(string sTemporaryFilePath)
        {
            OleDbConnection oOleConn = new OleDbConnection();
            DataSet ds = new DataSet();
            DataTable dt = ds.Tables.Add("tblTemporary");
            DataTable dtSchema = ds.Tables.Add("tblExcelSchema");
            OleDbDataAdapter da;
            OleDbCommand cmd = new OleDbCommand();

            try
            {
                if (m_ExcelType == "XLS")
                {
                    oOleConn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sTemporaryFilePath + ";Extended Properties=Excel 8.0";
                    //cmd.CommandText = "SELECT * FROM [Sheet1$]";
                    cmd.CommandText = "SELECT * FROM [" + m_SheetName + "$]";
                }
                else if (m_ExcelType == "XLSX")
                {
                    oOleConn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sTemporaryFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=YES;IMEX=1;\"";
                    //cmd.CommandText = "SELECT * FROM [Sheet1$]";
                    cmd.CommandText = "SELECT * FROM [" + m_SheetName + "$]";
                    //Provider=Microsoft.ACE.OLEDB.12.0;Data Source=c:\myFolder\myExcel2007file.xlsx;Extended Properties="Excel 12.0;HDR=YES";
                    //Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|Data Directory|\HSC.xlsx;Extended Properties=Excel 12.0;HDR=YES;")
                }
                else if (m_ExcelType == "CSV")
                {
                    createSchemaFile(sTemporaryFilePath);
                    string sFolderVirtual = retrieveFolderVirtual();
                    oOleConn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sFolderVirtual + ";Extended Properties=\"Text;HDR=Yes;FMT=Delimited;\"";
                    cmd.CommandText = "SELECT * FROM [" + sTemporaryFilePath + "]";
                }
                cmd.Connection = oOleConn;
                oOleConn.Open();
                da = new OleDbDataAdapter(cmd);
                da.Fill(ds.Tables["tblTemporary"]);
                return dt;
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message));
            }
            finally
            {
                oOleConn.Close();
                destroyTemporaryFile(sTemporaryFilePath);
            }
        }


        protected DataTable GetDataTemporary(string sTemporaryFilePath, string sqlSelectArg)
        {
            OleDbConnection oOleConn = new OleDbConnection();
            DataSet ds = new DataSet();
            DataTable dt = ds.Tables.Add("tblTemporary");
            DataTable dtSchema = ds.Tables.Add("tblExcelSchema");
            OleDbDataAdapter da;
            OleDbCommand cmd = new OleDbCommand();

            try
            {
                if (m_ExcelType == "XLS")
                {
                    oOleConn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sTemporaryFilePath + ";Extended Properties=Excel 8.0";
                    //cmd.CommandText = "SELECT * FROM [Sheet1$]";
                    cmd.CommandText = sqlSelectArg + " FROM [" + m_SheetName + "$]";
                }
                else if (m_ExcelType == "XLSX")
                {
                    oOleConn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sTemporaryFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=YES;IMEX=1;\"";
                    //cmd.CommandText = "SELECT * FROM [Sheet1$]";
                    cmd.CommandText = sqlSelectArg + " FROM [" + m_SheetName + "$]";
                    //Provider=Microsoft.ACE.OLEDB.12.0;Data Source=c:\myFolder\myExcel2007file.xlsx;Extended Properties="Excel 12.0;HDR=YES";
                    //Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|Data Directory|\HSC.xlsx;Extended Properties=Excel 12.0;HDR=YES;")
                }
                else if (m_ExcelType == "CSV")
                {
                    createSchemaFile(sTemporaryFilePath);
                    string sFolderVirtual = retrieveFolderVirtual();
                    oOleConn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sFolderVirtual + ";Extended Properties=\"Text;HDR=Yes;FMT=Delimited;\"";
                    cmd.CommandText = sqlSelectArg + " FROM [" + sTemporaryFilePath + "]";
                }
                cmd.Connection = oOleConn;
                oOleConn.Open();
                da = new OleDbDataAdapter(cmd);
                da.Fill(ds.Tables["tblTemporary"]);
                return dt;
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message));
            }
            finally
            {
                oOleConn.Close();
                destroyTemporaryFile(sTemporaryFilePath);
            }
        }


        private void destroyTemporaryFile(string sTemporaryFilePath)
        {
            if (System.IO.File.Exists(sTemporaryFilePath))
                System.IO.File.Delete(sTemporaryFilePath);
        }

        private void createSchemaFile(string sFileName)
        {
            string sFolderVirtual = retrieveFolderVirtual();
            string sDataSource = sFolderVirtual;

            OleDbConnection oOleConn = new OleDbConnection();
            DataSet ds = new DataSet();
            OleDbDataAdapter da;
            OleDbCommand cmd = new OleDbCommand();
            DataTable dt = ds.Tables.Add("tblFileSchema");
            StreamWriter oWriter = null;
            try
            {
                if (File.Exists(sDataSource + "schema.ini"))
                    File.Delete(sDataSource + "schema.ini");

                oOleConn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sDataSource + ";Extended Properties=\"Text;HDR=Yes;FMT=CSVDelimited;\"";
                cmd.CommandText = "SELECT Top 1 * FROM [" + sFileName + "]";
                cmd.Connection = oOleConn;
                oOleConn.Open();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                string sCellField;
                oWriter = File.CreateText(sDataSource + "schema.ini");
                string sGeneratedString;
                sGeneratedString = "[" + sFileName + "]\nFormat=CSVDelimited\n";

                for (int iLoop = 0; iLoop == dt.Columns.Count - 1; iLoop++)
                {
                    sCellField = dt.Columns[iLoop].ColumnName.ToString();
                    sCellField = sCellField.Replace(" ", "");
                    sGeneratedString += "Col" + iLoop + 1 + "=" + sCellField + " text\n";
                }
                oWriter.WriteLine(sGeneratedString);
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message));
            }
            finally
            {
                oOleConn.Close();
                if (oWriter != null)
                    oWriter.Close();
            }
        }
        private string retrieveFolderVirtual()
        {
            string sFolderVirtual = "";
            if (MultiThread == 1)
                sFolderVirtual = @"" + clsGlobal.str_ApplicationName + @"\TABLEVIRTUAL\";
            else
                sFolderVirtual = @"" + clsGlobal.str_ApplicationName + @"\";

            return sFolderVirtual;
        }
        protected void CreateTemporaryFile(string sDestinationPath, string sTempFile)
        {
            string sFolderVirtual = "";
            try
            {
                if (m_ExcelType == "XLS" || m_ExcelType == "XLSX")
                {
                    SpreadsheetInfo.SetLicense("EQU1-4YRI-KEYA-HERE");
                    ExcelFile oExcelFile = new ExcelFile();
                    if (System.IO.File.Exists(sDestinationPath))
                        System.IO.File.Delete(sDestinationPath);
                    System.IO.File.Copy(FileSource, sDestinationPath);
                    //oExcelFile.LoadCsv(sTempFile, CsvType.TabDelimited)
                    //Dim oWs As ExcelWorksheet = oExcelFile.Worksheets(0) //first sheet without knowing name
                    //For Each row As ExcelRow In oWs.Rows
                    //For Each cell As ExcelCell In row.AllocatedCells
                    //Dim strVal As String = TryCast(cell.Value, String)
                    //if Not String.IsNullOrEmpty(strVal))
                    //cell.Value = strVal.Trim(CChar(ChrW(0)))
                    //End if
                    //Next
                    //Next
                    //oExcelFile.SaveXls(sDestinationPath)
                    //System.IO.File.Delete(sTempFile)
                }
                else if (m_ExcelType == "CSV")
                {
                    sFolderVirtual = retrieveFolderVirtual();

                    if (!System.IO.Directory.Exists(sFolderVirtual))
                        System.IO.Directory.CreateDirectory(sFolderVirtual);

                    if (System.IO.File.Exists(sFolderVirtual + sDestinationPath))
                        System.IO.File.Delete(sFolderVirtual + sDestinationPath);
                    System.IO.File.Copy(FileSource, sFolderVirtual + sDestinationPath);
                }
            }
            catch (Exception ex)
            {
                throw (new Exception(ex.Message));
            }
        }


        public abstract void UpdateDB();
        public abstract int GetTotalRowOfDB();
        public abstract int GetTotalColumnOfDB();

    }

}
