﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Npgsql;
using System.Windows.Forms;
using System.Data;

namespace Library
{
    public class clstbm_kegiatan
    {
        private String m_kegiatanid;
        private String m_programid;
        private String m_kegiatankode;
        private String m_kegiatannama;
        private String m_ket;
        private String m_tahun;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private NpgsqlConnection m_Koneksi;
        public String kegiatanid
        {
            get { return m_kegiatanid; }
            set { m_kegiatanid = value; }
        }
        public String programid
        {
            get { return m_programid; }
            set { m_programid = value; }
        }
        public String kegiatankode
        {
            get { return m_kegiatankode; }
            set { m_kegiatankode = value; }
        }
        public String kegiatannama
        {
            get { return m_kegiatannama; }
            set { m_kegiatannama = value; }
        }
        public String ket
        {
            get { return m_ket; }
            set { m_ket = value; }
        }
        public String tahun
        {
            get { return m_tahun; }
            set { m_tahun = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_kegiatan(kegiatanid,programid,kegiatankode,kegiatannama,ket,tahun,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt)"+
                            "VALUES"+
                            "(@kegiatanid,@programid,@kegiatankode,@kegiatannama,@ket,@tahun,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0')";
            NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
            if (kegiatanid != null )
            {
               cmd.Parameters.Add("@kegiatanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatanid;
            }
            else
            {
               cmd.Parameters.Add("@kegiatanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (programid != null )
            {
               cmd.Parameters.Add("@programid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = programid;
            }
            else
            {
               cmd.Parameters.Add("@programid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kegiatankode != null )
            {
               cmd.Parameters.Add("@kegiatankode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatankode;
            }
            else
            {
               cmd.Parameters.Add("@kegiatankode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kegiatannama != null )
            {
               cmd.Parameters.Add("@kegiatannama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatannama;
            }
            else
            {
               cmd.Parameters.Add("@kegiatannama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ket != null )
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ket;
            }
            else
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahun != null )
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Kesalahan !!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_kegiatan SET "+
                            " kegiatanid=@kegiatanid,programid=@programid,kegiatankode=@kegiatankode,kegiatannama=@kegiatannama,ket=@ket,tahun=@tahun,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0'"+
                            " WHERE kegiatanid=@kegiatanid";
            NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
            if (kegiatanid != null )
            {
               cmd.Parameters.Add("@kegiatanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatanid;
            }
            else
            {
               cmd.Parameters.Add("@kegiatanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (programid != null )
            {
               cmd.Parameters.Add("@programid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = programid;
            }
            else
            {
               cmd.Parameters.Add("@programid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kegiatankode != null )
            {
               cmd.Parameters.Add("@kegiatankode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatankode;
            }
            else
            {
               cmd.Parameters.Add("@kegiatankode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kegiatannama != null )
            {
               cmd.Parameters.Add("@kegiatannama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatannama;
            }
            else
            {
               cmd.Parameters.Add("@kegiatannama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ket != null )
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ket;
            }
            else
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahun != null )
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Ada Kesalahan!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbm_kegiatan WHERE kegiatanid=@kegiatanid";
           NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@kegiatanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatanid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Kesalahan !!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbm_kegiatan SET DLT=true WHERE kegiatanid=@kegiatanid";
           NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@kegiatanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kegiatanid;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Kesalahan !!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbm_kegiatan WHERE kegiatanid='"+ pKey  +"'";
        NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("kegiatanid"))) 
            {
              m_kegiatanid = rdr.GetString(rdr.GetOrdinal("kegiatanid"));
            }
            else
            {
              m_kegiatanid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("programid"))) 
            {
              m_programid = rdr.GetString(rdr.GetOrdinal("programid"));
            }
            else
            {
              m_programid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("kegiatankode"))) 
            {
              m_kegiatankode = rdr.GetString(rdr.GetOrdinal("kegiatankode"));
            }
            else
            {
              m_kegiatankode = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("kegiatannama"))) 
            {
              m_kegiatannama = rdr.GetString(rdr.GetOrdinal("kegiatannama"));
            }
            else
            {
              m_kegiatannama = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("ket"))) 
            {
              m_ket = rdr.GetString(rdr.GetOrdinal("ket"));
            }
            else
            {
              m_ket = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tahun"))) 
            {
              m_tahun = rdr.GetString(rdr.GetOrdinal("tahun"));
            }
            else
            {
              m_tahun = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
        }
          return true;
        }
        catch(NpgsqlException Ex)
        {
          MessageBox.Show(Ex.Message, "Kesalahan !!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public DataTable GetData(NpgsqlCommand cmd)
      {
         DataSet ds = new DataSet();
         DataTable dt = ds.Tables.Add("tbm_kegiatan");
         cmd.Connection = Koneksi;
         NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_kegiatan");
         return dt;
      }

      public DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbm_kegiatan";
         }
         NpgsqlCommand cmd = new NpgsqlCommand(strSQL  , Koneksi); 
         DataSet ds = new DataSet();
         DataTable dt = ds.Tables.Add("tbm_kegiatan");
         NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_kegiatan");
         return dt;
      }

      public NpgsqlDataReader ReadData(NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public NpgsqlDataReader ReadData(string strSQL)
      {
         NpgsqlCommand cmd = new NpgsqlCommand(strSQL, Koneksi);
         NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public string NewID()
      {
          string i = "";
          string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbm_kegiatan_nextid') as id";
          NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
          cmd.CommandText = sQuery;
          try
          {
              NpgsqlDataReader rdr = cmd.ExecuteReader();
              if (rdr.Read())
              {
                  if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                  {
                      i = rdr.GetValue(0).ToString();
                  }
                  else
                  {
                      i = "";
                  };
              }
              rdr.Close();
          }
          catch (NpgsqlException Ex)
          {
              MessageBox.Show(Ex.Message, "Error !!!");
              return "";
          }
          return i;
      }

    }
}
