﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbp_gaji
    {
        private String m_gajiid;
        private String m_cutoff_pegawai_pendid;
        private String m_cutoffid;
        private decimal m_gajipokok;
        private decimal m_tunj_kerajinan;
        private decimal m_tunj_jab_fungsional;
        private decimal m_tunj_keluarga;
        private decimal m_tunj_literatur;
        private decimal m_tunj_jab_struktural;
        private decimal m_pajak_yayasan;
        private decimal m_pendapatan_bersih;
        private decimal m_tunj_kelebihan_mengajar;
        private bool m_fas_tempat_tinggal;
        private bool m_fas_trans_operasional;
        private bool m_fas_kesehatan;
        private String m_diberikan;
        private String m_norek;
        private String m_jenis_tenaga;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_tempat;
        private DateTime m_tanggal;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String gajiid
        {
            get { return m_gajiid; }
            set { m_gajiid = value; }
        }
        public String cutoff_pegawai_pendid
        {
            get { return m_cutoff_pegawai_pendid; }
            set { m_cutoff_pegawai_pendid = value; }
        }
        public String cutoffid
        {
            get { return m_cutoffid; }
            set { m_cutoffid = value; }
        }
        public decimal gajipokok
        {
            get { return m_gajipokok; }
            set { m_gajipokok = value; }
        }
        public decimal tunj_kerajinan
        {
            get { return m_tunj_kerajinan; }
            set { m_tunj_kerajinan = value; }
        }
        public decimal tunj_jab_fungsional
        {
            get { return m_tunj_jab_fungsional; }
            set { m_tunj_jab_fungsional = value; }
        }
        public decimal tunj_keluarga
        {
            get { return m_tunj_keluarga; }
            set { m_tunj_keluarga = value; }
        }
        public decimal tunj_literatur
        {
            get { return m_tunj_literatur; }
            set { m_tunj_literatur = value; }
        }
        public decimal tunj_jab_struktural
        {
            get { return m_tunj_jab_struktural; }
            set { m_tunj_jab_struktural = value; }
        }
        public decimal pajak_yayasan
        {
            get { return m_pajak_yayasan; }
            set { m_pajak_yayasan = value; }
        }
        public decimal pendapatan_bersih
        {
            get { return m_pendapatan_bersih; }
            set { m_pendapatan_bersih = value; }
        }
        public decimal tunj_kelebihan_mengajar
        {
            get { return m_tunj_kelebihan_mengajar; }
            set { m_tunj_kelebihan_mengajar = value; }
        }
        public bool fas_tempat_tinggal
        {
            get { return m_fas_tempat_tinggal; }
            set { m_fas_tempat_tinggal = value; }
        }
        public bool fas_trans_operasional
        {
            get { return m_fas_trans_operasional; }
            set { m_fas_trans_operasional = value; }
        }
        public bool fas_kesehatan
        {
            get { return m_fas_kesehatan; }
            set { m_fas_kesehatan = value; }
        }
        public String diberikan
        {
            get { return m_diberikan; }
            set { m_diberikan = value; }
        }
        public String norek
        {
            get { return m_norek; }
            set { m_norek = value; }
        }
        public String jenis_tenaga
        {
            get { return m_jenis_tenaga; }
            set { m_jenis_tenaga = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String tempat
        {
            get { return m_tempat; }
            set { m_tempat = value; }
        }
        public DateTime tanggal
        {
            get { return m_tanggal; }
            set { m_tanggal = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_gaji(gajiid,cutoff_pegawai_pendid,cutoffid,gajipokok,tunj_kerajinan,tunj_jab_fungsional,tunj_keluarga,tunj_literatur,tunj_jab_struktural,pajak_yayasan,pendapatan_bersih,tunj_kelebihan_mengajar,fas_tempat_tinggal,fas_trans_operasional,fas_kesehatan,diberikan,norek,jenis_tenaga,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt,tempat,tanggal)" +
                            "VALUES"+
                            "(@gajiid,@cutoff_pegawai_pendid,@cutoffid,@gajipokok,@tunj_kerajinan,@tunj_jab_fungsional,@tunj_keluarga,@tunj_literatur,@tunj_jab_struktural,@pajak_yayasan,@pendapatan_bersih,@tunj_kelebihan_mengajar,@fas_tempat_tinggal,@fas_trans_operasional,@fas_kesehatan,@diberikan,@norek,@jenis_tenaga,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0',@tempat,@tanggal)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (gajiid != null )
            {
               cmd.Parameters.Add("@gajiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = gajiid;
            }
            else
            {
               cmd.Parameters.Add("@gajiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (cutoff_pegawai_pendid != null )
            {
               cmd.Parameters.Add("@cutoff_pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = cutoff_pegawai_pendid;
            }
            else
            {
               cmd.Parameters.Add("@cutoff_pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (cutoffid != null )
            {
               cmd.Parameters.Add("@cutoffid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = cutoffid;
            }
            else
            {
               cmd.Parameters.Add("@cutoffid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@gajipokok", NpgsqlTypes.NpgsqlDbType.Numeric).Value = gajipokok;
               cmd.Parameters.Add("@tunj_kerajinan", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_kerajinan;
               cmd.Parameters.Add("@tunj_jab_fungsional", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_jab_fungsional;
               cmd.Parameters.Add("@tunj_keluarga", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_keluarga;
               cmd.Parameters.Add("@tunj_literatur", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_literatur;
               cmd.Parameters.Add("@tunj_jab_struktural", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_jab_struktural;
               cmd.Parameters.Add("@pajak_yayasan", NpgsqlTypes.NpgsqlDbType.Numeric).Value = pajak_yayasan;
               cmd.Parameters.Add("@pendapatan_bersih", NpgsqlTypes.NpgsqlDbType.Numeric).Value = pendapatan_bersih;
               cmd.Parameters.Add("@tunj_kelebihan_mengajar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_kelebihan_mengajar;
               cmd.Parameters.Add("@fas_tempat_tinggal", NpgsqlTypes.NpgsqlDbType.Boolean).Value = fas_tempat_tinggal;
               cmd.Parameters.Add("@fas_trans_operasional", NpgsqlTypes.NpgsqlDbType.Boolean).Value = fas_trans_operasional;
               cmd.Parameters.Add("@fas_kesehatan", NpgsqlTypes.NpgsqlDbType.Boolean).Value = fas_kesehatan;
            if (diberikan != null )
            {
               cmd.Parameters.Add("@diberikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = diberikan;
            }
            else
            {
               cmd.Parameters.Add("@diberikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (norek != null )
            {
               cmd.Parameters.Add("@norek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = norek;
            }
            else
            {
               cmd.Parameters.Add("@norek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenis_tenaga != null )
            {
               cmd.Parameters.Add("@jenis_tenaga", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis_tenaga;
            }
            else
            {
               cmd.Parameters.Add("@jenis_tenaga", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tempat != null)
            {
                cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempat;
            }
            else
            {
                cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggal != null && tanggal != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggal;
            }
            else
            {
                cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_gaji SET "+
                            " gajiid=@gajiid,cutoff_pegawai_pendid=@cutoff_pegawai_pendid,cutoffid=@cutoffid,gajipokok=@gajipokok,tunj_kerajinan=@tunj_kerajinan,tunj_jab_fungsional=@tunj_jab_fungsional,tunj_keluarga=@tunj_keluarga,tunj_literatur=@tunj_literatur,tunj_jab_struktural=@tunj_jab_struktural,pajak_yayasan=@pajak_yayasan,pendapatan_bersih=@pendapatan_bersih,tunj_kelebihan_mengajar=@tunj_kelebihan_mengajar,fas_tempat_tinggal=@fas_tempat_tinggal,fas_trans_operasional=@fas_trans_operasional,fas_kesehatan=@fas_kesehatan,diberikan=@diberikan,norek=@norek,jenis_tenaga=@jenis_tenaga,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0',tempat=@tempat,tanggal=@tanggal" +
                            " WHERE gajiid=@gajiid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (gajiid != null )
            {
               cmd.Parameters.Add("@gajiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = gajiid;
            }
            else
            {
               cmd.Parameters.Add("@gajiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (cutoff_pegawai_pendid != null )
            {
               cmd.Parameters.Add("@cutoff_pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = cutoff_pegawai_pendid;
            }
            else
            {
               cmd.Parameters.Add("@cutoff_pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (cutoffid != null )
            {
               cmd.Parameters.Add("@cutoffid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = cutoffid;
            }
            else
            {
               cmd.Parameters.Add("@cutoffid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@gajipokok", NpgsqlTypes.NpgsqlDbType.Numeric).Value = gajipokok;
               cmd.Parameters.Add("@tunj_kerajinan", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_kerajinan;
               cmd.Parameters.Add("@tunj_jab_fungsional", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_jab_fungsional;
               cmd.Parameters.Add("@tunj_keluarga", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_keluarga;
               cmd.Parameters.Add("@tunj_literatur", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_literatur;
               cmd.Parameters.Add("@tunj_jab_struktural", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_jab_struktural;
               cmd.Parameters.Add("@pajak_yayasan", NpgsqlTypes.NpgsqlDbType.Numeric).Value = pajak_yayasan;
               cmd.Parameters.Add("@pendapatan_bersih", NpgsqlTypes.NpgsqlDbType.Numeric).Value = pendapatan_bersih;
               cmd.Parameters.Add("@tunj_kelebihan_mengajar", NpgsqlTypes.NpgsqlDbType.Numeric).Value = tunj_kelebihan_mengajar;
               cmd.Parameters.Add("@fas_tempat_tinggal", NpgsqlTypes.NpgsqlDbType.Boolean).Value = fas_tempat_tinggal;
               cmd.Parameters.Add("@fas_trans_operasional", NpgsqlTypes.NpgsqlDbType.Boolean).Value = fas_trans_operasional;
               cmd.Parameters.Add("@fas_kesehatan", NpgsqlTypes.NpgsqlDbType.Boolean).Value = fas_kesehatan;
            if (diberikan != null )
            {
               cmd.Parameters.Add("@diberikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = diberikan;
            }
            else
            {
               cmd.Parameters.Add("@diberikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (norek != null )
            {
               cmd.Parameters.Add("@norek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = norek;
            }
            else
            {
               cmd.Parameters.Add("@norek", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenis_tenaga != null )
            {
               cmd.Parameters.Add("@jenis_tenaga", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis_tenaga;
            }
            else
            {
               cmd.Parameters.Add("@jenis_tenaga", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tempat != null)
            {
                cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempat;
            }
            else
            {
                cmd.Parameters.Add("@tempat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggal != null && tanggal != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggal;
            }
            else
            {
                cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_gaji WHERE gajiid=@gajiid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@gajiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = gajiid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbp_gaji SET DLT='1',op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now() WHERE gajiid=@gajiid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@gajiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = gajiid;
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_gaji WHERE gajiid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("gajiid"))) 
            {
              m_gajiid = rdr.GetString(rdr.GetOrdinal("gajiid"));
            }
            else
            {
              m_gajiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("cutoff_pegawai_pendid"))) 
            {
              m_cutoff_pegawai_pendid = rdr.GetString(rdr.GetOrdinal("cutoff_pegawai_pendid"));
            }
            else
            {
              m_cutoff_pegawai_pendid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("cutoffid"))) 
            {
              m_cutoffid = rdr.GetString(rdr.GetOrdinal("cutoffid"));
            }
            else
            {
              m_cutoffid = "";
            };
            m_gajipokok = rdr.GetDecimal(rdr.GetOrdinal("gajipokok"));
            m_tunj_kerajinan = rdr.GetDecimal(rdr.GetOrdinal("tunj_kerajinan"));
            m_tunj_jab_fungsional = rdr.GetDecimal(rdr.GetOrdinal("tunj_jab_fungsional"));
            m_tunj_keluarga = rdr.GetDecimal(rdr.GetOrdinal("tunj_keluarga"));
            m_tunj_literatur = rdr.GetDecimal(rdr.GetOrdinal("tunj_literatur"));
            m_tunj_jab_struktural = rdr.GetDecimal(rdr.GetOrdinal("tunj_jab_struktural"));
            m_pajak_yayasan = rdr.GetDecimal(rdr.GetOrdinal("pajak_yayasan"));
            m_pendapatan_bersih = rdr.GetDecimal(rdr.GetOrdinal("pendapatan_bersih"));
            m_tunj_kelebihan_mengajar = rdr.GetDecimal(rdr.GetOrdinal("tunj_kelebihan_mengajar"));
             m_fas_tempat_tinggal = rdr.GetBoolean(rdr.GetOrdinal("fas_tempat_tinggal"));
             m_fas_trans_operasional = rdr.GetBoolean(rdr.GetOrdinal("fas_trans_operasional"));
             m_fas_kesehatan = rdr.GetBoolean(rdr.GetOrdinal("fas_kesehatan"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("diberikan"))) 
            {
              m_diberikan = rdr.GetString(rdr.GetOrdinal("diberikan"));
            }
            else
            {
              m_diberikan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("norek"))) 
            {
              m_norek = rdr.GetString(rdr.GetOrdinal("norek"));
            }
            else
            {
              m_norek = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jenis_tenaga"))) 
            {
              m_jenis_tenaga = rdr.GetString(rdr.GetOrdinal("jenis_tenaga"));
            }
            else
            {
              m_jenis_tenaga = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("tempat")))
            {
                m_tempat = rdr.GetString(rdr.GetOrdinal("tempat"));
            }
            else
            {
                m_tempat = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggal")))
            {
                m_tanggal = rdr.GetDateTime(rdr.GetOrdinal("tanggal"));
            }
            else
            {
                m_tanggal = System.DateTime.MinValue;
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_gaji");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_gaji");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbp_gaji";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_gaji");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_gaji");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_gaji_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
