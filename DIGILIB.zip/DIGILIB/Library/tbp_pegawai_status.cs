﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbp_pegawai_status
    {
        private String m_pegawai_statusid;
        private String m_pegawai_pendid;
        private String m_status;
        private DateTime m_tanggal;
        private bool m_isaktif;
        private String m_remarks;
        private decimal m_nourut;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pegawai_statusid
        {
            get { return m_pegawai_statusid; }
            set { m_pegawai_statusid = value; }
        }
        public String pegawai_pendid
        {
            get { return m_pegawai_pendid; }
            set { m_pegawai_pendid = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }
        public DateTime tanggal
        {
            get { return m_tanggal; }
            set { m_tanggal = value; }
        }
        public bool isaktif
        {
            get { return m_isaktif; }
            set { m_isaktif = value; }
        }
        public String remarks
        {
            get { return m_remarks; }
            set { m_remarks = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_pegawai_status(pegawai_statusid,pegawai_pendid,status,tanggal,isaktif,remarks,nourut,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt)"+
                            "VALUES"+
                            "(@pegawai_statusid,@pegawai_pendid,@status,@tanggal,@isaktif,@remarks,@nourut,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0')";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pegawai_statusid != null )
            {
               cmd.Parameters.Add("@pegawai_statusid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_statusid;
            }
            else
            {
               cmd.Parameters.Add("@pegawai_statusid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pegawai_pendid != null )
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_pendid;
            }
            else
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggal != null && tanggal != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggal;
            }
            else
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@isaktif", NpgsqlTypes.NpgsqlDbType.Boolean).Value = isaktif;
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_pegawai_status SET "+
                            " pegawai_statusid=@pegawai_statusid,pegawai_pendid=@pegawai_pendid,status=@status,tanggal=@tanggal,isaktif=@isaktif,remarks=@remarks,nourut=@nourut,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0'"+
                            " WHERE pegawai_statusid=@pegawai_statusid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pegawai_statusid != null )
            {
               cmd.Parameters.Add("@pegawai_statusid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_statusid;
            }
            else
            {
               cmd.Parameters.Add("@pegawai_statusid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pegawai_pendid != null )
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_pendid;
            }
            else
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tanggal != null && tanggal != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tanggal;
            }
            else
            {
               cmd.Parameters.Add("@tanggal", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@isaktif", NpgsqlTypes.NpgsqlDbType.Boolean).Value = isaktif;
            if (remarks != null )
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = remarks;
            }
            else
            {
               cmd.Parameters.Add("@remarks", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_pegawai_status WHERE pegawai_statusid=@pegawai_statusid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pegawai_statusid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_statusid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbp_pegawai_status SET DLT='1', op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now() WHERE pegawai_statusid=@pegawai_statusid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@pegawai_statusid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_statusid;
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_pegawai_status WHERE pegawai_statusid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pegawai_statusid"))) 
            {
              m_pegawai_statusid = rdr.GetString(rdr.GetOrdinal("pegawai_statusid"));
            }
            else
            {
              m_pegawai_statusid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pegawai_pendid"))) 
            {
              m_pegawai_pendid = rdr.GetString(rdr.GetOrdinal("pegawai_pendid"));
            }
            else
            {
              m_pegawai_pendid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("status"))) 
            {
              m_status = rdr.GetString(rdr.GetOrdinal("status"));
            }
            else
            {
              m_status = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tanggal"))) 
            {
              m_tanggal = rdr.GetDateTime(rdr.GetOrdinal("tanggal"));
            }
            else
            {
              m_tanggal = System.DateTime.MinValue;
            };
             m_isaktif = rdr.GetBoolean(rdr.GetOrdinal("isaktif"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("remarks"))) 
            {
              m_remarks = rdr.GetString(rdr.GetOrdinal("remarks"));
            }
            else
            {
              m_remarks = "";
            };
            m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pegawai_status");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pegawai_status");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbp_pegawai_status";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pegawai_status");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pegawai_status");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_pegawai_status_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
