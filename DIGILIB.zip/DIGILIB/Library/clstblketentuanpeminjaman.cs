﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstblketentuanpeminjaman
    {
        private String m_ketentuanpeminjamanid;
        private decimal m_lamapeminjaman;
        private decimal m_dendaperhari;
        private decimal m_maksbukudipinjam;
        private String m_ketentuanpeminjaman;
        private String m_op;
        private String m_pc;
        private DateTime m_lu;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String ketentuanpeminjamanid
        {
            get { return m_ketentuanpeminjamanid; }
            set { m_ketentuanpeminjamanid = value; }
        }
        public decimal lamapeminjaman
        {
            get { return m_lamapeminjaman; }
            set { m_lamapeminjaman = value; }
        }
        public decimal dendaperhari
        {
            get { return m_dendaperhari; }
            set { m_dendaperhari = value; }
        }
        public decimal maksbukudipinjam
        {
            get { return m_maksbukudipinjam; }
            set { m_maksbukudipinjam = value; }
        }
        public String ketentuanpeminjaman
        {
            get { return m_ketentuanpeminjaman; }
            set { m_ketentuanpeminjaman = value; }
        }
        public String op
        {
            get { return m_op; }
            set { m_op = value; }
        }
        public String pc
        {
            get { return m_pc; }
            set { m_pc = value; }
        }
        public DateTime lu
        {
            get { return m_lu; }
            set { m_lu = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tblketentuanpeminjaman(ketentuanpeminjamanid,lamapeminjaman,dendaperhari,maksbukudipinjam,ketentuanpeminjaman,op,pc,lu,dlt)" +
                            "VALUES" +
                            "(@ketentuanpeminjamanid,@lamapeminjaman,@dendaperhari,@maksbukudipinjam,@ketentuanpeminjaman,@op,@pc,now(),@dlt)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (ketentuanpeminjamanid != null)
            {
                cmd.Parameters.Add("@ketentuanpeminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ketentuanpeminjamanid;
            }
            else
            {
                cmd.Parameters.Add("@ketentuanpeminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@lamapeminjaman", NpgsqlTypes.NpgsqlDbType.Numeric).Value = lamapeminjaman;
            cmd.Parameters.Add("@dendaperhari", NpgsqlTypes.NpgsqlDbType.Numeric).Value = dendaperhari;
            cmd.Parameters.Add("@maksbukudipinjam", NpgsqlTypes.NpgsqlDbType.Numeric).Value = maksbukudipinjam;
            if (ketentuanpeminjaman != null)
            {
                cmd.Parameters.Add("@ketentuanpeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ketentuanpeminjaman;
            }
            else
            {
                cmd.Parameters.Add("@ketentuanpeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op != null)
            {
                cmd.Parameters.Add("@op", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op;
            }
            else
            {
                cmd.Parameters.Add("@op", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc != null)
            {
                cmd.Parameters.Add("@pc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc;
            }
            else
            {
                cmd.Parameters.Add("@pc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu != null && lu != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu;
            }
            else
            {
                cmd.Parameters.Add("@lu", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tblketentuanpeminjaman SET " +
                            " ketentuanpeminjamanid=@ketentuanpeminjamanid,lamapeminjaman=@lamapeminjaman,dendaperhari=@dendaperhari,maksbukudipinjam=@maksbukudipinjam,ketentuanpeminjaman=@ketentuanpeminjaman,op=@op,pc=@pc,lu=now(),dlt=@dlt" +
                            " WHERE ketentuanpeminjamanid=@ketentuanpeminjamanid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (ketentuanpeminjamanid != null)
            {
                cmd.Parameters.Add("@ketentuanpeminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ketentuanpeminjamanid;
            }
            else
            {
                cmd.Parameters.Add("@ketentuanpeminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@lamapeminjaman", NpgsqlTypes.NpgsqlDbType.Numeric).Value = lamapeminjaman;
            cmd.Parameters.Add("@dendaperhari", NpgsqlTypes.NpgsqlDbType.Numeric).Value = dendaperhari;
            cmd.Parameters.Add("@maksbukudipinjam", NpgsqlTypes.NpgsqlDbType.Numeric).Value = maksbukudipinjam;
            if (ketentuanpeminjaman != null)
            {
                cmd.Parameters.Add("@ketentuanpeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ketentuanpeminjaman;
            }
            else
            {
                cmd.Parameters.Add("@ketentuanpeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op != null)
            {
                cmd.Parameters.Add("@op", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op;
            }
            else
            {
                cmd.Parameters.Add("@op", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc != null)
            {
                cmd.Parameters.Add("@pc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc;
            }
            else
            {
                cmd.Parameters.Add("@pc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu != null && lu != DateTime.MinValue)
            {
                cmd.Parameters.Add("@lu", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu;
            }
            else
            {
                cmd.Parameters.Add("@lu", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tblketentuanpeminjaman WHERE ketentuanpeminjamanid=@ketentuanpeminjamanid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@ketentuanpeminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ketentuanpeminjamanid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tblketentuanpeminjaman SET DLT=true , op=@op, pc=@pc, lu=now() WHERE ketentuanpeminjamanid=@ketentuanpeminjamanid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@ketentuanpeminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ketentuanpeminjamanid;
            cmd.Parameters.Add("@op", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
            cmd.Parameters.Add("@pc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tblketentuanpeminjaman WHERE ketentuanpeminjamanid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("ketentuanpeminjamanid")))
                    {
                        m_ketentuanpeminjamanid = rdr.GetString(rdr.GetOrdinal("ketentuanpeminjamanid"));
                    }
                    else
                    {
                        m_ketentuanpeminjamanid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lamapeminjaman")))
                    {
                        m_lamapeminjaman = rdr.GetDecimal(rdr.GetOrdinal("lamapeminjaman"));
                    }
                    else
                    {
                        m_lamapeminjaman = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dendaperhari")))
                    {
                        m_dendaperhari = rdr.GetDecimal(rdr.GetOrdinal("dendaperhari"));
                    }
                    else
                    {
                        m_dendaperhari = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("maksbukudipinjam")))
                    {
                        m_maksbukudipinjam = rdr.GetDecimal(rdr.GetOrdinal("maksbukudipinjam"));
                    }
                    else
                    {
                        m_maksbukudipinjam = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("ketentuanpeminjaman")))
                    {
                        m_ketentuanpeminjaman = rdr.GetString(rdr.GetOrdinal("ketentuanpeminjaman"));
                    }
                    else
                    {
                        m_ketentuanpeminjaman = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("op")))
                    {
                        m_op = rdr.GetString(rdr.GetOrdinal("op"));
                    }
                    else
                    {
                        m_op = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pc")))
                    {
                        m_pc = rdr.GetString(rdr.GetOrdinal("pc"));
                    }
                    else
                    {
                        m_pc = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lu")))
                    {
                        m_lu = rdr.GetDateTime(rdr.GetOrdinal("lu"));
                    }
                    else
                    {
                        m_lu = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dlt")))
                    {
                        m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                    }
                    else
                    {
                        m_dlt = false;
                    };
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tblketentuanpeminjaman");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tblketentuanpeminjaman");
            return dt;
        }

        public System.Data.DataTable GetData(string strSQL)
        {
            if (strSQL == "")
            {
                strSQL = "select * from tblketentuanpeminjaman where dlt='0' ";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tblketentuanpeminjaman");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tblketentuanpeminjaman");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tblketentuanpeminjaman_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}
