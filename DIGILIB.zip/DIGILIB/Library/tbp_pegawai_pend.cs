﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbp_pegawai_pend
    {
        private String m_pegawai_pendid;
        private String m_prodiid;
        private String m_nik;
        private String m_nama;
        private String m_jeniskelamin;
        private String m_tunj_jabatan_strukturalid;
        private DateTime m_tglmasuk;
        private String m_statuskerja;
        private String m_pendidikan;
        private String m_tempatlahir;
        private DateTime m_tgllahir;
        private String m_alamatasal;
        private String m_alamatbatam;
        private String m_notelp;
        private String m_noktp;
        private String m_agama;
        private String m_suku;
        private String m_statuskawin;
        private String m_istri_suami;
        private String m_anak1;
        private String m_anak2;
        private String m_anak3;
        private String m_jabatanakademik;
        private decimal m_kum;
        private String m_npwp;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_golongan_gajipokokid;
        private String m_jenis_dosenid;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String pegawai_pendid
        {
            get { return m_pegawai_pendid; }
            set { m_pegawai_pendid = value; }
        }
        public String golongan_gajipokokid
        {
            get { return m_golongan_gajipokokid; }
            set { m_golongan_gajipokokid = value; }
        }
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String nik
        {
            get { return m_nik; }
            set { m_nik = value; }
        }
        public String nama
        {
            get { return m_nama; }
            set { m_nama = value; }
        }
        public String jeniskelamin
        {
            get { return m_jeniskelamin; }
            set { m_jeniskelamin = value; }
        }
        public String tunj_jabatan_strukturalid
        {
            get { return m_tunj_jabatan_strukturalid; }
            set { m_tunj_jabatan_strukturalid = value; }
        }
        public DateTime tglmasuk
        {
            get { return m_tglmasuk; }
            set { m_tglmasuk = value; }
        }
        public String statuskerja
        {
            get { return m_statuskerja; }
            set { m_statuskerja = value; }
        }
        public String pendidikan
        {
            get { return m_pendidikan; }
            set { m_pendidikan = value; }
        }
        public String tempatlahir
        {
            get { return m_tempatlahir; }
            set { m_tempatlahir = value; }
        }
        public DateTime tgllahir
        {
            get { return m_tgllahir; }
            set { m_tgllahir = value; }
        }
        public String alamatasal
        {
            get { return m_alamatasal; }
            set { m_alamatasal = value; }
        }
        public String alamatbatam
        {
            get { return m_alamatbatam; }
            set { m_alamatbatam = value; }
        }
        public String notelp
        {
            get { return m_notelp; }
            set { m_notelp = value; }
        }
        public String noktp
        {
            get { return m_noktp; }
            set { m_noktp = value; }
        }
        public String agama
        {
            get { return m_agama; }
            set { m_agama = value; }
        }
        public String suku
        {
            get { return m_suku; }
            set { m_suku = value; }
        }
        public String statuskawin
        {
            get { return m_statuskawin; }
            set { m_statuskawin = value; }
        }
        public String istri_suami
        {
            get { return m_istri_suami; }
            set { m_istri_suami = value; }
        }
        public String anak1
        {
            get { return m_anak1; }
            set { m_anak1 = value; }
        }
        public String anak2
        {
            get { return m_anak2; }
            set { m_anak2 = value; }
        }
        public String anak3
        {
            get { return m_anak3; }
            set { m_anak3 = value; }
        }
        public String jabatanakademik
        {
            get { return m_jabatanakademik; }
            set { m_jabatanakademik = value; }
        }
        public decimal kum
        {
            get { return m_kum; }
            set { m_kum = value; }
        }
        public String npwp
        {
            get { return m_npwp; }
            set { m_npwp = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String jenis_dosenid
        {
            get { return m_jenis_dosenid; }
            set { m_jenis_dosenid = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_pegawai_pend(pegawai_pendid,prodiid,nik,nama,jeniskelamin,tunj_jabatan_strukturalid,tglmasuk,statuskerja,pendidikan,tempatlahir,tgllahir,alamatasal,alamatbatam,notelp,noktp,agama,suku,statuskawin,istri_suami,anak1,anak2,anak3,jabatanakademik,kum,npwp,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt,golongan_gajipokokid,jenis_dosenid)" +
                            "VALUES"+
                            "(@pegawai_pendid,@prodiid,@nik,@nama,@jeniskelamin,@tunj_jabatan_strukturalid,@tglmasuk,@statuskerja,@pendidikan,@tempatlahir,@tgllahir,@alamatasal,@alamatbatam,@notelp,@noktp,@agama,@suku,@statuskawin,@istri_suami,@anak1,@anak2,@anak3,@jabatanakademik,@kum,@npwp,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0',@golongan_gajipokokid,@jenis_dosenid)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pegawai_pendid != null )
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_pendid;
            }
            else
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nik != null )
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nik;
            }
            else
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nama != null )
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nama;
            }
            else
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskelamin != null )
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskelamin;
            }
            else
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tunj_jabatan_strukturalid != null )
            {
               cmd.Parameters.Add("@tunj_jabatan_strukturalid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tunj_jabatan_strukturalid;
            }
            else
            {
               cmd.Parameters.Add("@tunj_jabatan_strukturalid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglmasuk != null && tglmasuk != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglmasuk", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglmasuk;
            }
            else
            {
               cmd.Parameters.Add("@tglmasuk", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (statuskerja != null )
            {
               cmd.Parameters.Add("@statuskerja", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statuskerja;
            }
            else
            {
               cmd.Parameters.Add("@statuskerja", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pendidikan != null )
            {
               cmd.Parameters.Add("@pendidikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pendidikan;
            }
            else
            {
               cmd.Parameters.Add("@pendidikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tempatlahir != null )
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatlahir;
            }
            else
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tgllahir != null && tgllahir != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgllahir;
            }
            else
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (alamatasal != null )
            {
               cmd.Parameters.Add("@alamatasal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamatasal;
            }
            else
            {
               cmd.Parameters.Add("@alamatasal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamatbatam != null )
            {
               cmd.Parameters.Add("@alamatbatam", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamatbatam;
            }
            else
            {
               cmd.Parameters.Add("@alamatbatam", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (notelp != null )
            {
               cmd.Parameters.Add("@notelp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = notelp;
            }
            else
            {
               cmd.Parameters.Add("@notelp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noktp != null )
            {
               cmd.Parameters.Add("@noktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noktp;
            }
            else
            {
               cmd.Parameters.Add("@noktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (agama != null )
            {
               cmd.Parameters.Add("@agama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = agama;
            }
            else
            {
               cmd.Parameters.Add("@agama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (suku != null )
            {
               cmd.Parameters.Add("@suku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = suku;
            }
            else
            {
               cmd.Parameters.Add("@suku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statuskawin != null )
            {
               cmd.Parameters.Add("@statuskawin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statuskawin;
            }
            else
            {
               cmd.Parameters.Add("@statuskawin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (istri_suami != null )
            {
               cmd.Parameters.Add("@istri_suami", NpgsqlTypes.NpgsqlDbType.Varchar).Value = istri_suami;
            }
            else
            {
               cmd.Parameters.Add("@istri_suami", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anak1 != null )
            {
               cmd.Parameters.Add("@anak1", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anak1;
            }
            else
            {
               cmd.Parameters.Add("@anak1", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anak2 != null )
            {
               cmd.Parameters.Add("@anak2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anak2;
            }
            else
            {
               cmd.Parameters.Add("@anak2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anak3 != null )
            {
               cmd.Parameters.Add("@anak3", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anak3;
            }
            else
            {
               cmd.Parameters.Add("@anak3", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jabatanakademik != null )
            {
               cmd.Parameters.Add("@jabatanakademik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jabatanakademik;
            }
            else
            {
               cmd.Parameters.Add("@jabatanakademik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@kum", NpgsqlTypes.NpgsqlDbType.Numeric).Value = kum;
            if (npwp != null )
            {
               cmd.Parameters.Add("@npwp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = npwp;
            }
            else
            {
               cmd.Parameters.Add("@npwp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (golongan_gajipokokid != null)
            {
                cmd.Parameters.Add("@golongan_gajipokokid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = golongan_gajipokokid;
            }
            else
            {
                cmd.Parameters.Add("@golongan_gajipokokid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenis_dosenid != null)
            {
                cmd.Parameters.Add("@jenis_dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis_dosenid;
            }
            else
            {
                cmd.Parameters.Add("@jenis_dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_pegawai_pend SET "+
                            " pegawai_pendid=@pegawai_pendid,prodiid=@prodiid,nik=@nik,nama=@nama,jeniskelamin=@jeniskelamin,tunj_jabatan_strukturalid=@tunj_jabatan_strukturalid,tglmasuk=@tglmasuk,statuskerja=@statuskerja,pendidikan=@pendidikan,tempatlahir=@tempatlahir,tgllahir=@tgllahir,alamatasal=@alamatasal,alamatbatam=@alamatbatam,notelp=@notelp,noktp=@noktp,agama=@agama,suku=@suku,statuskawin=@statuskawin,istri_suami=@istri_suami,anak1=@anak1,anak2=@anak2,anak3=@anak3,jabatanakademik=@jabatanakademik,kum=@kum,npwp=@npwp,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0',golongan_gajipokokid=@golongan_gajipokokid,jenis_dosenid=@jenis_dosenid" +
                            " WHERE pegawai_pendid=@pegawai_pendid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (pegawai_pendid != null )
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_pendid;
            }
            else
            {
               cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nik != null )
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nik;
            }
            else
            {
               cmd.Parameters.Add("@nik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nama != null )
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nama;
            }
            else
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskelamin != null )
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskelamin;
            }
            else
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tunj_jabatan_strukturalid != null )
            {
               cmd.Parameters.Add("@tunj_jabatan_strukturalid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tunj_jabatan_strukturalid;
            }
            else
            {
               cmd.Parameters.Add("@tunj_jabatan_strukturalid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglmasuk != null && tglmasuk != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglmasuk", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglmasuk;
            }
            else
            {
               cmd.Parameters.Add("@tglmasuk", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (statuskerja != null )
            {
               cmd.Parameters.Add("@statuskerja", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statuskerja;
            }
            else
            {
               cmd.Parameters.Add("@statuskerja", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pendidikan != null )
            {
               cmd.Parameters.Add("@pendidikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pendidikan;
            }
            else
            {
               cmd.Parameters.Add("@pendidikan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tempatlahir != null )
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatlahir;
            }
            else
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tgllahir != null && tgllahir != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgllahir;
            }
            else
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (alamatasal != null )
            {
               cmd.Parameters.Add("@alamatasal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamatasal;
            }
            else
            {
               cmd.Parameters.Add("@alamatasal", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamatbatam != null )
            {
               cmd.Parameters.Add("@alamatbatam", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamatbatam;
            }
            else
            {
               cmd.Parameters.Add("@alamatbatam", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (notelp != null )
            {
               cmd.Parameters.Add("@notelp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = notelp;
            }
            else
            {
               cmd.Parameters.Add("@notelp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noktp != null )
            {
               cmd.Parameters.Add("@noktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noktp;
            }
            else
            {
               cmd.Parameters.Add("@noktp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (agama != null )
            {
               cmd.Parameters.Add("@agama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = agama;
            }
            else
            {
               cmd.Parameters.Add("@agama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (suku != null )
            {
               cmd.Parameters.Add("@suku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = suku;
            }
            else
            {
               cmd.Parameters.Add("@suku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statuskawin != null )
            {
               cmd.Parameters.Add("@statuskawin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statuskawin;
            }
            else
            {
               cmd.Parameters.Add("@statuskawin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (istri_suami != null )
            {
               cmd.Parameters.Add("@istri_suami", NpgsqlTypes.NpgsqlDbType.Varchar).Value = istri_suami;
            }
            else
            {
               cmd.Parameters.Add("@istri_suami", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anak1 != null )
            {
               cmd.Parameters.Add("@anak1", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anak1;
            }
            else
            {
               cmd.Parameters.Add("@anak1", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anak2 != null )
            {
               cmd.Parameters.Add("@anak2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anak2;
            }
            else
            {
               cmd.Parameters.Add("@anak2", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anak3 != null )
            {
               cmd.Parameters.Add("@anak3", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anak3;
            }
            else
            {
               cmd.Parameters.Add("@anak3", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jabatanakademik != null )
            {
               cmd.Parameters.Add("@jabatanakademik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jabatanakademik;
            }
            else
            {
               cmd.Parameters.Add("@jabatanakademik", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@kum", NpgsqlTypes.NpgsqlDbType.Numeric).Value = kum;
            if (npwp != null )
            {
               cmd.Parameters.Add("@npwp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = npwp;
            }
            else
            {
               cmd.Parameters.Add("@npwp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (golongan_gajipokokid != null)
            {
                cmd.Parameters.Add("@golongan_gajipokokid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = golongan_gajipokokid;
            }
            else
            {
                cmd.Parameters.Add("@golongan_gajipokokid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenis_dosenid != null)
            {
                cmd.Parameters.Add("@jenis_dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis_dosenid;
            }
            else
            {
                cmd.Parameters.Add("@jenis_dosenid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_pegawai_pend WHERE pegawai_pendid=@pegawai_pendid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_pendid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbp_pegawai_pend SET DLT='1', op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now() WHERE pegawai_pendid=@pegawai_pendid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@pegawai_pendid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pegawai_pendid;
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_pegawai_pend WHERE pegawai_pendid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("pegawai_pendid"))) 
            {
              m_pegawai_pendid = rdr.GetString(rdr.GetOrdinal("pegawai_pendid"));
            }
            else
            {
              m_pegawai_pendid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid"))) 
            {
              m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
            }
            else
            {
              m_prodiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nik"))) 
            {
              m_nik = rdr.GetString(rdr.GetOrdinal("nik"));
            }
            else
            {
              m_nik = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nama"))) 
            {
              m_nama = rdr.GetString(rdr.GetOrdinal("nama"));
            }
            else
            {
              m_nama = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jeniskelamin"))) 
            {
              m_jeniskelamin = rdr.GetString(rdr.GetOrdinal("jeniskelamin"));
            }
            else
            {
              m_jeniskelamin = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tunj_jabatan_strukturalid"))) 
            {
              m_tunj_jabatan_strukturalid = rdr.GetString(rdr.GetOrdinal("tunj_jabatan_strukturalid"));
            }
            else
            {
              m_tunj_jabatan_strukturalid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tglmasuk"))) 
            {
              m_tglmasuk = rdr.GetDateTime(rdr.GetOrdinal("tglmasuk"));
            }
            else
            {
              m_tglmasuk = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("statuskerja"))) 
            {
              m_statuskerja = rdr.GetString(rdr.GetOrdinal("statuskerja"));
            }
            else
            {
              m_statuskerja = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pendidikan"))) 
            {
              m_pendidikan = rdr.GetString(rdr.GetOrdinal("pendidikan"));
            }
            else
            {
              m_pendidikan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tempatlahir"))) 
            {
              m_tempatlahir = rdr.GetString(rdr.GetOrdinal("tempatlahir"));
            }
            else
            {
              m_tempatlahir = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tgllahir"))) 
            {
              m_tgllahir = rdr.GetDateTime(rdr.GetOrdinal("tgllahir"));
            }
            else
            {
              m_tgllahir = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("alamatasal"))) 
            {
              m_alamatasal = rdr.GetString(rdr.GetOrdinal("alamatasal"));
            }
            else
            {
              m_alamatasal = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("alamatbatam"))) 
            {
              m_alamatbatam = rdr.GetString(rdr.GetOrdinal("alamatbatam"));
            }
            else
            {
              m_alamatbatam = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("notelp"))) 
            {
              m_notelp = rdr.GetString(rdr.GetOrdinal("notelp"));
            }
            else
            {
              m_notelp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("noktp"))) 
            {
              m_noktp = rdr.GetString(rdr.GetOrdinal("noktp"));
            }
            else
            {
              m_noktp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("agama"))) 
            {
              m_agama = rdr.GetString(rdr.GetOrdinal("agama"));
            }
            else
            {
              m_agama = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("suku"))) 
            {
              m_suku = rdr.GetString(rdr.GetOrdinal("suku"));
            }
            else
            {
              m_suku = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("statuskawin"))) 
            {
              m_statuskawin = rdr.GetString(rdr.GetOrdinal("statuskawin"));
            }
            else
            {
              m_statuskawin = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("istri_suami"))) 
            {
              m_istri_suami = rdr.GetString(rdr.GetOrdinal("istri_suami"));
            }
            else
            {
              m_istri_suami = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("anak1"))) 
            {
              m_anak1 = rdr.GetString(rdr.GetOrdinal("anak1"));
            }
            else
            {
              m_anak1 = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("anak2"))) 
            {
              m_anak2 = rdr.GetString(rdr.GetOrdinal("anak2"));
            }
            else
            {
              m_anak2 = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("anak3"))) 
            {
              m_anak3 = rdr.GetString(rdr.GetOrdinal("anak3"));
            }
            else
            {
              m_anak3 = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jabatanakademik"))) 
            {
              m_jabatanakademik = rdr.GetString(rdr.GetOrdinal("jabatanakademik"));
            }
            else
            {
              m_jabatanakademik = "";
            };
            m_kum = rdr.GetDecimal(rdr.GetOrdinal("kum"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("npwp"))) 
            {
              m_npwp = rdr.GetString(rdr.GetOrdinal("npwp"));
            }
            else
            {
              m_npwp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("golongan_gajipokokid")))
            {
                m_golongan_gajipokokid = rdr.GetString(rdr.GetOrdinal("golongan_gajipokokid"));
            }
            else
            {
                m_golongan_gajipokokid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jenis_dosenid")))
            {
                m_jenis_dosenid = rdr.GetString(rdr.GetOrdinal("jenis_dosenid"));
            }
            else
            {
                m_jenis_dosenid = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pegawai_pend");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pegawai_pend");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbp_pegawai_pend";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_pegawai_pend");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_pegawai_pend");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbp_pegawai_pend_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
