﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Npgsql;
using System.Data;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Library
{
    public class tbm_buku : clsExcel
    {
        private String m_bukuid;
        private String m_pengadaanid;
        private String m_noinduk;
        private String m_kodepanggil;
        private String m_judul;
        private String m_pengarang;
        private String m_badankorporat;
        private String m_edisi;
        private String m_penerbit;
        private String m_tempatterbit;
        private String m_tahunterbit;
        private String m_isbn;
        private String m_deskripsi;
        private String m_supplemen;
        private String m_lokasikoleksi;
        private String m_jeniskoleksi;
        private String m_keterangan;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private decimal m_nourut;
        private String m_jenis_barang;
        private String m_pdffilename;
        private String m_coverbuku;
        private String m_prodiid;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String bukuid
        {
            get { return m_bukuid; }
            set { m_bukuid = value; }
        }
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String pengadaanid
        {
            get { return m_pengadaanid; }
            set { m_pengadaanid = value; }
        }
        public String noinduk
        {
            get { return m_noinduk; }
            set { m_noinduk = value; }
        }
        public String kodepanggil
        {
            get { return m_kodepanggil; }
            set { m_kodepanggil = value; }
        }
        public String judul
        {
            get { return m_judul; }
            set { m_judul = value; }
        }
        public String pengarang
        {
            get { return m_pengarang; }
            set { m_pengarang = value; }
        }
        public String badankorporat
        {
            get { return m_badankorporat; }
            set { m_badankorporat = value; }
        }
        public String edisi
        {
            get { return m_edisi; }
            set { m_edisi = value; }
        }
        public String penerbit
        {
            get { return m_penerbit; }
            set { m_penerbit = value; }
        }
        public String tempatterbit
        {
            get { return m_tempatterbit; }
            set { m_tempatterbit = value; }
        }
        public String tahunterbit
        {
            get { return m_tahunterbit; }
            set { m_tahunterbit = value; }
        }
        public String isbn
        {
            get { return m_isbn; }
            set { m_isbn = value; }
        }
        public String deskripsi
        {
            get { return m_deskripsi; }
            set { m_deskripsi = value; }
        }
        public String supplemen
        {
            get { return m_supplemen; }
            set { m_supplemen = value; }
        }
        public String lokasikoleksi
        {
            get { return m_lokasikoleksi; }
            set { m_lokasikoleksi = value; }
        }
        public String jeniskoleksi
        {
            get { return m_jeniskoleksi; }
            set { m_jeniskoleksi = value; }
        }
        public String keterangan
        {
            get { return m_keterangan; }
            set { m_keterangan = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public String jenis_barang
        {
            get { return m_jenis_barang; }
            set { m_jenis_barang = value; }
        }
        public String pdffilename
        {
            get { return m_pdffilename; }
            set { m_pdffilename = value; }
        }
        public String coverbuku
        {
            get { return m_coverbuku; }
            set { m_coverbuku = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_buku(bukuid,pengadaanid,noinduk,kodepanggil,judul,pengarang,badankorporat,edisi,penerbit,tempatterbit,tahunterbit,isbn,deskripsi,supplemen,lokasikoleksi,jeniskoleksi,keterangan,opadd,pcadd,luadd,dlt,nourut,jenis_barang,pdffilename,coverbuku,prodiid)" +
                            "VALUES" +
                            "(@bukuid,@pengadaanid,@noinduk,@kodepanggil,@judul,@pengarang,@badankorporat,@edisi,@penerbit,@tempatterbit,@tahunterbit,@isbn,@deskripsi,@supplemen,@lokasikoleksi,@jeniskoleksi,@keterangan,@opadd,@pcadd,now(),@dlt,@nourut,@jenis_barang,@pdffilename,@coverbuku,@prodiid)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (bukuid != null)
            {
                cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukuid;
            }
            else
            {
                cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengadaanid != null)
            {
                cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaanid;
            }
            else
            {
                cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noinduk != null)
            {
                cmd.Parameters.Add("@noinduk", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noinduk;
            }
            else
            {
                cmd.Parameters.Add("@noinduk", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kodepanggil != null)
            {
                cmd.Parameters.Add("@kodepanggil", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kodepanggil;
            }
            else
            {
                cmd.Parameters.Add("@kodepanggil", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (judul != null)
            {
                cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judul;
            }
            else
            {
                cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengarang != null)
            {
                cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengarang;
            }
            else
            {
                cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (badankorporat != null)
            {
                cmd.Parameters.Add("@badankorporat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = badankorporat;
            }
            else
            {
                cmd.Parameters.Add("@badankorporat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (edisi != null)
            {
                cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = edisi;
            }
            else
            {
                cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (penerbit != null)
            {
                cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = penerbit;
            }
            else
            {
                cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tempatterbit != null)
            {
                cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatterbit;
            }
            else
            {
                cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahunterbit != null)
            {
                cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunterbit;
            }
            else
            {
                cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (isbn != null)
            {
                cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = isbn;
            }
            else
            {
                cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (deskripsi != null)
            {
                cmd.Parameters.Add("@deskripsi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = deskripsi;
            }
            else
            {
                cmd.Parameters.Add("@deskripsi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (supplemen != null)
            {
                cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = supplemen;
            }
            else
            {
                cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lokasikoleksi != null)
            {
                cmd.Parameters.Add("@lokasikoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = lokasikoleksi;
            }
            else
            {
                cmd.Parameters.Add("@lokasikoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskoleksi != null)
            {
                cmd.Parameters.Add("@jeniskoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskoleksi;
            }
            else
            {
                cmd.Parameters.Add("@jeniskoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null)
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (jenis_barang != null)
            {
                cmd.Parameters.Add("@jenis_barang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis_barang;
            }
            else
            {
                cmd.Parameters.Add("@jenis_barang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pdffilename != null)
            {
                cmd.Parameters.Add("@pdffilename", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pdffilename;
            }
            else
            {
                cmd.Parameters.Add("@pdffilename", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (coverbuku != null)
            {
                cmd.Parameters.Add("@coverbuku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = coverbuku;
            }
            else
            {
                cmd.Parameters.Add("@coverbuku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodiid != null)
            {
                cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
                cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_buku SET " +
                            " bukuid=@bukuid,pengadaanid=@pengadaanid,noinduk=@noinduk,kodepanggil=@kodepanggil,judul=@judul,pengarang=@pengarang,badankorporat=@badankorporat,edisi=@edisi,penerbit=@penerbit,tempatterbit=@tempatterbit,tahunterbit=@tahunterbit,isbn=@isbn,deskripsi=@deskripsi,supplemen=@supplemen,lokasikoleksi=@lokasikoleksi,jeniskoleksi=@jeniskoleksi,keterangan=@keterangan,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt=@dlt,nourut=@nourut,jenis_barang=@jenis_barang,pdffilename=@pdffilename,coverbuku=@coverbuku,prodiid=@prodiid" +
                            " WHERE bukuid=@bukuid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (bukuid != null)
            {
                cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukuid;
            }
            else
            {
                cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengadaanid != null)
            {
                cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaanid;
            }
            else
            {
                cmd.Parameters.Add("@pengadaanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (noinduk != null)
            {
                cmd.Parameters.Add("@noinduk", NpgsqlTypes.NpgsqlDbType.Varchar).Value = noinduk;
            }
            else
            {
                cmd.Parameters.Add("@noinduk", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kodepanggil != null)
            {
                cmd.Parameters.Add("@kodepanggil", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kodepanggil;
            }
            else
            {
                cmd.Parameters.Add("@kodepanggil", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (judul != null)
            {
                cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judul;
            }
            else
            {
                cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengarang != null)
            {
                cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengarang;
            }
            else
            {
                cmd.Parameters.Add("@pengarang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (badankorporat != null)
            {
                cmd.Parameters.Add("@badankorporat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = badankorporat;
            }
            else
            {
                cmd.Parameters.Add("@badankorporat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (edisi != null)
            {
                cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = edisi;
            }
            else
            {
                cmd.Parameters.Add("@edisi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (penerbit != null)
            {
                cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = penerbit;
            }
            else
            {
                cmd.Parameters.Add("@penerbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tempatterbit != null)
            {
                cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatterbit;
            }
            else
            {
                cmd.Parameters.Add("@tempatterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahunterbit != null)
            {
                cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunterbit;
            }
            else
            {
                cmd.Parameters.Add("@tahunterbit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (isbn != null)
            {
                cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = isbn;
            }
            else
            {
                cmd.Parameters.Add("@isbn", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (deskripsi != null)
            {
                cmd.Parameters.Add("@deskripsi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = deskripsi;
            }
            else
            {
                cmd.Parameters.Add("@deskripsi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (supplemen != null)
            {
                cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = supplemen;
            }
            else
            {
                cmd.Parameters.Add("@supplemen", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lokasikoleksi != null)
            {
                cmd.Parameters.Add("@lokasikoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = lokasikoleksi;
            }
            else
            {
                cmd.Parameters.Add("@lokasikoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskoleksi != null)
            {
                cmd.Parameters.Add("@jeniskoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskoleksi;
            }
            else
            {
                cmd.Parameters.Add("@jeniskoleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null)
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            if (jenis_barang != null)
            {
                cmd.Parameters.Add("@jenis_barang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis_barang;
            }
            else
            {
                cmd.Parameters.Add("@jenis_barang", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pdffilename != null)
            {
                cmd.Parameters.Add("@pdffilename", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pdffilename;
            }
            else
            {
                cmd.Parameters.Add("@pdffilename", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (coverbuku != null)
            {
                cmd.Parameters.Add("@coverbuku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = coverbuku;
            }
            else
            {
                cmd.Parameters.Add("@coverbuku", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (prodiid != null)
            {
                cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
                cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tbm_buku WHERE bukuid=@bukuid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukuid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbm_buku SET DLT=true , opedit=@opedit, pcedit=@pcedit, luedit=now() WHERE bukuid=@bukuid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukuid;
            cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strEmployeeName;
            cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tbm_buku WHERE bukuid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("bukuid")))
                    {
                        m_bukuid = rdr.GetString(rdr.GetOrdinal("bukuid"));
                    }
                    else
                    {
                        m_bukuid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pengadaanid")))
                    {
                        m_pengadaanid = rdr.GetString(rdr.GetOrdinal("pengadaanid"));
                    }
                    else
                    {
                        m_pengadaanid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("noinduk")))
                    {
                        m_noinduk = rdr.GetString(rdr.GetOrdinal("noinduk"));
                    }
                    else
                    {
                        m_noinduk = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("kodepanggil")))
                    {
                        m_kodepanggil = rdr.GetString(rdr.GetOrdinal("kodepanggil"));
                    }
                    else
                    {
                        m_kodepanggil = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("judul")))
                    {
                        m_judul = rdr.GetString(rdr.GetOrdinal("judul"));
                    }
                    else
                    {
                        m_judul = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pengarang")))
                    {
                        m_pengarang = rdr.GetString(rdr.GetOrdinal("pengarang"));
                    }
                    else
                    {
                        m_pengarang = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("badankorporat")))
                    {
                        m_badankorporat = rdr.GetString(rdr.GetOrdinal("badankorporat"));
                    }
                    else
                    {
                        m_badankorporat = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("edisi")))
                    {
                        m_edisi = rdr.GetString(rdr.GetOrdinal("edisi"));
                    }
                    else
                    {
                        m_edisi = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("penerbit")))
                    {
                        m_penerbit = rdr.GetString(rdr.GetOrdinal("penerbit"));
                    }
                    else
                    {
                        m_penerbit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tempatterbit")))
                    {
                        m_tempatterbit = rdr.GetString(rdr.GetOrdinal("tempatterbit"));
                    }
                    else
                    {
                        m_tempatterbit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tahunterbit")))
                    {
                        m_tahunterbit = rdr.GetString(rdr.GetOrdinal("tahunterbit"));
                    }
                    else
                    {
                        m_tahunterbit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("isbn")))
                    {
                        m_isbn = rdr.GetString(rdr.GetOrdinal("isbn"));
                    }
                    else
                    {
                        m_isbn = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("deskripsi")))
                    {
                        m_deskripsi = rdr.GetString(rdr.GetOrdinal("deskripsi"));
                    }
                    else
                    {
                        m_deskripsi = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("supplemen")))
                    {
                        m_supplemen = rdr.GetString(rdr.GetOrdinal("supplemen"));
                    }
                    else
                    {
                        m_supplemen = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lokasikoleksi")))
                    {
                        m_lokasikoleksi = rdr.GetString(rdr.GetOrdinal("lokasikoleksi"));
                    }
                    else
                    {
                        m_lokasikoleksi = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jeniskoleksi")))
                    {
                        m_jeniskoleksi = rdr.GetString(rdr.GetOrdinal("jeniskoleksi"));
                    }
                    else
                    {
                        m_jeniskoleksi = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("keterangan")))
                    {
                        m_keterangan = rdr.GetString(rdr.GetOrdinal("keterangan"));
                    }
                    else
                    {
                        m_keterangan = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opadd")))
                    {
                        m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
                    }
                    else
                    {
                        m_opadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd")))
                    {
                        m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
                    }
                    else
                    {
                        m_pcadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luadd")))
                    {
                        m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
                    }
                    else
                    {
                        m_luadd = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opedit")))
                    {
                        m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
                    }
                    else
                    {
                        m_opedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit")))
                    {
                        m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
                    }
                    else
                    {
                        m_pcedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luedit")))
                    {
                        m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
                    }
                    else
                    {
                        m_luedit = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dlt")))
                    {
                        m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                    }
                    else
                    {
                        m_dlt = false;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("nourut")))
                    {
                        m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
                    }
                    else
                    {
                        m_nourut = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("jenis_barang")))
                    {
                        m_jenis_barang = rdr.GetString(rdr.GetOrdinal("jenis_barang"));
                    }
                    else
                    {
                        m_jenis_barang = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pdffilename")))
                    {
                        m_pdffilename = rdr.GetString(rdr.GetOrdinal("pdffilename"));
                    }
                    else
                    {
                        m_pdffilename = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("coverbuku")))
                    {
                        m_coverbuku = rdr.GetString(rdr.GetOrdinal("coverbuku"));
                    }
                    else
                    {
                        m_coverbuku = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid")))
                    {
                        m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
                    }
                    else
                    {
                        m_prodiid = "";
                    };
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbm_buku");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbm_buku");
            return dt;
        }

        public System.Data.DataTable GetData(string strSQL)
        {
            if (strSQL == "")
            {
                strSQL = "select * from tbm_buku where dlt='0' ";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tbm_buku");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tbm_buku");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.pstrservercode + "'||nextval('tbm_buku_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }


        #region "Import Excel"
        public override void UpdateDB()
        {

        }
        int idxtypecode = 1;
        int idxmaterialdesc = 2;
        int idxunitweight = 3;
        int idxweight_uom = 4;
        int idxgpsgrade = 5;
        int idxgrade = 6;
        int idxsize = 7;
        int idxsize2 = 8;
        int idxsize3 = 9;
        int idxmaterialcode = 10;

        public DataTable getExcelData()
        {

            CreateTemporaryFile(@"" + clsGlobal.pstrAppPath + @"\$TEMPORARYFILEIMPORT$." + m_ExcelType + "",
                                  @"" + clsGlobal.pstrAppPath + @"\$TEMPORARYFILEIMPORT_COPIED$." + m_ExcelType + "");

            string selectArg = @"SELECT abs(true) as [select], * ";

            DataTable dt = GetDataTemporary(@"" + clsGlobal.pstrAppPath + @"\$TEMPORARYFILEIMPORT$." + m_ExcelType + "", selectArg);
            DataColumn cbukuid = new DataColumn();
            cbukuid.DataType = System.Type.GetType("System.String");
            cbukuid.ColumnName = "bukuid";
            dt.Columns.Add(cbukuid);

            DataColumn cinventarisid = new DataColumn();
            cinventarisid.DataType = System.Type.GetType("System.String");
            cinventarisid.ColumnName = "inventarisid";
            dt.Columns.Add(cinventarisid);

            clsConnection oconn = new clsConnection();
            DataTable dttbm_buku = oconn.GetData("select bukuid, pengadaanid, noinduk, judul, kodepanggil, pengarang, edisi from tbm_buku where dlt='0'");

            DataTable dttbm_inventaris = oconn.GetData(@"select inv.inventarisid, inv.bukuid, inv.pengadaandetailsid, inv.rfid, inv.nib from tbm_inventaris inv
            where inv.dlt='0'
            ");
            foreach (DataRow dRows in dt.Rows)
            {
                DataRow[] dr0 = dttbm_buku.Select("noinduk='" + Regex.Replace(Convert.ToString(dRows["Bibli"]).Trim().Replace("'", "''"), @"\t|\n|\r", "") + @"'
                    and kodepanggil='" + Regex.Replace(Convert.ToString(dRows["Kode Panggil/ Kode DDC"]).Trim().Replace("'", "''"), @"\t|\n|\r", "") + @"'
                    ");
                if (dr0.Length > 0)
                    dRows["bukuid"] = dr0[0]["bukuid"];

                string strFilter = @"nib='" + Regex.Replace(Convert.ToString(dRows["No Inventaris Buku (NIB)"]).Trim().Replace("'", "''"), @"\t|\n|\r", "") + @"' 
                    and bukuid='" + dRows["bukuid"] + "'";
                DataRow[] drx = dttbm_inventaris.Select(strFilter);
                if (drx.Length > 0)
                {
                    dRows["inventarisid"] = drx[0]["inventarisid"];
                }
            }
            return dt;
        }
        public string discipline;
        public DataTable ImportNewData(DataTable dtsource)
        {
            iUpdatedRow = 0;
            iFailUpdatedRow = 0;
            DataTable dtFail = new DataTable();
            dtFail = dtsource.Clone();
            dtFail.Clear();

            int iTotalRow, iColExcel;
            iTotalRow = dtsource.Rows.Count;
            iColExcel = dtsource.Columns.Count;

            string sql = "";
            string srefResult = "";

            DateTime dateOut;
            decimal decOut;

            NpgsqlCommand npcmd;
            string checkStep = "";

            DateTime prevtglditerima = DateTime.MinValue;
            string prevBibli = "";
            for (int iRow = 0; iRow < iTotalRow; iRow++)
            {
                if (Convert.ToBoolean(dtsource.Rows[iRow]["select"]) == false) continue;
                checkStep = "";
                bIsInserted = false;
                checkStep = "Buku";
                if (Convert.ToString(dtsource.Rows[iRow]["Bibli"]).Trim() == "")
                {
                    dtsource.Rows[iRow]["Bibli"] = prevBibli;
                }


                if (Convert.ToString(dtsource.Rows[iRow]["Bibli"]).Trim() == "" &&
                    Convert.ToString(dtsource.Rows[iRow]["Judul"]).Trim() == "")
                {
                    iUpdatedRow++;
                    goto UpdateProgress;
                }
                prevBibli = Convert.ToString(dtsource.Rows[iRow]["Bibli"]).Trim();

                #region buku
                tbm_buku otbm_buku = new tbm_buku();
                if (Koneksi.State == ConnectionState.Closed)
                    Koneksi.Open();
                otbm_buku.Koneksi = Koneksi;
                otbm_buku.bukuid = Convert.ToString(dtsource.Rows[iRow]["bukuid"]);

                if (string.IsNullOrEmpty(otbm_buku.bukuid))
                {
                    sql = @"select bukuid from tbm_buku where dlt='0'                         
                        and lower(coalesce(noinduk,''))=lower(@noinduk)                        
                        and lower(coalesce(judul,''))=lower(@judul)                      
                        ";
                    npcmd = new NpgsqlCommand();
                    npcmd.CommandText = sql;
                    npcmd.Parameters.Add("@noinduk", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Bibli"]).Trim(), @"\t|\n|\r", "");
                    npcmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Judul"]).Trim(), @"\t|\n|\r", "");

                    otbm_buku.bukuid = getData1Field(npcmd);
                }

                if (!string.IsNullOrEmpty(otbm_buku.bukuid))
                {
                    otbm_buku.GetByPrimaryKey(otbm_buku.bukuid);
                }

                otbm_buku.noinduk = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Bibli"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.kodepanggil = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Kode Panggil/ Kode DDC"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.judul = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Judul"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.pengarang = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Pengarang"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.badankorporat = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Badan Korporat"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.edisi = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Edisi"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.penerbit = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Penerbit"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.tempatterbit = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Tempat Terbit"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.tahunterbit = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Tahun Terbit"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.isbn = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["ISBN"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.deskripsi = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Deskripsi Fisik"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.supplemen = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Suplemen"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.lokasikoleksi = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["No Rak"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.jeniskoleksi = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Keterangan"]).Trim(), @"\t|\n|\r", "");
                otbm_buku.keterangan = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["KET STOCK"]).Trim(), @"\t|\n|\r", "");

                otbm_buku.dlt = false;


                if (Convert.ToString(otbm_buku.bukuid) == "" || otbm_buku.bukuid == null)
                {
                    otbm_buku.jenis_barang = jenis_barang;
                    //otbm_buku.pdffilename = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["pdffilename"]).Trim(), @"\t|\n|\r", "");
                    otbm_buku.nourut = 1;
                    otbm_buku.opadd = clsGlobal.strUserID + "- AUTO";
                    otbm_buku.pcadd = SystemInformation.ComputerName;
                    otbm_buku.bukuid = Convert.ToString(otbm_buku.NewID());
                    otbm_buku.Insert();

                }
                else
                {
                    otbm_buku.opedit = clsGlobal.strUserID + "- AUTO";
                    otbm_buku.pcedit = SystemInformation.ComputerName;
                    otbm_buku.Update();

                }


                #endregion

                #region Details
                tbm_inventaris otbm_inventaris = new tbm_inventaris();
                if (Koneksi.State == ConnectionState.Closed)
                    Koneksi.Open();
                otbm_inventaris.Koneksi = Koneksi;
                otbm_inventaris.inventarisid = Convert.ToString(dtsource.Rows[iRow]["inventarisid"]);
                otbm_inventaris.bukuid = otbm_buku.bukuid;
                if (string.IsNullOrEmpty(otbm_inventaris.inventarisid))
                {
                    sql = @"select inventarisid from tbm_inventaris where dlt='0' 
                        and lower(coalesce(bukuid,''))=lower(@bukuid) and lower(coalesce(nib,''))=lower(@nib) 
                        ";
                    npcmd = new NpgsqlCommand();
                    npcmd.CommandText = sql;
                    npcmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Convert.ToString(otbm_inventaris.bukuid);
                    npcmd.Parameters.Add("@nib", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["No Inventaris Buku (NIB)"]).Trim(), @"\t|\n|\r", "");
                    otbm_inventaris.inventarisid = getData1Field(npcmd);
                }
                if (!string.IsNullOrEmpty(otbm_inventaris.inventarisid))
                {
                    otbm_inventaris.GetByPrimaryKey(otbm_inventaris.inventarisid);
                }
                otbm_inventaris.tglditerima = clsGlobal.GetParseDate(Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Tanggal diterima"]).Trim(), @"\t|\n|\r", ""));
                if (otbm_inventaris.tglditerima == DateTime.MinValue)
                {
                    otbm_inventaris.tglditerima = prevtglditerima;
                }
                otbm_inventaris.nib = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["No Inventaris Buku (NIB)"]).Trim(), @"\t|\n|\r", "");
                otbm_inventaris.status = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Keterangan"]).Trim(), @"\t|\n|\r", "");
                //otbm_inventaris.ket_koleksi = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["ket_koleksi"]).Trim(), @"\t|\n|\r", "");
                otbm_inventaris.kode_makul = Regex.Replace(Convert.ToString(dtsource.Rows[iRow]["Mata Kuliah"]).Trim(), @"\t|\n|\r", "");

                otbm_inventaris.dlt = false;

                if (Koneksi.State == ConnectionState.Closed) Koneksi.Open();
                otbm_inventaris.Koneksi = Koneksi;
                if (Convert.ToString(otbm_inventaris.inventarisid) == "" || otbm_inventaris.inventarisid == null)
                {
                    otbm_inventaris.nourut = 1;
                    otbm_inventaris.opadd = clsGlobal.strUserID + "- AUTO";
                    otbm_inventaris.pcadd = SystemInformation.ComputerName;
                    otbm_inventaris.inventarisid = Convert.ToString(otbm_inventaris.NewID());
                    otbm_inventaris.Insert();
                    bIsInserted = true;
                }
                else
                {
                    otbm_inventaris.opedit = clsGlobal.strUserID + "- AUTO";
                    otbm_inventaris.pcedit = SystemInformation.ComputerName;
                    otbm_inventaris.Update();
                    bIsInserted = true;
                }
                prevtglditerima = otbm_inventaris.tglditerima;
                #endregion

                iUpdatedRow++;
            FoundMissingLinks:
                if (!bIsInserted)
                {
                    object[] val = new object[iColExcel];
                    for (int iCol = 0; iCol <= iColExcel - 1; iCol++)
                    {
                        if (iCol == iColExcel - 1)
                        {
                            val[iCol] = checkStep;
                        }
                        else
                        {
                            if (dtsource.Rows[iRow][iCol] == null)
                                val[iCol] = "";
                            else
                                val[iCol] = dtsource.Rows[iRow][iCol];
                        }
                    }

                    dtFail.Rows.Add(val);
                }
            UpdateProgress:
                onUpdate(Convert.ToString(iTotalRow));
            }
            iFailUpdatedRow = dtFail.Rows.Count;

            return dtFail;

        }

        public string[] getArrDataField(NpgsqlCommand ocmd)
        {
            string[] val = { };
            try
            {

                DataTable dt = new DataTable();
                if (Koneksi.State == ConnectionState.Closed) Koneksi.Open();
                ocmd.Connection = Koneksi;
                ocmd.CommandType = CommandType.Text;
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(ocmd);
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    val = new string[dt.Columns.Count];
                    for (int iCol = 0; iCol <= dt.Columns.Count - 1; iCol++)
                    {
                        if (dt.Rows[0][iCol] == null)
                            val[iCol] = "";
                        else
                            val[iCol] = dt.Rows[0][iCol].ToString();
                    }
                    //val = dt.Rows[0].ItemArray.GetValue(0).ToString();
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.ToString());
            }
            return val;
        }
        public string getData1Field(NpgsqlCommand ocmd)
        {
            string strHasil = "";
            try
            {

                DataTable dt = new DataTable();
                if (Koneksi.State == ConnectionState.Closed) Koneksi.Open();
                ocmd.Connection = Koneksi;
                ocmd.CommandType = CommandType.Text;
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(ocmd);
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    strHasil = dt.Rows[0].ItemArray.GetValue(0).ToString();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            return strHasil;
        }
        private bool bIsInserted = false;
        private bool bIsLastRowNull = false;
        public static int iUpdatedRow = 0;
        public static int iFailUpdatedRow = 0;

        public event updateProgressBar updateEventMsg;

        protected void onUpdate(string msg)
        {
            if (msg != null)
            {
                Control target = updateEventMsg.Target as Control;
                if (target != null && target.InvokeRequired)
                {
                    object[] args = new object[] { this, msg };
                    target.Invoke(updateEventMsg);
                }
                else
                {
                    updateEventMsg(this, msg);

                }
            }
        }


        #endregion

    }
}
