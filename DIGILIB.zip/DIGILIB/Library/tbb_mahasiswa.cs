﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbb_mahasiswa
    {
        private String m_mahasiswaid;
        private String m_nim;
        private String m_namalengkap;
        private String m_jeniskelamin;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_tempatlahir;
        private DateTime m_tgllahir;
        private String m_tahunangkatan;
        private String m_username;
        private String m__password;
        private String m_captcha;
        private bool m_isactive;
        private String m_prodiid;
        private String m_photo;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String mahasiswaid
        {
            get { return m_mahasiswaid; }
            set { m_mahasiswaid = value; }
        }
        public String nim
        {
            get { return m_nim; }
            set { m_nim = value; }
        }
        public String namalengkap
        {
            get { return m_namalengkap; }
            set { m_namalengkap = value; }
        }
        public String jeniskelamin
        {
            get { return m_jeniskelamin; }
            set { m_jeniskelamin = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String tempatlahir
        {
            get { return m_tempatlahir; }
            set { m_tempatlahir = value; }
        }
        public DateTime tgllahir
        {
            get { return m_tgllahir; }
            set { m_tgllahir = value; }
        }
        public String tahunangkatan
        {
            get { return m_tahunangkatan; }
            set { m_tahunangkatan = value; }
        }
        public String username
        {
            get { return m_username; }
            set { m_username = value; }
        }
        public String _password
        {
            get { return m__password; }
            set { m__password = value; }
        }
        public String captcha
        {
            get { return m_captcha; }
            set { m_captcha = value; }
        }
        public bool isactive
        {
            get { return m_isactive; }
            set { m_isactive = value; }
        }
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String photo
        {
            get { return m_photo; }
            set { m_photo = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbb_mahasiswa(mahasiswaid,nim,namalengkap,jeniskelamin,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt,tempatlahir,tgllahir,tahunangkatan,username,_password,captcha,isactive,prodiid,photo)" +
                            "VALUES"+
                            "(@mahasiswaid,@nim,@namalengkap,@jeniskelamin,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0',@tempatlahir,@tgllahir,@tahunangkatan,@username, "+
                            "convert_from(encrypt((@_password)::bytea, '1234', 'aes'),'SQL_ASCII'),@captcha,@isactive,@prodiid,@photo)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (mahasiswaid != null )
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nim != null )
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nim;
            }
            else
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (namalengkap != null )
            {
               cmd.Parameters.Add("@namalengkap", NpgsqlTypes.NpgsqlDbType.Varchar).Value = namalengkap;
            }
            else
            {
               cmd.Parameters.Add("@namalengkap", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskelamin != null )
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskelamin;
            }
            else
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tempatlahir != null )
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatlahir;
            }
            else
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tgllahir != null && tgllahir != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgllahir;
            }
            else
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tahunangkatan != null )
            {
               cmd.Parameters.Add("@tahunangkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunangkatan;
            }
            else
            {
               cmd.Parameters.Add("@tahunangkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (username != null )
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = username;
            }
            else
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (_password != null )
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = _password;
            }
            else
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (captcha != null )
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = captcha;
            }
            else
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@isactive", NpgsqlTypes.NpgsqlDbType.Boolean).Value = isactive;
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (photo != null)
            {
                cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = photo;
            }
            else
            {
                cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbb_mahasiswa SET "+
                            " mahasiswaid=@mahasiswaid,nim=@nim,namalengkap=@namalengkap,jeniskelamin=@jeniskelamin,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0',tempatlahir=@tempatlahir,tgllahir=@tgllahir,tahunangkatan=@tahunangkatan,username=@username, "+
                            " _password=(convert_from(encrypt((@_password)::bytea, '1234', 'aes'),'SQL_ASCII')),captcha=@captcha,isactive=@isactive,prodiid=@prodiid,photo=@photo" +
                            " WHERE mahasiswaid=@mahasiswaid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (mahasiswaid != null )
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            }
            else
            {
               cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nim != null )
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nim;
            }
            else
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (namalengkap != null )
            {
               cmd.Parameters.Add("@namalengkap", NpgsqlTypes.NpgsqlDbType.Varchar).Value = namalengkap;
            }
            else
            {
               cmd.Parameters.Add("@namalengkap", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskelamin != null )
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskelamin;
            }
            else
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (tempatlahir != null )
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tempatlahir;
            }
            else
            {
               cmd.Parameters.Add("@tempatlahir", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tgllahir != null && tgllahir != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgllahir;
            }
            else
            {
               cmd.Parameters.Add("@tgllahir", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tahunangkatan != null )
            {
               cmd.Parameters.Add("@tahunangkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahunangkatan;
            }
            else
            {
               cmd.Parameters.Add("@tahunangkatan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (username != null )
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = username;
            }
            else
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (_password != null )
            {
                
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = _password;
            }
            else
            {
               cmd.Parameters.Add("@_password", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (captcha != null )
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = captcha;
            }
            else
            {
               cmd.Parameters.Add("@captcha", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@isactive", NpgsqlTypes.NpgsqlDbType.Boolean).Value = isactive;
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (photo != null)
            {
                cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = photo;
            }
            else
            {
                cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbb_mahasiswa WHERE mahasiswaid=@mahasiswaid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbb_mahasiswa SET DLT='1',op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now() WHERE mahasiswaid=@mahasiswaid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@mahasiswaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = mahasiswaid;
            if (op_edit != null)
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
                cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null)
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
                cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbb_mahasiswa WHERE mahasiswaid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("mahasiswaid"))) 
            {
              m_mahasiswaid = rdr.GetString(rdr.GetOrdinal("mahasiswaid"));
            }
            else
            {
              m_mahasiswaid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nim"))) 
            {
              m_nim = rdr.GetString(rdr.GetOrdinal("nim"));
            }
            else
            {
              m_nim = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("namalengkap"))) 
            {
              m_namalengkap = rdr.GetString(rdr.GetOrdinal("namalengkap"));
            }
            else
            {
              m_namalengkap = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jeniskelamin"))) 
            {
              m_jeniskelamin = rdr.GetString(rdr.GetOrdinal("jeniskelamin"));
            }
            else
            {
              m_jeniskelamin = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("tempatlahir"))) 
            {
              m_tempatlahir = rdr.GetString(rdr.GetOrdinal("tempatlahir"));
            }
            else
            {
              m_tempatlahir = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tgllahir"))) 
            {
              m_tgllahir = rdr.GetDateTime(rdr.GetOrdinal("tgllahir"));
            }
            else
            {
              m_tgllahir = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tahunangkatan"))) 
            {
              m_tahunangkatan = rdr.GetString(rdr.GetOrdinal("tahunangkatan"));
            }
            else
            {
              m_tahunangkatan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("username"))) 
            {
              m_username = rdr.GetString(rdr.GetOrdinal("username"));
            }
            else
            {
              m_username = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("_password"))) 
            {
              m__password = rdr.GetString(rdr.GetOrdinal("_password"));
            }
            else
            {
              m__password = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("captcha"))) 
            {
              m_captcha = rdr.GetString(rdr.GetOrdinal("captcha"));
            }
            else
            {
              m_captcha = "";
            };
             m_isactive = rdr.GetBoolean(rdr.GetOrdinal("isactive"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid"))) 
            {
              m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
            }
            else
            {
              m_prodiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("photo")))
            {
                m_photo = rdr.GetString(rdr.GetOrdinal("photo"));
            }
            else
            {
                m_photo = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbb_mahasiswa");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbb_mahasiswa");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbb_mahasiswa";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbb_mahasiswa");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbb_mahasiswa");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbb_mahasiswa_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
