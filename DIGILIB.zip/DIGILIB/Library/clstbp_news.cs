﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstbp_news
    {
        private String m_newsid;
        private DateTime m_tglterbit;
        private String m_news;
        private String m_news_html;
        private decimal m_nourut;
        private bool m_isterbit;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private String m_judul;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String newsid
        {
            get { return m_newsid; }
            set { m_newsid = value; }
        }
        public DateTime tglterbit
        {
            get { return m_tglterbit; }
            set { m_tglterbit = value; }
        }
        public String news
        {
            get { return m_news; }
            set { m_news = value; }
        }
        public String news_html
        {
            get { return m_news_html; }
            set { m_news_html = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public bool isterbit
        {
            get { return m_isterbit; }
            set { m_isterbit = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String judul
        {
            get { return m_judul; }
            set { m_judul = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbp_news(newsid,tglterbit,news,news_html,nourut,isterbit,opadd,pcadd,luadd,dlt,judul)"+
                            "VALUES"+
                            "(@newsid,@tglterbit,@news,@news_html,@nourut,@isterbit,@opadd,@pcadd,now(),@dlt,@judul)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (newsid != null )
            {
               cmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = newsid;
            }
            else
            {
               cmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglterbit != null && tglterbit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglterbit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglterbit;
            }
            else
            {
               cmd.Parameters.Add("@tglterbit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (news != null )
            {
               cmd.Parameters.Add("@news", NpgsqlTypes.NpgsqlDbType.Varchar).Value = news;
            }
            else
            {
               cmd.Parameters.Add("@news", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (news_html != null )
            {
               cmd.Parameters.Add("@news_html", NpgsqlTypes.NpgsqlDbType.Varchar).Value = news_html;
            }
            else
            {
               cmd.Parameters.Add("@news_html", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
               cmd.Parameters.Add("@isterbit", NpgsqlTypes.NpgsqlDbType.Boolean).Value = isterbit;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (judul != null )
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judul;
            }
            else
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbp_news SET "+
                            " newsid=@newsid,tglterbit=@tglterbit,news=@news,news_html=@news_html,nourut=@nourut,isterbit=@isterbit,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt=@dlt,judul=@judul"+
                            " WHERE newsid=@newsid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (newsid != null )
            {
               cmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = newsid;
            }
            else
            {
               cmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglterbit != null && tglterbit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglterbit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglterbit;
            }
            else
            {
               cmd.Parameters.Add("@tglterbit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (news != null )
            {
               cmd.Parameters.Add("@news", NpgsqlTypes.NpgsqlDbType.Varchar).Value = news;
            }
            else
            {
               cmd.Parameters.Add("@news", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (news_html != null )
            {
               cmd.Parameters.Add("@news_html", NpgsqlTypes.NpgsqlDbType.Varchar).Value = news_html;
            }
            else
            {
               cmd.Parameters.Add("@news_html", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
               cmd.Parameters.Add("@isterbit", NpgsqlTypes.NpgsqlDbType.Boolean).Value = isterbit;
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (judul != null )
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = judul;
            }
            else
            {
               cmd.Parameters.Add("@judul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbp_news WHERE newsid=@newsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = newsid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbp_news SET DLT=true , opedit=@opedit, pcedit=@pcedit, luedit=now() WHERE newsid=@newsid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
               cmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = newsid;
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strEmployeeName;
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbp_news WHERE newsid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("newsid"))) 
            {
              m_newsid = rdr.GetString(rdr.GetOrdinal("newsid"));
            }
            else
            {
              m_newsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tglterbit"))) 
            {
              m_tglterbit = rdr.GetDateTime(rdr.GetOrdinal("tglterbit"));
            }
            else
            {
              m_tglterbit = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("news"))) 
            {
              m_news = rdr.GetString(rdr.GetOrdinal("news"));
            }
            else
            {
              m_news = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("news_html"))) 
            {
              m_news_html = rdr.GetString(rdr.GetOrdinal("news_html"));
            }
            else
            {
              m_news_html = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nourut"))) 
            {
              m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
            }
            else
            {
              m_nourut = 0;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("isterbit"))) 
            {
             m_isterbit = rdr.GetBoolean(rdr.GetOrdinal("isterbit"));
            }
            else
            {
              m_isterbit = false;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opadd"))) 
            {
              m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
            }
            else
            {
              m_opadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd"))) 
            {
              m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
            }
            else
            {
              m_pcadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luadd"))) 
            {
              m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
            }
            else
            {
              m_luadd = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opedit"))) 
            {
              m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
            }
            else
            {
              m_opedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit"))) 
            {
              m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
            }
            else
            {
              m_pcedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luedit"))) 
            {
              m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
            }
            else
            {
              m_luedit = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dlt"))) 
            {
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            }
            else
            {
              m_dlt = false;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("judul"))) 
            {
              m_judul = rdr.GetString(rdr.GetOrdinal("judul"));
            }
            else
            {
              m_judul = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_news");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_news");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbp_news where dlt='0' ";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi); 
         cmd.CommandTimeout = 0; 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbp_news");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbp_news");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         cmd.CommandTimeout = 0;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.pstrservercode + "'||nextval('tbp_news_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
