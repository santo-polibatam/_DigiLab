﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbm_anggota
    {
        private String m_anggotaid;
        private String m_rfid;
        private String m_nim;
        private String m_nama;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private String m_prodiid;
        private String m_jeniskelamin;
        private String m_alamat;
        private String m_nohp;
        private String m_keterangan;
        private String m_statusaktif;
        private String m_photo;
        private String m_jenis;
        private String m_username;
        private String m_passwd;
        private String m_hak_akses;
        private String m_usergroupid;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String anggotaid
        {
            get { return m_anggotaid; }
            set { m_anggotaid = value; }
        }
        public String rfid
        {
            get { return m_rfid; }
            set { m_rfid = value; }
        }
        public String nim
        {
            get { return m_nim; }
            set { m_nim = value; }
        }
        public String nama
        {
            get { return m_nama; }
            set { m_nama = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String prodiid
        {
            get { return m_prodiid; }
            set { m_prodiid = value; }
        }
        public String jeniskelamin
        {
            get { return m_jeniskelamin; }
            set { m_jeniskelamin = value; }
        }
        public String alamat
        {
            get { return m_alamat; }
            set { m_alamat = value; }
        }
        public String nohp
        {
            get { return m_nohp; }
            set { m_nohp = value; }
        }
        public String keterangan
        {
            get { return m_keterangan; }
            set { m_keterangan = value; }
        }
        public String statusaktif
        {
            get { return m_statusaktif; }
            set { m_statusaktif = value; }
        }
        public String photo
        {
            get { return m_photo; }
            set { m_photo = value; }
        }
        public String jenis
        {
            get { return m_jenis; }
            set { m_jenis = value; }
        }
        public String username
        {
            get { return m_username; }
            set { m_username = value; }
        }
        public String passwd
        {
            get { return m_passwd; }
            set { m_passwd = value; }
        }
        public String hak_akses
        {
            get { return m_hak_akses; }
            set { m_hak_akses = value; }
        }
        public String usergroupid
        {
            get { return m_usergroupid; }
            set { m_usergroupid = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_anggota(anggotaid,rfid,nim,nama,opadd,pcadd,luadd,dlt,prodiid,jeniskelamin,alamat,nohp,keterangan,statusaktif,photo,jenis,username,passwd,hak_akses,usergroupid)"+
                            "VALUES"+
                            "(@anggotaid,@rfid,@nim,@nama,@opadd,@pcadd,now(),@dlt,@prodiid,@jeniskelamin,@alamat,@nohp,@keterangan,@statusaktif,@photo,@jenis,@username,@passwd,@hak_akses,@usergroupid)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (anggotaid != null )
            {
               cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
            }
            else
            {
               cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (rfid != null )
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = rfid;
            }
            else
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nim != null )
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nim;
            }
            else
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nama != null )
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nama;
            }
            else
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskelamin != null )
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskelamin;
            }
            else
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamat != null )
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamat;
            }
            else
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nohp != null )
            {
               cmd.Parameters.Add("@nohp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nohp;
            }
            else
            {
               cmd.Parameters.Add("@nohp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null )
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statusaktif != null )
            {
               cmd.Parameters.Add("@statusaktif", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statusaktif;
            }
            else
            {
               cmd.Parameters.Add("@statusaktif", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (photo != null )
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = photo;
            }
            else
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenis != null )
            {
               cmd.Parameters.Add("@jenis", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis;
            }
            else
            {
               cmd.Parameters.Add("@jenis", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (username != null )
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = username;
            }
            else
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (passwd != null )
            {
               cmd.Parameters.Add("@passwd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = passwd;
            }
            else
            {
               cmd.Parameters.Add("@passwd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (hak_akses != null )
            {
               cmd.Parameters.Add("@hak_akses", NpgsqlTypes.NpgsqlDbType.Varchar).Value = hak_akses;
            }
            else
            {
               cmd.Parameters.Add("@hak_akses", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (usergroupid != null )
            {
               cmd.Parameters.Add("@usergroupid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = usergroupid;
            }
            else
            {
               cmd.Parameters.Add("@usergroupid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_anggota SET "+
                            " anggotaid=@anggotaid,rfid=@rfid,nim=@nim,nama=@nama,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt=@dlt,prodiid=@prodiid,jeniskelamin=@jeniskelamin,alamat=@alamat,nohp=@nohp,keterangan=@keterangan,statusaktif=@statusaktif,photo=@photo,jenis=@jenis,username=@username,passwd=@passwd,hak_akses=@hak_akses,usergroupid=@usergroupid"+
                            " WHERE anggotaid=@anggotaid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (anggotaid != null )
            {
               cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
            }
            else
            {
               cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (rfid != null )
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = rfid;
            }
            else
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nim != null )
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nim;
            }
            else
            {
               cmd.Parameters.Add("@nim", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nama != null )
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nama;
            }
            else
            {
               cmd.Parameters.Add("@nama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (prodiid != null )
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = prodiid;
            }
            else
            {
               cmd.Parameters.Add("@prodiid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jeniskelamin != null )
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jeniskelamin;
            }
            else
            {
               cmd.Parameters.Add("@jeniskelamin", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (alamat != null )
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = alamat;
            }
            else
            {
               cmd.Parameters.Add("@alamat", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nohp != null )
            {
               cmd.Parameters.Add("@nohp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nohp;
            }
            else
            {
               cmd.Parameters.Add("@nohp", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null )
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
               cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (statusaktif != null )
            {
               cmd.Parameters.Add("@statusaktif", NpgsqlTypes.NpgsqlDbType.Varchar).Value = statusaktif;
            }
            else
            {
               cmd.Parameters.Add("@statusaktif", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (photo != null )
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = photo;
            }
            else
            {
               cmd.Parameters.Add("@photo", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (jenis != null )
            {
               cmd.Parameters.Add("@jenis", NpgsqlTypes.NpgsqlDbType.Varchar).Value = jenis;
            }
            else
            {
               cmd.Parameters.Add("@jenis", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (username != null )
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = username;
            }
            else
            {
               cmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (passwd != null )
            {
               cmd.Parameters.Add("@passwd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = passwd;
            }
            else
            {
               cmd.Parameters.Add("@passwd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (hak_akses != null )
            {
               cmd.Parameters.Add("@hak_akses", NpgsqlTypes.NpgsqlDbType.Varchar).Value = hak_akses;
            }
            else
            {
               cmd.Parameters.Add("@hak_akses", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (usergroupid != null )
            {
               cmd.Parameters.Add("@usergroupid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = usergroupid;
            }
            else
            {
               cmd.Parameters.Add("@usergroupid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbm_anggota WHERE anggotaid=@anggotaid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbm_anggota SET DLT=true , opedit=@opedit, pcedit=@pcedit, luedit=now() WHERE anggotaid=@anggotaid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
               cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserID;
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbm_anggota WHERE anggotaid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("anggotaid"))) 
            {
              m_anggotaid = rdr.GetString(rdr.GetOrdinal("anggotaid"));
            }
            else
            {
              m_anggotaid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("rfid"))) 
            {
              m_rfid = rdr.GetString(rdr.GetOrdinal("rfid"));
            }
            else
            {
              m_rfid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nim"))) 
            {
              m_nim = rdr.GetString(rdr.GetOrdinal("nim"));
            }
            else
            {
              m_nim = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nama"))) 
            {
              m_nama = rdr.GetString(rdr.GetOrdinal("nama"));
            }
            else
            {
              m_nama = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opadd"))) 
            {
              m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
            }
            else
            {
              m_opadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd"))) 
            {
              m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
            }
            else
            {
              m_pcadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luadd"))) 
            {
              m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
            }
            else
            {
              m_luadd = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opedit"))) 
            {
              m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
            }
            else
            {
              m_opedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit"))) 
            {
              m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
            }
            else
            {
              m_pcedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luedit"))) 
            {
              m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
            }
            else
            {
              m_luedit = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("dlt"))) 
            {
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            }
            else
            {
              m_dlt = false;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("prodiid"))) 
            {
              m_prodiid = rdr.GetString(rdr.GetOrdinal("prodiid"));
            }
            else
            {
              m_prodiid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jeniskelamin"))) 
            {
              m_jeniskelamin = rdr.GetString(rdr.GetOrdinal("jeniskelamin"));
            }
            else
            {
              m_jeniskelamin = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("alamat"))) 
            {
              m_alamat = rdr.GetString(rdr.GetOrdinal("alamat"));
            }
            else
            {
              m_alamat = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nohp"))) 
            {
              m_nohp = rdr.GetString(rdr.GetOrdinal("nohp"));
            }
            else
            {
              m_nohp = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("keterangan"))) 
            {
              m_keterangan = rdr.GetString(rdr.GetOrdinal("keterangan"));
            }
            else
            {
              m_keterangan = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("statusaktif"))) 
            {
              m_statusaktif = rdr.GetString(rdr.GetOrdinal("statusaktif"));
            }
            else
            {
              m_statusaktif = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("photo"))) 
            {
              m_photo = rdr.GetString(rdr.GetOrdinal("photo"));
            }
            else
            {
              m_photo = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("jenis"))) 
            {
              m_jenis = rdr.GetString(rdr.GetOrdinal("jenis"));
            }
            else
            {
              m_jenis = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("username"))) 
            {
              m_username = rdr.GetString(rdr.GetOrdinal("username"));
            }
            else
            {
              m_username = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("passwd"))) 
            {
              m_passwd = rdr.GetString(rdr.GetOrdinal("passwd"));
            }
            else
            {
              m_passwd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("hak_akses"))) 
            {
              m_hak_akses = rdr.GetString(rdr.GetOrdinal("hak_akses"));
            }
            else
            {
              m_hak_akses = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("usergroupid"))) 
            {
              m_usergroupid = rdr.GetString(rdr.GetOrdinal("usergroupid"));
            }
            else
            {
              m_usergroupid = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_anggota");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_anggota");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbm_anggota where dlt='0' ";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi); 
         cmd.CommandTimeout = 0; 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_anggota");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_anggota");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         cmd.CommandTimeout = 0;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbm_anggota_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
