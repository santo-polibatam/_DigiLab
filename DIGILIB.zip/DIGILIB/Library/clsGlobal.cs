﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Npgsql;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Net;

namespace Library
{
    public class clsGlobal
    {
        public static string s_FullRegKey = "SOFTWARE\\DIGILIB\\Versi 1";

        public static string str_Server = "";
        public static string str_User = "";
        public static string str_Password = "";
        public static string str_Database = "";
        public static string str_Port = "";

        public static string str_Tahun = "2013";

        public static string str_ApplicationName = "Digital Library Politeknik Negeri Batam";
        public static string pstrAppName = str_ApplicationName;
        public static string str_serverCode = "DL01";
        static string  m_servercode;
        public static string pstrAppPath = Application.StartupPath.ToString();

        public static string strConnectionGateC3100 = "protocol=TCP,ipaddress=10.11.5.240,port=4370,timeout=2000,passwd=";

        public static String pstrservercode
        {
            get { return str_serverCode; }
            set { m_servercode = str_serverCode; }
        }
        

        public static string s_SubKey = "";
        public static string s_RegKey = "";

        public static bool bolRead = false;
        public static bool bolAdd = false;
        public static bool bolEdit = false;
        public static bool bolDelete = false;
        public static bool bolPrint = false;
        public static bool bolDownload = false;
        public static bool bolUpload = false;

        static clsConnection oconn = new clsConnection();

        public static string strNamaPetugas = "";
        public static string strUserName = "Superadmin";
        static string m_strEmployeeName;
        public static String strEmployeeName
        {
            get { return strUserName; }
            set { m_strEmployeeName = strUserName; }
        }
        public static string strHakAkses = "Superadmin";
        public static string strUserID = "";
        public static string strUserType = "";

        
        public static bool firstConnect = true;

        public static int portNumber = 0;
        public static byte comAddr = 0xff;
        public static byte baud = 0;
        public static int portIndex = -1;
        public static int fCmdRet = 0;
        public static byte activeOutput = 0;
        public static byte inActiveOutput = 3;

        public static string DefaultSkinName = "Office 2010 Blue";
        public static void setupdatabase()
        {
            oconn.Open();

            #region REPER
            oconn.ExecuteCommand(@"CREATE TABLE tbm_user
                                (
	                                userid character varying(50) NOT NULL,
	                                username character varying(100),
	                                passwd character varying(150),
	                                hak_akses character varying(50),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_user_pkey PRIMARY KEY (userid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_user_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_user_username ON tbm_user (username);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_program
                                (
	                                programid character varying(50) NOT NULL,
	                                programkode character varying(100),
	                                programnama character varying(255),
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_program_pkey PRIMARY KEY (programid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_program_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_program_programkode ON tbm_program (programkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_program_tahun ON tbm_program (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_kegiatan
                                (
	                                kegiatanid character varying(50) NOT NULL,
                                    programid character varying(50) NOT NULL,
	                                kegiatankode character varying(100),
	                                kegiatannama character varying(255),
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_kegiatan_pkey PRIMARY KEY (kegiatanid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_kegiatan_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_kegiatan_programid ON tbm_kegiatan (programid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_kegiatan_kegiatankode ON tbm_kegiatan (kegiatankode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_kegiatan_tahun ON tbm_kegiatan (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_output
                                (
	                                outputid character varying(50) NOT NULL,
	                                kegiatanid character varying(50) NOT NULL,
	                                outputkode character varying(100),
	                                outputnama character varying(255),
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_output_pkey PRIMARY KEY (outputid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_output_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_output_kegiatanid ON tbm_output (kegiatanid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_output_outputkode ON tbm_output (outputkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_output_tahun ON tbm_output (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_output_sub
                                (
	                                outputsubid character varying(50) NOT NULL,
	                                outputid character varying(50) NOT NULL,
	                                outputsubkode character varying(100),
	                                outputsubnama character varying(255),
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_output_sub_pkey PRIMARY KEY (outputsubid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_output_sub_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_output_sub_outputid ON tbm_output_sub (outputid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_output_sub_outputsubkode ON tbm_output_sub (outputsubkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_output_sub_tahun ON tbm_output_sub (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_komponen
                                (
	                                komponenid character varying(50) NOT NULL,
	                                outputid character varying(50) NOT NULL,
                                    outputsubid character varying(50),
	                                komponenkode character varying(100),
	                                komponennama character varying(255),
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_komponen_pkey PRIMARY KEY (komponenid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_komponen_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_outputid ON tbm_komponen (outputid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_outputsubid ON tbm_komponen (outputsubid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_komponenkode ON tbm_komponen (komponenkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_tahun ON tbm_komponen (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_komponen_sub
                                (
	                                komponensubid character varying(50) NOT NULL,
	                                komponenid character varying(50) NOT NULL,
	                                komponensubkode character varying(100),
	                                komponensubnama character varying(255),
	                                ket character varying(255),
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_komponen_sub_pkey PRIMARY KEY (komponensubid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_komponen_sub_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_sub_komponenid ON tbm_komponen_sub (komponenid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_sub_komponensubkode ON tbm_komponen_sub (komponensubkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komponen_sub_tahun ON tbm_komponen_sub (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_mak
                                (
	                                makid character varying(50) NOT NULL,
	                                makkode character varying(100),
	                                maknama character varying(255),
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_mak_pkey PRIMARY KEY (makid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_mak_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_mak_makkode ON tbm_mak (makkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_mak_tahun ON tbm_mak (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_komp_mak
                                (
		                            komp_makid character varying(50) NOT NULL,
		                            komponenid character varying(50) NOT NULL,
		                            komponensubid character varying(50),
		                            makid character varying(50) NOT NULL,
		                            ket character varying(255),
		                            tahun character varying(8),
		                            op_add character varying(100),
		                            pc_add character varying(100),
		                            lu_add timestamp without time zone DEFAULT now(),
		                            op_edit character varying(100),
		                            pc_edit character varying(100),
		                            lu_edit timestamp without time zone,
		                            dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_komp_mak_pkey PRIMARY KEY (komp_makid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_komp_mak_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komp_mak_makid ON tbm_komp_mak (makid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komp_mak_komponenid ON tbm_komp_mak (komponenid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komp_mak_komponensubid ON tbm_komp_mak (komponensubid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_komp_mak_tahun ON tbm_komp_mak (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_makdetail
                                (
                                    makdetailid character varying(50) NOT NULL,
	                                makid character varying(50) NOT NULL,
                                    komponenid character varying(50) NOT NULL,
                                    komp_makid character varying(50) NOT NULL,
	                                makdetailkode character varying(100),
	                                makdetailnama character varying(255),
                                    volume numeric,
                                    satuan character varying(30),
                                    harga numeric,
                                    total numeric,
	                                ket character varying(255),
                                    tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_makdetail_pkey PRIMARY KEY (makdetailid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_makdetail_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_makid ON tbm_makdetail (makid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_komponenid ON tbm_makdetail (komponenid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_komp_makid ON tbm_makdetail (komp_makid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_makdetailkode ON tbm_makdetail (makdetailkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_tahun ON tbm_makdetail (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_permintaan
                                (
	                                permintaanid character varying(50) NOT NULL,
	                                nobukti character varying(100) NOT NULL,
	                                uraian character varying(255) NOT NULL,
	                                ket character varying(255),
	                                tanggal	date,
                                    karyawanid character varying(50) NOT NULL,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbl_permintaan_pkey PRIMARY KEY (permintaanid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_permintaan_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_karyawanid ON tbl_permintaan (karyawanid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_nobukti ON tbl_permintaan (nobukti);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_tanggal ON tbl_permintaan (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_tahun ON tbl_permintaan (tahun);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_uraian ON tbl_permintaan (uraian);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_permintaan_detail
                                (
	                                permintaandetailid character varying(50) NOT NULL,
	                                permintaanid character varying(50) NOT NULL,
	                                makdetailid character varying(50) NOT NULL,
	                                jumlahpermintaan NUMERIC,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbl_permintaan_detail_pkey PRIMARY KEY (permintaandetailid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_permintaan_detail_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_detail_permintaanid ON tbl_permintaan_detail (permintaanid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_detail_makdetailid ON tbl_permintaan_detail (makdetailid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_detail_jumlahpermintaan ON tbl_permintaan_detail (jumlahpermintaan);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_permintaan_detail_tahun ON tbl_permintaan_detail (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_unit
                                (
	                                unitid character varying(50) NOT NULL,
	                                unitkode character varying(50) NOT NULL,
	                                unitnama character varying(150) NOT NULL,
	                                ket TEXT,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_unit_pkey PRIMARY KEY (unitid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_unit_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_unit_unitkode ON tbm_unit (unitkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_unit_unitnama ON tbm_unit (unitnama);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_karyawan
                                (
	                                karyawanid character varying(50) NOT NULL,
	                                unitid character varying(50) NOT NULL,
	                                nik character varying(100) NOT NULL,
	                                namakaryawan character varying(250) NOT NULL,
	                                ket TEXT,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_karyawan_pkey PRIMARY KEY (karyawanid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_karyawan_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_karyawan_nik ON tbm_karyawan (nik);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_karyawan_namakaryawan ON tbm_karyawan (namakaryawan);");


            oconn.ExecuteCommand(@"CREATE TABLE tbl_lpj
                                (
	                                lpjid character varying(50) NOT NULL,
									permintaanid character varying(50) NOT NULL,
	                                nobukti character varying(100) NOT NULL,
	                                uraian character varying(255) NOT NULL,
	                                ket character varying(255),
	                                tanggal	date,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbl_lpj_pkey PRIMARY KEY (lpjid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_lpj_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_permintaanid ON tbl_lpj (permintaanid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_nobukti ON tbl_lpj (nobukti);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_tanggal ON tbl_lpj (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_tahun ON tbl_lpj (tahun);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_uraian ON tbl_lpj (uraian);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_lpj_detail
                                (
	                                lpjdetailid character varying(50) NOT NULL,
	                                lpjid character varying(50) NOT NULL,
	                                makdetailid character varying(50) NOT NULL,
									permintaandetailid character varying(50) NOT NULL,
	                                jumlahup NUMERIC,
									jumlahls NUMERIC,
									total NUMERIC,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbl_lpj_detail_pkey PRIMARY KEY (lpjdetailid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_lpj_detail_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_lpjid ON tbl_lpj_detail (lpjid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_permintaandetailid ON tbl_lpj_detail (permintaandetailid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_makdetailid ON tbl_lpj_detail (makdetailid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_jumlahup ON tbl_lpj_detail (jumlahup);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_jumlahls ON tbl_lpj_detail (jumlahls);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_total ON tbl_lpj_detail (total);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_lpj_detail_tahun ON tbl_lpj_detail (tahun);");

            oconn.ExecuteCommand(@"alter table tbm_makdetail add column unitid CHARACTER VARYING(30);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_unitid ON tbm_makdetail (unitid);");

            oconn.ExecuteCommand(@"alter table tbm_makdetail add column datefrom date;");
            oconn.ExecuteCommand(@"alter table tbm_makdetail add column dateto date;");

            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_datefrom ON tbm_makdetail (datefrom);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_makdetail_dateto ON tbm_makdetail (dateto);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_jadwal
                                (
	                                jadwalid character varying(50) NOT NULL,
	                                unitid character varying(50) NOT NULL,
	                                makdetailid character varying(50) NOT NULL,
	                                datefrom date,
	                                dateto date,
                                    jumlah	numeric,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbl_jadwal_pkey PRIMARY KEY (jadwalid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_jadwal_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_jadwal_unitid ON tbl_jadwal (unitid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_jadwal_makdetailid ON tbl_jadwal (makdetailid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_jadwal_datefrom ON tbl_jadwal (datefrom);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_jadwal_dateto ON tbl_jadwal (dateto);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_jadwal_tahun ON tbl_jadwal (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_sp2d
                                (
	                                sp2did character varying(50) NOT NULL,
	                                sp2dkode character varying(100) NOT NULL,
	                                tanggal date,
	                                jumlah	numeric,
	                                ket	text,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbl_sp2d_pkey PRIMARY KEY (sp2did)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_sp2d_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_sp2dkode ON tbl_sp2d (sp2dkode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_tanggal ON tbl_sp2d (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_tahun ON tbl_sp2d (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_sp2d_detail
                                (
	                                sp2d_detailid character varying(50) NOT NULL,
	                                sp2did character varying(50) NOT NULL,
	                                lpjdetailid character varying(50) NOT NULL,
	                                lpjid	character varying(50) NOT NULL,
	                                jumlah	numeric,
	                                ket	text,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbl_sp2d_detail_pkey PRIMARY KEY (sp2d_detailid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_sp2d_detail_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_detail_sp2did ON tbl_sp2d_detail (sp2did);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_detail_lpjdetailid ON tbl_sp2d_detail (lpjdetailid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_detail_lpjid ON tbl_sp2d_detail (lpjid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_sp2d_detail_tahun ON tbl_sp2d_detail (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tbl_mappingunit
                                (
	                                mappingunitid character varying(50) NOT NULL,
	                                unitid character varying(50) NOT NULL,
	                                makdetailid character varying(50) NOT NULL,
	                                tahun character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbl_mappingunit_pkey PRIMARY KEY (mappingunitid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbl_mappingunit_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_mappingunit_unitid ON tbl_mappingunit (unitid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_mappingunit_makdetailid ON tbl_mappingunit (makdetailid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbl_mappingunit_tahun ON tbl_mappingunit (tahun);");

            oconn.ExecuteCommand("alter table tbl_jadwal add column mappingunitid CHARACTER VARYING(30);");
            oconn.ExecuteCommand("CREATE INDEX tbl_jadwal_mappingunitid ON tbl_jadwal (mappingunitid);");

            #endregion

            #region PENDAFTARAN
            oconn.ExecuteCommand(@"CREATE TABLE tba_pmdk_umpb
                                (
	                                pmdk_umpbid character varying(50) NOT NULL,
	                                kartuidentitas character varying(30) NOT NULL,
	                                nomoridentitas character varying(100) NOT NULL,
	                                namalengkap character varying(150) NOT NULL,
	                                jeniskelamin character varying(50) NOT NULL,
	                                tempatlahir character varying(150),
	                                tanggallahir date,
	                                agama character varying(50) NOT NULL,
	                                agamalainnya character varying(50) ,
	                                kewarganegaraan character varying(100),
	                                alamat text,
	                                kodepos character varying(15),
	                                telp character varying(50),
	                                butawarna boolean default false NOT NULL,
	                                jeniskelas character varying(30) NOT NULL,
	                                pilihan1 character varying(50) NOT NULL,
	                                pilihan2 character varying(50) NOT NULL,
	                                jenisdokumen character varying(30) NOT NULL,
	                                nomordokumen character varying(50) NOT NULL,
	                                namasekolah character varying(100) NOT NULL,
	                                jurusansekolah character varying(50),
	                                tahunsekolah1 character varying(4),
	                                tahunsekolah2 character varying(4),
	                                nilaiuan numeric NOT NULL,
	                                nilaistk numeric NOT NULL,
	                                alamatsekolah text,
	                                telpsekolah character varying(50),
	                                kotasekolah character varying(100),
	                                provinsisekolah character varying(100),
	                                ispindahan boolean default false,
	                                namaperguruantinggi_pindahan character varying(150),
	                                tahunpindahan1 character varying(4),
	                                tahunpindahan2 character varying(4),
	                                jurusanpindahan character varying(50),
	                                nilaiipkpindahan numeric,
	                                semesterpindahan character varying(2),
	                                namaperusahaan1 character varying(150),
	                                posisiperusahaan1 character varying(150),
	                                tahunperusahaan1 character varying(4),
	                                namaperusahaan2 character varying(150),
	                                posisiperusahaan2 character varying(150),
	                                tahunperusahaan2 character varying(4),
	                                namapenanggungjawab character varying(150) NOT NULL,
	                                hubunganpenanggungjawab character varying(30) NOT NULL,
	                                hubunganpenanggungjawablainnya character varying(50),
	                                alamatpenanggungjawab text,
	                                kotapenanggungjawab character varying(150),
	                                provinsipenanggungjawab character varying(150),
	                                kodepospenanggungjawab character varying(20),
	                                telppenanggungjawab character varying(50),
	                                pendidikanayah character varying(50),
	                                pendidikanibu character varying(50),
	                                penghasilanortu numeric,
	                                informasidiperoleh character varying(30) NOT NULL,
	                                informasidiperolehlainnya character varying(150),
	                                rata2sem1	numeric,
	                                rata2sem2	numeric,
	                                rata2sem3	numeric,
	                                rata2sem4	numeric,
	                                rata2sem5	numeric,
	                                rata2sem6	numeric,
	                                namapeserta character varying(150) NOT NULL,
	                                tanggal	date default now() NOT NULL,
	                                tempat	text,
	                                photo	text,
	                                captcha	character varying(30),
	                                tahun character varying(8) NOT NULL,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_pmdk_umpb_pkey PRIMARY KEY (pmdk_umpbid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_pmdk_umpb_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_kartuidentitas ON tba_pmdk_umpb (kartuidentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_nomoridentitas ON tba_pmdk_umpb (nomoridentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_namalengkap ON tba_pmdk_umpb (namalengkap);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_jeniskelamin ON tba_pmdk_umpb (jeniskelamin);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_agama ON tba_pmdk_umpb (agama);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_butawarna ON tba_pmdk_umpb (butawarna);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_jeniskelas ON tba_pmdk_umpb (jeniskelas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_pilihan1 ON tba_pmdk_umpb (pilihan1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_pilihan2 ON tba_pmdk_umpb (pilihan2);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_jenisdokumen ON tba_pmdk_umpb (jenisdokumen);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_nomordokumen ON tba_pmdk_umpb (nomordokumen);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_namasekolah ON tba_pmdk_umpb (namasekolah);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_nilaiuan ON tba_pmdk_umpb (nilaiuan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_nilaistk ON tba_pmdk_umpb (nilaistk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_namapenanggungjawab ON tba_pmdk_umpb (namapenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_hubunganpenanggungjawab ON tba_pmdk_umpb (hubunganpenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_informasidiperoleh ON tba_pmdk_umpb (informasidiperoleh);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_namapeserta ON tba_pmdk_umpb (namapeserta);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_tanggal ON tba_pmdk_umpb (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_tahun ON tba_pmdk_umpb (tahun);");


            oconn.ExecuteCommand(@"CREATE TABLE tba_d4
                                (
	                                d4id character varying(50) NOT NULL,
	                                kartuidentitas character varying(30) NOT NULL,
	                                nomoridentitas character varying(100) NOT NULL,
	                                namalengkap character varying(150) NOT NULL,
	                                jeniskelamin character varying(50) NOT NULL,
	                                tempatlahir character varying(150),
	                                tanggallahir date,
	                                agama character varying(50) NOT NULL,
	                                agamalainnya character varying(50) ,
	                                kewarganegaraan character varying(100),
	                                alamat text,
	                                kodepos character varying(15),
	                                telp character varying(50),
	                                butawarna boolean default false NOT NULL,
	                                pilihan1 character varying(50) NOT NULL,
	                                namaperguruantinggi character varying(150),
	                                jurusanperg character varying(50),
                                    tanggallulusperg	date,
	                                nilaiipkperg numeric,
	                                jumlahsksperg numeric,
	                                namapenanggungjawab character varying(150) NOT NULL,
	                                hubunganpenanggungjawab character varying(30) NOT NULL,
	                                hubunganpenanggungjawablainnya character varying(50),
	                                alamatpenanggungjawab text,
	                                kotapenanggungjawab character varying(150),
	                                provinsipenanggungjawab character varying(150),
	                                kodepospenanggungjawab character varying(20),
	                                telppenanggungjawab character varying(50),
	                                pendidikanayah character varying(50),
	                                pendidikanibu character varying(50),
	                                penghasilanortu numeric,
	                                informasidiperoleh character varying(30) NOT NULL,
	                                informasidiperolehlainnya character varying(150),
	                                ipsem1	numeric,
	                                ipsem2	numeric,
	                                ipsem3	numeric,
	                                ipsem4	numeric,
	                                ipsem5	numeric,
	                                ipsem6	numeric,
	                                namapeserta character varying(150) NOT NULL,
	                                tanggal	date default now() NOT NULL,
	                                tempat	text,
	                                photo	text,
	                                captcha	character varying(30),
	                                tahun character varying(8) NOT NULL,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_d4_pkey PRIMARY KEY (d4id)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_d4_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_kartuidentitas ON tba_d4 (kartuidentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_nomoridentitas ON tba_d4 (nomoridentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_namalengkap ON tba_d4 (namalengkap);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_jeniskelamin ON tba_d4 (jeniskelamin);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_agama ON tba_d4 (agama);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_butawarna ON tba_d4 (butawarna);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_pilihan1 ON tba_d4 (pilihan1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_namapenanggungjawab ON tba_d4 (namapenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_hubunganpenanggungjawab ON tba_d4 (hubunganpenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_informasidiperoleh ON tba_d4 (informasidiperoleh);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_namapeserta ON tba_d4 (namapeserta);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_tanggal ON tba_d4 (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_tahun ON tba_d4 (tahun);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_namaperguruantinggi ON tba_d4 (namaperguruantinggi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_jurusanperg ON tba_d4 (jurusanperg);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_tanggallulusperg ON tba_d4 (tanggallulusperg);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_nilaiipkperg ON tba_d4 (nilaiipkperg);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_jumlahsksperg ON tba_d4 (jumlahsksperg);");
            oconn.ExecuteCommand("alter table tba_d4 add column akreditasiperg CHARACTER VARYING(30);");


            oconn.ExecuteCommand(@"CREATE TABLE tba_ppl
                                (
	                                pplid character varying(50) NOT NULL,
	                                kartuidentitas character varying(30) NOT NULL,
	                                nomoridentitas character varying(100) NOT NULL,
	                                namalengkap character varying(150) NOT NULL,
	                                jeniskelamin character varying(50) NOT NULL,
	                                tempatlahir character varying(150),
	                                tanggallahir date,
	                                agama character varying(50) NOT NULL,
	                                agamalainnya character varying(50) ,
	                                kewarganegaraan character varying(100),
	                                alamat text,
	                                kodepos character varying(15),
	                                telp character varying(50),
	                                jeniskelas character varying(30) NOT NULL,
	                                jenisdokumen character varying(30) NOT NULL,
	                                nomordokumen character varying(50) NOT NULL,
	                                namasekolah character varying(100) NOT NULL,
	                                jurusansekolah character varying(50),
	                                tahunsekolah1 character varying(4),
	                                tahunsekolah2 character varying(4),
	                                nilaiuan numeric NOT NULL,
	                                nilaistk numeric NOT NULL,
	                                alamatsekolah text,
	                                telpsekolah character varying(50),
	                                kotasekolah character varying(100),
	                                provinsisekolah character varying(100),
	                                ispindahan boolean default false,
	                                namaperguruantinggi_pindahan character varying(150),
	                                tahunpindahan1 character varying(4),
	                                tahunpindahan2 character varying(4),
	                                jurusanpindahan character varying(50),
	                                nilaiipkpindahan numeric,
	                                semesterpindahan character varying(2),
	                                namaperusahaan1 character varying(150),
	                                posisiperusahaan1 character varying(150),
	                                tahunperusahaan1 character varying(4),
	                                namaperusahaan2 character varying(150),
	                                posisiperusahaan2 character varying(150),
	                                tahunperusahaan2 character varying(4),
	                                namapenanggungjawab character varying(150) NOT NULL,
	                                hubunganpenanggungjawab character varying(30) NOT NULL,
	                                hubunganpenanggungjawablainnya character varying(50),
	                                alamatpenanggungjawab text,
	                                kotapenanggungjawab character varying(150),
	                                provinsipenanggungjawab character varying(150),
	                                kodepospenanggungjawab character varying(20),
	                                telppenanggungjawab character varying(50),
	                                informasidiperoleh character varying(30) NOT NULL,
	                                informasidiperolehlainnya character varying(150),
	                                rata2sem1	numeric,
	                                rata2sem2	numeric,
	                                rata2sem3	numeric,
	                                rata2sem4	numeric,
	                                rata2sem5	numeric,
	                                rata2sem6	numeric,
									sertifikat1	character varying(150),
									sertifikat2	character varying(150),
									sertifikat3	character varying(150),
									sertifikat4	character varying(150),
									sertifikat5	character varying(150),
									sertifikat6	character varying(150),
									sertifikat7	character varying(150),
									sertifikat8	character varying(150),
									sertmakul1	character varying(150),
									sertmakul2	character varying(150),
									sertmakul3	character varying(150),
									sertmakul4	character varying(150),
									sertmakul5	character varying(150),
									sertmakul6	character varying(150),
									sertmakul7	character varying(150),
									sertmakul8	character varying(150),
									sertsks1	character varying(20),
									sertsks2	character varying(20),
									sertsks3	character varying(20),
									sertsks4	character varying(20),
									sertsks5	character varying(20),
									sertsks6	character varying(20),
									sertsks7	character varying(20),
									sertsks8	character varying(20),
	                                namapeserta character varying(150) NOT NULL,
	                                tanggal	date default now() NOT NULL,
	                                tempat	text,
	                                photo	text,
	                                captcha	character varying(30),
	                                tahun character varying(8) NOT NULL,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_ppl_pkey PRIMARY KEY (pplid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_ppl_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_kartuidentitas ON tba_ppl (kartuidentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_nomoridentitas ON tba_ppl (nomoridentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_namalengkap ON tba_ppl (namalengkap);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_jeniskelamin ON tba_ppl (jeniskelamin);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_agama ON tba_ppl (agama);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_jeniskelas ON tba_ppl (jeniskelas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_jenisdokumen ON tba_ppl (jenisdokumen);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_nomordokumen ON tba_ppl (nomordokumen);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_namasekolah ON tba_ppl (namasekolah);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_nilaiuan ON tba_ppl (nilaiuan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_nilaistk ON tba_ppl (nilaistk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_namapenanggungjawab ON tba_ppl (namapenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_hubunganpenanggungjawab ON tba_ppl (hubunganpenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_informasidiperoleh ON tba_ppl (informasidiperoleh);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_namapeserta ON tba_ppl (namapeserta);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_tanggal ON tba_ppl (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_tahun ON tba_ppl (tahun);");


            oconn.ExecuteCommand(@"CREATE TABLE tba_umpn
                                (
	                                umpnid character varying(50) NOT NULL,
	                                kartuidentitas character varying(30) NOT NULL,
	                                nomoridentitas character varying(100) NOT NULL,
	                                namalengkap character varying(150) NOT NULL,
	                                jeniskelamin character varying(50) NOT NULL,
	                                tempatlahir character varying(150),
	                                tanggallahir date,
	                                agama character varying(50) NOT NULL,
	                                agamalainnya character varying(50) ,
	                                kewarganegaraan character varying(100),
	                                alamat text,
	                                kodepos character varying(15),
	                                telp character varying(50),
	                                butawarna boolean default false NOT NULL,
	                                jenisdokumen character varying(30) NOT NULL,
	                                nomordokumen character varying(50) NOT NULL,
	                                namasekolah character varying(100) NOT NULL,
	                                jurusansekolah character varying(50),
	                                tahunsekolah1 character varying(4),
	                                tahunsekolah2 character varying(4),
	                                nilaiuan numeric NOT NULL,
	                                nilaistk numeric NOT NULL,
	                                alamatsekolah text,
	                                telpsekolah character varying(50),
	                                kotasekolah character varying(100),
	                                provinsisekolah character varying(100),
	                                namapenanggungjawab character varying(150) NOT NULL,
	                                hubunganpenanggungjawab character varying(30) NOT NULL,
	                                hubunganpenanggungjawablainnya character varying(50),
	                                alamatpenanggungjawab text,
	                                kotapenanggungjawab character varying(150),
	                                provinsipenanggungjawab character varying(150),
	                                kodepospenanggungjawab character varying(20),
	                                telppenanggungjawab character varying(50),
	                                pendidikanayah character varying(50),
	                                pendidikanibu character varying(50),
	                                penghasilanortu numeric,
	                                informasidiperoleh character varying(30) NOT NULL,
	                                informasidiperolehlainnya character varying(150),
	                                rata2sem1	numeric,
	                                rata2sem2	numeric,
	                                rata2sem3	numeric,
	                                rata2sem4	numeric,
	                                rata2sem5	numeric,
	                                rata2sem6	numeric,
	                                namapeserta character varying(150) NOT NULL,
	                                tanggal	date default now() NOT NULL,
	                                tempat	text,
									pilihan1kode character varying(50),
									pilihan2kode character varying(50),
									pilihan3kode character varying(50),
									pilihan4kode character varying(50),
									pilihan1prodi character varying(150),
									pilihan2prodi character varying(150),
									pilihan3prodi character varying(150),
									pilihan4prodi character varying(150),
									pilihan1politeknik character varying(200),
									pilihan2politeknik character varying(200),
									pilihan3politeknik character varying(200),
									pilihan4politeknik character varying(200),
	                                photo	text,
	                                captcha	character varying(30),
	                                tahun character varying(8) NOT NULL,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_umpn_pkey PRIMARY KEY (umpnid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_umpn_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_kartuidentitas ON tba_umpn (kartuidentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_nomoridentitas ON tba_umpn (nomoridentitas);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_namalengkap ON tba_umpn (namalengkap);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_jeniskelamin ON tba_umpn (jeniskelamin);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_agama ON tba_umpn (agama);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_butawarna ON tba_umpn (butawarna);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_jenisdokumen ON tba_umpn (jenisdokumen);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_nomordokumen ON tba_umpn (nomordokumen);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_namasekolah ON tba_umpn (namasekolah);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_nilaiuan ON tba_umpn (nilaiuan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_nilaistk ON tba_umpn (nilaistk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_namapenanggungjawab ON tba_umpn (namapenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_hubunganpenanggungjawab ON tba_umpn (hubunganpenanggungjawab);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_informasidiperoleh ON tba_umpn (informasidiperoleh);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_namapeserta ON tba_umpn (namapeserta);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_tanggal ON tba_umpn (tanggal);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_tahun ON tba_umpn (tahun);");

            oconn.ExecuteCommand("alter table tba_d4 add column noregistrasi CHARACTER VARYING(30) NOT NULL Default '';");
            oconn.ExecuteCommand("alter table tba_pmdk_umpb add column noregistrasi CHARACTER VARYING(30) NOT NULL Default '';");
            oconn.ExecuteCommand("alter table tba_ppl add column noregistrasi CHARACTER VARYING(30) NOT NULL Default '';");
            oconn.ExecuteCommand("alter table tba_umpn add column noregistrasi CHARACTER VARYING(30) NOT NULL Default '';");

            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_noregistrasi ON tba_d4 (noregistrasi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_noregistrasi ON tba_pmdk_umpb (noregistrasi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_noregistrasi ON tba_ppl (noregistrasi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_noregistrasi ON tba_umpn (noregistrasi);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_config
                                (
	                                configid character varying(50) NOT NULL,
	                                configname	character varying(100) NOT NULL,
	                                configdesc	text,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                    configvalue character varying(20) NOT NULL,
                                CONSTRAINT tba_config_pkey PRIMARY KEY (configid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_config_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_config_configname ON tba_config (configname);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_config_configvalue ON tba_config (configvalue);");

            oconn.ExecuteCommand(@"alter table tba_d4 add column semester CHARACTER VARYING(2) NOT NULL Default '1';");
            oconn.ExecuteCommand(@"alter table tba_pmdk_umpb add column semester CHARACTER VARYING(2) NOT NULL Default '1';");
            oconn.ExecuteCommand(@"alter table tba_ppl add column semester CHARACTER VARYING(2) NOT NULL Default '1';");
            oconn.ExecuteCommand(@"alter table tba_umpn add column semester CHARACTER VARYING(2) NOT NULL Default '1';");
            oconn.ExecuteCommand(@"CREATE INDEX tba_d4_semester ON tba_d4 (semester);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_semester ON tba_pmdk_umpb (semester);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_ppl_semester ON tba_ppl (semester);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_semester ON tba_umpn (semester);");

            oconn.ExecuteCommand(@"alter table tba_pmdk_umpb add column jalurmasuk CHARACTER VARYING(20) NOT NULL Default 'umpb';");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_umpb_jalurmasuk ON tba_pmdk_umpb (jalurmasuk);");

            oconn.ExecuteCommand(@"alter table tba_umpn add column jalurmasuk CHARACTER VARYING(20) NOT NULL Default 'umpn';");
            oconn.ExecuteCommand(@"CREATE INDEX tba_umpn_jalurmasuk ON tba_umpn (jalurmasuk);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_biayapendaftaran
                                (
	                                biayapendaftaranid character varying(50) NOT NULL,
	                                jalurmasuk character varying(100),
	                                nama	character varying(150),
	                                biaya	numeric,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_biayapendaftaran_pkey PRIMARY KEY (biayapendaftaranid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_biayapendaftaran_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_biayapendaftaran_jalurmasuk ON tba_biayapendaftaran (jalurmasuk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_biayapendaftaran_nama ON tba_biayapendaftaran (nama);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_biayapendaftaran_biaya ON tba_biayapendaftaran (biaya);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_biayapendaftaran_tahun ON tba_biayapendaftaran (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_gelombang
                                (
	                                gelombangid character varying(50) NOT NULL,
	                                jalurmasuk character varying(100),
	                                reguler	date,
	                                karyawan	date,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_gelombang_pkey PRIMARY KEY (gelombangid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_gelombang_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_gelombang_jalurmasuk ON tba_gelombang (jalurmasuk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_gelombang_reguler ON tba_gelombang (reguler);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_gelombang_karyawan ON tba_gelombang (karyawan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_gelombang_tahun ON tba_gelombang (tahun);");
            oconn.ExecuteCommand(@"alter table tba_gelombang add column gelombang numeric not null;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_gelombang_gelombang ON tba_gelombang (gelombang);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_pembayaran
                                (
	                                pembayaranid character varying(50) NOT NULL,
									tableprimary	character varying(100),
									primaryid	character varying(50),
									gelombangid	character varying(50),
	                                jalurmasuk character varying(100),
	                                reguler	date,
	                                karyawan	date,
									jumlahpilihan	numeric,
									jumlahbayar	numeric,
									noujian	character varying(100),
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_pembayaran_pkey PRIMARY KEY (pembayaranid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_pembayaran_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_tableprimary ON tba_pembayaran (tableprimary);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_primaryid ON tba_pembayaran (primaryid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_gelombangid ON tba_pembayaran (gelombangid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_noujian ON tba_pembayaran (noujian);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_jalurmasuk ON tba_pembayaran (jalurmasuk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_reguler ON tba_pembayaran (reguler);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_karyawan ON tba_pembayaran (karyawan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pembayaran_tahun ON tba_pembayaran (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_matapelajaran
                                (
	                                matapelajaranid character varying(50) NOT NULL,
									jalurmasuk	character varying(20) NOT NULL,
	                                kode character varying(30),
	                                nama	character varying(100),
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_matapelajaran_pkey PRIMARY KEY (matapelajaranid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_matapelajaran_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_matapelajaran_kode ON tba_matapelajaran (kode);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_matapelajaran_jalurmasuk ON tba_matapelajaran (jalurmasuk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_matapelajaran_nama ON tba_matapelajaran (nama);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_matapelajaran_tahun ON tba_matapelajaran (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_hasilujian
                                (
	                                hasilujianid character varying(50) NOT NULL,
	                                matapelajaranid character varying(50) NOT NULL,
									primaryid character varying(50) NOT NULL,
									jalurmasuk	character varying(20),
	                                namapelajaran	character varying(100),
                                    nilai   numeric,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_hasilujian_pkey PRIMARY KEY (hasilujianid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_hasilujian_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_hasilujian_matapelajaranid ON tba_hasilujian (matapelajaranid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_hasilujian_primaryid ON tba_hasilujian (primaryid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_hasilujian_namapelajaran ON tba_hasilujian (namapelajaran);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_hasilujian_jalurmasuk ON tba_hasilujian (jalurmasuk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_hasilujian_tahun ON tba_hasilujian (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_kelulusan_umpb
                                (
	                                kelulusan_umpbid character varying(50) NOT NULL,
	                                pmdk_umpbid character varying(50) NOT NULL,
									pilihan1 character varying(100),
									status1	boolean,
	                                pilihan2 character varying(100),
									status2	boolean,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_kelulusan_umpb_pkey PRIMARY KEY (kelulusan_umpbid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_kelulusan_umpb_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpb_pmdk_umpbid ON tba_kelulusan_umpb (pmdk_umpbid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpb_pilihan1 ON tba_kelulusan_umpb (pilihan1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpb_status1 ON tba_kelulusan_umpb (status1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpb_pilihan2 ON tba_kelulusan_umpb (pilihan2);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpb_status2 ON tba_kelulusan_umpb (status2);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpb_tahun ON tba_kelulusan_umpb (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_kelulusan_umpn
                                (
	                                kelulusan_umpnid character varying(50) NOT NULL,
	                                umpnid character varying(50) NOT NULL,
									pilihan1 character varying(100),
									status1	boolean,
	                                pilihan2 character varying(100),
									status2	boolean,
									pilihan3 character varying(100),
									status3	boolean,
									pilihan4 character varying(100),
									status4	boolean,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_kelulusan_umpn_pkey PRIMARY KEY (kelulusan_umpnid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_kelulusan_umpn_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_pmdk_umpnid ON tba_kelulusan_umpn (umpnid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_pilihan1 ON tba_kelulusan_umpn (pilihan1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_status1 ON tba_kelulusan_umpn (status1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_pilihan2 ON tba_kelulusan_umpn (pilihan2);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_status2 ON tba_kelulusan_umpn (status2);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_pilihan3 ON tba_kelulusan_umpn (pilihan3);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_status3 ON tba_kelulusan_umpn (status3);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_pilihan4 ON tba_kelulusan_umpn (pilihan4);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_status4 ON tba_kelulusan_umpn (status4);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_umpn_tahun ON tba_kelulusan_umpn (tahun);");

            oconn.ExecuteCommand("alter table tba_pmdk_umpb add column isbidikmisi BOOLEAN default false;");
            oconn.ExecuteCommand("alter table tba_umpn add column isbidikmisi BOOLEAN default false;");

            oconn.ExecuteCommand(@"CREATE TABLE tba_kelulusan_bidik
                                (
	                                kelulusan_bidikid character varying(50) NOT NULL,
	                                primaryid character varying(50) NOT NULL,
									prodi character varying(100),
									statusprimary	boolean,
									gelombangid	character varying(50),
									jalurmasuk	character varying(20),
									statusbidik	boolean,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_kelulusan_bidik_pkey PRIMARY KEY (kelulusan_bidikid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_kelulusan_bidik_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_primaryid ON tba_kelulusan_bidik (primaryid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_prodi ON tba_kelulusan_bidik (prodi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_statusprimary ON tba_kelulusan_bidik (statusprimary);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_gelombangid ON tba_kelulusan_bidik (gelombangid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_jalurmasuk ON tba_kelulusan_bidik (jalurmasuk);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_statusbidik ON tba_kelulusan_bidik (statusbidik);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_bidik_tahun ON tba_kelulusan_bidik (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_kelulusan_d4
                                (
	                                kelulusan_d4id character varying(50) NOT NULL,
	                                d4id character varying(50) NOT NULL,
									pilihan1 character varying(100),
									status1	boolean,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_kelulusan_d4_pkey PRIMARY KEY (kelulusan_d4id)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_kelulusan_d4_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_d4_d4id ON tba_kelulusan_d4 (d4id);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_d4_pilihan1 ON tba_kelulusan_d4 (pilihan1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_d4_status1 ON tba_kelulusan_d4 (status1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_d4_tahun ON tba_kelulusan_d4 (tahun);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_kelulusan_ppl
                                (
	                                kelulusan_pplid character varying(50) NOT NULL,
	                                pplid character varying(50) NOT NULL,
									pilihan1 character varying(100),
									status1	boolean,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_kelulusan_ppl_pkey PRIMARY KEY (kelulusan_pplid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_kelulusan_ppl_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_ppl_pplid ON tba_kelulusan_ppl (pplid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_ppl_pilihan1 ON tba_kelulusan_ppl (pilihan1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_ppl_status1 ON tba_kelulusan_ppl (status1);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_kelulusan_ppl_tahun ON tba_kelulusan_ppl (tahun);");

            oconn.ExecuteCommand(@"
                                CREATE TABLE tbm_module
                                (
	                                moduleid character varying(50) NOT NULL,
	                                modulename character varying(50) NOT NULL,
	                                remark character varying(255),
	                                groupcode character varying(10) not null,
	                                groupname character varying(255) not null,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbm_module_pkey PRIMARY KEY (moduleid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_module_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_module_modulename ON tbm_module (modulename);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_module_groupcode ON tbm_module (groupcode);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_module_groupname ON tbm_module (groupname);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_module_dlt ON tbm_module (dlt);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_usermodule
                                (
	                                usermoduleid character varying(50) NOT NULL,
	                                userid character varying(50) NOT NULL,
	                                moduleid character varying(50) not null,
	                                isread boolean default false not null,
	                                isadd boolean default false not null,
	                                isedit boolean default false not null,
	                                isdelete boolean default false not null,
	                                isprint boolean default false not null,
	                                isdownload boolean default false not null,
	                                isupload boolean default false not null,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbm_usermodule_pkey PRIMARY KEY (usermoduleid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_usermodule_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_userid ON tbm_usermodule (userid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_moduleid ON tbm_usermodule (moduleid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isread ON tbm_usermodule (isread);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isadd ON tbm_usermodule (isadd);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isedit ON tbm_usermodule (isedit);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isdelete ON tbm_usermodule (isdelete);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isprint ON tbm_usermodule (isprint);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isdownload ON tbm_usermodule (isdownload);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_isupload ON tbm_usermodule (isupload);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usermodule_dlt ON tbm_usermodule (dlt);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_usergroup
                                (
	                                usergroupid character varying(50) NOT NULL,
	                                groupname character varying(150) NOT NULL,
	                                remarks character varying(255),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbm_usergroup_pkey PRIMARY KEY (usergroupid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_usergroup_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroup_groupname ON tbm_usergroup (groupname);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroup_dlt ON tbm_usergroup (dlt);");

            oconn.ExecuteCommand(@"CREATE TABLE tbm_usergroupmodule
                                (
	                                usergroupmoduleid character varying(50) NOT NULL,
	                                usergroupid character varying(50) NOT NULL,
	                                moduleid character varying(50) not null,
	                                isread boolean default false not null,
	                                isadd boolean default false not null,
	                                isedit boolean default false not null,
	                                isdelete boolean default false not null,
	                                isprint boolean default false not null,
	                                isdownload boolean default false not null,
	                                isupload boolean default false not null,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tbm_usergroupmodule_pkey PRIMARY KEY (usergroupmoduleid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tbm_usergroupmodule_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_usergroupid ON tbm_usergroupmodule (usergroupid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_moduleid ON tbm_usergroupmodule (moduleid);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isread ON tbm_usergroupmodule (isread);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isadd ON tbm_usergroupmodule (isadd);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isedit ON tbm_usergroupmodule (isedit);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isdelete ON tbm_usergroupmodule (isdelete);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isprint ON tbm_usergroupmodule (isprint);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isdownload ON tbm_usergroupmodule (isdownload);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_isupload ON tbm_usergroupmodule (isupload);");
            oconn.ExecuteCommand(@"CREATE INDEX tbm_usergroupmodule_dlt ON tbm_usergroupmodule (dlt);");

            oconn.ExecuteCommand(@"alter table tbm_user add column usergroupid character varying(50) not null default '';");

            oconn.ExecuteCommand(@"CREATE TABLE tba_pmdk_bag1
                                (
	                                pmdk_bag1id character varying(50) NOT NULL,
	                                semester character varying(30) NOT NULL,
	                                rata_rapor	numeric,
	                                peringkat_kelas character varying(30),
	                                peringkat_sekolah character varying(30),
	                                remarks character varying(255),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tba_pmdk_bag1_pkey PRIMARY KEY (pmdk_bag1id)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_pmdk_bag1_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag1_semester ON tba_pmdk_bag1 (semester);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag1_dlt ON tba_pmdk_bag1 (dlt);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_pmdk_bag2
                                (
	                                pmdk_bag2id character varying(50) NOT NULL,
	                                tahun character varying(10) NOT NULL,
	                                nama_penghargaan character varying(200),
	                                tingkat character varying(100),
	                                remarks character varying(255),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tba_pmdk_bag2_pkey PRIMARY KEY (pmdk_bag2id)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_pmdk_bag2_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag2_tahun ON tba_pmdk_bag2 (tahun);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag2_nama_penghargaan ON tba_pmdk_bag2 (nama_penghargaan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag2_nama_tingkat ON tba_pmdk_bag2 (tingkat);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag2_dlt ON tba_pmdk_bag2 (dlt);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_pmdk_bag3
                                (
	                                pmdk_bag3id character varying(50) NOT NULL,
	                                tahun character varying(10) NOT NULL,
	                                jabatan character varying(200),
	                                nama_organisasi character varying(200),
	                                remarks character varying(255),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tba_pmdk_bag3_pkey PRIMARY KEY (pmdk_bag3id)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_pmdk_bag3_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag3_tahun ON tba_pmdk_bag3 (tahun);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag3_nama_jabatan ON tba_pmdk_bag3 (jabatan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag3_nama_nama_organisasi ON tba_pmdk_bag3 (nama_organisasi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag3_dlt ON tba_pmdk_bag3 (dlt);");

            oconn.ExecuteCommand(@"CREATE TABLE tba_pmdk_bag4
                                (
	                                pmdk_bag4id character varying(50) NOT NULL,
	                                tahun character varying(10) NOT NULL,
	                                lembaga character varying(200),
	                                jenis_keterampilan character varying(200),
	                                remarks character varying(255),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tba_pmdk_bag4_pkey PRIMARY KEY (pmdk_bag4id)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_pmdk_bag4_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag4_tahun ON tba_pmdk_bag4 (tahun);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag4_lembaga ON tba_pmdk_bag4 (lembaga);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag4_jenis_keterampilan ON tba_pmdk_bag4 (jenis_keterampilan);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag4_dlt ON tba_pmdk_bag4 (dlt);");

            oconn.ExecuteCommand(@"alter table tba_pmdk_bag1 add column pmdk_umpbid character varying(30) not null;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag2 add column pmdk_umpbid character varying(30) not null;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag3 add column pmdk_umpbid character varying(30) not null;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag4 add column pmdk_umpbid character varying(30) not null;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag1 add column nourut numeric not null default 0;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag2 add column nourut numeric not null default 0;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag3 add column nourut numeric not null default 0;");
            oconn.ExecuteCommand(@"alter table tba_pmdk_bag4 add column nourut numeric not null default 0;");

            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag1_pmdk_umpbid ON tba_pmdk_bag1 (pmdk_umpbid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag2_pmdk_umpbid ON tba_pmdk_bag2 (pmdk_umpbid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag3_pmdk_umpbid ON tba_pmdk_bag3 (pmdk_umpbid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag4_pmdk_umpbid ON tba_pmdk_bag4 (pmdk_umpbid);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag1_nourut ON tba_pmdk_bag1 (nourut);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag2_nourut ON tba_pmdk_bag2 (nourut);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag3_nourut ON tba_pmdk_bag3 (nourut);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_pmdk_bag4_nourut ON tba_pmdk_bag4 (nourut);");

            oconn.ExecuteCommand(@"CREATE TABLE tserverinfo (
	                            recordid varchar(20) NOT NULL,
	                            mailserver varchar(100),
	                            mailsender varchar(100),
	                            senderusername varchar(100),
	                            senderpassword varchar(100),
	                            port int4,
	                            remoteuri varchar(100),
	                            manifestfile varchar(100),
	                            applicationinstance varchar(100),
	                            sendemail bool DEFAULT false,
	                            synctime timestamp(6),
	                            syncday varchar(20),
	                            syncbase varchar(30),
	                            servercode varchar(20),
	                            allowctrapprovertoallbu bool DEFAULT false,
	                            remoteuri_user varchar(150),
	                            maintanance_new bool DEFAULT false NOT NULL,
	                            maintanance_durationofnotification numeric,
	                            CONSTRAINT tserverinfo_pkey PRIMARY KEY (recordid)
                            );");

            oconn.ExecuteCommand(@"CREATE TABLE tba_prodi
                                (
	                                kode character varying(100) NOT NULL,
	                                prodi character varying(200),
	                                jenjang character varying(20),
	                                namapoltek character varying(255),
																	tahun	character varying(20),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
                                CONSTRAINT tba_prodi_pkey PRIMARY KEY (kode)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_prodi_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_prodi_kode ON tba_prodi (kode);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_prodi_lembaga ON tba_prodi (prodi);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_prodi_jenjang ON tba_prodi (jenjang);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_prodi_namapoltek ON tba_prodi (namapoltek);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_prodi_dlt ON tba_prodi (dlt);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_prodi_tahun ON tba_prodi (tahun);");

            #region Program Studi Poltek Se Indonesia
            oconn.ExecuteCommand(@"insert into tba_prodi values('1001','Teknik Sipil','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1002','Teknik Mesin','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1003','Teknik Elektro','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1004','Refrigerasi dan Tata Udara','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1005','Akuntansi','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1006','Administrasi Bisnis','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1007','Usaha Perjalanan Wisata','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1008','Perhotelan','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1009','Sistem Informasi','D3','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1010','Manajemen Konstruksi','D4','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1011','Akuntansi Manajerial','D4','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('1012','Manajemen Bisnis Pariwisata','D4','POLITEKNIK NEGERI BALI','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2001','Teknik Desain dan Konstruksi Kapal','D3','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2002','Teknik Bangunan Kapal (Manufaktur)','D3','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2003','Teknik Permesinan Kapal','D3','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2004','Teknik Kelistrikan Kapal','D3','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2005','Teknik Keselamatan dan Kesehatan Kerja','D4','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2006','Teknik Pengelasan','D4','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2007','Teknik Desain dan Manufaktur','D4','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2008','Teknik Perpipaan','D4','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('2009','Teknik Otomasi','D4','POLITEKNIK PERKAPALAN NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3001','Teknik Elektronika','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3002','Teknik Listrik','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3003','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3004','Manajemen Informatika','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3005','Teknik Mesin','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3006','Teknik Sipil','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3007','Teknik Kimia','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3008','Akuntansi','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('3009','Administrasi Bisnis','D3','POLITEKNIK NEGERI MALANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4001','Produksi Tanaman Holtikultura','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4002','Produksi Tanaman Perkebunan','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4003','Teknologi Industri Panagan','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4004','Keteknikan Pertanian','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4005','Produksi Ternak','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4006','Manajemen Agribisnis','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4007','Bahasa Inggris','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4008','Manajemen Informatika','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4009','Teknik Komputer','D3','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4010','Manajemen Agroindustri','D4','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4011','Rekam Medik','D4','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4012','Gizi Klinik','D4','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4013','Manajemen Bisnis Unggas','D4','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4014','Teknik Energi Terbarukan','D4','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('4015','Teknik Produksi Benih','D4','POLITEKNIK NEGERI JEMBER','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5001','Teknik Elektronika','D3','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5002','Teknik Telekomunikasi','D3','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5003','Teknik Elektro Industri','D3','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5004','Teknologi Informasi','D3','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5006','Teknik Elektronika','D4','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5007','Teknik Telekomunikasi','D4','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5008','Teknik Elektro Industri','D4','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5009','Teknologi Informasi','D4','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5010','Teknik Mekatronika','D4','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('5011','Teknik Komputer','D4','POLITEKNIK ELEKTRONIKA NEGERI SURABAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6001','Teknik Mesin','D3','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6002','Teknik Sipil','D3','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6003','Teknik Listrik','D3','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6004','Akuntansi','D3','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6005','Administrasi Bisnis','D3','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6006','Akuntansi Sektor Publik','D4','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6007','Manajemen Perusahaan','D4','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6008','Teknik Perancangan Irigasi dan Penanganan Pantai','D4','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('6009','Teknik Perancangan dan Pemeliharaan Jalan dan Jembatan','D4','POLITEKNIK NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7001','Produksi Ternak','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7002','Manajemen Pertanian Lahan Kering','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7003','Tanaman Pangan dan Hortikultura','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7004','Manajemen Agribisnis','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7005','Manajemen Sumber Daya Hutan','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7006','Kesehatan Hewan','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7007','Teknologi Pengolahan Pangan','D3','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7008','Teknologi Industri Hortikultural','D4','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7009','Teknologi Pakan Ternak','D4','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('7010','Penyuluhan Pertanian Lahan Kering','D4','POLITEKNIK PERTANIAN NEGERI KUPANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8001','Teknik Konstruksi Sipil','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8002','Teknik Konstruksi Gedung','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8003','Teknik Listrik','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8004','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8005','Teknik Elektronika','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8006','Teknik Kimia','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8007','Teknik Mesin','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8008','Teknik Konversi Energi','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8009','Administrasi Niaga','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8010','Akuntansi','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8011','Teknik Otomotif','D3','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8012','Akuntansi Manajerial','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8013','Teknik Pembangkitan','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8014','Administrasi Bisnis','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8015','Teknik Komputer dan Jaringan','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8016','Teknik Pengolahan Pangan','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8017','Teknik Manufaktur','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('8018','Teknik Listrik Industri','D4','POLITEKNIK NEGERI UJUNG PANDANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9001','Teknik Mesin','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9002','Teknik Sipil','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9003','Teknik Elektronika','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9004','Teknik Listrik','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9005','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9006','Akuntansi','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9007','Administrasi Bisnis','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9008','Teknik Komputer','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9009','Manajemen Informatika','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9010','Usaha Perjalanan Wisata','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9011','Bahasa Inggris','D3','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9012','Teknik Elektronika','D4','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('9013','Akuntansi','D4','POLITEKNIK NEGERI UNAND PADANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10001','Teknik Mesin','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10002','Teknik Energi','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10003','Teknik Sipil','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10004','Teknik Elektro','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10005','Teknik Elektronika','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10006','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10007','Perbankan dan Keuangan','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10008','Akuntansi','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10009','Administrasi Bisnis','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10010','Manajemen Informatika','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10011','Teknik Komputer','D3','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10012','Jasa Usaha Pariwisata (MICE)','D4','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10013','Teknik Perancangan Jalan dan Jembatan','D4','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('10014','Manajemen Rekayasa Konstruksi Gedung','D4','POLITEKNIK NEGERI MEDAN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11001','Budidaya Tanaman Pangan','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11002','Agribisnis Pertanian','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11003','Peternakan','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11004','Budidaya Tanaman Perkebunan','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11005','Teknologi Pangan','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11006','Tata Air Pertanian','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11007','Mesin dan Peralatan Pertanian','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11008','Teknologi Produksi Tanaman Hortikultura','D3','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11009','Manajemen Produksi Pertanian','D4','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('11010','Manajemen Perkebunan','D4','POLITEKNIK NEGERI PAYAKUMBUH','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12001','Teknik Sipil','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12002','Teknik Elektro','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12003','Teknik Mesin','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12004','Teknik Komputer ','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12005','Akuntansi','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12006','Akuntansi Perpajakan ','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12007','Administrasi Bisnis','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12008','Manajemen Pemasaran','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12009','Usaha Perjalanan Wisata','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12010','Perhotelan','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12011','Ekowisata Bawah Laut','D3','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12012','Teknik Teknologi Informasi','D4','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12013','Teknik Konstruksi Bangunan Gedung','D4','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12014','Teknik Listrik','D4','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12015','Manajemen Bisnis','D4','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('12016','Akuntansi Keuangan','D4','POLITEKNIK NEGERI MANADO','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('13001','Teknik Sipil','D3','POLITEKNIK NEGERI AMBON','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('13002','Teknik Mesin','D3','POLITEKNIK NEGERI AMBON','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('13003','Teknik Elektro','D3','POLITEKNIK NEGERI AMBON','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('13004','Administrasi Bisnis','D3','POLITEKNIK NEGERI AMBON','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('13005','Akuntansi','D3','POLITEKNIK NEGERI AMBON','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14001','Teknik Sipil','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14002','Teknik Mesin','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14003','Teknik Listrik','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14004','Teknik Elektronika','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14005','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14006','Teknik Kimia','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14007','Akuntansi','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14008','Administrasi Niaga','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14009','Teknik Komputer','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14010','Manajemen Informatika','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14011','Bahasa Inggris Bisnis Pariwisata dan Perhotelan','D3','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14012','Perancangan Jalan dan Jembatan','D4','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('14013','Teknik Energi','D4','POLITEKNIK NEGERI SRIWIJAYA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15001','Teknik Sipil','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15002','Teknik Kimia','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15003','Teknik Mesin','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15004','Teknik Listrik','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15005','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15006','Teknik Elektronika','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15007','Akuntansi','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15008','Keuangan dan Perbankan','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15009','Administrasi Niaga','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15010','Teknik Pengolahan Minyak dan Gas','D3','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15011','Rekayasa Bangunan Transportasi','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15012','Teknologi Informatika','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15013','Instrumentasi Otomasi Industri','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15014','Teknik Mesin Produksi dan Perawatan','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15015','Teknik Multimedia dan Jaringan','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15016','Teknik Kimia Industri','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('15017','Keuangan dan Perbankan Syariah','D4','POLITEKNIK NEGERI LHOKSEUMAWE','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('16001','Manajemen Hutan','','POLITEKNIK PERTANIAN NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('16002','Teknologi Hasil Hutan','D3','POLITEKNIK PERTANIAN NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('16003','Budidaya Tanaman Perkebunan','D3','POLITEKNIK PERTANIAN NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('16004','Teknologi Pengolahan Hasil Perkebunan','D3','POLITEKNIK PERTANIAN NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('16005','Manajemen Lingkungan','D3','POLITEKNIK PERTANIAN NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('16006','Geo Informatika','D3','POLITEKNIK PERTANIAN NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('17001','Teknik Manufaktur','D3','POLITEKNIK MANUFAKTUR NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18001','Konstruksi Gedung','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18002','Konstruksi Sipil','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18003','Teknik Mesin','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18004','Teknik Konversi Energi','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18005','Teknik Listrik','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18006','Teknik Elektronika','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18007','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18008','Teknik Informasi dan Komunikasi','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18009','Akuntansi','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18010','Keuangan dan Perbankan','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18011','Administrasi Bisnis','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18012','Manajemen Pemasaran','D3','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18013','Teknik Jaringan Radio Komputer','D4','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18014','Perbankan Syariah','D4','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18015','Komputerisasi Akuntansi','D4','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18016','Manajemen Bisnis Internasional','D4','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('18017','Teknik Perbaikan dan Perawatan Gedung','D4','POLITEKNIK NEGERI SEMARANG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('19001','Perikanan Budidaya','D3','POLITEKNIK PERTANIAN NEGERI PANGKEP','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('19002','Perikanan Penangkapan','D3','POLITEKNIK PERTANIAN NEGERI PANGKEP','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('19003','Teknologi Pengolahan Hasil Perikanan','D3','POLITEKNIK PERTANIAN NEGERI PANGKEP','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('19004','Budidaya Tanaman Perkebunan','D3','POLITEKNIK PERTANIAN NEGERI PANGKEP','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('19005','Agribisnis Perikanan','D3','POLITEKNIK PERTANIAN NEGERI PANGKEP','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20001','Teknik Sipil','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20002','Teknik Geodesi','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20003','Teknik Pertambangan','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20004','Teknik Mesin','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20005','Teknik Listrik','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20006','Teknik Elektronika','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20007','Akuntansi','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20008','Administrasi Bisnis','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20009','Manajemen Informatika','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20010','Teknologi Informasi','D3','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20011','Teknik Bangunan Rawa','D4','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('20012','Akuntansi Lembaga Keuangan Syariah','D4','POLITEKNIK NEGERI BANJARMASIN','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21001','Rekayasa Jalan dan Jembatan','D4','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21002','Akuntansi Manajerial','D4','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21003','Manajemen Pemasaran','D4','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21004','Teknik Listrik','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21005','Teknik Informasi','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21006','Teknik Sipil','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21007','Desain Produk','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21008','Arsitektur','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21009','Teknik Mesin Alat Berat','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21010','Petro dan Oleo Kimia','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21011','Akuntansi','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21012','Administrasi Bisnis','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21013','Pariwisata','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21014','Maritim (Teknika)','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21015','Maritim (Nautika)','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21016','Maritim (Adm Pelabuhan)','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21017','Teknik Mesin Produksi','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('21018','Teknik Mesin Perawatan','D3','POLITEKNIK NEGERI SAMARINDA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22001','Konstruksi Gedung','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22002','Konstruksi Sipil','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22003','Teknik Mesin','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22004','Teknik Energi','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22005','Teknik Alat Berat','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22006','Teknik Listrik','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22007','Teknik Elektronika Industri','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22008','Teknik Telekomunikasi','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22009','Akuntansi','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22010','Keuangan dan Perbankan','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22011','Administrasi Bisnis','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22012','Teknik Grafika','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22013','Penerbitan','D3','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22014','Jalan Tol','D4','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('22015','Meeting Insentive Convention dan Exhibition','D4','POLITEKNIK NEGERI JAKARTA','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23001','Produksi Tanaman Pangan','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23002','Hortikultura','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23003','Teknologi Perbenihan','D4','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23004','Produksi Tanaman Perkebunan','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23005','Produksi dan Manajemen Industri Perkebunan','D4','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23006','Teknik Pengelolaan Sumberdaya Lahan dan Lingkungan','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23007','Mekanisasi Pertanian','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23008','Teknologi Pangan','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23009','Produksi Ternak','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23010','Budidaya Perikanan','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23011','Agribisnis','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23012','Akuntansi','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('23013','Manajemen Informatika','D3','POLITEKNIK NEGERI LAMPUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24001','Teknik Konstruksi Gedung','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24002','Teknik Konstruksi Sipil','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24003','Teknik Mesin','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24004','Aeronautika','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24005','Teknik Elektronika','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24006','Teknik Listrik','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24007','Teknik Telekomunikasi','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24008','Teknik Kimia','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24009','Analis Kimia ','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24010','Teknik Informatika','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24011','Teknik Pendingin dan Tata Udara','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24012','Teknik Konversi Energi','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24013','Akuntansi','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24014','Keuangan dan Perbankan','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24015','Administrasi Bisnis','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24016','Usaha Perjalanan Wisata','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24017','Manajemen Pemasaran','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24018','Bahasa Inggris','D 3','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24019','Teknik Perancangan Jalan dan Jembatan','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24020','Teknik Perawatan dan Perbaikan Gedung','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24021','Teknik Telekomunikasi Nirkabel','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24022','Teknik Elektronika','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24023','Teknik Kimia Produksi Bersih','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24024','Teknik Informatika','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24025','Teknologi Pembangkit Tenaga Listrik','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24026','Akuntansi Manajemen Pemerintahan','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24027','Keuangan Syari''ah','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24028','Manajemen Aset','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24029','Administrasi Bisnis','D 4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24030','Teknik Perancangan Konstruksi Mesin','D4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24031','Teknik Referigrasi dan Tata Udara','D4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('24032','Teknik Otomasi Industri','D4','POLITEKNIK NEGERI BANDUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('25001','Teknologi Hasil Perikanan','D3','POLITEKNIK NEGERI TUAL','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('25002','Teknologi Budidaya Perikanan','D3','POLITEKNIK NEGERI TUAL','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('25003','Teknologi Penangkapan Ikan','D3','POLITEKNIK NEGERI TUAL','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('25004','Agribisnis Perikanan','D3','POLITEKNIK NEGERI TUAL','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26001','Teknik Grafika','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26002','Desain Grafis','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26003','Penerbitan','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26004','Teknik Kemasan','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26005','Periklanan','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26006','Fotografi','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26007','Animasi','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('26008','Multimedia','D3','POLITEKNIK NEGERI MEDIA KREATIF','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27001','Teknik Sipil','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27002','Arsitektur','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27003','Teknik Mesin','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27004','Teknik Listrik','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27005','Teknik Elektronika','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27006','Teknik Informatika','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27007','Teknologi Pengolahan Hasil Perkebunan','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27008','Administrasi Bisnis','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27009','Akuntansi','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27010','Teknologi Budidaya Perikanan','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27011','Teknologi Pengolahan Hasil Perikanan','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27012','Teknologi Penangkapan Ikan','D3','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27013','Teknik Perencanaan Perumahan dan Permukiman','D4','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27014','Administrasi Instansi Pemerintahan (Administrasi Negara)','D4','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('27015','Akuntansi Sektor Publik','D4','POLITEKNIK NEGERI PONTIANAK','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('28001','Teknik Perawatan dan Perbaikan Mesin','D3','POLITEKNIK MANUFAKTUR NEGERI BANGKA BELITUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('28002','Teknik Perancangan Mekanik','D3','POLITEKNIK MANUFAKTUR NEGERI BANGKA BELITUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('28003','Teknik Elektronika','D3','POLITEKNIK MANUFAKTUR NEGERI BANGKA BELITUNG','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29001','Teknik Mesin','D3','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29002','Teknik Elektronika','D3','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29003','Teknik Informatika','D3','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29004','Akuntansi','D3','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29005','Teknik Mekatronika','D4','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29006','Teknik Multimedia dan Jaringan','D4','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29007','Administrasi Bisnis Terapan','D4','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('29008','Akuntansi Manajerial','D4','POLITEKNIK NEGERI BATAM','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30001','Teknik Perkapalan','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30002','Teknik Mesin','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30003','Teknik Elektro','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30004','Teknik Sipil','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30005','Teknik Informatika','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30006','Administrasi Bisnis','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
                                insert into tba_prodi values('30007','Bahasa Inggris Bisnis','D3','POLITEKNIK NEGERI BENGKALIS','2012','Superadmin','Superadmin',now(),'Superadmin','Superadmin',now(),'0');
");
            #endregion

            oconn.ExecuteCommand(@"CREATE TABLE tba_tahunajaran
                                (
	                                tahunajaranid character varying(50) NOT NULL,
	                                tahunajaran	character varying(100) NOT NULL,
	                                isactive boolean DEFAULT false,
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_tahunajaran_pkey PRIMARY KEY (tahunajaranid)
                                );");
            oconn.ExecuteCommand(@"create SEQUENCE tba_tahunajaran_nextid;");
            oconn.ExecuteCommand(@"CREATE INDEX tba_tahunajaran_tahunajaran ON tba_tahunajaran (tahunajaran);");
            oconn.ExecuteCommand(@"CREATE INDEX tba_tahunajaran_isactive ON tba_tahunajaran (isactive);");

            oconn.ExecuteCommand("alter table tba_gelombang add column jamujian time;");


            oconn.ExecuteCommand(@"CREATE TABLE tba_publishkelulusan
                                (
	                                publishkelulusanid character varying(50) NOT NULL,
	                                jalurmasuk character varying(100) not null,
	                                gelombangid	character varying(50) not null,
	                                jeniskelas	character varying(100) not null,
	                                ispublish	boolean default false,
	                                tahun	character varying(8),
	                                op_add character varying(100),
	                                pc_add character varying(100),
	                                lu_add timestamp without time zone DEFAULT now(),
	                                op_edit character varying(100),
	                                pc_edit character varying(100),
	                                lu_edit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tba_publishkelulusan_pkey PRIMARY KEY (publishkelulusanid)
                                );
                                create SEQUENCE tba_publishkelulusan_nextid;
                                CREATE INDEX tba_publishkelulusan_jalurmasuk ON tba_publishkelulusan (jalurmasuk);
                                CREATE INDEX tba_publishkelulusan_gelombangid ON tba_publishkelulusan (gelombangid);
                                CREATE INDEX tba_publishkelulusan_jeniskelas ON tba_publishkelulusan (jeniskelas);
                                CREATE INDEX tba_publishkelulusan_ispublish ON tba_publishkelulusan (ispublish);
                                CREATE INDEX tba_publishkelulusan_tahun ON tba_publishkelulusan (tahun);
                                CREATE INDEX tba_publishkelulusan_dlt ON tba_publishkelulusan (dlt);");

            oconn.ExecuteCommand(@"alter table tba_pmdk_umpb add column penghasilan_ayah numeric;
                                alter table tba_pmdk_umpb add column penghasilan_ibu numeric;
                                alter table tba_pmdk_umpb add column tanggungan_keluarga numeric;

                                alter table tba_umpn add column penghasilan_ayah numeric;
                                alter table tba_umpn add column penghasilan_ibu numeric;
                                alter table tba_umpn add column tanggungan_keluarga numeric;");
            #endregion

            oconn.Close();
        }

        public static string getNextABC(string strABC, int nextIndex)
        {
            string[] strArr = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            string strHasil = "";
            for (int i = 0; i < strArr.Length; i++)
            {
                if (strArr[i] == strABC)
                {
                    try
                    {
                        strHasil = strArr[i + nextIndex]; break;
                    }
                    catch (Exception)
                    {
                        strHasil = strArr[0]; break;
                    }
                }
            }
            return strHasil;
        }

        public static string getData1Field(string strSQL)
        {
            string strHasil = "";
            try
            {
                clsConnection xconn = new clsConnection();
                xconn.Open();

                DataTable dt = new DataTable();
                NpgsqlCommand ocmd = new NpgsqlCommand();
                ocmd.Connection = xconn.Conn;
                ocmd.CommandType = CommandType.Text;
                ocmd.CommandText = strSQL;
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(ocmd);
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    strHasil = dt.Rows[0].ItemArray.GetValue(0).ToString();
                }
                xconn.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            return strHasil;
        }

        public static string getData1Field(NpgsqlCommand ocmd)
        {
            string strHasil = "";
            try
            {
                clsConnection xconn = new clsConnection();
                xconn.Open();

                DataTable dt = new DataTable();
                ocmd.Connection = xconn.Conn;
                ocmd.CommandType = CommandType.Text;
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(ocmd);
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    strHasil = dt.Rows[0].ItemArray.GetValue(0).ToString();
                }
                xconn.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            return strHasil;
        }

        public static string getNoUjian(string strJalurMasuk, bool isReguler, string strJenjang)
        {
            string strNoUjian = "";
            string strLatestNoujian = "";
            string strSemester = clsGlobal.getData1Field("select configvalue from tba_config where dlt='0' and lower(configname)='semester'");
            string strTahun2Digit = clsGlobal.getData1Field("select to_char(now(), 'yy') as tahun");

            string strSql = @"select noujian
                            from tba_pembayaran
                            where tahun='" + str_Tahun + @"' and dlt='0' and (lower(jalurmasuk)='umpb' or lower(jalurmasuk)='pmdk' or lower(jalurmasuk)='umpn')
                            and substr(noujian, 0, 9)='" + strNoUjian + "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "' order by noujian desc limit 1";

            if (strJalurMasuk.Trim().ToLower() == "umpb")
            {
                strNoUjian = (isReguler == true ? "R" : "K");

                strSql = @"select a.noujian
                            from tba_pembayaran a
					        inner join tba_pmdk_umpb b on a.primaryid=b.pmdk_umpbid and b.dlt='0' and b.tahun=a.tahun
                            where a.tahun='" + str_Tahun + @"' and a.dlt='0' and lower(a.jalurmasuk)='umpb'
                            and substr(a.noujian, 0, 9)='" + strNoUjian + "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "' order by a.noujian desc limit 1";
            }
            else if (strJalurMasuk.Trim().ToLower() == "umpn")
            {
                strNoUjian = "RN";

                strSql = @"select a.noujian
                            from tba_pembayaran a
					        inner join tba_umpn b on a.primaryid=b.umpnid and b.dlt='0' and b.tahun=a.tahun
                            where a.tahun='" + str_Tahun + @"' and a.dlt='0' and lower(a.jalurmasuk)='umpn'
                            and substr(a.noujian, 0, 10)='" + strNoUjian + "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "' order by a.noujian desc limit 1";
            }
            else if (strJalurMasuk.Trim().ToLower() == "pmdk")
            {
                strNoUjian = "MD";

                strSql = @"select a.noujian
                            from tba_pembayaran a
					        inner join tba_pmdk_umpb b on a.primaryid=b.pmdk_umpbid and b.dlt='0' and b.tahun=a.tahun
                            where a.tahun='" + str_Tahun + @"' and a.dlt='0' and lower(a.jalurmasuk)='pmdk'
                            and substr(a.noujian, 0, 10)='" + strNoUjian + "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "' order by a.noujian desc limit 1";
            }
            else if (strJalurMasuk.Trim().ToLower() == "ppl")
            {
                strNoUjian = "P";

                strSql = @"select a.noujian
                            from tba_pembayaran a
                            inner join tba_ppl b on a.primaryid=b.pplid and b.dlt='0' and b.tahun=a.tahun
                            where a.tahun='" + str_Tahun + @"' and a.dlt='0' and lower(a.jalurmasuk)='ppl'
                            and substr(a.noujian, 0, 9)='" + strNoUjian + "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "' order by a.noujian desc limit 1";
            }
            else if (strJalurMasuk.Trim().ToLower() == "d4")
            {
                strNoUjian = "L";

                strSql = @"select a.noujian
                            from tba_pembayaran a
                            inner join tba_d4 b on a.primaryid=b.d4id and b.dlt='0' and b.tahun=a.tahun
                            where a.tahun='" + str_Tahun + @"' and a.dlt='0' and lower(a.jalurmasuk)='d4'
                            and substr(a.noujian, 0, 9)='" + strNoUjian + "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "' order by a.noujian desc limit 1";
            }

            strLatestNoujian = clsGlobal.getData1Field(strSql);

            if (strLatestNoujian == "" || strLatestNoujian == null)
            {
                strNoUjian += "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "-0001";
            }
            else
            {
                string[] strArr = strLatestNoujian.Split('-');
                int intLatestNoUjian = 0;
                int.TryParse(strArr[strArr.Length - 1], out intLatestNoUjian);
                intLatestNoUjian = intLatestNoUjian + 1;
                string strNextNoUjian = intLatestNoUjian.ToString("0000");
                strNoUjian += "-" + strTahun2Digit + "-" + strJenjang + "-" + strSemester + "-" + strNextNoUjian;
            }
            return strNoUjian;
        }

        public static string getWordFromNumber(int numb)
        {
            string strWord = "";
            switch (numb)
            {
                case 1: strWord = "Satu"; break;
                case 2: strWord = "Dua"; break;
                case 3: strWord = "Tiga"; break;
                case 4: strWord = "Empat"; break;
                case 5: strWord = "Lima"; break;
                case 6: strWord = "Enam"; break;
                case 7: strWord = "Tujuh"; break;
                case 8: strWord = "Delapan"; break;
                case 9: strWord = "Sembilan"; break;
                case 10: strWord = "Sepuluh"; break;
            }
            return strWord;
        }

        #region Numbering Format
        private static string strROMAWI = "";
        public static string strdocumentname = "";
        public static string strNumberingFormat = "";
        public static string strPrefix = "";
        public static string strStartFrom = "";
        public static string strRestartEvery = "";
        public static Int32 intNewNumber = 0;

        private static string getSuratNoFormat(string strModuleName)
        {
            oconn.Open();
            NpgsqlCommand ocmd = new NpgsqlCommand();
            ocmd.Connection = oconn.Conn;
            ocmd.CommandType = CommandType.Text;
            string strsql = "";
            strsql = @"select * from tbm_projectnumberingprefix where
                    trim(lower(description))=trim(lower('" + strModuleName + @"')) and dlt='0'";
            ocmd.CommandText = strsql;

            NpgsqlDataReader dr;

            dr = ocmd.ExecuteReader();
            strdocumentname = strModuleName;
            strNumberingFormat = "";
            strPrefix = "";
            strStartFrom = "";
            strRestartEvery = "";
            intNewNumber = 0;
            while (dr.Read())
            {
                strNumberingFormat = Convert.ToString(dr["numberingformat"]);
                strPrefix = Convert.ToString(dr["prefix"]);
                strStartFrom = Convert.ToString(dr["startfrom"]);
                strRestartEvery = Convert.ToString(dr["restartevery"]);
            }
            oconn.Close();
            dr.Close();
            return strNumberingFormat;
        }

        public static string GetNewNumber(string strModuleName)
        {
            DateTime d_Time = DateTime.Now;
            string monthROMAWI = d_Time.ToString("MM");
            switch (monthROMAWI)
            {
                case "01":
                    strROMAWI = "I";
                    break;
                case "02":
                    strROMAWI = "II";
                    break;
                case "03":
                    strROMAWI = "III";
                    break;
                case "04":
                    strROMAWI = "IV";
                    break;
                case "05":
                    strROMAWI = "V";
                    break;
                case "06":
                    strROMAWI = "VI";
                    break;
                case "07":
                    strROMAWI = "VII";
                    break;
                case "08":
                    strROMAWI = "VIII";
                    break;
                case "09":
                    strROMAWI = "IX";
                    break;
                case "10":
                    strROMAWI = "X";
                    break;
                case "11":
                    strROMAWI = "XI";
                    break;
                default:
                    strROMAWI = "XII";
                    break;
            }

            string strmonth = d_Time.ToString("MM");
            string stryear = d_Time.ToString("yyyy");

            string strFormatSurat = getSuratNoFormat(strModuleName);
            strFormatSurat = strFormatSurat.ToUpper();

            strFormatSurat = strFormatSurat.Replace("[MM]", strmonth);
            strFormatSurat = strFormatSurat.Replace("[MMR]", strROMAWI);
            strFormatSurat = strFormatSurat.Replace("[YYYY]", stryear);

            string strmynumber = "";
            strmynumber = getMyNoUrut(strModuleName).ToString(strPrefix);

            strFormatSurat = strFormatSurat.Replace("[NUMBER]", strmynumber);
            return strFormatSurat;
        }

        private static string strsqlsurat;
        private static Int32 getMyNoUrut(string strModuleName)
        {
            try
            {
                switch (strModuleName.ToLower())
                {
                    case "nomor induk buku":
                        string strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(luadd,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(luadd,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(luadd,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = "select coalesce(max(nourut) ,0) + 1 as newid from tbm_buku where dlt='0' and lower(jenis_barang)='buku' " + strWhere;
                        break;
                    case "nomor inventaris buku":
                        strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(a.luadd,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(a.luadd,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(a.luadd,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = @"select coalesce(max(a.nourut) ,0) + 1 as newid 
                                       from tbm_inventaris a 
                                       inner join tbm_buku b on b.dlt='0' and a.bukuid=b.bukuid and lower(b.jenis_barang)='buku'
                                       where a.dlt='0' " + strWhere;
                        break;
                    case "nomor induk multimedia":
                        strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(luadd,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(luadd,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(luadd,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = "select coalesce(max(nourut) ,0) + 1 as newid from tbm_buku where dlt='0' and lower(jenis_barang)='multimedia' " + strWhere;
                        break;
                    case "nomor inventaris multimedia":
                        strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(a.luadd,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(a.luadd,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(a.luadd,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = @"select coalesce(max(a.nourut) ,0) + 1 as newid 
                                       from tbm_inventaris a 
                                       inner join tbm_buku b on b.dlt='0' and a.bukuid=b.bukuid and lower(b.jenis_barang)='multimedia'
                                       where a.dlt='0' " + strWhere;
                        break;
                    case "nomor pengadaan":
                        strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = "select coalesce(max(nourut) ,0) + 1 as newid from tbm_pengadaan where dlt='0' " + strWhere;
                        break;
                    case "nomor peminjaman buku":
                        strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = "select coalesce(max(regno) ,0) + 1 as newid from tblpeminjaman where dlt='0' " + strWhere;
                        break;
                    case "nomor pengembalian buku":
                        strWhere = "";
                        if (strRestartEvery != "")
                        {
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Daily", "dd") + "')=to_char(now(),'" + strRestartEvery.Replace("Daily", "dd") + "')";
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Monthly", "mm") + "')=to_char(now(),'" + strRestartEvery.Replace("Monthly", "mm") + "')";
                            strWhere = " and to_char(tglditerima,'" + strRestartEvery.Replace("Yearly", "yyyy") + "')=to_char(now(),'" + strRestartEvery.Replace("Yearly", "yyyy") + "')";
                        }
                        strsqlsurat = "select coalesce(max(regno) ,0) + 1 as newid from tblpengembalian where dlt='0' " + strWhere;
                        break;
                    default:
                        strsqlsurat = "select 1 as newid";
                        break;
                }
               

                clsRegKey oReg = new clsRegKey();
                oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
                oconn.Open();

                NpgsqlCommand ocmd = new NpgsqlCommand();
                ocmd.Connection = oconn.Conn;
                ocmd.CommandType = CommandType.Text;
                ocmd.CommandText = strsqlsurat;

                NpgsqlDataReader dr;

                dr = ocmd.ExecuteReader();

                intNewNumber = 0;
                while (dr.Read())
                {
                    intNewNumber = Convert.ToInt32(dr["newid"]);
                }
                oconn.Close();
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), clsGlobal.str_ApplicationName);
            }

            return intNewNumber;
        }
        #endregion

        #region Application Information

        #region GetFrameWork
        private const string FRAMEWORK_PATH = "\\Microsoft.NET\\Framework";
        private const string WINDIR1 = "windir";
        private const string WINDIR2 = "SystemRoot";

        public static string GetNetFrameWorkVersion
        {
            get
            {
                try
                {
                    return getHighestVersion(NetFrameworkInstallationPath);
                }
                catch (System.Security.SecurityException)
                {
                    return "Unknown";
                }
            }
        }

        private static string getHighestVersion(string installationPath)
        {
            string[] versions = Directory.GetDirectories(installationPath, "v*");
            string version = "Unknown";

            for (int i = versions.Length - 1; i >= 0; i--)
            {
                version = extractVersion(versions[i]);
                if (isNumber(version.Replace('.', '0').Trim()))
                    return version;
            }

            return version;
        }

        private static string extractVersion(string directory)
        {
            int startIndex = directory.LastIndexOf("\\") + 2;
            return directory.Substring(startIndex, directory.Length - startIndex);
        }

        private static bool isNumber(string str)
        {
            return new System.Text.RegularExpressions.Regex(@"^[0-9]+\.?[0-9]*$").IsMatch(str);
        }

        public static string NetFrameworkInstallationPath
        {
            get { return WindowsPath + FRAMEWORK_PATH; }
        }

        public static string WindowsPath
        {
            get
            {
                string winDir = Environment.GetEnvironmentVariable(WINDIR1);
                if (String.IsNullOrEmpty(winDir))
                    winDir = Environment.GetEnvironmentVariable(WINDIR2);

                return winDir;
            }
        }
        #endregion

        public static string GetMacAddress()
        {
            string macAddresses = "";

            foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
                {
                    macAddresses += nic.GetPhysicalAddress().ToString();
                    break;
                }
            }
            return macAddresses;
        }

        public static string s_LastUpdate()
        {

            string sfileversion = "";
            try
            {
                string sExeName = System.IO.Path.GetFileName(Application.ExecutablePath).ToString();
                sfileversion = getVersionInfo(sExeName);
                if (sfileversion == "")
                    sfileversion = getAssemblyInfo(sExeName);
                sfileversion = "Version : " + sfileversion + " LU:" + File.GetLastWriteTime(Application.ExecutablePath.ToString()).ToString("d/M/yyyy hh:mm tt");
            }
            catch { }
            return sfileversion;
        }
        public static string getAssemblyInfo(string assemblyFile)
        {
            string strVersion = "";
            try
            {
                AssemblyName asbInfo = AssemblyName.GetAssemblyName(assemblyFile);
                strVersion = asbInfo.Version.Major + "." + asbInfo.Version.MajorRevision + "." + asbInfo.Version.Minor + "." + asbInfo.Version.MinorRevision;
            }
            catch
            {
                strVersion = "";
            }
            return strVersion;
        }

        public static string getVersionInfo(string fileName)
        {
            string strVersion = "";
            try
            {
                FileVersionInfo fvInfo = FileVersionInfo.GetVersionInfo(fileName);
                strVersion = fvInfo.FileMajorPart + "." + fvInfo.FileMinorPart + "." + fvInfo.FileBuildPart + "." + fvInfo.FilePrivatePart;
            }
            catch
            {
                strVersion = "";
            }
            return strVersion;
        }

        static public string strComputerName()
        {
            return System.Windows.Forms.SystemInformation.ComputerName;
        }
        static public string strIPAddress()
        {
            string sCode = "";
            string myHost = System.Net.Dns.GetHostName();
            System.Net.IPHostEntry myIPs = System.Net.Dns.GetHostEntry(myHost);
            foreach (System.Net.IPAddress myIP in myIPs.AddressList)
            {
                if (myIP.AddressFamily.ToString() == "InterNetwork")
                {
                    sCode = myIP.ToString(); //ip v4
                    break;
                }
            }
            return sCode;
        }
        #endregion Application Information

    
        public static string DateToStringInd(DateTime dt)
        {
            string str = "";
            str = dt.Day.ToString("00") + " ";
            switch (dt.Month)
            {
                case 1: str += "Januari"; break;
                case 2: str += "Februari"; break;
                case 3: str += "Maret"; break;
                case 4: str += "April"; break;
                case 5: str += "Mei"; break;
                case 6: str += "Juni"; break;
                case 7: str += "Juli"; break;
                case 8: str += "Agustus"; break;
                case 9: str += "September"; break;
                case 10: str += "Oktober"; break;
                case 11: str += "November"; break;
                case 12: str += "Desember"; break;
            }
            str += " " + dt.Year.ToString("0000");
            return str;
        }

        public static string MonthToStringInd(DateTime dt)
        {
            string str = "";
            switch (dt.Month)
            {
                case 1: str = "Januari"; break;
                case 2: str = "Februari"; break;
                case 3: str = "Maret"; break;
                case 4: str = "April"; break;
                case 5: str = "Mei"; break;
                case 6: str = "Juni"; break;
                case 7: str = "Juli"; break;
                case 8: str = "Agustus"; break;
                case 9: str = "September"; break;
                case 10: str = "Oktober"; break;
                case 11: str = "November"; break;
                case 12: str = "Desember"; break;
            }
            return str;
        }

        public static DateTime getServerDate()
        {
            DateTime dateResult = DateTime.Now;
            try
            {
                DateTime.TryParse(getData1Field("select now()"), out dateResult);
            }
            catch (Exception)
            {
            }
            finally
            {
            }
            return dateResult;
        }

        #region cek Constraint

        public static bool cekConstraint(string strIDPrimaryTable, string strValueToCheck, string[] strConstraintTable)
        {
            bool constraintExist = false;
            NpgsqlCommand npcmd = new NpgsqlCommand();
            clsConnection xconn = new clsConnection();


            npcmd.CommandType = CommandType.Text;
            NpgsqlDataReader dr;
            string strSql = "";
            for (int ix = 0; ix < strConstraintTable.Length; ix++)
            {
                if (!String.IsNullOrEmpty(strConstraintTable[ix].ToString()))
                {
                    if (strConstraintTable[ix].ToLower() == "tblproject")
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and projectid<>'LV' and dlt='0' limit 1";
                    }
                    else if (strConstraintTable[ix].ToLower() == "tblctr")
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and ctrno<>'LV' and dlt='0' limit 1";
                    }
                    else
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and dlt='0' limit 1";
                    }
                    npcmd = new NpgsqlCommand(strSql, xconn.Conn);
                    npcmd.Parameters.Add("@strValueToCheck", NpgsqlTypes.NpgsqlDbType.Varchar).Value = strValueToCheck;
                    xconn.Open();
                    dr = npcmd.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr["rowCount"].ToString() != "0")
                        {
                            constraintExist = true;
                            return constraintExist;
                        }
                    }
                    dr.Close();
                    xconn.Close();
                }
            }
            return constraintExist;
        }

        public static bool cekConstraint(string strIDPrimaryTable, string strValueToCheck, string[] strConstraintTable, ref string strExistConstraint)
        {
            bool constraintExist = false;
            NpgsqlCommand npcmd = new NpgsqlCommand();
            clsConnection xconn = new clsConnection();

            npcmd.CommandType = CommandType.Text;
            NpgsqlDataReader dr;
            string strSql = "";
            for (int ix = 0; ix < strConstraintTable.Length; ix++)
            {
                if (!String.IsNullOrEmpty(strConstraintTable[ix].ToString()))
                {
                    strExistConstraint = "";
                    if (strConstraintTable[ix].ToLower() == "tblproject")
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and projectid<>'LV' and dlt='0' limit 1";
                    }
                    else if (strConstraintTable[ix].ToLower() == "tblctr")
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and ctrno<>'LV' and dlt='0' limit 1";
                    }
                    else if (strConstraintTable[ix].ToLower() == "pcms_tbljoint" && strIDPrimaryTable == "piecemarkid")
                    {
                        strSql = "select count(*) as rowCount from pcms_tbljoint where piecemarkid1=@strValueToCheck and dlt='0' limit 1";
                    }
                    else if (strConstraintTable[ix].ToLower() == "pcms_tbljoint2" && strIDPrimaryTable == "piecemarkid")
                    {
                        strSql = "select count(*) as rowCount from pcms_tbljoint where piecemarkid2=@strValueToCheck and dlt='0' limit 1";
                    }
                    else
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and dlt='0' limit 1";
                    }

                    npcmd = new NpgsqlCommand(strSql, xconn.Conn);
                    npcmd.Parameters.Add("@strValueToCheck", NpgsqlTypes.NpgsqlDbType.Varchar).Value = strValueToCheck;
                    xconn.Open();
                    dr = npcmd.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr["rowCount"].ToString() != "0")
                        {
                            strExistConstraint = "table [" + strConstraintTable[ix].ToLower() + "]";
                            constraintExist = true;
                            return constraintExist;
                        }
                    }
                    dr.Close();
                    xconn.Close();
                }
            }
            return constraintExist;
        }


        public static bool cekConstraint(string strIDPrimaryTable, string strValueToCheck, string[] strConstraintTable, string strAddWhere, ref string strExistConstraint)
        {
            bool constraintExist = false;
            NpgsqlCommand npcmd = new NpgsqlCommand();
            clsConnection xconn = new clsConnection();

            npcmd.CommandType = CommandType.Text;
            NpgsqlDataReader dr;
            string strSql = "";
            for (int ix = 0; ix < strConstraintTable.Length; ix++)
            {
                if (!String.IsNullOrEmpty(strConstraintTable[ix].ToString()))
                {
                    strExistConstraint = "";
                    if (strConstraintTable[ix].ToLower() == "tblproject")
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and projectid<>'LV' and dlt='0' " + strAddWhere + " limit 1";
                    }
                    else if (strConstraintTable[ix].ToLower() == "tblctr")
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and ctrno<>'LV' and dlt='0' " + strAddWhere + " limit 1";
                    }
                    else
                    {
                        strSql = "select count(*) as rowCount from " + strConstraintTable[ix] + " where " + strIDPrimaryTable + "=@strValueToCheck and dlt='0' " + strAddWhere + " limit 1";
                    }
                    npcmd = new NpgsqlCommand(strSql, xconn.Conn);
                    npcmd.Parameters.Add("@strValueToCheck", NpgsqlTypes.NpgsqlDbType.Varchar).Value = strValueToCheck;
                    xconn.Open();
                    dr = npcmd.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr["rowCount"].ToString() != "0")
                        {
                            strExistConstraint = "table [" + strConstraintTable[ix].ToLower() + "]";
                            constraintExist = true;
                            return constraintExist;
                        }
                    }
                    dr.Close();
                    xconn.Close();
                }
            }
            return constraintExist;
        }

        #endregion
        
        public static void generateErrMessageAndSendmail(NpgsqlException ex, bool bolShowMessage)
        {
            try
            {
                //clsSendMail oSendMail = new clsSendMail();
                string sMessage1 = ("Error occured at '" + ex.Source + "' on " + DateTime.Now.ToLongDateString() + " - " + DateTime.Now.ToLongTimeString() + ":\n" +
                ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n");

                string sMessage = ("======================================================================================\n" +
                    sMessage1 +
                    "\n\r==================\n\r" +
                "Error Sql: \n\r" + ex.ErrorSql.ToString() +
                "\n\r==================\n" +
                "\n\nStack Trace: \n" + ex.StackTrace + "\n======================================================================================");

                if (bolShowMessage)
                {
                    MessageBox.Show(sMessage1, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                //oSendMail.sendMailToAdministrator(ex.Message, sMessage);
            }
            catch
            {
            }
        }

        public static void generateErrMessageAndSendmail(Exception ex, bool bolShowMessage)
        {
            try
            {
                //clsSendMail oSendMail = new clsSendMail();
                string sMessage1 = ("Error occured at '" + ex.Source + "' on " + DateTime.Now.ToLongDateString() + " - " + DateTime.Now.ToLongTimeString() + ":\n" +
                ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n");

                string sMessage = ("======================================================================================\n" +
                    sMessage1 +
                "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");

                if (bolShowMessage)
                {
                    MessageBox.Show(sMessage1, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


                //oSendMail.sendMailToAdministrator(ex.Message, sMessage);
            }
            catch
            {
                //clsTextGenerator oTextGenerator = new clsTextGenerator();
                //oTextGenerator.AppendTLog(sMessage);  
            }
        }
        public static void xupdatedatabase()
        {
            #region PERPUSTAKAAN
            xsetupdatedatabase(@"CREATE TABLE tbp_news (
                newsid varchar(50) NOT NULL,
                tglterbit timestamp(6),
                judul varchar(100), 
                news text,
                news_html text,
                nourut numeric,
                isterbit bool DEFAULT false,
                opadd varchar(100),
                pcadd varchar(100),
                luadd timestamp(6) DEFAULT now(),
                opedit varchar(100),
                pcedit varchar(100),
                luedit timestamp(6),
                dlt bool DEFAULT false,
                CONSTRAINT tbp_news_pkey PRIMARY KEY (newsid)
                );

                CREATE SEQUENCE tbp_news_nextid;


                CREATE INDEX tbp_news_newsid ON tbp_news USING btree (newsid);
                CREATE INDEX tbp_news_tglditerima ON tbp_news USING btree (tglterbit);
                
                CREATE TABLE tbp_agenda (
                agendaid varchar(50) NOT NULL,
                tglterbit timestamp(6),
				judul varchar(100), 
                agenda text,
                agenda_html text,
                nourut numeric,
                isterbit bool DEFAULT false,
                opadd varchar(100),
                pcadd varchar(100),
                luadd timestamp(6) DEFAULT now(),
                opedit varchar(100),
                pcedit varchar(100),
                luedit timestamp(6),
                dlt bool DEFAULT false,
                CONSTRAINT tbp_agenda_pkey PRIMARY KEY (agendaid)
                );

                CREATE SEQUENCE tbp_agenda_nextid;


                CREATE INDEX tbp_agenda_agendaid ON tbp_agenda USING btree (agendaid);
                CREATE INDEX tbp_agenda_tglditerima ON tbp_agenda USING btree (tglterbit);
            ");
            xsetupdatedatabase(@"alter table tbm_buku add column coverbuku text;");
            xsetupdatedatabase(@"alter table tbp_user add column photo text;");
            xsetupdatedatabase(@"alter table tblpeminjamandetails rename column bukuid to inventarisid;");
            xsetupdatedatabase(@"alter table tbm_anggota add column username varchar(100),
                add column passwd varchar(150),
                add column hak_akses varchar(50),
                add column usergroupid varchar(50);

                alter table tbp_user add column rfid varchar(150), add column nik varchar(200), add column nama varchar(255);
                ");

            xsetupdatedatabase(@"CREATE TABLE tblketentuanpeminjaman (
                ketentuanpeminjamanid varchar(30) NOT NULL,
                lamapeminjaman numeric,
                dendaperhari numeric,
                maksbukudipinjam numeric,
                ketentuanpeminjaman varchar(100),
                op varchar(100),
                pc varchar(100),
                lu timestamp(6) DEFAULT now(),
                dlt bool DEFAULT false,
                CONSTRAINT tblketentuanpeminjaman_pkey PRIMARY KEY (ketentuanpeminjamanid)
                );

                CREATE SEQUENCE tblketentuanpeminjaman_nextid;
                CREATE INDEX tblketentuanpeminjaman_dlt_idx ON tblketentuanpeminjaman USING btree (dlt);
                CREATE INDEX tblketentuanpeminjaman_ketentuanpeminjamanid_idx ON tblketentuanpeminjaman USING btree (ketentuanpeminjamanid);
");
            xsetupdatedatabase(@"CREATE TABLE tblnumberingformat (
                numberingformatid varchar(30) NOT NULL,
                proid varchar(30),
                modulename varchar(100),
                prefix varchar(100),
                prefixseparator varchar(10),
                infix varchar(100),
                infixseparator varchar(10),
                suffix varchar(100),
                startfrom numeric,
                lengthofnumber numeric,
                numberingformat varchar(100),
                sample varchar(100),
                op varchar(100),
                pc varchar(100),
                lu timestamp(6) DEFAULT now(),
                dlt bool DEFAULT false,
                CONSTRAINT tblnumberingformat_pkey PRIMARY KEY (numberingformatid)
                );

                CREATE SEQUENCE tblnumberingformat_nextid;
                CREATE INDEX tblnumberingformat_dlt_idx ON tblnumberingformat USING btree (dlt);

                CREATE INDEX tblnumberingformat_modulename_idx ON tblnumberingformat USING btree (modulename);

                CREATE INDEX tblnumberingformat_numberingformatid_idx ON tblnumberingformat USING btree (numberingformatid);

                CREATE INDEX tblnumberingformat_proid_idx ON tblnumberingformat USING btree (proid);");

            xsetupdatedatabase(@"CREATE TABLE tblpengembalian (
                pengembalianid varchar(50) NOT NULL,
                petugasid varchar(50),
                nopengembalian varchar(100),
                tglkembali timestamp(6),
                keterangan varchar(255),
                regno numeric DEFAULT 0,
                opadd varchar(100),
                pcadd varchar(100),
                luadd timestamp(6) DEFAULT now(),
                opedit varchar(100),
                pcedit varchar(100),
                luedit timestamp(6),
                dlt bool DEFAULT false,
                CONSTRAINT tblpengembalian_pkey PRIMARY KEY (pengembalianid)
                );
                CREATE SEQUENCE tblpengembalian_nextid;
                CREATE INDEX tblpengembalian_pengembalianid ON tblpengembalian USING btree (pengembalianid);
                CREATE INDEX tblpengembalian_petugasid ON tblpengembalian USING btree (petugasid);

                CREATE TABLE tblpengembaliandetails
                (
	                pengembaliandetailsid	character varying(50) NOT NULL,	                
	                pengembalianid varchar(50) NOT NULL,            
	                peminjamandetailsid character varying(50),
	                tglkembali	timestamp(6),
	                jumlah numeric,
	                status character varying(100),
	                keterangan character varying(255),
	                jumlahdenda numeric,
	                dendadibayar numeric,
	                opadd character varying(100),
	                pcadd character varying(100),
	                luadd timestamp without time zone DEFAULT now(),
	                opedit character varying(100),
	                pcedit character varying(100),
	                luedit timestamp without time zone,
	                dlt boolean DEFAULT false,
	                CONSTRAINT tblpengembaliandetails_pkey PRIMARY KEY (pengembaliandetailsid)
                );
                CREATE SEQUENCE tblpengembaliandetails_nextid;
                CREATE INDEX tblpengembaliandetails_pengembaliandetailsid ON tblpengembaliandetails (pengembaliandetailsid);
                CREATE INDEX tblpengembaliandetails_pengembalianid ON tblpengembaliandetails (pengembalianid);
                CREATE INDEX tblpengembaliandetails_status ON tblpengembaliandetails (status);                
                CREATE INDEX tblpengembaliandetails_peminjamandetailsid ON tblpengembaliandetails (peminjamandetailsid);
                
                ");
            xsetupdatedatabase(@"CREATE TABLE tblpeminjaman
                (
                    peminjamanid	character varying(50) NOT NULL,
                    anggotaid character varying(50) NOT NULL,
                    petugasid character varying(50),
                    nopeminjaman character varying(100),
                    tglpinjam	timestamp(6),
                    tgljatuhtempo	date,
                    lamapeminjaman numeric,
                    dendaperhari numeric,
                    maksbukudipinjam numeric,
                    status character varying(100),
                    keterangan character varying(255),
                    regno numeric default 0,
                    opadd character varying(100),
                    pcadd character varying(100),
                    luadd timestamp without time zone DEFAULT now(),
                    opedit character varying(100),
                    pcedit character varying(100),
                    luedit timestamp without time zone,
                    dlt boolean DEFAULT false,
                    CONSTRAINT tblpeminjaman_pkey PRIMARY KEY (peminjamanid)
                );
                CREATE SEQUENCE tblpeminjaman_nextid;
                CREATE INDEX tblpeminjaman_peminjamanid ON tblpeminjaman (peminjamanid);
                CREATE INDEX tblpeminjaman_anggotaid ON tblpeminjaman (anggotaid);
                CREATE INDEX tblpeminjaman_status ON tblpeminjaman (status);
                CREATE INDEX tblpeminjaman_petugasid ON tblpeminjaman (petugasid);



                CREATE TABLE tblpeminjamandetails
                (
                    peminjamandetailsid	character varying(50) NOT NULL,
                    peminjamanid character varying(50) NOT NULL,
                    bukuid character varying(50),
                    tglpinjam	timestamp(6),
                    tgljatuhtempo	date,                    
                    jumlah numeric,
                    status character varying(100),
                    keterangan character varying(255),
                    opadd character varying(100),
                    pcadd character varying(100),
                    luadd timestamp without time zone DEFAULT now(),
                    opedit character varying(100),
                    pcedit character varying(100),
                    luedit timestamp without time zone,
                    dlt boolean DEFAULT false,
                    CONSTRAINT tblpeminjamandetails_pkey PRIMARY KEY (peminjamandetailsid)
                );
                
                CREATE INDEX tblpeminjamandetails_peminjamandetailsid ON tblpeminjamandetails (peminjamandetailsid);
                CREATE INDEX tblpeminjamandetails_bukuid ON tblpeminjamandetails (bukuid);
                CREATE INDEX tblpeminjamandetails_peminjamanid ON tblpeminjamandetails (peminjamanid);
                CREATE INDEX tblpeminjamandetails_status ON tblpeminjamandetails (status);
                create SEQUENCE tblpeminjamandetails_nextid;
                
                ");

            xsetupdatedatabase(@"alter table tblpeminjaman  add column regno numeric default 0");

            xsetupdatedatabase(@"CREATE TABLE tbm_anggota
                (
                    anggotaid	character varying(50) NOT NULL,
                    rfid character varying(150) NOT NULL,
                    nim character varying(200),
                    nama character varying(255),
                    opadd character varying(100),
                    pcadd character varying(100),
                    luadd timestamp without time zone DEFAULT now(),
                    opedit character varying(100),
                    pcedit character varying(100),
                    luedit timestamp without time zone,
                    dlt boolean DEFAULT false,
                    CONSTRAINT tbm_anggota_pkey PRIMARY KEY (anggotaid)
                );

                CREATE INDEX tbm_anggota_anggotaid ON tbm_anggota (anggotaid);
                CREATE INDEX tbm_anggota_rfid ON tbm_anggota (rfid);
                CREATE INDEX tbm_anggota_nim ON tbm_anggota (nim);
                CREATE INDEX tbm_anggota_nama ON tbm_anggota (nama);

                create SEQUENCE tbm_anggota_nextid;
                ");
            xsetupdatedatabase(@"CREATE TABLE tbm_pengadaan
                                (
	                                pengadaanid character varying(50) NOT NULL,
	                                tglditerima date,
	                                nopo character varying(255),
	                                judul character varying(255),
	                                pengarang character varying(255),
	                                edisi character varying(255),
	                                penerbit character varying(255),
	                                tempatterbit character varying(255),
	                                tahunterbit character varying(50),
	                                isbn character varying(255),
	                                supplemen character varying(255),
	                                pengusul character varying(255),
	                                jumlah numeric,
	                                status character varying(100),
	                                harga numeric,
	                                opadd character varying(100),
	                                pcadd character varying(100),
	                                luadd timestamp without time zone DEFAULT now(),
	                                opedit character varying(100),
	                                pcedit character varying(100),
	                                luedit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_pengadaan_pkey PRIMARY KEY (pengadaanid)
                                );
                                create SEQUENCE tbm_pengadaan_nextid;
                                CREATE INDEX tbm_pengadaan_nopo ON tbm_pengadaan (nopo);
                                CREATE INDEX tbm_pengadaan_judul ON tbm_pengadaan (judul);
                                CREATE INDEX tbm_pengadaan_pengarang ON tbm_pengadaan (pengarang);
                                CREATE INDEX tbm_pengadaan_edisi ON tbm_pengadaan (edisi);
                                CREATE INDEX tbm_pengadaan_penerbit ON tbm_pengadaan (penerbit);
                                CREATE INDEX tbm_pengadaan_isbn ON tbm_pengadaan (isbn);
                                ");

            xsetupdatedatabase(@"CREATE TABLE tbm_buku
                                (
	                                bukuid character varying(50) NOT NULL,
	                                pengadaanid character varying(50),
	                                noinduk character varying(255),
	                                kodepanggil	character varying(255),
	                                judul character varying(255),
	                                pengarang character varying(255),
	                                badankorporat	character varying(255),
	                                edisi character varying(255),
	                                penerbit character varying(255),
	                                tempatterbit character varying(255),
	                                tahunterbit character varying(50),
	                                isbn character varying(255),
	                                deskripsi character varying(255),
	                                supplemen character varying(255),
	                                lokasikoleksi character varying(255),
	                                jeniskoleksi	character varying(255),
	                                keterangan	text,
	                                opadd character varying(100),
	                                pcadd character varying(100),
	                                luadd timestamp without time zone DEFAULT now(),
	                                opedit character varying(100),
	                                pcedit character varying(100),
	                                luedit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_buku_pkey PRIMARY KEY (bukuid)
                                );
                                create SEQUENCE tbm_buku_nextid;
                                CREATE INDEX tbm_buku_pengadaanid ON tbm_buku (pengadaanid);
                                CREATE INDEX tbm_buku_noinduk ON tbm_buku (noinduk);
                                CREATE INDEX tbm_buku_kodepanggil ON tbm_buku (kodepanggil);
                                CREATE INDEX tbm_buku_judul ON tbm_buku (judul);
                                CREATE INDEX tbm_buku_pengarang ON tbm_buku (pengarang);
                                CREATE INDEX tbm_buku_edisi ON tbm_buku (edisi);
                                CREATE INDEX tbm_buku_penerbit ON tbm_buku (penerbit);
                                CREATE INDEX tbm_buku_isbn ON tbm_buku (isbn);");

            xsetupdatedatabase(@"CREATE TABLE tbm_inventaris
                                (
	                                inventarisid	character varying(50) NOT NULL,
	                                bukuid character varying(50) NOT NULL,
	                                pengadaanid character varying(50),
	                                rfid	character varying(255),
	                                tglditerima	date,
	                                nib character varying(255),
	                                status character varying(100),
	                                ket_koleksi character varying(100),
	                                kode_makul	character varying(100),
	                                opadd character varying(100),
	                                pcadd character varying(100),
	                                luadd timestamp without time zone DEFAULT now(),
	                                opedit character varying(100),
	                                pcedit character varying(100),
	                                luedit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_inventaris_pkey PRIMARY KEY (inventarisid)
                                );
                                create SEQUENCE tbm_inventaris_nextid;
                                CREATE INDEX tbm_inventaris_pengadaanid ON tbm_inventaris (pengadaanid);
                                CREATE INDEX tbm_inventaris_bukuid ON tbm_inventaris (bukuid);
                                CREATE INDEX tbm_inventaris_rfid ON tbm_inventaris (rfid);
                                CREATE INDEX tbm_inventaris_tglditerima ON tbm_inventaris (tglditerima);
                                CREATE INDEX tbm_inventaris_nib ON tbm_inventaris (nib);
                                CREATE INDEX tbm_inventaris_status ON tbm_inventaris (status);
                                CREATE INDEX tbm_inventaris_ket_koleksi ON tbm_inventaris (ket_koleksi);
                                CREATE INDEX tbm_inventaris_kode_makul ON tbm_inventaris (kode_makul);");

            xsetupdatedatabase(@"CREATE TABLE tbm_pengadaan
                                (
	                                pengadaanid character varying(50) NOT NULL,
	                                anggotaid	character varying(50),
	                                tglditerima date,
	                                nopengadaan character varying(255),
	                                nourut	numeric,
	                                opadd character varying(100),
	                                pcadd character varying(100),
	                                luadd timestamp without time zone DEFAULT now(),
	                                opedit character varying(100),
	                                pcedit character varying(100),
	                                luedit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_pengadaan_pkey PRIMARY KEY (pengadaanid)
                                );
                                create SEQUENCE tbm_pengadaan_nextid;
                                CREATE INDEX tbm_pengadaan_anggotaid ON tbm_pengadaan (anggotaid);
                                CREATE INDEX tbm_pengadaan_tglditerima ON tbm_pengadaan (tglditerima);
                                CREATE INDEX tbm_pengadaan_nopengadaan ON tbm_pengadaan (nopengadaan);
                                CREATE INDEX tbm_pengadaan_nourut ON tbm_pengadaan (nourut);");

            xsetupdatedatabase(@"CREATE TABLE tbm_pengadaandetails
                                (
	                                pengadaandetailsid character varying(50) NOT NULL,
	                                pengadaanid character varying(50) NOT NULL,
	                                nopo character varying(255),
	                                judul character varying(255),
	                                pengarang character varying(255),
	                                edisi character varying(255),
	                                penerbit character varying(255),
	                                tempatterbit character varying(255),
	                                tahunterbit character varying(50),
	                                isbn character varying(255),
	                                supplemen character varying(255),
	                                pengusul character varying(255),
	                                jumlah numeric,
	                                status character varying(100),
	                                harga numeric,
	                                nourut	numeric,
	                                opadd character varying(100),
	                                pcadd character varying(100),
	                                luadd timestamp without time zone DEFAULT now(),
	                                opedit character varying(100),
	                                pcedit character varying(100),
	                                luedit timestamp without time zone,
	                                dlt boolean DEFAULT false,
	                                CONSTRAINT tbm_pengadaandetails_pkey PRIMARY KEY (pengadaandetailsid)
                                );
                                create SEQUENCE tbm_pengadaandetails_nextid;
                                CREATE INDEX tbm_pengadaandetails_pengadaanid ON tbm_pengadaandetails (pengadaanid);
                                CREATE INDEX tbm_pengadaandetails_nopo ON tbm_pengadaandetails (nopo);
                                CREATE INDEX tbm_pengadaandetails_judul ON tbm_pengadaandetails (judul);
                                CREATE INDEX tbm_pengadaandetails_pengarang ON tbm_pengadaandetails (pengarang);
                                CREATE INDEX tbm_pengadaandetails_edisi ON tbm_pengadaandetails (edisi);
                                CREATE INDEX tbm_pengadaandetails_penerbit ON tbm_pengadaandetails (penerbit);
                                CREATE INDEX tbm_pengadaandetails_isbn ON tbm_pengadaandetails (isbn);");

            xsetupdatedatabase(@"alter table tbm_inventaris rename column pengadaanid to pengadaandetailsid;");

            xsetupdatedatabase(@"CREATE TABLE tbm_projectnumberingprefix (
	                                numberingprefixid varchar(50) NOT NULL,
	                                description varchar(150),
	                                numberingformat varchar(100),
	                                prefix varchar(20),
	                                startfrom varchar(10),
	                                restartevery varchar(20),
	                                opadd varchar(100),
	                                pcadd varchar(100),
	                                luadd timestamp(6) DEFAULT now(),
	                                opedit varchar(100),
	                                pcedit varchar(100),
	                                luedit timestamp(6),
	                                dlt bool DEFAULT false,
	                                CONSTRAINT tbm_projectnumberingprefix_pkey PRIMARY KEY (numberingprefixid)
                                );

                                create sequence tbm_projectnumberingprefix_nextid;

                                CREATE INDEX tbm_projectnumberingprefix_description ON tbm_projectnumberingprefix (description);
                                CREATE INDEX tbm_projectnumberingprefix_numberingformat ON tbm_projectnumberingprefix (numberingformat);
                                CREATE INDEX tbm_projectnumberingprefix_prefix ON tbm_projectnumberingprefix (prefix);
                                CREATE INDEX tbm_projectnumberingprefix_startfrom ON tbm_projectnumberingprefix (startfrom);
                                CREATE INDEX tbm_projectnumberingprefix_restartevery ON tbm_projectnumberingprefix (restartevery);
                                CREATE INDEX tbm_projectnumberingprefix_dlt ON tbm_projectnumberingprefix (dlt);");

            xsetupdatedatabase(@"alter table tbm_buku add column nourut numeric;
                                create index tbm_buku_nourut on tbm_buku(nourut);");

            xsetupdatedatabase(@"CREATE TABLE tbm_jurusan (
	            jurusanid varchar(50) NOT NULL,
	            jurusancode varchar(150) not null,
	            jurusandesc varchar(255) not null,
				remarks	text,
	            nourut	numeric default 0,
	            opadd varchar(100),
	            pcadd varchar(100),
	            luadd timestamp(6) DEFAULT now(),
	            opedit varchar(100),
	            pcedit varchar(100),
	            luedit timestamp(6),
	            dlt bool DEFAULT false,
	            CONSTRAINT tbm_jurusan_pkey PRIMARY KEY (jurusanid)
            );

            CREATE INDEX tbm_jurusan_dlt ON tbm_jurusan (dlt);
			CREATE INDEX tbm_jurusan_jurusancode ON tbm_jurusan (jurusancode);
			CREATE INDEX tbm_jurusan_jurusandesc ON tbm_jurusan (jurusandesc);
            CREATE INDEX tbm_jurusan_nourut ON tbm_jurusan (nourut);

            CREATE SEQUENCE tbm_jurusan_nextid;

            CREATE TABLE tbm_prodi (
	            prodiid varchar(50) NOT NULL,
				jurusanid	varchar(50) not null,
				inisial varchar(150) not null,
	            prodicode varchar(150) not null,
	            prodidesc varchar(255) not null,
				remarks	text,
	            nourut	numeric default 0,
	            opadd varchar(100),
	            pcadd varchar(100),
	            luadd timestamp(6) DEFAULT now(),
	            opedit varchar(100),
	            pcedit varchar(100),
	            luedit timestamp(6),
	            dlt bool DEFAULT false,
	            CONSTRAINT tbm_prodi_pkey PRIMARY KEY (prodiid)
            );

            CREATE INDEX tbm_prodi_dlt ON tbm_prodi (dlt);
			CREATE INDEX tbm_prodi_jurusanid ON tbm_prodi (jurusanid);
			CREATE INDEX tbm_prodi_inisial ON tbm_prodi (inisial);
			CREATE INDEX tbm_prodi_prodicode ON tbm_prodi (prodicode);
			CREATE INDEX tbm_prodi_prodidesc ON tbm_prodi (prodidesc);
            CREATE INDEX tbm_prodi_nourut ON tbm_prodi (nourut);

            CREATE SEQUENCE tbm_prodi_nextid;");

            xsetupdatedatabase(@"alter table tbm_anggota add column prodiid varchar(50);
                            alter table tbm_anggota add column jeniskelamin varchar(50);
                            alter table tbm_anggota add column alamat text;
                            alter table tbm_anggota add column nohp varchar(100);
                            alter table tbm_anggota add column keterangan text;
                            alter table tbm_anggota add column statusaktif varchar(100);
                            alter table tbm_anggota add column photo text;

                            CREATE INDEX tbm_anggota_prodiid ON tbm_anggota (prodiid);
                            CREATE INDEX tbm_anggota_jeniskelamin ON tbm_anggota (jeniskelamin);
                            CREATE INDEX tbm_anggota_statusaktif ON tbm_anggota (statusaktif);");

            xsetupdatedatabase(@"CREATE TABLE tbm_config (
	                        configid varchar(50) NOT NULL,
	                        configname varchar(100) NOT NULL,
	                        configdesc text,
	                        op_add varchar(100),
	                        pc_add varchar(100),
	                        lu_add timestamp(6) DEFAULT now(),
	                        op_edit varchar(100),
	                        pc_edit varchar(100),
	                        lu_edit timestamp(6),
	                        dlt bool DEFAULT false,
	                        configvalue varchar(100) NOT NULL,
	                        CONSTRAINT tbm_config_pkey PRIMARY KEY (configid)
                        );

                        create SEQUENCE tbm_config_nextid;
                        CREATE INDEX tbm_config_configname ON tbm_config (configname);
                        CREATE INDEX tbm_config_configvalue ON tbm_config (configvalue);");

            xsetupdatedatabase(@"alter table tbm_anggota add column jenis VARCHAR(50);
                        CREATE INDEX tbm_anggota_jenis ON tbm_anggota (jenis);");

            xsetupdatedatabase(@"alter table tbm_buku add column jenis_barang VARCHAR(50);
                        create index tbm_buku_jenis_barang on tbm_buku (jenis_barang);");


            xsetupdatedatabase(@"CREATE TABLE tbm_holiday (
	                        holidayid varchar(50) NOT NULL,
	                        tgl date,
	                        remarks	varchar(200),
	                        opadd varchar(100),
	                        pcadd varchar(100),
	                        luadd timestamp(6) DEFAULT now(),
	                        opedit varchar(100),
	                        pcedit varchar(100),
	                        luedit timestamp(6),
	                        dlt bool DEFAULT false,
	                        CONSTRAINT tbm_holiday_pkey PRIMARY KEY (holidayid)
                        );

                        create sequence tbm_holiday_nextid;
                        CREATE INDEX tbm_holiday_holidayid ON tbm_holiday (holidayid);
                        CREATE INDEX tbm_holiday_tgl ON tbm_holiday (tgl);
                        CREATE INDEX tbm_holiday_dlt ON tbm_holiday (dlt);");
            #endregion
        }

        public static void xsetupdatedatabase(string strsql)
        {
            try
            {
                clsConnection oconn = new clsConnection();
                clsRegKey oReg = new clsRegKey();
                oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;


                oconn.Open();

                NpgsqlCommand ocmd = new NpgsqlCommand();

                ocmd = new NpgsqlCommand();
                ocmd.Connection = oconn.Conn;
                ocmd.CommandType = CommandType.Text;
                ocmd.CommandText = strsql;
                ocmd.ExecuteNonQuery();
                oconn.Close();
            }
            catch (Exception ex)
            {

                //throw;
            }
        }

        #region Parsing
        public static DateTime GetParseDate(object strIn)
        {
            DateTime m_Out;
            DateTime.TryParse(Convert.ToString(strIn), out m_Out);
            return m_Out;
        }

        public static Decimal GetParseDecimal(object strIn)
        {
            Decimal m_Out;
            Decimal.TryParse(Convert.ToString(strIn), out m_Out);
            return m_Out;
        }

        public static Double GetParseDouble(object strIn)
        {
            Double m_Out;
            Double.TryParse(Convert.ToString(strIn), out m_Out);
            return m_Out;
        }

        public static int GetParseInt(object strIn)
        {
            int m_Out;
            int.TryParse(Convert.ToString(strIn), out m_Out);
            return m_Out;
        }
        public static Boolean GetParseBoolean(object strIn)
        {
            Boolean m_Out;
            Boolean.TryParse(Convert.ToString(strIn), out m_Out);
            return m_Out;
        }

        public static DateTime UnixTimestampToDateTime(decimal unixTime)
        {
            DateTime unixStart = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            long unixTimeStampInTicks = (long)(unixTime * TimeSpan.TicksPerSecond);
            return new DateTime(unixStart.Ticks + unixTimeStampInTicks, System.DateTimeKind.Utc);
        }
        #endregion

        #region Number To Words
        public static string NumberToText(int number)
        {
            //    if (number == 0) return "Nol";
            //    string and = ""; 
            //    if (number == -2147483648) return "Minus Two Billion One Hundred " + and +
            //    "Forty Seven Million Four Hundred " + and + "Eighty Three Thousand " +
            //    "Six Hundred " + and + "Forty Eight";
            //    int[] num = new int[4];
            //    int first = 0;
            //    int u, h, t;
            //    System.Text.StringBuilder sb = new System.Text.StringBuilder(); 
            //    if (number < 0)
            //    {
            //        sb.Append("Minus ");
            //        number = -number;
            //    }
            //    string[] words0 = {"", "Satu ", "Dua ", "Tiga ", "Empat ", "Lima ", "Enam ", "Tujuh ", "Delapan ", "Sembilan "};
            //    string[] words1 = {"Sepuluh ", "Sebelas ", "Dua Belas ", "Tiga Belas ", "Empat Belas ", "Lima Belas ", "Enam Belas ", "Tujuh Belas ", "Delapan Belas ", "Sembilan Belas "};
            //    string[] words2 = {"Dua Puluh ", "Tiga Puluh ", "Empat Puluh ", "Lima Puluh ", "Enam Puluh ", "Tujuh Puluh ", "Delapan Puluh ", "Sembilan Puluh "};
            //    string[] words3 = { "Ribu ", "Juta ", "Miliar " };
            //    num[0] = number % 1000;           // units
            //    num[1] = number / 1000;
            //    num[2] = number / 1000000;
            //    num[1] = num[1] - 1000 * num[2];  // thousands
            //    num[3] = number / 1000000000;     // billions
            //    num[2] = num[2] - 1000 * num[3];  // millions
            //    for (int i = 3; i > 0; i--)
            //    {
            //        if (num[i] != 0)
            //        {
            //            first = i;
            //            break;
            //        }
            //    }
            //    for (int i = first; i >= 0; i--)
            //    {
            //        if (num[i] == 0) continue;
            //        u = num[i] % 10;              // ones
            //        t = num[i] / 10;
            //        h = num[i] / 100;             // hundreds
            //        t = t - 10 * h;               // tens
            //        if (h > 0) sb.Append(words0[h] + "Ratus ");
            //        if (u > 0 || t > 0)
            //        {
            //            if (h > 0 || i < first) sb.Append(and);
            //            if (t == 0)
            //                sb.Append(words0[u]);
            //            else if (t == 1)
            //                sb.Append(words1[u]);
            //            else
            //                sb.Append(words2[t - 2] + words0[u]);
            //        }
            //        if (i != 0) sb.Append(words3[i - 1]);
            //    }
            //    return sb.ToString().TrimEnd();
            return "";
        }
        #endregion

        #region RFID

        private const byte lengthError = 0x01;
        private const byte operationNotSupport = 0x02;
        private const byte dataRangError = 0x03;
        private const byte cmdNotOperation = 0x04;
        private const byte rfClosed = 0x05;
        private const byte EEPROM = 0x06;
        private const byte timeOut = 0x0a;
        private const byte moreUID = 0x0b;
        private const byte ISOError = 0x0c;
        private const byte noElectronicTag = 0x0e;
        private const byte operationError = 0x0f;
        private const byte cmdNotSupport = 0x01;
        private const byte cmdNotIdentify = 0x02;
        private const byte errOperationNotSupport = 0x03;
        private const byte unknownError = 0x0f;
        private const byte blockError = 0x10;
        private const byte blockLockedCntLock = 0x11;
        private const byte blockLockedCntWrite = 0x12;
        private const byte blockCntOperate = 0x13;
        private const byte blockCntLock = 0x14;
        private const byte communicationErr = 0x30;
        private const byte retCRCErr = 0x31;
        private const byte retDataErr = 0x32;
        private const byte communicationBusy = 0x33;
        private const byte executeCmdBusy = 0x34;
        private const byte comPortOpened = 0x35;
        private const byte comPortClose = 0x36;
        private const byte invalidHandle = 0x37;
        private const byte invalidPort = 0x38;
        private const byte OK = 0x00;

        public static byte[] HexStringToByteArray(string s)
        {
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
                buffer[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            return buffer;
        }
        public static string ByteArrayToHexString(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 3);
            foreach (byte b in data)
                sb.Append(Convert.ToString(b, 16).PadLeft(2, '0').PadRight(3, ' '));
            return sb.ToString().ToUpper();
        }

        public static string HF9000GetReturnCodeDesc(int cmdRet)
        {
            switch (cmdRet)
            {
                case lengthError:
                    return "Command operand length error";
                case operationNotSupport:
                    return "Command not supported";
                case dataRangError:
                    return "Operation data range error";
                case rfClosed:
                    return "RF field is inactive";
                case EEPROM:
                    return "EEPROM operation error";
                case timeOut:
                    return "Inventory-Scan-Time overflow";
                case moreUID:
                    return "Not all tag's UID are collected before the Inventory-Scan-Time overflow";
                case ISOError:
                    return "ISO error";
                case noElectronicTag:
                    return "No Tags";
                case operationError:
                    return "Operation error";
                case communicationErr:
                    return "Communication Error";
                case retCRCErr:
                    return "CRC checksummat Error";
                case communicationBusy:
                    return "Communication busy";
                case cmdNotOperation:
                    return "CMD can't execute at current";
                case comPortOpened:
                    return "Port Opend";
                case comPortClose:
                    return "Port Already Closed";
                case invalidHandle:
                    return "Invalid PortHandle";
                case invalidPort:
                    return "Invalid ComPort ";
                case OK:
                    return "successfully";
                default:
                    return "";
            }
        }

        public static string HF9000GetErrorCodeDesc(byte errorCode)
        {
            switch (errorCode)
            {
                case cmdNotSupport:
                    return "Commands  not supported ";
                case cmdNotIdentify:
                    return "Unknown Command ";
                case errOperationNotSupport:
                    return "Operation not supported ";
                case unknownError:
                    return "Unknown error ";
                case blockError:
                    return "Appointed  block can't be used or does not exist ";
                case blockLockedCntLock:
                case blockLockedCntWrite:
                    return "Appointed  block is locked";
                case blockCntOperate:
                    return "Appointed  block can't be operated normally";
                case blockCntLock:
                    return "Appointed  block can't be locked normally";
                default:
                    return "";
            }
        }

        #endregion


        #region FTP
        public static string strFTP_host = "";
        public static string strFTP_user = "";
        public static string strFTP_passwd = "";
        public static string strFTP_photopath = "";
        public static string strHttp = "";
        public static string strHttp_photopath = "";

        public static string strftppdfpath = "";
        public static string strhttppdfpath = "";

        public static string strftpcoverpath = "";
        public static string strhttpcoverpath = "";
        public static void setFTP()
        {
            //clsEncryption oEncrypt = new clsEncryption();
            clsConnection oconn = new clsConnection();
            oconn.Open();
            string strSql = @"select (select configvalue from tbm_config where dlt='0' and configname='hostname' limit 1) as hostname,
                            (select configvalue from tbm_config where dlt='0' and configname='hostuser' limit 1) as hostuser,
                            (select configvalue from tbm_config where dlt='0' and configname='hostpassword' limit 1) as hostpassword,
                            (select configvalue from tbm_config where dlt='0' and configname='ftpphotopath' limit 1) as ftpphotopath,
                            (select configvalue from tbm_config where dlt='0' and configname='http' limit 1) as http,
                            (select configvalue from tbm_config where dlt='0' and configname='httpphotopath' limit 1) as httpphotopath,
                            (select configvalue from tbm_config where dlt='0' and configname='ftppdfpath' limit 1) as ftppdfpath,
                            (select configvalue from tbm_config where dlt='0' and configname='httppdfpath' limit 1) as httppdfpath,
                            (select configvalue from tbm_config where dlt='0' and configname='ftpcoverpath' limit 1) as ftpcoverpath,
                            (select configvalue from tbm_config where dlt='0' and configname='httpcoverpath' limit 1) as httpcoverpath";
           
            DataTable dt = oconn.GetData(strSql);
            if (dt.Rows.Count > 0)
            {
                clsGlobal.strFTP_host = dt.Rows[0][0].ToString();
                clsGlobal.strFTP_user = dt.Rows[0][1].ToString();
                clsGlobal.strFTP_passwd = dt.Rows[0][2].ToString();
                clsGlobal.strFTP_photopath = dt.Rows[0][3].ToString();
                clsGlobal.strHttp = dt.Rows[0][4].ToString();
                clsGlobal.strHttp_photopath = dt.Rows[0][5].ToString();
                clsGlobal.strftppdfpath = dt.Rows[0][6].ToString();
                clsGlobal.strhttppdfpath = dt.Rows[0][7].ToString();
                clsGlobal.strftpcoverpath = dt.Rows[0][8].ToString();
                clsGlobal.strhttpcoverpath = dt.Rows[0][9].ToString();
            }

            
            oconn.Close();
            oconn = null; //oEncrypt = null;
        }

        public static bool isFtpDirectoryExists(string uriftpServer, string directory, string username, string password)
        {
            bool bolResult = true;
            if (uriftpServer == directory)return false;

            if (uriftpServer.LastIndexOf('/')+1 != uriftpServer.Length)
            {
                uriftpServer = uriftpServer + "/";
            }
            string sUriFolder = directory.Substring(uriftpServer.Length + 1, (directory.Length) - uriftpServer.Length - 1);
            string[] arrUriFolder = sUriFolder.Split(Path.AltDirectorySeparatorChar);
            List<string> folderlist = new List<string>(arrUriFolder);
            folderlist.Insert(0, uriftpServer);

            foreach (string foldername in folderlist)
            {
                try
                {
                    if (string.IsNullOrEmpty(foldername.Trim())) continue;
                    if (foldername != uriftpServer)
                        uriftpServer += "/" + foldername + "/";
                    else
                        uriftpServer += "/";
                    var request = (System.Net.FtpWebRequest)System.Net.WebRequest.Create(uriftpServer);
                    request.Credentials = new System.Net.NetworkCredential(username, password);
                    request.Method = System.Net.WebRequestMethods.Ftp.ListDirectory;
                    request.KeepAlive = false;
                    System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)request.GetResponse();
                    response.Close();
                }
                catch (System.Net.WebException ex)
                {
                    System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)ex.Response;
                    if (response.StatusCode == System.Net.FtpStatusCode.ActionNotTakenFileUnavailable)
                    {
                        response.Close();
                        bolResult = false;
                    }
                    else
                    {
                        response.Close();
                        bolResult = true;
                    }
                }
                catch (Exception ex)
                {

                }
                if (bolResult == false)
                {
                    try
                    {
                        System.Net.FtpWebRequest request = (System.Net.FtpWebRequest)System.Net.WebRequest.Create(uriftpServer);
                        request.Method = System.Net.WebRequestMethods.Ftp.MakeDirectory;
                        request.Credentials = new System.Net.NetworkCredential(username, password);
                        request.KeepAlive = false;
                        System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)request.GetResponse();

                        response.Close();
                    }
                    catch (System.Net.WebException ex)
                    {
                    }
                }

            }
            return bolResult;
        }

        public static void deleteFtpFile(string ftpfile, string username, string password)
        {
            try
            {
                System.Net.WebRequest request = System.Net.WebRequest.Create(ftpfile);
                request.Method = System.Net.WebRequestMethods.Ftp.DeleteFile;
                request.Credentials = new System.Net.NetworkCredential(username, password);
                System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)request.GetResponse();
                response.Close();
            }
            catch { }
        }

        private static bool isFtpFileExists(string ftpFile, string username, string password, bool boldlgactionreplace)
        {
            bool bolResult = true;
            try
            {
                var request = (System.Net.FtpWebRequest)System.Net.WebRequest.Create(ftpFile);
                request.Credentials = new System.Net.NetworkCredential(username, password);
                request.Method = System.Net.WebRequestMethods.Ftp.GetFileSize;
                request.KeepAlive = false;
                request.UseBinary = true;
                System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)request.GetResponse();
                response.Close();
            }
            catch (System.Net.WebException ex)
            {
                System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)ex.Response;
                if (response.StatusCode == System.Net.FtpStatusCode.ActionNotTakenFileUnavailable)
                {
                    response.Close();
                    bolResult = false;
                }
                else
                {
                    response.Close();
                    bolResult = true;
                }
            }
            catch (Exception ex)
            {

            }
            if (bolResult && boldlgactionreplace)
            {
                try
                {
                    deleteFtpFile(ftpFile, username, password);
                    bolResult = false;
                }
                catch
                {
                    bolResult = true;
                }

            }
            return bolResult;
        }
        public static void Upload(string strHost, string strUser, string strPasswd, string strPath, string fileUpload, string strRenamefile)
        {
            FileInfo fileInf = new FileInfo(fileUpload);
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create((new Uri("ftp://" + strHost + "/" + strPath + "/" + strRenamefile)));

            reqFTP.Credentials = new NetworkCredential(strUser, strPasswd);
            reqFTP.KeepAlive = false;
            reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
            reqFTP.UseBinary = true;
            reqFTP.ContentLength = fileInf.Length;
            int buffLength = 2048;
            byte[] buff = new byte[buffLength];
            int contentLen;
            FileStream fs = fileInf.OpenRead();

            try
            {
                Stream strm = reqFTP.GetRequestStream();
                contentLen = fs.Read(buff, 0, buffLength);
                while (contentLen != 0)
                {
                    strm.Write(buff, 0, contentLen);
                    contentLen = fs.Read(buff, 0, buffLength);
                }
                strm.Close();
                fs.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Upload Error");
            }
        }

        public static bool Upload(string strftpServer, string strftpUserID, string strftpPassword,
               ref string sourceFullFilename, string strFilename, string folder, bool boldlgactionreplace, ref string strMessage)
        {
            bool bolResult = true;
            try
            {
                if (strftpServer.LastIndexOf('/') + 1 != strftpServer.Length)
                    strftpServer = (strftpServer.Contains("ftp://") ? "" : "ftp://") + strftpServer + "/";
                else
                    strftpServer = (strftpServer.Contains("ftp://") ? "" : "ftp://") + strftpServer;

                if (!string.IsNullOrEmpty(strftpServer))
                    strftpServer = strftpServer.Replace("////", "/").Replace("///", "/");
                FileInfo fileInf = new FileInfo(sourceFullFilename);
                string uriFolder = strftpServer + (folder == "" ? "" : "/" + folder);
                var newUriFolder = uriFolder;
                if (!string.IsNullOrEmpty(uriFolder))
                    newUriFolder = uriFolder.Replace("////", "/").Replace("///", "/");
                isFtpDirectoryExists(strftpServer, newUriFolder, strftpUserID, strftpPassword);

                int intExtraFilename = 0;
                string strExtraFileName = "_";
            step1:

                string uriFile = strftpServer + "/" + folder + "/" + strFilename;
                var newUriFile = uriFile;
                if (!string.IsNullOrEmpty(uriFile))
                    newUriFile = uriFile.Replace("////", "/").Replace("///", "/");

                //if (isFtpFileExists(newUriFile, strftpUserID, strftpPassword, boldlgactionreplace))
                //{
                if (isFtpFileExists_new(strftpServer, strftpUserID, strftpPassword, folder, strFilename) && boldlgactionreplace == false)
                {
                    strMessage = "file exists";

                    intExtraFilename++;
                    string strNewFilename = strFilename;
                    if (intExtraFilename != 0)
                    {
                        string[] arrFilename = new string[2];
                        arrFilename[0] = Path.GetFileNameWithoutExtension(strFilename);
                        arrFilename[1] = Path.GetExtension(strFilename);

                        if (arrFilename.Length > 0)
                        {
                            strNewFilename = arrFilename[0] + strExtraFileName + Convert.ToString(intExtraFilename) + arrFilename[1];
                        }
                        else
                        {
                            strNewFilename += strExtraFileName + Convert.ToString(intExtraFilename);
                        }

                    }

                    DialogResult dlgResult = MessageBox.Show("There is already a file with the same name in server.\nClick [Yes] to replace file in destination folder, or\nclick [No] to keep both files and the file you are uploading will be renamed to : " + strNewFilename + ", otherwise\nClick [Cancel] to leave this file in destination folder", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (dlgResult == DialogResult.Yes)
                    {
                        try
                        {
                            deleteFtpFile(newUriFile, strftpUserID, strftpPassword);
                        }
                        catch
                        {
                        }
                    }
                    else if (dlgResult == DialogResult.No)
                    {
                        strFilename = strNewFilename;
                        goto step1;

                    }
                    else
                    {
                        strMessage = "cancel";
                        return false;
                        //MessageBox.Show("Fail to upload.." + strMessage, clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    //return false;
                }
                sourceFullFilename = newUriFile;

                System.Net.FtpWebRequest reqFTP;

                reqFTP = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(new Uri(newUriFile));

                reqFTP.Credentials = new System.Net.NetworkCredential(strftpUserID, strftpPassword);
                reqFTP.KeepAlive = false;
                reqFTP.Method = System.Net.WebRequestMethods.Ftp.UploadFile;
                reqFTP.UseBinary = true;
                reqFTP.ContentLength = fileInf.Length;

                int buffLength = 2048;
                byte[] buff = new byte[buffLength];
                int contentLen;
                FileStream fs = fileInf.OpenRead();

                Stream strm = reqFTP.GetRequestStream();
                contentLen = fs.Read(buff, 0, buffLength);
                while (contentLen != 0)
                {
                    strm.Write(buff, 0, contentLen);
                    contentLen = fs.Read(buff, 0, buffLength);
                }
                strm.Close();
                fs.Close();

            }
            catch (Exception ex)
            {
                strMessage = ex.Message;
                //MessageBox.Show(ex.Message, "Upload Error");
                clsGlobal.generateErrMessageAndSendmail(ex, false);
                bolResult = false;
            }
            finally
            {

            }
            return bolResult;
        }

        public static bool Download(string strftpServer, string strftpUserID, string strftpPassword,
            string filePath, string fileName, ref string strMessage)
        {
            bool bolResult = true;
            System.Net.FtpWebRequest reqFTP;
            try
            {
                FileStream outputStream = new FileStream(filePath, FileMode.Create);

                reqFTP = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(new Uri(fileName));
                reqFTP.Method = System.Net.WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new System.Net.NetworkCredential(strftpUserID, strftpPassword);
                System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                long cl = response.ContentLength;
                int bufferSize = 2048;
                int readCount;
                byte[] buffer = new byte[bufferSize];

                readCount = ftpStream.Read(buffer, 0, bufferSize);
                while (readCount > 0)
                {
                    outputStream.Write(buffer, 0, readCount);
                    readCount = ftpStream.Read(buffer, 0, bufferSize);
                }

                ftpStream.Close();
                outputStream.Close();
                response.Close();
                bolResult = true;
            }
            catch (Exception ex)
            {
                strMessage = ex.Message;
                //MessageBox.Show(ex.Message, "Upload Error");
                clsGlobal.generateErrMessageAndSendmail(ex, true);
                bolResult = false;
            }
            return bolResult;
        }

        public static bool Download(string strftpServer, string strftpUserID, string strftpPassword,
            string filePathSave, string fileName, string folder, ref string strMessage)
        {
            bool bolResult = true;
            System.Net.FtpWebRequest reqFTP;
            try
            {
                FileStream outputStream = new FileStream(filePathSave, FileMode.Create);

                string uriFile = (strftpServer.Contains("ftp://") ? "" : "ftp://") + strftpServer  + "/" + folder + "/" + fileName;
                var newUriFile = uriFile;
                if (!string.IsNullOrEmpty(uriFile))
                    newUriFile = uriFile.Replace("////", "/").Replace("///", "/");

                reqFTP = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(new Uri(newUriFile));
                reqFTP.Method = System.Net.WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new System.Net.NetworkCredential(strftpUserID, strftpPassword);
                System.Net.FtpWebResponse response = (System.Net.FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                long cl = response.ContentLength;
                int bufferSize = 2048;
                int readCount;
                byte[] buffer = new byte[bufferSize];

                readCount = ftpStream.Read(buffer, 0, bufferSize);
                while (readCount > 0)
                {
                    outputStream.Write(buffer, 0, readCount);
                    readCount = ftpStream.Read(buffer, 0, bufferSize);
                }

                ftpStream.Close();
                outputStream.Close();
                response.Close();
                bolResult = true;
            }
            catch (Exception ex)
            {
                strMessage = ex.Message;
                //MessageBox.Show(ex.Message, "Upload Error");
                clsGlobal.generateErrMessageAndSendmail(ex, true);
                bolResult = false;
            }
            return bolResult;
        }

        public static string[] GetFileList(string strftpServer, string strftpUserID, string strftpPassword, string folder)
        {
            string[] downloadFiles;
            StringBuilder result = new StringBuilder();
            WebResponse response = null;
            StreamReader reader = null;
            try
            {
                FtpWebRequest reqFTP;
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(strftpServer + "/" + folder + "/"));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(strftpUserID, strftpPassword);
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
                reqFTP.Proxy = null;
                reqFTP.KeepAlive = false;
                reqFTP.UsePassive = true;
                response = reqFTP.GetResponse();
                reader = new StreamReader(response.GetResponseStream());
                string line = reader.ReadLine();
                while (line != null)
                {
                    result.Append(line);
                    result.Append("\n");
                    line = reader.ReadLine();
                }

                if (reader != null)
                {
                    reader.Close();
                }
                if (response != null)
                {
                    response.Close();
                }

                // to remove the trailing '\n'
                if (result == null || result.Length == 0)
                {
                    return null;
                }
                else
                {
                    result.Remove(result.ToString().LastIndexOf('\n'), 1);
                    return result.ToString().Split('\n');
                }
            }
            catch (Exception ex)
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
                downloadFiles = null;
                return downloadFiles;
            }
        }

        public static bool isFtpFileExists_new(string strftpServer, string strftpUserID, string strftpPassword, string folder, string strFileNameCheck)
        {
            string[] strFileList = GetFileList(strftpServer, strftpUserID, strftpPassword, folder);
            bool isExist = false;
            if (strFileList != null)
            {
                foreach (string file in strFileList)
                {
                    if (file.ToLower() == strFileNameCheck.ToLower())
                    {
                        isExist = true; break;
                    }
                }
            }
            return isExist;
        }

        #endregion


        public static bool isFileOpened(string fullfilename)
        {
            bool opened = false;
            try
            {

                FileStream fs = new FileStream(fullfilename, FileMode.Open, FileAccess.Write,
                FileShare.None);
                fs.Close();
                opened = false;
            }
            catch (FileNotFoundException ex)
            {
                //what to do now?
                opened = false;
            }
            catch (UnauthorizedAccessException e)
            {
                opened = true;
            }
            catch (IOException ioex)
            {
                opened = true;
            }
            return opened;
        }

    }
}
