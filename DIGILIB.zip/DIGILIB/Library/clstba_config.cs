﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Npgsql;
using System.Windows.Forms;
using System.Data;

namespace Library
{
    public class clstba_config
    {
        private String m_configid;
        private String m_configname;
        private String m_configdesc;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private String m_configvalue;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String configid
        {
            get { return m_configid; }
            set { m_configid = value; }
        }
        public String configname
        {
            get { return m_configname; }
            set { m_configname = value; }
        }
        public String configdesc
        {
            get { return m_configdesc; }
            set { m_configdesc = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public String configvalue
        {
            get { return m_configvalue; }
            set { m_configvalue = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tba_config(configid,configname,configdesc,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt,configvalue)"+
                            "VALUES"+
                            "(@configid,@configname,@configdesc,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0',@configvalue)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (configid != null )
            {
               cmd.Parameters.Add("@configid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configid;
            }
            else
            {
               cmd.Parameters.Add("@configid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (configname != null )
            {
               cmd.Parameters.Add("@configname", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configname;
            }
            else
            {
               cmd.Parameters.Add("@configname", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (configdesc != null )
            {
               cmd.Parameters.Add("@configdesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configdesc;
            }
            else
            {
               cmd.Parameters.Add("@configdesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (configvalue != null )
            {
               cmd.Parameters.Add("@configvalue", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configvalue;
            }
            else
            {
               cmd.Parameters.Add("@configvalue", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tba_config SET "+
                            " configid=@configid,configname=@configname,configdesc=@configdesc,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0',configvalue=@configvalue"+
                            " WHERE configid=@configid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (configid != null )
            {
               cmd.Parameters.Add("@configid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configid;
            }
            else
            {
               cmd.Parameters.Add("@configid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (configname != null )
            {
               cmd.Parameters.Add("@configname", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configname;
            }
            else
            {
               cmd.Parameters.Add("@configname", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (configdesc != null )
            {
               cmd.Parameters.Add("@configdesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configdesc;
            }
            else
            {
               cmd.Parameters.Add("@configdesc", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null && lu_add != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null && lu_edit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            if (configvalue != null )
            {
               cmd.Parameters.Add("@configvalue", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configvalue;
            }
            else
            {
               cmd.Parameters.Add("@configvalue", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tba_config WHERE configid=@configid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@configid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tba_config SET DLT=true WHERE configid=@configid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@configid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = configid;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tba_config WHERE configid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("configid"))) 
            {
              m_configid = rdr.GetString(rdr.GetOrdinal("configid"));
            }
            else
            {
              m_configid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("configname"))) 
            {
              m_configname = rdr.GetString(rdr.GetOrdinal("configname"));
            }
            else
            {
              m_configname = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("configdesc"))) 
            {
              m_configdesc = rdr.GetString(rdr.GetOrdinal("configdesc"));
            }
            else
            {
              m_configdesc = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
            if (!rdr.IsDBNull(rdr.GetOrdinal("configvalue"))) 
            {
              m_configvalue = rdr.GetString(rdr.GetOrdinal("configvalue"));
            }
            else
            {
              m_configvalue = "";
            };
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tba_config");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tba_config");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tba_config";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tba_config");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tba_config");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tba_config_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
