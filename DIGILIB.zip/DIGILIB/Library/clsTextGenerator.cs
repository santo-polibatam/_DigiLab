﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Library
{
    public class clsTextGenerator
    {
        public void AppendTLog(string sMessage)
        {
            try
            {
                string sDirectoryPath = System.Windows.Forms.Application.StartupPath.ToString() + "\\" + DateTime.Now.ToString("yyyy");
                string sFilePath;
                
                //sDirectoryPath = oSetting.GetTLogPath & sTableName & " TLog - " & Format(Now, "MMM") & " " & Format(Now, "yyyy")


                if (!Directory.Exists(sDirectoryPath))
                {
                    Directory.CreateDirectory(sDirectoryPath);
                }

                //the directory exists
                string sCurrentDate="";
                sCurrentDate = DateTime.Now.ToString("dd MMM yyyy");

                sFilePath = sCurrentDate + " - " + clsGlobal.strComputerName();
                sFilePath = sDirectoryPath + "\\" + sFilePath + ".txt";

                if (!File.Exists(sFilePath))
                {
                    StreamWriter oCreator = File.CreateText(sFilePath);
                    oCreator.Close();
                }

                StreamWriter oWriter = File.AppendText(sFilePath);
                oWriter.WriteLine(sMessage);
                oWriter.Close();
            }
            catch (Exception ex)
            {
                sMessage = ("======================================================================================\n" +
                    "Error occured at '" + ex.Source + "' on " + DateTime.Now.ToString() + " - " + DateTime.Now.ToString() + ":\n" +
                    ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                    "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");
                AppendTLog( sMessage);
            }
        }

        public void generateErrMsg(Exception ex)
        {
            string sMessage = ("======================================================================================\n" +
                        "Error occured at //" + ex.Source + "// on " + DateTime.Now.ToString() + " - " + DateTime.Now.ToString() + ":\n" +
                        ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                        "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");
        }


    }
}
