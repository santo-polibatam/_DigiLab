﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace Library
{
    public class clsC3100
    {
        [DllImport("plcommpro.dll", EntryPoint = "Connect")]
        public static extern IntPtr Connect(string Parameters);
        [DllImport("plcommpro.dll", EntryPoint = "PullLastError")]
        public static extern int PullLastError();

        [DllImport("plcommpro.dll", EntryPoint = "Disconnect")]
        public static extern void Disconnect(IntPtr h);

        [DllImport("plcommpro.dll", EntryPoint = "GetDeviceData")]
        public static extern int GetDeviceData(IntPtr h, ref byte buffer, int buffersize, string tablename, string fieldname, string filter, string options);

        [DllImport("plcommpro.dll", EntryPoint = "GetDeviceDataCount")]
        public static extern int GetDeviceDataCount(IntPtr h, string tablename, string filter, string options);


        [DllImport("plcommpro.dll", EntryPoint = "SetDeviceData")]
        public static extern int SetDeviceData(IntPtr h, string tablename, string data, string options);

        [DllImport("plcommpro.dll", EntryPoint = "DeleteDeviceData")]
        public static extern int DeleteDeviceData(IntPtr h, string tablename, string data, string options);

        public static DataTable strGateUsertoDatatable(string strData)
        {
            string[] strDataArr = Regex.Split(strData.Replace("\0", ""), "\r\n");
            DataTable dtDataGate = new DataTable();
            dtDataGate.Columns.Add("cardno", typeof(string));
            dtDataGate.Columns.Add("pin", typeof(string));
            foreach (string strVal in strDataArr)
            {
                if (!string.IsNullOrEmpty(strVal))
                {
                    string[] strValArr = strVal.Split(',');
                    if (strValArr.Length > 0)
                    {
                        if (strValArr[0] == "CardNo")
                        {
                            continue;
                        }
                        else
                        {
                            DataRow dr = dtDataGate.NewRow();
                            dr["cardno"] = strValArr[0];
                            dr["pin"] = strValArr[1];
                            dtDataGate.Rows.Add(dr);
                        }
                    }

                }
            }
            return dtDataGate;
        }

        public static DataTable strGateTrxtoDatatable(string strData)
        {
            string[] strDataArr = Regex.Split(strData.Replace("\0", ""), "\r\n");
            DataTable dtDataGate = new DataTable();
            dtDataGate.Columns.Add("cardno", typeof(string));
            dtDataGate.Columns.Add("rfid", typeof(string));
            dtDataGate.Columns.Add("pin", typeof(string));
            dtDataGate.Columns.Add("verified", typeof(string));
            dtDataGate.Columns.Add("doorid", typeof(string));
            dtDataGate.Columns.Add("eventtype", typeof(string));
            dtDataGate.Columns.Add("inoutstate", typeof(string));
            dtDataGate.Columns.Add("timesecond", typeof(string));
            dtDataGate.Columns.Add("timesecond2", typeof(string));
            foreach (string strVal in strDataArr)
            {
                if (!string.IsNullOrEmpty(strVal))
                {
                    string[] strValArr = strVal.Split(',');
                    if (strValArr.Length > 0)
                    {
                        if (strValArr[0].ToLower() == "cardno")
                        {
                            continue;
                        }
                        else
                        {
                            if (strValArr[0].ToLower() == "" || strValArr[0].ToLower() == "0")
                            {
                                continue;
                            }
                            if (strValArr[0] == "6122756") 
                            { }
                            DataRow dr = dtDataGate.NewRow();
                            dr["cardno"] = strValArr[0];
                            dr["rfid"] = GetDecWiegandtoHexACS(strValArr[0]);
                            dr["pin"] = strValArr[1];
                            dr["verified"] = strValArr[2];
                            dr["doorid"] = strValArr[3];
                            dr["eventtype"] = strValArr[4];
                            dr["inoutstate"] = strValArr[5];
                            dr["timesecond"] = strValArr[6];
                            decimal decOut = clsGlobal.GetParseDecimal(strValArr[6]);
                            if (decOut > 0)
                            {
                                dr["timesecond2"] = clsGlobal.UnixTimestampToDateTime(decOut);
                            }
                            dtDataGate.Rows.Add(dr);
                        }
                    }

                }
            }
            return dtDataGate;
        }

        public static string GethexACStoDecWiegand(string strHex)
        {
            string strReturn = "";
            if (!string.IsNullOrEmpty(strHex))
            {
                string strBinACS = String.Join(String.Empty, strHex.Select(c => Convert.ToString(Convert.ToUInt32(c.ToString(), 16), 2).PadLeft(4, '0')));
                char[] chrBinACSArr = strBinACS.ToCharArray();
                if (chrBinACSArr.Length > 30)
                {
                    char[] chrBinWiegand = new char[24];

                    int idx = 0;
                    for (int i = 16; i < 24; i++)
                    {
                        chrBinWiegand[idx] = chrBinACSArr[i];
                        idx++;
                    }

                    idx = 8;
                    for (int i = 8; i < 16; i++)
                    {
                        chrBinWiegand[idx] = chrBinACSArr[i];
                        idx++;
                    }

                    idx = 16;
                    for (int i = 0; i < 8; i++)
                    {
                        chrBinWiegand[idx] = chrBinACSArr[i];
                        idx++;
                    }

                    string strBinWiegand = new string(chrBinWiegand);
                    strReturn = Convert.ToInt32(strBinWiegand, 2).ToString();
                }
            }
            return strReturn;
        }

        public static string GetDecWiegandtoHexACS(string strDec)
        {
            string strReturn = "";
            if (!string.IsNullOrEmpty(strDec))
            {
                string strBinWiegand = DecimalToBinary(strDec); //String.Join(String.Empty, strDec.Select(c => Convert.ToString(Convert.ToUInt32(c.ToString(), 8), 2).PadLeft(4, '0')));
                if (strBinWiegand.Length < 24 && strBinWiegand.Length >= 16)
                {
                    switch (strBinWiegand.Length)
                    {
                        case 16: strBinWiegand = "00000000" + strBinWiegand; break;
                        case 17: strBinWiegand = "0000000" + strBinWiegand; break;
                        case 18: strBinWiegand = "000000" + strBinWiegand; break;
                        case 19: strBinWiegand = "00000" + strBinWiegand; break;
                        case 20: strBinWiegand = "0000" + strBinWiegand; break;
                        case 21: strBinWiegand = "000" + strBinWiegand; break;
                        case 22: strBinWiegand = "00" + strBinWiegand; break;
                        case 23: strBinWiegand = "0" + strBinWiegand; break;
                    }
                }
                char[] chrBinWiegandArr = strBinWiegand.ToCharArray();
                if (chrBinWiegandArr.Length > 20)
                {

                    char[] chrBinACS = new char[24];

                    int idx = 0;
                    for (int i = 16; i < 24; i++)
                    {
                        chrBinACS[idx] = chrBinWiegandArr[i];
                        idx++;
                    }

                    idx = 8;
                    for (int i = 8; i < 16; i++)
                    {
                        chrBinACS[idx] = chrBinWiegandArr[i];
                        idx++;
                    }

                    idx = 16;
                    for (int i = 0; i < 8; i++)
                    {
                        chrBinACS[idx] = chrBinWiegandArr[i];
                        idx++;
                    }

                    string strBinACS = new string(chrBinACS);
                    strReturn = Convert.ToInt32(strBinACS, 2).ToString("X");
                    if (strReturn.Length >= 4 && strReturn.Length < 6)
                    {
                        if (strReturn.Length == 4) { strReturn = "00" + strReturn; }
                        else if (strReturn.Length == 5) { strReturn = "0" + strReturn; }
                    }
                }
            }
            return strReturn;
        }


        public static string DecimalToBinary(string data)
        {
            string result = string.Empty;
            int rem = 0;
            try
            {
                int num = int.Parse(data);
                while (num > 0)
                {
                    rem = num % 2;
                    num = num / 2;
                    result = rem.ToString() + result;
                }
            }
            catch (Exception ex)
            {
                //error = ex.Message;
            }
            return result;
        }
    }
}
