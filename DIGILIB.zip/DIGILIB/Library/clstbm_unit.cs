﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Npgsql;
using System.Windows.Forms;
using System.Data;

namespace Library
{
    public class clstbm_unit
    {
        private String m_unitid;
        private String m_unitkode;
        private String m_unitnama;
        private String m_ket;
        private String m_tahun;
        private String m_op_add;
        private String m_pc_add;
        private DateTime m_lu_add;
        private String m_op_edit;
        private String m_pc_edit;
        private DateTime m_lu_edit;
        private bool m_dlt;
        private NpgsqlConnection m_Koneksi;
        public String unitid
        {
            get { return m_unitid; }
            set { m_unitid = value; }
        }
        public String unitkode
        {
            get { return m_unitkode; }
            set { m_unitkode = value; }
        }
        public String unitnama
        {
            get { return m_unitnama; }
            set { m_unitnama = value; }
        }
        public String ket
        {
            get { return m_ket; }
            set { m_ket = value; }
        }
        public String tahun
        {
            get { return m_tahun; }
            set { m_tahun = value; }
        }
        public String op_add
        {
            get { return m_op_add; }
            set { m_op_add = value; }
        }
        public String pc_add
        {
            get { return m_pc_add; }
            set { m_pc_add = value; }
        }
        public DateTime lu_add
        {
            get { return m_lu_add; }
            set { m_lu_add = value; }
        }
        public String op_edit
        {
            get { return m_op_edit; }
            set { m_op_edit = value; }
        }
        public String pc_edit
        {
            get { return m_pc_edit; }
            set { m_pc_edit = value; }
        }
        public DateTime lu_edit
        {
            get { return m_lu_edit; }
            set { m_lu_edit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_unit(unitid,unitkode,unitnama,ket,tahun,op_add,pc_add,lu_add,op_edit,pc_edit,lu_edit,dlt)"+
                            "VALUES"+
                            "(@unitid,@unitkode,@unitnama,@ket,@tahun,@op_add,@pc_add,now(),@op_edit,@pc_edit,@lu_edit,'0')";
            NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
            if (unitid != null )
            {
               cmd.Parameters.Add("@unitid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitid;
            }
            else
            {
               cmd.Parameters.Add("@unitid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (unitkode != null )
            {
               cmd.Parameters.Add("@unitkode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitkode;
            }
            else
            {
               cmd.Parameters.Add("@unitkode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (unitnama != null )
            {
               cmd.Parameters.Add("@unitnama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitnama;
            }
            else
            {
               cmd.Parameters.Add("@unitnama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ket != null )
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ket;
            }
            else
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahun != null )
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Kesalahan !!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_unit SET "+
                            " unitid=@unitid,unitkode=@unitkode,unitnama=@unitnama,ket=@ket,tahun=@tahun,op_add=@op_add,pc_add=@pc_add,lu_add=@lu_add,op_edit=@op_edit,pc_edit=@pc_edit,lu_edit=now(),dlt='0'"+
                            " WHERE unitid=@unitid";
            NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
            if (unitid != null )
            {
               cmd.Parameters.Add("@unitid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitid;
            }
            else
            {
               cmd.Parameters.Add("@unitid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (unitkode != null )
            {
               cmd.Parameters.Add("@unitkode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitkode;
            }
            else
            {
               cmd.Parameters.Add("@unitkode", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (unitnama != null )
            {
               cmd.Parameters.Add("@unitnama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitnama;
            }
            else
            {
               cmd.Parameters.Add("@unitnama", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ket != null )
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ket;
            }
            else
            {
               cmd.Parameters.Add("@ket", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tahun != null )
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = tahun;
            }
            else
            {
               cmd.Parameters.Add("@tahun", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (op_add != null )
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_add;
            }
            else
            {
               cmd.Parameters.Add("@op_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_add != null )
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_add;
            }
            else
            {
               cmd.Parameters.Add("@pc_add", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_add != null )
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_add;
            }
            else
            {
               cmd.Parameters.Add("@lu_add", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
            if (op_edit != null )
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = op_edit;
            }
            else
            {
               cmd.Parameters.Add("@op_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pc_edit != null )
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pc_edit;
            }
            else
            {
               cmd.Parameters.Add("@pc_edit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (lu_edit != null )
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = lu_edit;
            }
            else
            {
               cmd.Parameters.Add("@lu_edit", NpgsqlTypes.NpgsqlDbType.Date).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Ada Kesalahan!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbm_unit WHERE unitid=@unitid";
           NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@unitid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Kesalahan !!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
           string sQuery = " UPDATE tbm_unit SET DLT=true WHERE unitid=@unitid";
           NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@unitid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = unitid;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(NpgsqlException Ex)
            {
              MessageBox.Show(Ex.Message, "Kesalahan !!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbm_unit WHERE unitid='"+ pKey  +"'";
        NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("unitid"))) 
            {
              m_unitid = rdr.GetString(rdr.GetOrdinal("unitid"));
            }
            else
            {
              m_unitid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("unitkode"))) 
            {
              m_unitkode = rdr.GetString(rdr.GetOrdinal("unitkode"));
            }
            else
            {
              m_unitkode = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("unitnama"))) 
            {
              m_unitnama = rdr.GetString(rdr.GetOrdinal("unitnama"));
            }
            else
            {
              m_unitnama = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("ket"))) 
            {
              m_ket = rdr.GetString(rdr.GetOrdinal("ket"));
            }
            else
            {
              m_ket = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tahun"))) 
            {
              m_tahun = rdr.GetString(rdr.GetOrdinal("tahun"));
            }
            else
            {
              m_tahun = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_add"))) 
            {
              m_op_add = rdr.GetString(rdr.GetOrdinal("op_add"));
            }
            else
            {
              m_op_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_add"))) 
            {
              m_pc_add = rdr.GetString(rdr.GetOrdinal("pc_add"));
            }
            else
            {
              m_pc_add = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_add"))) 
            {
              m_lu_add = rdr.GetDateTime(rdr.GetOrdinal("lu_add"));
            }
            else
            {
              m_lu_add = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("op_edit"))) 
            {
              m_op_edit = rdr.GetString(rdr.GetOrdinal("op_edit"));
            }
            else
            {
              m_op_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pc_edit"))) 
            {
              m_pc_edit = rdr.GetString(rdr.GetOrdinal("pc_edit"));
            }
            else
            {
              m_pc_edit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("lu_edit"))) 
            {
              m_lu_edit = rdr.GetDateTime(rdr.GetOrdinal("lu_edit"));
            }
            else
            {
              m_lu_edit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
        }
          return true;
        }
        catch(NpgsqlException Ex)
        {
          MessageBox.Show(Ex.Message, "Kesalahan !!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public DataTable GetData(NpgsqlCommand cmd)
      {
         DataSet ds = new DataSet();
         DataTable dt = ds.Tables.Add("tbm_unit");
         cmd.Connection = Koneksi;
         NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_unit");
         return dt;
      }

      public DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbm_unit";
         }
         NpgsqlCommand cmd = new NpgsqlCommand(strSQL  , Koneksi); 
         DataSet ds = new DataSet();
         DataTable dt = ds.Tables.Add("tbm_unit");
         NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_unit");
         return dt;
      }

      public NpgsqlDataReader ReadData(NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public NpgsqlDataReader ReadData(string strSQL)
      {
         NpgsqlCommand cmd = new NpgsqlCommand(strSQL, Koneksi);
         NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public string NewID()
      {
          string i = "";
          string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbm_unit_nextid') as id";
          NpgsqlCommand cmd = new NpgsqlCommand(sQuery, Koneksi);
          cmd.CommandText = sQuery;
          try
          {
              NpgsqlDataReader rdr = cmd.ExecuteReader();
              if (rdr.Read())
              {
                  if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                  {
                      i = rdr.GetValue(0).ToString();
                  }
                  else
                  {
                      i = "";
                  };
              }
              rdr.Close();
          }
          catch (NpgsqlException Ex)
          {
              MessageBox.Show(Ex.Message, "Error !!!");
              return "";
          }
          return i;
      }

    }
}
