﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class tbm_inventaris
    {
        private String m_inventarisid;
        private String m_bukuid;
        private String m_pengadaandetailsid;
        private String m_rfid;
        private DateTime m_tglditerima;
        private String m_nib;
        private String m_status;
        private String m_ket_koleksi;
        private String m_kode_makul;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private decimal m_nourut;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String inventarisid
        {
            get { return m_inventarisid; }
            set { m_inventarisid = value; }
        }
        public String bukuid
        {
            get { return m_bukuid; }
            set { m_bukuid = value; }
        }
        public String pengadaandetailsid
        {
            get { return m_pengadaandetailsid; }
            set { m_pengadaandetailsid = value; }
        }
        public String rfid
        {
            get { return m_rfid; }
            set { m_rfid = value; }
        }
        public DateTime tglditerima
        {
            get { return m_tglditerima; }
            set { m_tglditerima = value; }
        }
        public String nib
        {
            get { return m_nib; }
            set { m_nib = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }
        public String ket_koleksi
        {
            get { return m_ket_koleksi; }
            set { m_ket_koleksi = value; }
        }
        public String kode_makul
        {
            get { return m_kode_makul; }
            set { m_kode_makul = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public decimal nourut
        {
            get { return m_nourut; }
            set { m_nourut = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi  ; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tbm_inventaris(inventarisid,bukuid,pengadaandetailsid,rfid,tglditerima,nib,status,ket_koleksi,kode_makul,opadd,pcadd,luadd,opedit,pcedit,luedit,dlt,nourut)" +
                            "VALUES"+
                            "(@inventarisid,@bukuid,@pengadaandetailsid,@rfid,@tglditerima,@nib,@status,@ket_koleksi,@kode_makul,@opadd,@pcadd,now(),@opedit,@pcedit,@luedit,'0',@nourut)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (inventarisid != null )
            {
               cmd.Parameters.Add("@inventarisid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inventarisid;
            }
            else
            {
               cmd.Parameters.Add("@inventarisid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (bukuid != null )
            {
               cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukuid;
            }
            else
            {
               cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengadaandetailsid != null )
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (rfid != null )
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = rfid;
            }
            else
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglditerima != null && tglditerima != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglditerima", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglditerima;
            }
            else
            {
               cmd.Parameters.Add("@tglditerima", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (nib != null )
            {
               cmd.Parameters.Add("@nib", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nib;
            }
            else
            {
               cmd.Parameters.Add("@nib", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ket_koleksi != null )
            {
               cmd.Parameters.Add("@ket_koleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ket_koleksi;
            }
            else
            {
               cmd.Parameters.Add("@ket_koleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kode_makul != null )
            {
               cmd.Parameters.Add("@kode_makul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kode_makul;
            }
            else
            {
               cmd.Parameters.Add("@kode_makul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tbm_inventaris SET "+
                            " inventarisid=@inventarisid,bukuid=@bukuid,pengadaandetailsid=@pengadaandetailsid,rfid=@rfid,tglditerima=@tglditerima,nib=@nib,status=@status,ket_koleksi=@ket_koleksi,kode_makul=@kode_makul,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt='0',nourut=@nourut" +
                            " WHERE inventarisid=@inventarisid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (inventarisid != null )
            {
               cmd.Parameters.Add("@inventarisid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inventarisid;
            }
            else
            {
               cmd.Parameters.Add("@inventarisid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (bukuid != null )
            {
               cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = bukuid;
            }
            else
            {
               cmd.Parameters.Add("@bukuid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pengadaandetailsid != null )
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pengadaandetailsid;
            }
            else
            {
               cmd.Parameters.Add("@pengadaandetailsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (rfid != null )
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = rfid;
            }
            else
            {
               cmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglditerima != null && tglditerima != DateTime.MinValue )
            {
               cmd.Parameters.Add("@tglditerima", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglditerima;
            }
            else
            {
               cmd.Parameters.Add("@tglditerima", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (nib != null )
            {
               cmd.Parameters.Add("@nib", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nib;
            }
            else
            {
               cmd.Parameters.Add("@nib", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (status != null )
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
               cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (ket_koleksi != null )
            {
               cmd.Parameters.Add("@ket_koleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = ket_koleksi;
            }
            else
            {
               cmd.Parameters.Add("@ket_koleksi", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (kode_makul != null )
            {
               cmd.Parameters.Add("@kode_makul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = kode_makul;
            }
            else
            {
               cmd.Parameters.Add("@kode_makul", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (opadd != null )
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
               cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null )
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
               cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
               cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null )
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
               cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null )
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
               cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue )
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
               cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
               cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
               cmd.Parameters.Add("@nourut", NpgsqlTypes.NpgsqlDbType.Numeric).Value = nourut;
            cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool Delete()
        {
           string sQuery = " DELETE FROM tbm_inventaris WHERE inventarisid=@inventarisid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@inventarisid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inventarisid;
           cmd.CommandText = sQuery;
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tbm_inventaris SET DLT='1', opedit=@opedit,pcedit=@pcedit,luedit=now() WHERE inventarisid=@inventarisid";
           Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
           cmd.CommandText = sQuery;
            cmd.Parameters.Add("@inventarisid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = inventarisid;
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            try
            {
              cmd.ExecuteNonQuery();
              return true;
            }
            catch(Npgsql.NpgsqlException Ex)
            {
              System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
              return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
        string sQuery = "select * from tbm_inventaris WHERE inventarisid='"+ pKey  +"'";
        Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi );
        cmd.CommandText = sQuery;
        Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
        try
        {
          if (rdr.Read()) 
          {
            if (!rdr.IsDBNull(rdr.GetOrdinal("inventarisid"))) 
            {
              m_inventarisid = rdr.GetString(rdr.GetOrdinal("inventarisid"));
            }
            else
            {
              m_inventarisid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("bukuid"))) 
            {
              m_bukuid = rdr.GetString(rdr.GetOrdinal("bukuid"));
            }
            else
            {
              m_bukuid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pengadaandetailsid"))) 
            {
              m_pengadaandetailsid = rdr.GetString(rdr.GetOrdinal("pengadaandetailsid"));
            }
            else
            {
              m_pengadaandetailsid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("rfid"))) 
            {
              m_rfid = rdr.GetString(rdr.GetOrdinal("rfid"));
            }
            else
            {
              m_rfid = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("tglditerima"))) 
            {
              m_tglditerima = rdr.GetDateTime(rdr.GetOrdinal("tglditerima"));
            }
            else
            {
              m_tglditerima = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("nib"))) 
            {
              m_nib = rdr.GetString(rdr.GetOrdinal("nib"));
            }
            else
            {
              m_nib = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("status"))) 
            {
              m_status = rdr.GetString(rdr.GetOrdinal("status"));
            }
            else
            {
              m_status = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("ket_koleksi"))) 
            {
              m_ket_koleksi = rdr.GetString(rdr.GetOrdinal("ket_koleksi"));
            }
            else
            {
              m_ket_koleksi = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("kode_makul"))) 
            {
              m_kode_makul = rdr.GetString(rdr.GetOrdinal("kode_makul"));
            }
            else
            {
              m_kode_makul = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opadd"))) 
            {
              m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
            }
            else
            {
              m_opadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd"))) 
            {
              m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
            }
            else
            {
              m_pcadd = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luadd"))) 
            {
              m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
            }
            else
            {
              m_luadd = System.DateTime.MinValue;
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("opedit"))) 
            {
              m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
            }
            else
            {
              m_opedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit"))) 
            {
              m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
            }
            else
            {
              m_pcedit = "";
            };
            if (!rdr.IsDBNull(rdr.GetOrdinal("luedit"))) 
            {
              m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
            }
            else
            {
              m_luedit = System.DateTime.MinValue;
            };
             m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
             m_nourut = rdr.GetDecimal(rdr.GetOrdinal("nourut"));
        }
          return true;
        }
        catch(Npgsql.NpgsqlException Ex)
        {
          System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
          return false;
        }
        finally
        { 
          if (rdr!= null)
          {
            rdr.Close(); 
          }
        }
       }

      public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
      {
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_inventaris");
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_inventaris");
         return dt;
      }

      public System.Data.DataTable GetData(string strSQL)
      {
         if (strSQL =="" )
         {   
            strSQL ="select * from tbm_inventaris";
         }
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL  , Koneksi); 
         System.Data.DataSet ds = new System.Data.DataSet();
         System.Data.DataTable dt = ds.Tables.Add("tbm_inventaris");
         Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
         da.Fill(ds, "tbm_inventaris");
         return dt;
      }

      public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
      {
         cmd.Connection = Koneksi;
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }

      public Npgsql.NpgsqlDataReader ReadData(string strSQL)
      {
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
         Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
         return dr;
      }
      public string  NewID()
      {
         string i="";
         string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tbm_inventaris_nextid') as id;";
         Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
         cmd.CommandText = sQuery;
         try
         {
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read()) 
            {
               if (!rdr.IsDBNull(rdr.GetOrdinal("id"))) 
               {
                  i = rdr.GetValue(0).ToString(); 
               }
               else
               {
                  i= "";
               };
            }
            rdr.Close();
         }
         catch (Npgsql.NpgsqlException Ex)
         {
            System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
            return "";
         }

         return i;
      }

    }
}
