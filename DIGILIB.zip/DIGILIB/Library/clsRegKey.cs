﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;

namespace Library
{
    public class clsRegKey
    {
        private string m_RegistryPathCurrenUser;

        public string RegistryPathCurrenUser
        {
            get { return m_RegistryPathCurrenUser; }
            set { m_RegistryPathCurrenUser = value; }
        }

        //Dapatkan Key value nya-nya
        public string getSetting(String strFile)
        {
            RegistryKey regkey = Registry.CurrentUser;
            regkey = regkey.CreateSubKey(RegistryPathCurrenUser);
            string strValue = "";
            strValue = regkey.GetValue("" + strFile + "", "").ToString();

            return strValue;
        }
        //Simpan Key value nya-nya
        public void SaveSetting(String strFile, String strValue)
        {
            RegistryKey regkey = Registry.CurrentUser;
            regkey = regkey.CreateSubKey(RegistryPathCurrenUser);
            regkey.SetValue(strFile, strValue);
        }
    }
}
