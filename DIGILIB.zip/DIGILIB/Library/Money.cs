﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class Money {
        static string[] _units = {
            String.Empty, "satu", "dua", "tiga", "empat",
            "lima", "enam", "tujuh", "delapan", "sembilan"
        };
 
        static string[] _thousands = {
            String.Empty, "ribu", "juta", "miliar", "triliun"
        };
 
        public decimal Amount { get; private set; }
        public string CurrencyText { get; set; }
        public string CentText { get; set; }
 
        public Money(decimal amount)
        {
            if (amount < 0m)
                throw new ArgumentOutOfRangeException();
 
            Amount = amount;
            CurrencyText = "rupiah";
            CentText = "sen";
        }
 
        public override string ToString()
        {
            List<string> textHolder = new List<string>();
            ProcessIntegerPartConvertionToString(textHolder);
            ProcessFractionPartConvertionToString(textHolder);
            return String.Join(" ", textHolder.Where(x => x != String.Empty));
        }
 
        private void ProcessIntegerPartConvertionToString(List<string> textHolder)
        {
            long integerPart = (long)Amount;
            if (integerPart == 0L) {
                textHolder.Add("nol");
            } else {
                int[] parts = SplitIntegerPart(integerPart).ToArray();
                for (int index = parts.Length - 1; index >= 0; index--) {
                    ConvertToText(textHolder, parts[index], _thousands[index % _thousands.Length]);
                }
            }
 
            textHolder.Add(CurrencyText);
        }
 
        private IEnumerable<int> SplitIntegerPart(long amount)
        {
            while (amount != 0L) {
                yield return (int)(amount % 1000L);
                amount /= 1000L;
            }
        }
 
        private void ProcessFractionPartConvertionToString(List<string> textHolder)
        {
            decimal fraction = Amount - Decimal.Truncate(Amount);
            if (fraction > 0m) {
                int cent = (int)(fraction * 100m);
                ConvertToText(textHolder, cent, CentText);
            }
        }
 
        private void ConvertToText(List<string> textHolder, int amount, string suffix)
        {
            // amount == 123, parts[2] = 1, parts[1] = 2, parts[0] = 3
            int[] parts = new int[3];
            int temp = amount;
            for (int index = 0; index < parts.Length; index++) {
                parts[index] = temp % 10;
                temp /= 10;
            }
 
            if (parts[2] == 1) {
                textHolder.Add("seratus");
            } else if (parts[2] != 0) {
                textHolder.Add(_units[parts[2]]);
                textHolder.Add("ratus");
            }
 
            if (parts[1] == 1) {
                switch (parts[0]) {
                    case 0: // cek angka 10
                        textHolder.Add("sepuluh");
                        break;
                    case 1: // cek angka 11
                        textHolder.Add("sebelas");
                        break;
                    default:
                        textHolder.Add(_units[parts[0]] + " belas");
                        break;
                }
 
                textHolder.Add(suffix);
                return;
            } else if (parts[1] != 0) {
                textHolder.Add(_units[parts[1]]);
                textHolder.Add("puluh");
            }
 
            bool isOneThousand = amount == 1 && suffix == "ribu";
            if (isOneThousand) {
                textHolder.Add("seribu");
            } else {
                textHolder.Add(_units[parts[0]]);
                textHolder.Add(suffix);
            }
        }
    }
}
