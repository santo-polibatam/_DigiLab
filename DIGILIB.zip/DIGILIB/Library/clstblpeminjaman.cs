﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library
{
    public class clstblpeminjaman
    {
        private String m_peminjamanid;
        private String m_anggotaid;
        private String m_petugasid;
        private String m_nopeminjaman;
        private DateTime m_tglpinjam;
        private DateTime m_tgljatuhtempo;
        private decimal m_lamapeminjaman;
        private decimal m_dendaperhari;
        private decimal m_maksbukudipinjam;
        private String m_status;
        private String m_keterangan;
        private decimal m_regno;
        private String m_opadd;
        private String m_pcadd;
        private DateTime m_luadd;
        private String m_opedit;
        private String m_pcedit;
        private DateTime m_luedit;
        private bool m_dlt;
        private Npgsql.NpgsqlConnection m_Koneksi;
        public String peminjamanid
        {
            get { return m_peminjamanid; }
            set { m_peminjamanid = value; }
        }
        public String anggotaid
        {
            get { return m_anggotaid; }
            set { m_anggotaid = value; }
        }
        public String petugasid
        {
            get { return m_petugasid; }
            set { m_petugasid = value; }
        }
        public String nopeminjaman
        {
            get { return m_nopeminjaman; }
            set { m_nopeminjaman = value; }
        }
        public DateTime tglpinjam
        {
            get { return m_tglpinjam; }
            set { m_tglpinjam = value; }
        }
        public DateTime tgljatuhtempo
        {
            get { return m_tgljatuhtempo; }
            set { m_tgljatuhtempo = value; }
        }
        public decimal lamapeminjaman
        {
            get { return m_lamapeminjaman; }
            set { m_lamapeminjaman = value; }
        }
        public decimal dendaperhari
        {
            get { return m_dendaperhari; }
            set { m_dendaperhari = value; }
        }
        public decimal maksbukudipinjam
        {
            get { return m_maksbukudipinjam; }
            set { m_maksbukudipinjam = value; }
        }
        public String status
        {
            get { return m_status; }
            set { m_status = value; }
        }
        public String keterangan
        {
            get { return m_keterangan; }
            set { m_keterangan = value; }
        }
        public decimal regno
        {
            get { return m_regno; }
            set { m_regno = value; }
        }
        public String opadd
        {
            get { return m_opadd; }
            set { m_opadd = value; }
        }
        public String pcadd
        {
            get { return m_pcadd; }
            set { m_pcadd = value; }
        }
        public DateTime luadd
        {
            get { return m_luadd; }
            set { m_luadd = value; }
        }
        public String opedit
        {
            get { return m_opedit; }
            set { m_opedit = value; }
        }
        public String pcedit
        {
            get { return m_pcedit; }
            set { m_pcedit = value; }
        }
        public DateTime luedit
        {
            get { return m_luedit; }
            set { m_luedit = value; }
        }
        public bool dlt
        {
            get { return m_dlt; }
            set { m_dlt = value; }
        }
        public Npgsql.NpgsqlConnection Koneksi
        {
            get { return m_Koneksi; }
            set { m_Koneksi = value; }
        }
        public bool Insert()
        {
            string sQuery = "INSERT INTO tblpeminjaman(peminjamanid,anggotaid,petugasid,nopeminjaman,tglpinjam,tgljatuhtempo,lamapeminjaman,dendaperhari,maksbukudipinjam,status,keterangan,regno,opadd,pcadd,luadd,dlt)" +
                            "VALUES" +
                            "(@peminjamanid,@anggotaid,@petugasid,@nopeminjaman,@tglpinjam,@tgljatuhtempo,@lamapeminjaman,@dendaperhari,@maksbukudipinjam,@status,@keterangan,@regno,@opadd,@pcadd,now(),@dlt)";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (peminjamanid != null)
            {
                cmd.Parameters.Add("@peminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = peminjamanid;
            }
            else
            {
                cmd.Parameters.Add("@peminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anggotaid != null)
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
            }
            else
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (petugasid != null)
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = petugasid;
            }
            else
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nopeminjaman != null)
            {
                cmd.Parameters.Add("@nopeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nopeminjaman;
            }
            else
            {
                cmd.Parameters.Add("@nopeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglpinjam != null && tglpinjam != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tglpinjam", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglpinjam;
            }
            else
            {
                cmd.Parameters.Add("@tglpinjam", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tgljatuhtempo != null && tgljatuhtempo != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tgljatuhtempo", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgljatuhtempo;
            }
            else
            {
                cmd.Parameters.Add("@tgljatuhtempo", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@lamapeminjaman", NpgsqlTypes.NpgsqlDbType.Numeric).Value = lamapeminjaman;
            cmd.Parameters.Add("@dendaperhari", NpgsqlTypes.NpgsqlDbType.Numeric).Value = dendaperhari;
            cmd.Parameters.Add("@maksbukudipinjam", NpgsqlTypes.NpgsqlDbType.Numeric).Value = maksbukudipinjam;
            if (status != null)
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null)
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@regno", NpgsqlTypes.NpgsqlDbType.Numeric).Value = regno;
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Update()
        {
            string sQuery = " UPDATE tblpeminjaman SET " +
                            " peminjamanid=@peminjamanid,anggotaid=@anggotaid,petugasid=@petugasid,nopeminjaman=@nopeminjaman,tglpinjam=@tglpinjam,tgljatuhtempo=@tgljatuhtempo,lamapeminjaman=@lamapeminjaman,dendaperhari=@dendaperhari,maksbukudipinjam=@maksbukudipinjam,status=@status,keterangan=@keterangan,regno=@regno,opedit=@opedit,pcedit=@pcedit,luedit=now(),dlt=@dlt" +
                            " WHERE peminjamanid=@peminjamanid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            if (peminjamanid != null)
            {
                cmd.Parameters.Add("@peminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = peminjamanid;
            }
            else
            {
                cmd.Parameters.Add("@peminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (anggotaid != null)
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = anggotaid;
            }
            else
            {
                cmd.Parameters.Add("@anggotaid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (petugasid != null)
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = petugasid;
            }
            else
            {
                cmd.Parameters.Add("@petugasid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (nopeminjaman != null)
            {
                cmd.Parameters.Add("@nopeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = nopeminjaman;
            }
            else
            {
                cmd.Parameters.Add("@nopeminjaman", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (tglpinjam != null && tglpinjam != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tglpinjam", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tglpinjam;
            }
            else
            {
                cmd.Parameters.Add("@tglpinjam", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (tgljatuhtempo != null && tgljatuhtempo != DateTime.MinValue)
            {
                cmd.Parameters.Add("@tgljatuhtempo", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = tgljatuhtempo;
            }
            else
            {
                cmd.Parameters.Add("@tgljatuhtempo", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@lamapeminjaman", NpgsqlTypes.NpgsqlDbType.Numeric).Value = lamapeminjaman;
            cmd.Parameters.Add("@dendaperhari", NpgsqlTypes.NpgsqlDbType.Numeric).Value = dendaperhari;
            cmd.Parameters.Add("@maksbukudipinjam", NpgsqlTypes.NpgsqlDbType.Numeric).Value = maksbukudipinjam;
            if (status != null)
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = status;
            }
            else
            {
                cmd.Parameters.Add("@status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (keterangan != null)
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = keterangan;
            }
            else
            {
                cmd.Parameters.Add("@keterangan", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@regno", NpgsqlTypes.NpgsqlDbType.Numeric).Value = regno;
            if (opadd != null)
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opadd;
            }
            else
            {
                cmd.Parameters.Add("@opadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcadd != null)
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcadd;
            }
            else
            {
                cmd.Parameters.Add("@pcadd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luadd != null && luadd != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luadd;
            }
            else
            {
                cmd.Parameters.Add("@luadd", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            if (opedit != null)
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = opedit;
            }
            else
            {
                cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (pcedit != null)
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = pcedit;
            }
            else
            {
                cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = DBNull.Value;
            }
            if (luedit != null && luedit != DateTime.MinValue)
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = luedit;
            }
            else
            {
                cmd.Parameters.Add("@luedit", NpgsqlTypes.NpgsqlDbType.Timestamp).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@dlt", NpgsqlTypes.NpgsqlDbType.Boolean).Value = dlt;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool Delete()
        {
            string sQuery = " DELETE FROM tblpeminjaman WHERE peminjamanid=@peminjamanid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.Parameters.Add("@peminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = peminjamanid;
            cmd.CommandText = sQuery;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool SoftDelete()
        {
            string sQuery = " UPDATE tblpeminjaman SET DLT=true , opedit=@opedit, pcedit=@pcedit, luedit=now() WHERE peminjamanid=@peminjamanid";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            cmd.Parameters.Add("@peminjamanid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = peminjamanid;
            cmd.Parameters.Add("@opedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = clsGlobal.strUserName;
            cmd.Parameters.Add("@pcedit", NpgsqlTypes.NpgsqlDbType.Varchar).Value = System.Windows.Forms.SystemInformation.ComputerName;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
        }
        public bool GetByPrimaryKey(string pKey)
        {
            string sQuery = "select * from tblpeminjaman WHERE peminjamanid='" + pKey + "'";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("peminjamanid")))
                    {
                        m_peminjamanid = rdr.GetString(rdr.GetOrdinal("peminjamanid"));
                    }
                    else
                    {
                        m_peminjamanid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("anggotaid")))
                    {
                        m_anggotaid = rdr.GetString(rdr.GetOrdinal("anggotaid"));
                    }
                    else
                    {
                        m_anggotaid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("petugasid")))
                    {
                        m_petugasid = rdr.GetString(rdr.GetOrdinal("petugasid"));
                    }
                    else
                    {
                        m_petugasid = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("nopeminjaman")))
                    {
                        m_nopeminjaman = rdr.GetString(rdr.GetOrdinal("nopeminjaman"));
                    }
                    else
                    {
                        m_nopeminjaman = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tglpinjam")))
                    {
                        m_tglpinjam = rdr.GetDateTime(rdr.GetOrdinal("tglpinjam"));
                    }
                    else
                    {
                        m_tglpinjam = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("tgljatuhtempo")))
                    {
                        m_tgljatuhtempo = rdr.GetDateTime(rdr.GetOrdinal("tgljatuhtempo"));
                    }
                    else
                    {
                        m_tgljatuhtempo = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("lamapeminjaman")))
                    {
                        m_lamapeminjaman = rdr.GetDecimal(rdr.GetOrdinal("lamapeminjaman"));
                    }
                    else
                    {
                        m_lamapeminjaman = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dendaperhari")))
                    {
                        m_dendaperhari = rdr.GetDecimal(rdr.GetOrdinal("dendaperhari"));
                    }
                    else
                    {
                        m_dendaperhari = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("maksbukudipinjam")))
                    {
                        m_maksbukudipinjam = rdr.GetDecimal(rdr.GetOrdinal("maksbukudipinjam"));
                    }
                    else
                    {
                        m_maksbukudipinjam = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("status")))
                    {
                        m_status = rdr.GetString(rdr.GetOrdinal("status"));
                    }
                    else
                    {
                        m_status = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("keterangan")))
                    {
                        m_keterangan = rdr.GetString(rdr.GetOrdinal("keterangan"));
                    }
                    else
                    {
                        m_keterangan = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("regno")))
                    {
                        m_regno = rdr.GetDecimal(rdr.GetOrdinal("regno"));
                    }
                    else
                    {
                        m_regno = 0;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opadd")))
                    {
                        m_opadd = rdr.GetString(rdr.GetOrdinal("opadd"));
                    }
                    else
                    {
                        m_opadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcadd")))
                    {
                        m_pcadd = rdr.GetString(rdr.GetOrdinal("pcadd"));
                    }
                    else
                    {
                        m_pcadd = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luadd")))
                    {
                        m_luadd = rdr.GetDateTime(rdr.GetOrdinal("luadd"));
                    }
                    else
                    {
                        m_luadd = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("opedit")))
                    {
                        m_opedit = rdr.GetString(rdr.GetOrdinal("opedit"));
                    }
                    else
                    {
                        m_opedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("pcedit")))
                    {
                        m_pcedit = rdr.GetString(rdr.GetOrdinal("pcedit"));
                    }
                    else
                    {
                        m_pcedit = "";
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("luedit")))
                    {
                        m_luedit = rdr.GetDateTime(rdr.GetOrdinal("luedit"));
                    }
                    else
                    {
                        m_luedit = System.DateTime.MinValue;
                    };
                    if (!rdr.IsDBNull(rdr.GetOrdinal("dlt")))
                    {
                        m_dlt = rdr.GetBoolean(rdr.GetOrdinal("dlt"));
                    }
                    else
                    {
                        m_dlt = false;
                    };
                }
                return true;
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return false;
            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
            }
        }

        public System.Data.DataTable GetData(Npgsql.NpgsqlCommand cmd)
        {
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tblpeminjaman");
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tblpeminjaman");
            return dt;
        }


        public System.Data.DataTable GetData(string strSQL, string strFilter = "")
        {
            if (strSQL == "")
            {

                strSQL = @"select pm.peminjamanid, pm.nopeminjaman, pm.tglpinjam, pm.tgljatuhtempo, pm.status, pm.keterangan,
                    pm.lamapeminjaman, pm.dendaperhari, pm.maksbukudipinjam,
                    ag.anggotaid, ag.rfid, ag.nim as nimanggota, ag.nama as namaanggota, ag.photo, ag.alamat, ag.jenis, ag.statusaktif,
                    peg.anggotaid as petugasid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, peg.photo as photopetugas
                    from tblpeminjaman pm 
                    left outer join tbm_anggota ag on ag.anggotaid=pm.anggotaid and ag.dlt='0'
                    left outer join tbm_anggota peg on peg.anggotaid=pm.petugasid and peg.dlt='0'
                    
                    where pm.dlt='0' " + strFilter + @"
                    order by pm.nopeminjaman desc ";
            }
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            System.Data.DataSet ds = new System.Data.DataSet();
            System.Data.DataTable dt = ds.Tables.Add("tblpeminjaman");
            Npgsql.NpgsqlDataAdapter da = new Npgsql.NpgsqlDataAdapter(cmd);
            da.Fill(ds, "tblpeminjaman");
            return dt;
        }

        public Npgsql.NpgsqlDataReader ReadData(Npgsql.NpgsqlCommand cmd)
        {
            cmd.Connection = Koneksi;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public Npgsql.NpgsqlDataReader ReadData(string strSQL)
        {
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(strSQL, Koneksi);
            cmd.CommandTimeout = 0;
            Npgsql.NpgsqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }
        public string NewID()
        {
            string i = "";
            string sQuery = "select '" + clsGlobal.str_serverCode + "'||nextval('tblpeminjaman_nextid') as id;";
            Npgsql.NpgsqlCommand cmd = new Npgsql.NpgsqlCommand(sQuery, Koneksi);
            cmd.CommandText = sQuery;
            try
            {
                Npgsql.NpgsqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    if (!rdr.IsDBNull(rdr.GetOrdinal("id")))
                    {
                        i = rdr.GetValue(0).ToString();
                    }
                    else
                    {
                        i = "";
                    };
                }
                rdr.Close();
            }
            catch (Npgsql.NpgsqlException Ex)
            {
                System.Windows.Forms.MessageBox.Show(Ex.Message, "An error occurred while processing!!!");
                return "";
            }

            return i;
        }

    }
}
