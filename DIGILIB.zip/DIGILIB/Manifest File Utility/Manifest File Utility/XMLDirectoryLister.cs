using System;
using System.IO;
using System.Xml;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Diagnostics;

namespace Manifest_File_Utility
{
    public class StringWriterWithEncoding : StringWriter
    {
        Encoding encoding;

        public StringWriterWithEncoding(Encoding encoding)
        {
            this.encoding = encoding;
        }

        public override Encoding Encoding
        {
            get { return encoding; }
        }
    }

    public class XMLDirectoryLister
    {
        private Boolean m_bUseDOMCalls;
        public Form myForm = null;

        public XMLDirectoryLister(Boolean bUseDOMCalls)
        {
            m_bUseDOMCalls = bUseDOMCalls;
        }
        public string
        getXMLString(string strDirectory)
        {
            string strXML = "";

            XmlDocument doc = getXML(strDirectory);
            if (doc != null)
            {
                StringWriterWithEncoding writer = new StringWriterWithEncoding(new UTF8Encoding());
                doc.Save(writer);

                strXML = writer.ToString();
            }

            doc = null;
            return strXML;
        }

        public DataSet
        getXMLDataset(string strDirectory)
        {
            DataSet ds = null;

            string strXML = getXMLString(strDirectory);
            XmlDataDocument datadoc = new XmlDataDocument();
            datadoc.DataSet.ReadXml(new StringReader(strXML));

            ds = datadoc.DataSet;

            return ds;
        }

        public XmlDocument
        getXMLDocument(string strDirectory)
        {
            return getXML(strDirectory);
        }

        private XmlDocument
        getXML(string strDirectory)
        {
            XmlDocument xmlDoc;
            if (m_bUseDOMCalls)
                xmlDoc = getXMLUsingDOMCalls(strDirectory);
            else
                xmlDoc = getXMLUsingTextWriterClass(strDirectory);

            return xmlDoc;
        }

        private void
        addTextElement(XmlDocument doc, XmlElement nodeParent, string strTag, string strValue)
        {
            XmlElement nodeElem = doc.CreateElement(strTag);
            XmlText nodeText = doc.CreateTextNode(strValue);
            nodeParent.AppendChild(nodeElem);
            nodeElem.AppendChild(nodeText);
        }

        private XmlDocument
        getXMLUsingTextWriterClass(string strDirectory)
        {
            StringWriterWithEncoding writerString = new StringWriterWithEncoding(new UTF8Encoding());
            XmlTextWriter writer = new XmlTextWriter(writerString);
            writer.WriteStartDocument();
            Boolean bFirst = true;
            string sfileversion = "";
            DirectoryInfo dir = new DirectoryInfo(strDirectory);
            foreach (FileSystemInfo entry in dir.GetFileSystemInfos())
            {
                try
                {
                    if (bFirst == true)
                    {
                        writer.WriteStartElement("update", "");
                        String strFullName = entry.FullName;
                        String strFileName = entry.Name;
                        bFirst = false;

                    }
                    if (entry.Name != "ServerManifest.xml" && entry.Name != "Manifest File Utility.exe")
                    {
                        if ((entry.Attributes & FileAttributes.Directory) <= 0)
                        {
                            writer.WriteStartElement("name", "");
                            writer.WriteAttributeString("file", entry.Name);
                            writer.WriteElementString("filename", entry.Name);

                            sfileversion = getAssemblyInfo(entry.FullName);
                            if (sfileversion == "")
                                sfileversion = getVersionInfo(entry.FullName);
                            writer.WriteElementString("fileversion", sfileversion);
                            writer.WriteElementString("filelastmodified", entry.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                            writer.WriteElementString("isdir", ((entry.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");
                            writer.WriteEndElement();    // entry     
                        }

                    }
                }
                catch { }
            }

            writer.WriteEndElement();       // dirlist
            writer.WriteEndDocument();

            string strXML = writerString.ToString();
            StringReader reader = new StringReader(strXML);

            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return doc;
        }

        private XmlDocument getXMLUsingDOMCalls(string strDirectory)
        {
            frmCreateManifestFile fCreateManifestFile = myForm as frmCreateManifestFile;
            XmlDocument doc = new XmlDocument();
            string sfileversion = "";
            // Insert the xml processing instruction and the root node
            XmlDeclaration dec =
               doc.CreateXmlDeclaration("1.0", "utf-8", "yes");
            dec.Encoding = "utf-8";
            doc.PrependChild(dec);

            // Add the root element
            XmlElement nodeElem =
               doc.CreateElement("update");
            doc.AppendChild(nodeElem);

            Boolean bFirst = true;

            // Process the directory list
            DirectoryInfo dir = new DirectoryInfo(strDirectory);
            foreach (FileSystemInfo entry in dir.GetFileSystemInfos())
            {
                if (bFirst == true)
                {
                    // If we haven't added any elements yet, go ahead and add a text element which
                    // contains the full directory path.
                    XmlElement root = doc.DocumentElement;

                    String strFullName = entry.FullName;
                    String strFileName = entry.Name;

                    String strDir = strFullName.Substring(0, strFullName.Length - strFileName.Length);
                    //root.SetAttribute("dir", strDir);

                    bFirst = false;
                }
                if (entry.Name != "ServerManifest.xml" && entry.Name != "Manifest File Utility.exe" && entry.Name != "Manifest File Utility New.exe")
                {
                    // Add a new text node with a tag entry.  There will be one added per
                    // item encountered in the directory.
                    XmlElement elem = doc.CreateElement("name");
                    doc.DocumentElement.AppendChild(elem);

                    elem.SetAttribute("file", entry.Name);

                    if ((entry.Attributes & FileAttributes.Directory) > 0)
                    {
                        addTextElement(doc, elem, "filename", entry.Name);
                        addTextElement(doc, elem, "fileversion", "");
                        addTextElement(doc, elem, "filelastmodified", entry.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                        addTextElement(doc, elem, "isdir", ((entry.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");

                        DirectoryInfo dir2 = new DirectoryInfo(strDirectory + "\\" + entry.Name);
                        foreach (FileSystemInfo entry2 in dir2.GetFileSystemInfos())
                        {
                            XmlElement elem2 = doc.CreateElement("name");
                            elem.AppendChild(elem2);
                            elem2.SetAttribute("file", entry2.Name);

                            if ((entry2.Attributes & FileAttributes.Directory) > 0)
                            {
                                addTextElement(doc, elem2, "filename", entry2.Name);
                                addTextElement(doc, elem2, "fileversion", "");
                                addTextElement(doc, elem2, "filelastmodified", entry2.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                                addTextElement(doc, elem2, "isdir", ((entry2.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");
                                #region "directory 3"
                                DirectoryInfo dir3 = new DirectoryInfo(strDirectory + "\\" + entry.Name + "\\" + entry2.Name);
                                foreach (FileSystemInfo entry3 in dir3.GetFileSystemInfos())
                                {
                                    XmlElement elem3 = doc.CreateElement("name");
                                    elem2.AppendChild(elem3);
                                    elem3.SetAttribute("file", entry3.Name);

                                    if ((entry3.Attributes & FileAttributes.Directory) > 0)
                                    {
                                        addTextElement(doc, elem3, "filename", entry3.Name);
                                        addTextElement(doc, elem3, "fileversion", "");
                                        addTextElement(doc, elem3, "filelastmodified", entry3.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                                        addTextElement(doc, elem3, "isdir", ((entry3.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");
                                        #region "directory 4"

                                        DirectoryInfo dir4 = new DirectoryInfo(strDirectory + "\\" + entry.Name + "\\" + entry2.Name + "\\" + entry3.Name);
                                        foreach (FileSystemInfo entry4 in dir4.GetFileSystemInfos())
                                        {
                                            XmlElement elem4 = doc.CreateElement("name");
                                            elem3.AppendChild(elem4);
                                            elem4.SetAttribute("file", entry4.Name);
                                            addTextElement(doc, elem4, "filename", entry4.Name);
                                            if ((entry4.Attributes & FileAttributes.Directory) > 0)
                                            {
                                                addTextElement(doc, elem4, "fileversion", "");
                                            }
                                            else
                                            {
                                                sfileversion = getAssemblyInfo(entry4.FullName);
                                                if (sfileversion == "")
                                                    sfileversion = getVersionInfo(entry4.FullName);
                                                addTextElement(doc, elem4, "fileversion", sfileversion);

                                            }

                                            addTextElement(doc, elem4, "filelastmodified", entry4.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                                            addTextElement(doc, elem4, "isdir", ((entry4.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");

                                            fCreateManifestFile.lblStatus.Text = "Status : reading file_" + entry4.Name.ToString();
                                            Application.DoEvents();

                                            //next directory
                                        }

                                        #endregion

                                    }
                                    else
                                    {
                                        addTextElement(doc, elem3, "filename", entry3.Name);

                                        sfileversion = getAssemblyInfo(entry3.FullName);
                                        if (sfileversion != "")
                                            sfileversion = getVersionInfo(entry3.FullName);
                                        addTextElement(doc, elem3, "fileversion", sfileversion);
                                        addTextElement(doc, elem3, "filelastmodified", entry3.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                                        addTextElement(doc, elem3, "isdir", ((entry3.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");
                                    }

                                    fCreateManifestFile.lblStatus.Text = "Status : reading file_" + entry3.Name.ToString();
                                    Application.DoEvents();
                                }
                                #endregion
                            }
                            else
                            {

                                addTextElement(doc, elem2, "filename", entry2.Name);

                                sfileversion = getAssemblyInfo(entry2.FullName);
                                if (sfileversion == "")
                                    sfileversion = getVersionInfo(entry2.FullName);
                                addTextElement(doc, elem2, "fileversion", sfileversion);
                                addTextElement(doc, elem2, "filelastmodified", entry2.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                                addTextElement(doc, elem2, "isdir", ((entry2.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");
                            }

                            fCreateManifestFile.lblStatus.Text = "Status : reading file_" + entry2.Name.ToString();
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        addTextElement(doc, elem, "filename", entry.Name);
                        sfileversion = getAssemblyInfo(entry.FullName);
                        if (sfileversion == "")
                            sfileversion = getVersionInfo(entry.FullName);
                        addTextElement(doc, elem, "fileversion", sfileversion);

                        addTextElement(doc, elem, "filelastmodified", entry.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"));
                        addTextElement(doc, elem, "isdir", ((entry.Attributes & FileAttributes.Directory) > 0) ? "True" : "False");
                    }

                    fCreateManifestFile.lblStatus.Text = "Status : reading file_" + entry.Name.ToString();
                    Application.DoEvents();
                }
            }
            fCreateManifestFile.lblStatus.Text = "Status :";
            return doc;
        }

        private string getVersionInfo(string assemblyFile)
        {
            string strVersion = "";
            try
            {
                AssemblyName asbInfo = AssemblyName.GetAssemblyName(assemblyFile);

                strVersion = asbInfo.Version.Major + "." + asbInfo.Version.MajorRevision + "." + asbInfo.Version.Minor + "." + asbInfo.Version.MinorRevision;
            }
            catch
            {
                strVersion = "";
            }
            return strVersion;
        }

        private string getAssemblyInfo(string fileName)
        {
            string strVersion = "";
            try
            {
                FileVersionInfo fvInfo = FileVersionInfo.GetVersionInfo(fileName);
                strVersion = fvInfo.FileMajorPart + "." + fvInfo.FileMinorPart + "." + fvInfo.FileBuildPart + "." + fvInfo.FilePrivatePart;

            }
            catch
            {
                strVersion = "";
            }
            return strVersion;
        }
    }
}