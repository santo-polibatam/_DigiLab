﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Manifest_File_Utility
{
    public partial class frmCreateManifestFile : Form
    {
        public frmCreateManifestFile()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = Application.StartupPath;
        }
                

        public void AppendTLog(string sMessage, string sPath)
        {
            try
            {
                string sDirectoryPath = sPath;
                string sFilePath;


                //if (!Directory.Exists(sDirectoryPath))
                //{
                //    Directory.CreateDirectory(sDirectoryPath);
                //}

                //the directory exists

                sFilePath = sDirectoryPath;

                if (!File.Exists(sFilePath))
                {
                    StreamWriter oCreator = File.CreateText(sFilePath);
                    oCreator.Close();
                }
                else
                { 

                }
                File.WriteAllText(sFilePath, sMessage);
                
                //StreamWriter oWriter = File.AppendText(sFilePath);
                
                //oWriter.WriteLine(sMessage);
                //oWriter.Close();
            }
            catch (Exception ex)
            {
                sMessage = ("======================================================================================\n" +
                    "Error occured at '" + ex.Source + "' on " + DateTime.Now.ToString() + " - " + DateTime.Now.ToString() + ":\n" +
                    ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                    "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");
                MessageBox.Show(sMessage);
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                string sFileSource = textBox1.Text.ToString();

                FolderBrowserDialog myFolderBrowserDialog = new FolderBrowserDialog();
                myFolderBrowserDialog.SelectedPath = sFileSource;

                if (myFolderBrowserDialog.ShowDialog() == DialogResult.OK)
                    sFileSource = myFolderBrowserDialog.SelectedPath.ToString();

                if ((sFileSource == ""))
                {
                    MessageBox.Show("Please specify the folder or filename...", "TMS Tools", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                textBox1.Text = sFileSource;
            }
            catch (Exception ex)
            {
                string sMessage = ("======================================================================================\n" +
                    "Error occured at '" + ex.Source + "' on " + DateTime.Now.ToString() + " - " + DateTime.Now.ToString() + ":\n" +
                    ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                    "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");
                MessageBox.Show(sMessage);
            }
        }

        private void btnCreateManifestFile_Click(object sender, EventArgs e)
        {
            try
            {
                CreateManifestFile();
                
            }
            catch (Exception ex)
            {
                string sMessage = ("======================================================================================\n" +
                    "Error occured at '" + ex.Source + "' on " + DateTime.Now.ToString() + " - " + DateTime.Now.ToString() + ":\n" +
                    ex.Message.ToString() + "\nPlease contact your system administrator if this problem occurs persistently.\n" +
                    "Stack Trace: \n" + ex.StackTrace + "\n======================================================================================");
                MessageBox.Show(sMessage);
            }
        }
        private void CreateManifestFile()
        {
            XMLDirectoryLister manifestxml = new XMLDirectoryLister(checkBox1.Checked);
            manifestxml.myForm = this;
            string sMessage = manifestxml.getXMLString(textBox1.Text.ToString());

            string sFileSource = "";
            saveFileDialog1.Title = "Please select the folder which contains the needed file: ";
            saveFileDialog1.FileName = "ServerManifest.xml";
            saveFileDialog1.DefaultExt = "*.xml";
            saveFileDialog1.Filter = "XML File(*.xml)|*.xml";
            saveFileDialog1.InitialDirectory = textBox1.Text.ToString();

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                sFileSource = saveFileDialog1.FileName;

            if ((sFileSource == ""))
            {
                MessageBox.Show("Please specify the filename...", this.Text.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            AppendTLog(sMessage, sFileSource);
            Application.Exit();
        }
    }
}
