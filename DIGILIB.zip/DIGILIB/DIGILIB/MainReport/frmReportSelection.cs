﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace DIGILIB
{
    public partial class frmReportSelection : DevExpress.XtraEditors.XtraForm
    {
        public frmReportSelection()
        {
            InitializeComponent();
        }

        private void frmReportSelection_Load(object sender, EventArgs e)
        {
        }
        public string filename = "";
        public bool loadDataXml(string xmlFile)
        {
            filename = xmlFile;
            if (filename == "") return false;
            bool bolResult = false;
            string sPath = System.IO.Path.GetDirectoryName(xmlFile);
            string[] sFile = System.IO.Path.GetFileName(xmlFile).Split('.');
            string[] sFileOnly = sFile[0].Split('_');

            if (sFileOnly.Length <= 0) return bolResult;
            xmlFile = System.IO.Path.Combine(sPath, sFileOnly[0] + ".xml");

            DataSet ds = new DataSet();
            DataTable rptTable = ds.Tables.Add("rptTable");
            DataColumn reportCol = rptTable.Columns.Add("reportname");
            rptTable.Columns.AddRange(new DataColumn[] { 
                new DataColumn("filepath", typeof(string)), 
                new DataColumn("no", typeof(int)), 
            });

            DataColumn[] keys = new DataColumn[1];
            keys[0] = reportCol;
            rptTable.PrimaryKey = keys;

            if (System.IO.File.Exists(xmlFile))
            {
                ds.ReadXml(xmlFile);
                dgData.DataSource = ds.Tables[0];

            }

            if (gridView1.RowCount > 1) bolResult = true;
            return bolResult;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (gridView1.RowCount > 0)            
                filename = gridView1.GetFocusedRowCellValue(filepath).ToString();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}