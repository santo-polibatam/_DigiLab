using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;
using DevExpress.XtraReports.UserDesigner;

namespace DIGILIB.MainReport
{
    public partial class XtraSubReport1 : DevExpress.XtraReports.UI.XtraReport
    {
        public string realPath = "";
        public string strFilter = "";
        public string reportName = "";
        public bool showdesinerwizard = false;
        public XtraSubReport1()
        {
            InitializeComponent();
        }

        private void XtraSubReport1_DesignerLoaded(object sender, DevExpress.XtraReports.UserDesigner.DesignerLoadedEventArgs e)
        {
            if (showdesinerwizard)
            {
                XRDesignPanel designwizard = e.DesignerHost.GetService(typeof(XRDesignPanel)) as XRDesignPanel;
                designwizard.ExecCommand(ReportCommand.VerbReportWizard, null);
            }
        }

    }
}
