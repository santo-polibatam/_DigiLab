﻿namespace DIGILIB.Honor
{
    partial class userControlReports
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userControlReports));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.treeList1 = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.xtraScrollableControl2 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.pnlRepository = new DevExpress.XtraEditors.PanelControl();
            this.cboStatusDenda = new DevExpress.XtraEditors.ComboBoxEdit();
            this.lblRepository = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditStatusActive = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditModul = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditBahanAjar = new DevExpress.XtraEditors.LookUpEdit();
            this.chkFilterPeriode = new DevExpress.XtraEditors.CheckEdit();
            this.xBulan2 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.xBulan1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.pnlFilter = new DevExpress.XtraEditors.PanelControl();
            this.optPeriode = new DevExpress.XtraEditors.RadioGroup();
            this.panelTgl = new DevExpress.XtraEditors.PanelControl();
            this.checkEdit4 = new DevExpress.XtraEditors.CheckEdit();
            this.dateTanggal2 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.dateTanggal1 = new DevExpress.XtraEditors.DateEdit();
            this.panelBln = new DevExpress.XtraEditors.PanelControl();
            this.lookUpEditBulan2 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditBulan1 = new DevExpress.XtraEditors.LookUpEdit();
            this.checkEdit5 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.panelThn = new DevExpress.XtraEditors.PanelControl();
            this.lookUpEditTahun2 = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditTahun1 = new DevExpress.XtraEditors.LookUpEdit();
            this.checkEdit6 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditPeriode = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditProdi = new DevExpress.XtraEditors.LookUpEdit();
            this.checkedEditProdi = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditSemester = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditTA = new DevExpress.XtraEditors.LookUpEdit();
            this.lookUpEditProgram = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.xtraScrollableControl1 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdkiri_nama = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdkiri_footer = new DevExpress.XtraEditors.TextEdit();
            this.txtttdkiri_header = new DevExpress.XtraEditors.TextEdit();
            this.chkttdkiri_tampilkan = new DevExpress.XtraEditors.CheckEdit();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.panelControl5 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdkanan_nama = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdkanan_footer = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdkanan_header = new DevExpress.XtraEditors.TextEdit();
            this.chkttdkanan_tampilkan = new DevExpress.XtraEditors.CheckEdit();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdtengah_nama = new DevExpress.XtraEditors.TextEdit();
            this.txtttdtengah_footer = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtttdtengah_header = new DevExpress.XtraEditors.TextEdit();
            this.chkttdtengah_tampilkan = new DevExpress.XtraEditors.CheckEdit();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.ribbonImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            this.xtraScrollableControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlRepository)).BeginInit();
            this.pnlRepository.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboStatusDenda.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditStatusActive.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditModul.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBahanAjar.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFilterPeriode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xBulan2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xBulan1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlFilter)).BeginInit();
            this.pnlFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.optPeriode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelTgl)).BeginInit();
            this.panelTgl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelBln)).BeginInit();
            this.panelBln.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBulan2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBulan1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelThn)).BeginInit();
            this.panelThn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditTahun2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditTahun1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditPeriode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditProdi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkedEditProdi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditSemester.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditTA.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditProgram.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            this.xtraScrollableControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkiri_nama.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkiri_footer.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkiri_header.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkttdkiri_tampilkan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).BeginInit();
            this.panelControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkanan_nama.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkanan_footer.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkanan_header.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkttdkanan_tampilkan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdtengah_nama.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdtengah_footer.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdtengah_header.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkttdtengah_tampilkan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.splitContainerControl1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1485, 878);
            this.panelControl1.TabIndex = 0;
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Location = new System.Drawing.Point(2, 2);
            this.splitContainerControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.treeList1);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.panelControl2);
            this.splitContainerControl1.Panel2.Controls.Add(this.groupControl1);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1481, 874);
            this.splitContainerControl1.SplitterPosition = 327;
            this.splitContainerControl1.TabIndex = 90;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // treeList1
            // 
            this.treeList1.Appearance.FocusedCell.BackColor = System.Drawing.Color.LimeGreen;
            this.treeList1.Appearance.FocusedCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.treeList1.Appearance.FocusedCell.ForeColor = System.Drawing.Color.White;
            this.treeList1.Appearance.FocusedCell.Options.UseBackColor = true;
            this.treeList1.Appearance.FocusedCell.Options.UseFont = true;
            this.treeList1.Appearance.FocusedCell.Options.UseForeColor = true;
            this.treeList1.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1});
            this.treeList1.ColumnsImageList = this.imageCollection1;
            this.treeList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeList1.Location = new System.Drawing.Point(0, 0);
            this.treeList1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.treeList1.Name = "treeList1";
            this.treeList1.BeginUnboundLoad();
            this.treeList1.AppendNode(new object[] {
            "Laporan Jumlah Anggota Mahasiswa"}, -1, 0, 1, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Jumlah Anggota Tenaga Pendidik dan Tenaga Kependidikan"}, -1, 0, 1, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Jumlah Koleksi Perpustakaan"}, -1, 0, 1, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Transaksi Peminjaman"}, -1, 0, 1, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Transaksi Pengembalian"}, -1, 0, 1, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Denda"}, -1, 0, 1, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Pembayaran Denda"}, -1);
            this.treeList1.AppendNode(new object[] {
            "Laporan Daftar Buku Populer"}, -1);
            this.treeList1.EndUnboundLoad();
            this.treeList1.OptionsBehavior.Editable = false;
            this.treeList1.OptionsBehavior.PopulateServiceColumns = true;
            this.treeList1.SelectImageList = this.imageCollection1;
            this.treeList1.Size = new System.Drawing.Size(327, 874);
            this.treeList1.TabIndex = 87;
            this.treeList1.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.treeList1_FocusedNodeChanged);
            // 
            // treeListColumn1
            // 
            this.treeListColumn1.Caption = "Jenis Laporan";
            this.treeListColumn1.FieldName = "Jenis Laporan";
            this.treeListColumn1.MinWidth = 70;
            this.treeListColumn1.Name = "treeListColumn1";
            this.treeListColumn1.OptionsColumn.ReadOnly = true;
            this.treeListColumn1.Visible = true;
            this.treeListColumn1.VisibleIndex = 0;
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "scorm16.png");
            this.imageCollection1.Images.SetKeyName(1, "1380791622_Gnome-Emblem-Default-32.png");
            this.imageCollection1.Images.SetKeyName(2, "Actions-bookmark-new-list-icon24.png");
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.xtraScrollableControl2);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl2.Location = new System.Drawing.Point(0, 0);
            this.panelControl2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(1149, 440);
            this.panelControl2.TabIndex = 89;
            // 
            // xtraScrollableControl2
            // 
            this.xtraScrollableControl2.Controls.Add(this.pnlRepository);
            this.xtraScrollableControl2.Controls.Add(this.chkFilterPeriode);
            this.xtraScrollableControl2.Controls.Add(this.xBulan2);
            this.xtraScrollableControl2.Controls.Add(this.lblTitle);
            this.xtraScrollableControl2.Controls.Add(this.xBulan1);
            this.xtraScrollableControl2.Controls.Add(this.pnlFilter);
            this.xtraScrollableControl2.Controls.Add(this.labelControl12);
            this.xtraScrollableControl2.Controls.Add(this.lookUpEditPeriode);
            this.xtraScrollableControl2.Controls.Add(this.lookUpEditProdi);
            this.xtraScrollableControl2.Controls.Add(this.checkedEditProdi);
            this.xtraScrollableControl2.Controls.Add(this.labelControl17);
            this.xtraScrollableControl2.Controls.Add(this.lookUpEditSemester);
            this.xtraScrollableControl2.Controls.Add(this.lookUpEditTA);
            this.xtraScrollableControl2.Controls.Add(this.lookUpEditProgram);
            this.xtraScrollableControl2.Controls.Add(this.labelControl13);
            this.xtraScrollableControl2.Controls.Add(this.labelControl10);
            this.xtraScrollableControl2.Controls.Add(this.labelControl11);
            this.xtraScrollableControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl2.Location = new System.Drawing.Point(2, 2);
            this.xtraScrollableControl2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.xtraScrollableControl2.Name = "xtraScrollableControl2";
            this.xtraScrollableControl2.Size = new System.Drawing.Size(1145, 436);
            this.xtraScrollableControl2.TabIndex = 114;
            // 
            // pnlRepository
            // 
            this.pnlRepository.Controls.Add(this.cboStatusDenda);
            this.pnlRepository.Controls.Add(this.lblRepository);
            this.pnlRepository.Controls.Add(this.lookUpEditStatusActive);
            this.pnlRepository.Controls.Add(this.lookUpEditModul);
            this.pnlRepository.Controls.Add(this.lookUpEditBahanAjar);
            this.pnlRepository.Location = new System.Drawing.Point(6, 228);
            this.pnlRepository.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlRepository.Name = "pnlRepository";
            this.pnlRepository.Size = new System.Drawing.Size(699, 46);
            this.pnlRepository.TabIndex = 120;
            // 
            // cboStatusDenda
            // 
            this.cboStatusDenda.Location = new System.Drawing.Point(177, 6);
            this.cboStatusDenda.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboStatusDenda.Name = "cboStatusDenda";
            this.cboStatusDenda.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboStatusDenda.Properties.Items.AddRange(new object[] {
            "",
            "Sudah Lunas",
            "Belum Lunas"});
            this.cboStatusDenda.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cboStatusDenda.Size = new System.Drawing.Size(337, 26);
            this.cboStatusDenda.TabIndex = 120;
            this.cboStatusDenda.Visible = false;
            // 
            // lblRepository
            // 
            this.lblRepository.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepository.Location = new System.Drawing.Point(8, 9);
            this.lblRepository.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lblRepository.Name = "lblRepository";
            this.lblRepository.Size = new System.Drawing.Size(97, 21);
            this.lblRepository.TabIndex = 114;
            this.lblRepository.Text = "Status Aktif :";
            // 
            // lookUpEditStatusActive
            // 
            this.lookUpEditStatusActive.Location = new System.Drawing.Point(176, 6);
            this.lookUpEditStatusActive.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditStatusActive.Name = "lookUpEditStatusActive";
            this.lookUpEditStatusActive.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditStatusActive.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus, "", -1, true, false, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.lookUpEditStatusActive.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("statusaktif", 200, "Status Aktif")});
            this.lookUpEditStatusActive.Properties.NullText = "";
            this.lookUpEditStatusActive.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditStatusActive.TabIndex = 115;
            // 
            // lookUpEditModul
            // 
            this.lookUpEditModul.Location = new System.Drawing.Point(176, 6);
            this.lookUpEditModul.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditModul.Name = "lookUpEditModul";
            this.lookUpEditModul.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditModul.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus, "", -1, true, false, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.lookUpEditModul.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("pkid", "pkid", 100, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("deskripsi", 200, "Deskripsi")});
            this.lookUpEditModul.Properties.NullText = "";
            this.lookUpEditModul.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditModul.TabIndex = 117;
            // 
            // lookUpEditBahanAjar
            // 
            this.lookUpEditBahanAjar.Location = new System.Drawing.Point(176, 6);
            this.lookUpEditBahanAjar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditBahanAjar.Name = "lookUpEditBahanAjar";
            this.lookUpEditBahanAjar.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditBahanAjar.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus, "", -1, true, false, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject3, "", null, null, true)});
            this.lookUpEditBahanAjar.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("pkid", "pkid", 100, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("deskripsi", 200, "Deskripsi")});
            this.lookUpEditBahanAjar.Properties.NullText = "";
            this.lookUpEditBahanAjar.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditBahanAjar.TabIndex = 119;
            // 
            // chkFilterPeriode
            // 
            this.chkFilterPeriode.Enabled = false;
            this.chkFilterPeriode.Location = new System.Drawing.Point(15, 35);
            this.chkFilterPeriode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chkFilterPeriode.Name = "chkFilterPeriode";
            this.chkFilterPeriode.Properties.Caption = "Filter Periode :";
            this.chkFilterPeriode.Size = new System.Drawing.Size(153, 24);
            this.chkFilterPeriode.TabIndex = 107;
            this.chkFilterPeriode.CheckedChanged += new System.EventHandler(this.chkFilterPeriode_CheckedChanged);
            // 
            // xBulan2
            // 
            this.xBulan2.Location = new System.Drawing.Point(830, 131);
            this.xBulan2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.xBulan2.Name = "xBulan2";
            this.xBulan2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xBulan2.Properties.Items.AddRange(new object[] {
            "",
            "Januari",
            "Pebruari",
            "Maret",
            "April",
            "Mei",
            "Juni",
            "Juli",
            "Agustus",
            "September",
            "November",
            "Desember"});
            this.xBulan2.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.xBulan2.Size = new System.Drawing.Size(94, 26);
            this.xBulan2.TabIndex = 108;
            this.xBulan2.Visible = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AllowHtmlString = true;
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Location = new System.Drawing.Point(18, 2);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(235, 24);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Laporan Perpustakaan";
            // 
            // xBulan1
            // 
            this.xBulan1.Location = new System.Drawing.Point(716, 131);
            this.xBulan1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.xBulan1.Name = "xBulan1";
            this.xBulan1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.xBulan1.Properties.Items.AddRange(new object[] {
            "",
            "Januari",
            "Pebruari",
            "Maret",
            "April",
            "Mei",
            "Juni",
            "Juli",
            "Agustus",
            "September",
            "November",
            "Desember"});
            this.xBulan1.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.xBulan1.Size = new System.Drawing.Size(92, 26);
            this.xBulan1.TabIndex = 107;
            this.xBulan1.Visible = false;
            // 
            // pnlFilter
            // 
            this.pnlFilter.Controls.Add(this.optPeriode);
            this.pnlFilter.Controls.Add(this.panelTgl);
            this.pnlFilter.Controls.Add(this.panelBln);
            this.pnlFilter.Controls.Add(this.panelThn);
            this.pnlFilter.Enabled = false;
            this.pnlFilter.Location = new System.Drawing.Point(8, 68);
            this.pnlFilter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlFilter.Name = "pnlFilter";
            this.pnlFilter.Size = new System.Drawing.Size(699, 142);
            this.pnlFilter.TabIndex = 112;
            // 
            // optPeriode
            // 
            this.optPeriode.EditValue = "Tanggal";
            this.optPeriode.Location = new System.Drawing.Point(8, 6);
            this.optPeriode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.optPeriode.Name = "optPeriode";
            this.optPeriode.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Tanggal", "Tanggal"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Bulan", "Bulan"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Tahun", "Tahun")});
            this.optPeriode.Size = new System.Drawing.Size(165, 125);
            this.optPeriode.TabIndex = 1;
            this.optPeriode.SelectedIndexChanged += new System.EventHandler(this.radioGroup1_SelectedIndexChanged);
            // 
            // panelTgl
            // 
            this.panelTgl.Controls.Add(this.checkEdit4);
            this.panelTgl.Controls.Add(this.dateTanggal2);
            this.panelTgl.Controls.Add(this.labelControl14);
            this.panelTgl.Controls.Add(this.dateTanggal1);
            this.panelTgl.Location = new System.Drawing.Point(176, 6);
            this.panelTgl.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelTgl.Name = "panelTgl";
            this.panelTgl.Size = new System.Drawing.Size(524, 40);
            this.panelTgl.TabIndex = 2;
            // 
            // checkEdit4
            // 
            this.checkEdit4.EditValue = true;
            this.checkEdit4.Location = new System.Drawing.Point(237, 5);
            this.checkEdit4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkEdit4.Name = "checkEdit4";
            this.checkEdit4.Properties.Caption = "Sampai :";
            this.checkEdit4.Size = new System.Drawing.Size(99, 24);
            this.checkEdit4.TabIndex = 106;
            this.checkEdit4.CheckedChanged += new System.EventHandler(this.checkEdit4_CheckedChanged);
            // 
            // dateTanggal2
            // 
            this.dateTanggal2.EditValue = null;
            this.dateTanggal2.Location = new System.Drawing.Point(358, 5);
            this.dateTanggal2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTanggal2.Name = "dateTanggal2";
            this.dateTanggal2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTanggal2.Properties.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal2.Properties.EditFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal2.Properties.Mask.EditMask = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTanggal2.Size = new System.Drawing.Size(150, 26);
            this.dateTanggal2.TabIndex = 105;
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(8, 9);
            this.labelControl14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(50, 21);
            this.labelControl14.TabIndex = 103;
            this.labelControl14.Text = "Mulai :";
            // 
            // dateTanggal1
            // 
            this.dateTanggal1.EditValue = null;
            this.dateTanggal1.Location = new System.Drawing.Point(63, 5);
            this.dateTanggal1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTanggal1.Name = "dateTanggal1";
            this.dateTanggal1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTanggal1.Properties.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal1.Properties.EditFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal1.Properties.Mask.EditMask = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTanggal1.Size = new System.Drawing.Size(150, 26);
            this.dateTanggal1.TabIndex = 0;
            // 
            // panelBln
            // 
            this.panelBln.Controls.Add(this.lookUpEditBulan2);
            this.panelBln.Controls.Add(this.lookUpEditBulan1);
            this.panelBln.Controls.Add(this.checkEdit5);
            this.panelBln.Controls.Add(this.labelControl15);
            this.panelBln.Enabled = false;
            this.panelBln.Location = new System.Drawing.Point(176, 48);
            this.panelBln.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelBln.Name = "panelBln";
            this.panelBln.Size = new System.Drawing.Size(524, 40);
            this.panelBln.TabIndex = 103;
            // 
            // lookUpEditBulan2
            // 
            this.lookUpEditBulan2.Location = new System.Drawing.Point(358, 5);
            this.lookUpEditBulan2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditBulan2.Name = "lookUpEditBulan2";
            this.lookUpEditBulan2.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditBulan2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditBulan2.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("bulantahun", 200, "Bulan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namabulan", "namabulan", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahun", "tahun", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("bulan", "bulan", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditBulan2.Properties.NullText = "";
            this.lookUpEditBulan2.Size = new System.Drawing.Size(150, 26);
            this.lookUpEditBulan2.TabIndex = 110;
            // 
            // lookUpEditBulan1
            // 
            this.lookUpEditBulan1.Location = new System.Drawing.Point(63, 6);
            this.lookUpEditBulan1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditBulan1.Name = "lookUpEditBulan1";
            this.lookUpEditBulan1.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditBulan1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditBulan1.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("bulantahun", 200, "Bulan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namabulan", "namabulan", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahun", "tahun", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("bulan", "bulan", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditBulan1.Properties.NullText = "";
            this.lookUpEditBulan1.Size = new System.Drawing.Size(150, 26);
            this.lookUpEditBulan1.TabIndex = 109;
            // 
            // checkEdit5
            // 
            this.checkEdit5.EditValue = true;
            this.checkEdit5.Location = new System.Drawing.Point(237, 5);
            this.checkEdit5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkEdit5.Name = "checkEdit5";
            this.checkEdit5.Properties.Caption = "Sampai :";
            this.checkEdit5.Size = new System.Drawing.Size(99, 24);
            this.checkEdit5.TabIndex = 106;
            this.checkEdit5.CheckedChanged += new System.EventHandler(this.checkEdit5_CheckedChanged);
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl15.Location = new System.Drawing.Point(8, 9);
            this.labelControl15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(50, 21);
            this.labelControl15.TabIndex = 103;
            this.labelControl15.Text = "Mulai :";
            // 
            // panelThn
            // 
            this.panelThn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelThn.Controls.Add(this.lookUpEditTahun2);
            this.panelThn.Controls.Add(this.lookUpEditTahun1);
            this.panelThn.Controls.Add(this.checkEdit6);
            this.panelThn.Controls.Add(this.labelControl16);
            this.panelThn.Enabled = false;
            this.panelThn.Location = new System.Drawing.Point(176, 91);
            this.panelThn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelThn.Name = "panelThn";
            this.panelThn.Size = new System.Drawing.Size(524, 40);
            this.panelThn.TabIndex = 104;
            // 
            // lookUpEditTahun2
            // 
            this.lookUpEditTahun2.Location = new System.Drawing.Point(358, 5);
            this.lookUpEditTahun2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditTahun2.Name = "lookUpEditTahun2";
            this.lookUpEditTahun2.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditTahun2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditTahun2.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahun", 200, "Tahun")});
            this.lookUpEditTahun2.Properties.NullText = "";
            this.lookUpEditTahun2.Size = new System.Drawing.Size(150, 26);
            this.lookUpEditTahun2.TabIndex = 108;
            // 
            // lookUpEditTahun1
            // 
            this.lookUpEditTahun1.Location = new System.Drawing.Point(63, 5);
            this.lookUpEditTahun1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditTahun1.Name = "lookUpEditTahun1";
            this.lookUpEditTahun1.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditTahun1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditTahun1.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahun", 200, "Tahun")});
            this.lookUpEditTahun1.Properties.NullText = "";
            this.lookUpEditTahun1.Size = new System.Drawing.Size(150, 26);
            this.lookUpEditTahun1.TabIndex = 107;
            // 
            // checkEdit6
            // 
            this.checkEdit6.EditValue = true;
            this.checkEdit6.Location = new System.Drawing.Point(237, 5);
            this.checkEdit6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkEdit6.Name = "checkEdit6";
            this.checkEdit6.Properties.Caption = "Sampai :";
            this.checkEdit6.Size = new System.Drawing.Size(99, 24);
            this.checkEdit6.TabIndex = 106;
            this.checkEdit6.CheckedChanged += new System.EventHandler(this.checkEdit6_CheckedChanged);
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Location = new System.Drawing.Point(8, 9);
            this.labelControl16.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(50, 21);
            this.labelControl16.TabIndex = 103;
            this.labelControl16.Text = "Mulai :";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(748, 246);
            this.labelControl12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(111, 21);
            this.labelControl12.TabIndex = 102;
            this.labelControl12.Text = "Tahun Ajaran :";
            this.labelControl12.Visible = false;
            // 
            // lookUpEditPeriode
            // 
            this.lookUpEditPeriode.Location = new System.Drawing.Point(183, 34);
            this.lookUpEditPeriode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditPeriode.Name = "lookUpEditPeriode";
            this.lookUpEditPeriode.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditPeriode.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditPeriode.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("periode", 200, "Periode"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("periodemulai", "Mulai", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("periodesampai", "Sampai", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditPeriode.Properties.NullText = "";
            this.lookUpEditPeriode.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditPeriode.TabIndex = 111;
            this.lookUpEditPeriode.Visible = false;
            // 
            // lookUpEditProdi
            // 
            this.lookUpEditProdi.Location = new System.Drawing.Point(430, 309);
            this.lookUpEditProdi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditProdi.Name = "lookUpEditProdi";
            this.lookUpEditProdi.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditProdi.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditProdi.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("prodicode", 100, "Kode"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("prodi", 200, "Prodi"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusan", 160, "Jurusan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("prodiid", "prodiid", 200, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahunajaran", "Tahun Ajaran", 80, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditProdi.Properties.NullText = "";
            this.lookUpEditProdi.Size = new System.Drawing.Size(276, 26);
            this.lookUpEditProdi.TabIndex = 96;
            this.lookUpEditProdi.Visible = false;
            // 
            // checkedEditProdi
            // 
            this.checkedEditProdi.Location = new System.Drawing.Point(912, 277);
            this.checkedEditProdi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkedEditProdi.Name = "checkedEditProdi";
            this.checkedEditProdi.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.checkedEditProdi.Size = new System.Drawing.Size(508, 26);
            this.checkedEditProdi.TabIndex = 113;
            this.checkedEditProdi.Visible = false;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl17.Location = new System.Drawing.Point(20, 38);
            this.labelControl17.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(66, 21);
            this.labelControl17.TabIndex = 110;
            this.labelControl17.Text = "Periode :";
            // 
            // lookUpEditSemester
            // 
            this.lookUpEditSemester.Location = new System.Drawing.Point(912, 354);
            this.lookUpEditSemester.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditSemester.Name = "lookUpEditSemester";
            this.lookUpEditSemester.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditSemester.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("semester", 200, "Semester")});
            this.lookUpEditSemester.Properties.ImmediatePopup = true;
            this.lookUpEditSemester.Properties.NullText = "";
            this.lookUpEditSemester.Properties.PopupSizeable = false;
            this.lookUpEditSemester.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditSemester.TabIndex = 98;
            this.lookUpEditSemester.Visible = false;
            // 
            // lookUpEditTA
            // 
            this.lookUpEditTA.Location = new System.Drawing.Point(912, 240);
            this.lookUpEditTA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditTA.Name = "lookUpEditTA";
            this.lookUpEditTA.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.lookUpEditTA.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditTA.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahunajaranid", "tahunajaranid", 100, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("tahunajaran", 200, "Tahun Ajaran"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("isactive", 60, "isactive")});
            this.lookUpEditTA.Properties.NullText = "";
            this.lookUpEditTA.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditTA.TabIndex = 95;
            this.lookUpEditTA.Visible = false;
            // 
            // lookUpEditProgram
            // 
            this.lookUpEditProgram.Location = new System.Drawing.Point(912, 314);
            this.lookUpEditProgram.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookUpEditProgram.Name = "lookUpEditProgram";
            this.lookUpEditProgram.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditProgram.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("program", 200, "Program")});
            this.lookUpEditProgram.Properties.ImmediatePopup = true;
            this.lookUpEditProgram.Properties.NullText = "";
            this.lookUpEditProgram.Properties.PopupSizeable = false;
            this.lookUpEditProgram.Size = new System.Drawing.Size(508, 26);
            this.lookUpEditProgram.TabIndex = 97;
            this.lookUpEditProgram.Visible = false;
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(748, 320);
            this.labelControl13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(73, 21);
            this.labelControl13.TabIndex = 99;
            this.labelControl13.Text = "Program :";
            this.labelControl13.Visible = false;
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(748, 285);
            this.labelControl10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(48, 21);
            this.labelControl10.TabIndex = 101;
            this.labelControl10.Text = "Prodi :";
            this.labelControl10.Visible = false;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(748, 360);
            this.labelControl11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(81, 21);
            this.labelControl11.TabIndex = 100;
            this.labelControl11.Text = "Semester :";
            this.labelControl11.Visible = false;
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControl1.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControl1.AppearanceCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.groupControl1.Controls.Add(this.xtraScrollableControl1);
            this.groupControl1.Controls.Add(this.simpleButton1);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupControl1.Location = new System.Drawing.Point(0, 440);
            this.groupControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1149, 434);
            this.groupControl1.TabIndex = 88;
            this.groupControl1.Text = "Penanda Tangan";
            // 
            // xtraScrollableControl1
            // 
            this.xtraScrollableControl1.Controls.Add(this.groupControl2);
            this.xtraScrollableControl1.Controls.Add(this.groupControl4);
            this.xtraScrollableControl1.Controls.Add(this.groupControl3);
            this.xtraScrollableControl1.Controls.Add(this.btnPreview);
            this.xtraScrollableControl1.Controls.Add(this.btnClose);
            this.xtraScrollableControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl1.Location = new System.Drawing.Point(2, 27);
            this.xtraScrollableControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.xtraScrollableControl1.Name = "xtraScrollableControl1";
            this.xtraScrollableControl1.Size = new System.Drawing.Size(1145, 405);
            this.xtraScrollableControl1.TabIndex = 10;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.panelControl4);
            this.groupControl2.Controls.Add(this.chkttdkiri_tampilkan);
            this.groupControl2.Location = new System.Drawing.Point(10, 6);
            this.groupControl2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(441, 188);
            this.groupControl2.TabIndex = 7;
            this.groupControl2.Text = "Sebelah Kiri";
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.labelControl1);
            this.panelControl4.Controls.Add(this.labelControl2);
            this.panelControl4.Controls.Add(this.txtttdkiri_nama);
            this.panelControl4.Controls.Add(this.labelControl3);
            this.panelControl4.Controls.Add(this.txtttdkiri_footer);
            this.panelControl4.Controls.Add(this.txtttdkiri_header);
            this.panelControl4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl4.Location = new System.Drawing.Point(2, 27);
            this.panelControl4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(437, 154);
            this.panelControl4.TabIndex = 8;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(18, 12);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(50, 19);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "Header";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(18, 60);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(118, 19);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Penanda Tangan";
            // 
            // txtttdkiri_nama
            // 
            this.txtttdkiri_nama.Location = new System.Drawing.Point(160, 55);
            this.txtttdkiri_nama.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdkiri_nama.Name = "txtttdkiri_nama";
            this.txtttdkiri_nama.Size = new System.Drawing.Size(243, 26);
            this.txtttdkiri_nama.TabIndex = 4;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(18, 100);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(45, 19);
            this.labelControl3.TabIndex = 6;
            this.labelControl3.Text = "Footer";
            // 
            // txtttdkiri_footer
            // 
            this.txtttdkiri_footer.Location = new System.Drawing.Point(160, 95);
            this.txtttdkiri_footer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdkiri_footer.Name = "txtttdkiri_footer";
            this.txtttdkiri_footer.Size = new System.Drawing.Size(243, 26);
            this.txtttdkiri_footer.TabIndex = 5;
            // 
            // txtttdkiri_header
            // 
            this.txtttdkiri_header.Location = new System.Drawing.Point(160, 8);
            this.txtttdkiri_header.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdkiri_header.Name = "txtttdkiri_header";
            this.txtttdkiri_header.Size = new System.Drawing.Size(243, 26);
            this.txtttdkiri_header.TabIndex = 1;
            // 
            // chkttdkiri_tampilkan
            // 
            this.chkttdkiri_tampilkan.EditValue = true;
            this.chkttdkiri_tampilkan.Location = new System.Drawing.Point(198, 2);
            this.chkttdkiri_tampilkan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chkttdkiri_tampilkan.Name = "chkttdkiri_tampilkan";
            this.chkttdkiri_tampilkan.Properties.Caption = "Tampilkan di Laporan";
            this.chkttdkiri_tampilkan.Size = new System.Drawing.Size(208, 24);
            this.chkttdkiri_tampilkan.TabIndex = 7;
            this.chkttdkiri_tampilkan.CheckedChanged += new System.EventHandler(this.checkEdit1_CheckedChanged);
            // 
            // groupControl4
            // 
            this.groupControl4.Controls.Add(this.panelControl5);
            this.groupControl4.Controls.Add(this.chkttdkanan_tampilkan);
            this.groupControl4.Location = new System.Drawing.Point(484, 6);
            this.groupControl4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(441, 188);
            this.groupControl4.TabIndex = 9;
            this.groupControl4.Text = "Sebelah Kanan";
            // 
            // panelControl5
            // 
            this.panelControl5.Controls.Add(this.labelControl9);
            this.panelControl5.Controls.Add(this.txtttdkanan_nama);
            this.panelControl5.Controls.Add(this.labelControl7);
            this.panelControl5.Controls.Add(this.txtttdkanan_footer);
            this.panelControl5.Controls.Add(this.labelControl8);
            this.panelControl5.Controls.Add(this.txtttdkanan_header);
            this.panelControl5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl5.Location = new System.Drawing.Point(2, 27);
            this.panelControl5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelControl5.Name = "panelControl5";
            this.panelControl5.Size = new System.Drawing.Size(437, 154);
            this.panelControl5.TabIndex = 9;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(16, 23);
            this.labelControl9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(50, 19);
            this.labelControl9.TabIndex = 2;
            this.labelControl9.Text = "Header";
            // 
            // txtttdkanan_nama
            // 
            this.txtttdkanan_nama.Location = new System.Drawing.Point(158, 66);
            this.txtttdkanan_nama.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdkanan_nama.Name = "txtttdkanan_nama";
            this.txtttdkanan_nama.Size = new System.Drawing.Size(243, 26);
            this.txtttdkanan_nama.TabIndex = 4;
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(16, 71);
            this.labelControl7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(118, 19);
            this.labelControl7.TabIndex = 3;
            this.labelControl7.Text = "Penanda Tangan";
            // 
            // txtttdkanan_footer
            // 
            this.txtttdkanan_footer.Location = new System.Drawing.Point(158, 106);
            this.txtttdkanan_footer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdkanan_footer.Name = "txtttdkanan_footer";
            this.txtttdkanan_footer.Size = new System.Drawing.Size(243, 26);
            this.txtttdkanan_footer.TabIndex = 5;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(16, 111);
            this.labelControl8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(45, 19);
            this.labelControl8.TabIndex = 6;
            this.labelControl8.Text = "Footer";
            // 
            // txtttdkanan_header
            // 
            this.txtttdkanan_header.Location = new System.Drawing.Point(158, 18);
            this.txtttdkanan_header.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdkanan_header.Name = "txtttdkanan_header";
            this.txtttdkanan_header.Size = new System.Drawing.Size(243, 26);
            this.txtttdkanan_header.TabIndex = 1;
            // 
            // chkttdkanan_tampilkan
            // 
            this.chkttdkanan_tampilkan.EditValue = true;
            this.chkttdkanan_tampilkan.Location = new System.Drawing.Point(225, 2);
            this.chkttdkanan_tampilkan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chkttdkanan_tampilkan.Name = "chkttdkanan_tampilkan";
            this.chkttdkanan_tampilkan.Properties.Caption = "Tampilkan di Laporan";
            this.chkttdkanan_tampilkan.Size = new System.Drawing.Size(208, 24);
            this.chkttdkanan_tampilkan.TabIndex = 8;
            this.chkttdkanan_tampilkan.CheckedChanged += new System.EventHandler(this.checkEdit3_CheckedChanged);
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.panelControl3);
            this.groupControl3.Controls.Add(this.chkttdtengah_tampilkan);
            this.groupControl3.Location = new System.Drawing.Point(10, 203);
            this.groupControl3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(441, 188);
            this.groupControl3.TabIndex = 8;
            this.groupControl3.Text = "Tengah";
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.labelControl6);
            this.panelControl3.Controls.Add(this.labelControl4);
            this.panelControl3.Controls.Add(this.txtttdtengah_nama);
            this.panelControl3.Controls.Add(this.txtttdtengah_footer);
            this.panelControl3.Controls.Add(this.labelControl5);
            this.panelControl3.Controls.Add(this.txtttdtengah_header);
            this.panelControl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl3.Location = new System.Drawing.Point(2, 27);
            this.panelControl3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(437, 154);
            this.panelControl3.TabIndex = 8;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(18, 18);
            this.labelControl6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(50, 19);
            this.labelControl6.TabIndex = 2;
            this.labelControl6.Text = "Header";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(18, 66);
            this.labelControl4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(118, 19);
            this.labelControl4.TabIndex = 3;
            this.labelControl4.Text = "Penanda Tangan";
            // 
            // txtttdtengah_nama
            // 
            this.txtttdtengah_nama.Location = new System.Drawing.Point(160, 55);
            this.txtttdtengah_nama.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdtengah_nama.Name = "txtttdtengah_nama";
            this.txtttdtengah_nama.Size = new System.Drawing.Size(243, 26);
            this.txtttdtengah_nama.TabIndex = 4;
            // 
            // txtttdtengah_footer
            // 
            this.txtttdtengah_footer.Location = new System.Drawing.Point(160, 95);
            this.txtttdtengah_footer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdtengah_footer.Name = "txtttdtengah_footer";
            this.txtttdtengah_footer.Size = new System.Drawing.Size(243, 26);
            this.txtttdtengah_footer.TabIndex = 5;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(18, 106);
            this.labelControl5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(45, 19);
            this.labelControl5.TabIndex = 6;
            this.labelControl5.Text = "Footer";
            // 
            // txtttdtengah_header
            // 
            this.txtttdtengah_header.Location = new System.Drawing.Point(160, 8);
            this.txtttdtengah_header.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtttdtengah_header.Name = "txtttdtengah_header";
            this.txtttdtengah_header.Size = new System.Drawing.Size(243, 26);
            this.txtttdtengah_header.TabIndex = 1;
            // 
            // chkttdtengah_tampilkan
            // 
            this.chkttdtengah_tampilkan.EditValue = true;
            this.chkttdtengah_tampilkan.Location = new System.Drawing.Point(198, 2);
            this.chkttdtengah_tampilkan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chkttdtengah_tampilkan.Name = "chkttdtengah_tampilkan";
            this.chkttdtengah_tampilkan.Properties.Caption = "Tampilkan di Laporan";
            this.chkttdtengah_tampilkan.Size = new System.Drawing.Size(208, 24);
            this.chkttdtengah_tampilkan.TabIndex = 8;
            this.chkttdtengah_tampilkan.CheckedChanged += new System.EventHandler(this.checkEdit2_CheckedChanged);
            // 
            // btnPreview
            // 
            this.btnPreview.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Appearance.Options.UseFont = true;
            this.btnPreview.Image = global::DIGILIB.Properties.Resources.Actions_print_preview_icon32;
            this.btnPreview.Location = new System.Drawing.Point(488, 332);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(166, 57);
            this.btnPreview.TabIndex = 85;
            this.btnPreview.Text = "Preview";
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnClose
            // 
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(663, 332);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 57);
            this.btnClose.TabIndex = 70;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.simpleButton1.ImageIndex = 11;
            this.simpleButton1.ImageList = this.ribbonImageCollection;
            this.simpleButton1.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            this.simpleButton1.Location = new System.Drawing.Point(1101, 0);
            this.simpleButton1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(48, 31);
            this.simpleButton1.TabIndex = 0;
            this.simpleButton1.Visible = false;
            // 
            // ribbonImageCollection
            // 
            this.ribbonImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollection.ImageStream")));
            this.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_Save_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_SaveAs_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Info_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(3, "remove-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(4, "close-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(5, "Copy16.png");
            this.ribbonImageCollection.Images.SetKeyName(6, "Paste16.png");
            this.ribbonImageCollection.Images.SetKeyName(7, "New Edit16.png");
            this.ribbonImageCollection.Images.SetKeyName(8, "New Remove64.png");
            this.ribbonImageCollection.Images.SetKeyName(9, "Paste.png");
            this.ribbonImageCollection.Images.SetKeyName(10, "Paste_dis.png");
            this.ribbonImageCollection.Images.SetKeyName(11, "maximize_square.png");
            this.ribbonImageCollection.Images.SetKeyName(12, "minimize_square.png");
            // 
            // userControlReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "userControlReports";
            this.Size = new System.Drawing.Size(1485, 878);
            this.Load += new System.EventHandler(this.userControlCTR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.xtraScrollableControl2.ResumeLayout(false);
            this.xtraScrollableControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlRepository)).EndInit();
            this.pnlRepository.ResumeLayout(false);
            this.pnlRepository.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboStatusDenda.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditStatusActive.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditModul.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBahanAjar.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFilterPeriode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xBulan2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xBulan1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlFilter)).EndInit();
            this.pnlFilter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.optPeriode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelTgl)).EndInit();
            this.panelTgl.ResumeLayout(false);
            this.panelTgl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelBln)).EndInit();
            this.panelBln.ResumeLayout(false);
            this.panelBln.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBulan2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBulan1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelThn)).EndInit();
            this.panelThn.ResumeLayout(false);
            this.panelThn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditTahun2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditTahun1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditPeriode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditProdi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkedEditProdi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditSemester.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditTA.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditProgram.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.xtraScrollableControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            this.panelControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkiri_nama.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkiri_footer.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkiri_header.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkttdkiri_tampilkan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).EndInit();
            this.panelControl5.ResumeLayout(false);
            this.panelControl5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkanan_nama.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkanan_footer.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdkanan_header.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkttdkanan_tampilkan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdtengah_nama.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdtengah_footer.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtttdtengah_header.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkttdtengah_tampilkan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private DevExpress.Utils.ImageCollection ribbonImageCollection;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraTreeList.TreeList treeList1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.TextEdit txtttdkiri_header;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.TextEdit txtttdkiri_nama;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtttdkanan_header;
        private DevExpress.XtraEditors.TextEdit txtttdkanan_footer;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit txtttdkanan_nama;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtttdtengah_header;
        private DevExpress.XtraEditors.TextEdit txtttdtengah_footer;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit txtttdtengah_nama;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtttdkiri_footer;
        private DevExpress.XtraEditors.CheckEdit chkttdkanan_tampilkan;
        private DevExpress.XtraEditors.CheckEdit chkttdtengah_tampilkan;
        private DevExpress.XtraEditors.CheckEdit chkttdkiri_tampilkan;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl1;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.PanelControl panelTgl;
        private DevExpress.XtraEditors.RadioGroup optPeriode;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditTA;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditProdi;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.DateEdit dateTanggal2;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.DateEdit dateTanggal1;
        private DevExpress.XtraEditors.CheckEdit checkEdit4;
        private DevExpress.XtraEditors.PanelControl panelBln;
        private DevExpress.XtraEditors.ComboBoxEdit xBulan2;
        private DevExpress.XtraEditors.ComboBoxEdit xBulan1;
        private DevExpress.XtraEditors.CheckEdit checkEdit5;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.PanelControl panelThn;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditTahun2;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditTahun1;
        private DevExpress.XtraEditors.CheckEdit checkEdit6;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl5;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditBulan2;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditBulan1;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditProgram;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditSemester;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditPeriode;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.PanelControl pnlFilter;
        private DevExpress.XtraEditors.CheckedComboBoxEdit checkedEditProdi;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl2;
        private DevExpress.XtraEditors.CheckEdit chkFilterPeriode;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditStatusActive;
        private DevExpress.XtraEditors.LabelControl lblRepository;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditModul;
        private DevExpress.XtraEditors.PanelControl pnlRepository;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditBahanAjar;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraEditors.ComboBoxEdit cboStatusDenda; 
        
    }
}
