using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;
using System.Data;
using DevExpress.XtraReports.UserDesigner;

namespace DIGILIB.MainReport
{
    public partial class XtraReport1 : DevExpress.XtraReports.UI.XtraReport
    {
        public XtraSubReport1 xtrasubreport;
        public XtraSubReport1 xtrasubreport1;
        public XtraSubReport1 xtrasubreport2;
        public XtraSubReport1 xtrasubreport3;
        public XtraSubReport1 xtrasubreport4;
        public XtraSubReport1 xtrasubreport5;
        public XtraSubReport1 xtrasubreport6;
        public XtraSubReport1 xtrasubreport7;
        public XtraSubReport1 xtrasubreport8;
        public XtraSubReport1 xtrasubreport9;
        public XtraSubReport1 xtrasubreport10;
        public XtraSubReport1 xtrasubreport11;
        public XtraSubReport1 xtrasubreport12;
        public XtraSubReport1 xtrasubreport13;
        public XtraSubReport1 xtrasubreport14;
        public XtraSubReport1 xtrasubreport15;
        public XtraSubReport1 xtrasubreport16;

        public bool showdesinerwizard = false;
        public string filename = "temp.repx";
        public DataView dv1;
        public DataView dv2;
        public int maxGate;
        public string realPath = "";
        public string strFilter = "";
        public string reportName = "";
        private DataView dv;
        public bool showChartLabel = true;
        public string reportNameReal = "";

        public DataTable dtGraph;
        decimal iPProgress = 0;
        int idocCount = 0;
        int intFooterFinalidx = 0;
        
        public XtraReport1()
        {
            InitializeComponent();
        }

        private void XtraReport1_DesignerLoaded(object sender, DevExpress.XtraReports.UserDesigner.DesignerLoadedEventArgs e)
        {
            if (showdesinerwizard)
            {
                XRDesignPanel designwizard = e.DesignerHost.GetService(typeof(XRDesignPanel)) as XRDesignPanel;
                designwizard.ExecCommand(ReportCommand.VerbReportWizard, null);
            }
        }

        int intNo = 1;
        private void XtraReport1_DataSourceRowChanged(object sender, DataSourceRowEventArgs e)
        {
            if (reportName == "rptProjectControl")
            {
                printReportProjectControl(sender, e);
            }
            else if (reportName == "rptRekapBPK.repx")
            {
              
            }
        }

        private void GroupFooter1_BeforePrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            if (reportName == "rptRekapBPK.repx")
            {
                
            }
        }

        private void tcNo_BeforePrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            XRTableCell tcNo = this.FindControl("tcNo", true) as XRTableCell;
            if (tcNo != null)
                tcNo.Text = intNo.ToString();
            intNo++;
        }

        private void tcPersen_BeforePrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            decimal totalRencana = 0; decimal totalRealisasi = 0; decimal sisaPersen = 0;
            decimal decOut = 0;
            DataTable dt = DataSource as DataTable;
            for (int i = 0; i < dt.Rows.Count; i++ )
            {
                decimal.TryParse(dt.Rows[i]["totalrencana"].ToString(), out decOut);
                totalRencana += decOut; decOut = 0;
                decimal.TryParse(dt.Rows[i]["jumlahrealisasi"].ToString(), out decOut);
                totalRealisasi += decOut; decOut = 0;
            }

            if (totalRencana == 0)
            {
                sisaPersen = 0;
            }
            else
            {
                sisaPersen = (totalRealisasi / totalRencana) * 100;
            }

            XRTableCell tcPersen = this.FindControl("tcPersen", true) as XRTableCell;
            if (tcPersen != null)
                tcPersen.Text = sisaPersen.ToString("#,##0.##") + "%";
        }

        private void XtraReport1_AfterPrint(object sender, EventArgs e)
        {
            if (reportName == "rptDeliverables" || reportName == "rptNonDeliverables" || reportName == "rptProjectControl" || reportName == "rptprojectcontrol_physicalprogress"
                || reportName == "rptEarnedValue" || reportName == "rptManhoursHistogram" || reportName == "rptDeliverablesCount" ||
                reportName == "rptDashboardEarnValue" || reportName == "rptDashboardproduktivity" || reportName == "rptDashboardmanhours" || reportName == "rptDashboardactualManhours" || reportName == "rptDashboarddeliverablesCount" || reportName == "rptOverallProductivity"
            || reportName == "rptDocumentRevisionHistory")
            {
                this.PrintingSystem.Document.AutoFitToPagesWidth = 1;
            }
            else if (reportName == "rptActivityManhours" && this.Landscape == true)
            {
                this.PrintingSystem.Document.AutoFitToPagesWidth = 1;

            }

        }

        private void XtraReport1_BeforePrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            XRTableCell tcNo = this.FindControl("tcNo", true) as XRTableCell;
                if(tcNo!=null)
                    tcNo.BeforePrint += new System.Drawing.Printing.PrintEventHandler(this.tcNo_BeforePrint);

            GroupFooterBand GroupFooterCTR = this.FindControl("GroupFooter1", true) as GroupFooterBand;
            if (GroupFooterCTR != null)
                GroupFooterCTR.BeforePrint += new System.Drawing.Printing.PrintEventHandler(this.GroupFooter1_BeforePrint);

            XRTableCell tcPersen = this.FindControl("tcPersen", true) as XRTableCell;
            if (tcPersen != null)
                tcPersen.BeforePrint += new System.Drawing.Printing.PrintEventHandler(this.tcPersen_BeforePrint);


            DataTable dtSource = DataSource as DataTable;
            if (dtSource != null)
                dv = dtSource.DefaultView;
            else
                dv = DataSource as DataView;
            if (strFilter != "")
            {
                dv.RowFilter = strFilter;
            }
            if (reportName == "rptdocumentreview" || reportName == "rptdocumenttransmittal")
            {
                XRSubreport subreport = this.FindControl("subreport1", true) as XRSubreport;
                if (subreport != null && xtrasubreport1 != null)
                {
                    subreport.ReportSource = xtrasubreport1;
                }
            }
            if (reportName == "rptPMDK_UMPB.repx" || reportName == "rptD4.repx" || reportName=="rptUMPN.repx" || reportName=="rptPPL.repx")
            {
                XRPictureBox pct = this.FindControl("pictureBox2", true) as XRPictureBox;
                if (pct != null)
                {
                    if (Convert.ToString(dv[0]["photo"]) != "")
                    {
                        pct.ImageUrl = @"http://registrasi.polibatam.ac.id/images/photos/" + Convert.ToString(dv[0]["photo"]);
                        //pct.ImageUrl = @"http://27.50.24.75/registrasi/images/photos/" + Convert.ToString(dv[0]["photo"]);
                        //pct.ImageUrl = @"http://localhost/polibatam/images/photos/" + Convert.ToString(dv[0]["photo"]);
                    }
                }
                XRCheckBox chkAgama1 = this.FindControl("chkAgama1", true) as XRCheckBox;
                XRCheckBox chkAgama2 = this.FindControl("chkAgama2", true) as XRCheckBox;
                XRCheckBox chkAgama3 = this.FindControl("chkAgama3", true) as XRCheckBox;
                XRCheckBox chkAgama4 = this.FindControl("chkAgama4", true) as XRCheckBox;
                XRCheckBox chkAgama5 = this.FindControl("chkAgama5", true) as XRCheckBox;
                XRCheckBox chkAgama6 = this.FindControl("chkAgama6", true) as XRCheckBox;

                if (dv[0]["agama"].ToString().ToLower() == "islam")
                {
                    chkAgama1.Checked = true;
                }
                else if (dv[0]["agama"].ToString().ToLower() == "kristen")
                {
                    chkAgama2.Checked = true;
                }
                else if (dv[0]["agama"].ToString().ToLower() == "katolik")
                {
                    chkAgama3.Checked = true;
                }
                else if (dv[0]["agama"].ToString().ToLower() == "hindu")
                {
                    chkAgama4.Checked = true;
                }
                else if (dv[0]["agama"].ToString().ToLower() == "budha")
                {
                    chkAgama5.Checked = true;
                }
                else if (dv[0]["agama"].ToString().ToLower() == "lainnya")
                {
                    chkAgama6.Checked = true;
                    chkAgama6.Text=dv[0]["agamalainnya"].ToString();
                }

                if (reportName != "rptPPL.repx")
                {
                    XRCheckBox chkButa1 = this.FindControl("chkButa1", true) as XRCheckBox;
                    XRCheckBox chkButa2 = this.FindControl("chkButa2", true) as XRCheckBox;
                    if (dv[0]["butawarna"].ToString().ToLower() == "true")
                    {
                        chkButa1.Checked = true;
                    }
                    else
                    {
                        chkButa2.Checked = true;
                    }
                }

                if (reportName == "rptPMDK_UMPB.repx")
                {
                    XRCheckBox chkJenisKelas1 = this.FindControl("chkJenisKelas1", true) as XRCheckBox;
                    XRCheckBox chkJenisKelas2 = this.FindControl("chkJenisKelas2", true) as XRCheckBox;
                    if (dv[0]["jeniskelas"].ToString().ToLower() == "kelas regular")
                    {
                        chkJenisKelas1.Checked = true;
                    }
                    else if (dv[0]["jeniskelas"].ToString().ToLower() == "kelas karyawan")
                    {
                        chkJenisKelas2.Checked = true;
                    }
                }

                if (reportName != "rptUMPN.repx" && reportName!="rptPPL.repx")
                {
                    XRCheckBox chkPilihan1_1 = this.FindControl("chkPilihan1_1", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_2 = this.FindControl("chkPilihan1_2", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_3 = this.FindControl("chkPilihan1_3", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_4 = this.FindControl("chkPilihan1_4", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_5 = this.FindControl("chkPilihan1_5", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_6 = this.FindControl("chkPilihan1_6", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_7 = this.FindControl("chkPilihan1_7", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_8 = this.FindControl("chkPilihan1_8", true) as XRCheckBox;
                    XRCheckBox chkPilihan1_9 = this.FindControl("chkPilihan1_9", true) as XRCheckBox;
                    if (dv[0]["pilihan1"].ToString().ToLower() == "d3 akuntansi")
                    {
                        if (chkPilihan1_1 != null)
                            chkPilihan1_1.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d3 teknik elektronika")
                    {
                        if (chkPilihan1_2 != null)
                            chkPilihan1_2.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d3 teknik informatika")
                    {
                        if (chkPilihan1_3 != null)
                            chkPilihan1_3.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d3 teknik mesin")
                    {
                        if (chkPilihan1_4 != null)
                            chkPilihan1_4.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d3 lnstrumentasi")
                    {
                        if (chkPilihan1_5 != null)
                            chkPilihan1_5.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d4 administrasi bisnis terapan")
                    {
                        if (chkPilihan1_6 != null)
                            chkPilihan1_6.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d4 teknik mekatronika")
                    {
                        if (chkPilihan1_7 != null)
                            chkPilihan1_7.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d4 teknik multimedia & jaringan")
                    {
                        if (chkPilihan1_8 != null)
                            chkPilihan1_8.Checked = true;
                    }
                    else if (dv[0]["pilihan1"].ToString().ToLower() == "d4 akuntansi  manajerial")
                    {
                        if (chkPilihan1_9 != null)
                            chkPilihan1_9.Checked = true;
                    }
                }

                if (reportName == "rptPMDK_UMPB.repx")
                {
                    XRCheckBox chkPilihan2_1 = this.FindControl("chkPilihan2_1", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_2 = this.FindControl("chkPilihan2_2", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_3 = this.FindControl("chkPilihan2_3", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_4 = this.FindControl("chkPilihan2_4", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_5 = this.FindControl("chkPilihan2_5", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_6 = this.FindControl("chkPilihan2_6", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_7 = this.FindControl("chkPilihan2_7", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_8 = this.FindControl("chkPilihan2_8", true) as XRCheckBox;
                    XRCheckBox chkPilihan2_9 = this.FindControl("chkPilihan2_9", true) as XRCheckBox;
                    if (dv[0]["pilihan2"].ToString().ToLower() == "d3 akuntansi")
                    {
                        if (chkPilihan2_1 != null)
                            chkPilihan2_1.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d3 teknik elektronika")
                    {
                        if (chkPilihan2_2 != null)
                            chkPilihan2_2.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d3 teknik informatika")
                    {
                        if (chkPilihan2_3 != null)
                            chkPilihan2_3.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d3 teknik mesin")
                    {
                        if (chkPilihan2_4 != null)
                            chkPilihan2_4.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d3 lnstrumentasi")
                    {
                        if (chkPilihan2_5 != null)
                            chkPilihan2_5.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d4 administrasi bisnis terapan")
                    {
                        if (chkPilihan2_6 != null)
                            chkPilihan2_6.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d4 teknik mekatronika")
                    {
                        if (chkPilihan2_7 != null)
                            chkPilihan2_7.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d4 teknik multimedia & jaringan")
                    {
                        if (chkPilihan2_8 != null)
                            chkPilihan2_8.Checked = true;
                    }
                    else if (dv[0]["pilihan2"].ToString().ToLower() == "d4 akuntansi  manajerial")
                    {
                        if (chkPilihan2_9 != null)
                            chkPilihan2_9.Checked = true;
                    }
                }

                XRCheckBox chkHubungan1 = this.FindControl("chkHubungan1", true) as XRCheckBox;
                XRCheckBox chkHubungan2 = this.FindControl("chkHubungan2", true) as XRCheckBox;
                XRCheckBox chkHubungan3 = this.FindControl("chkHubungan3", true) as XRCheckBox;
                XRCheckBox chkHubungan4 = this.FindControl("chkHubungan4", true) as XRCheckBox;
                if (dv[0]["hubunganpenanggungjawab"].ToString().ToLower() == "ayah")
                {
                    chkHubungan1.Checked = true;
                }
                else if (dv[0]["hubunganpenanggungjawab"].ToString().ToLower() == "ibu")
                {
                    chkHubungan2.Checked = true;
                }
                else if (dv[0]["hubunganpenanggungjawab"].ToString().ToLower() == "saudara kandung")
                {
                    chkHubungan3.Checked = true;
                }
                else if (dv[0]["hubunganpenanggungjawab"].ToString().ToLower() == "lainnya")
                {
                    chkHubungan4.Checked = true;
                }

                XRCheckBox chkInformasi1 = this.FindControl("chkInformasi1", true) as XRCheckBox;
                XRCheckBox chkInformasi2 = this.FindControl("chkInformasi2", true) as XRCheckBox;
                XRCheckBox chkInformasi3 = this.FindControl("chkInformasi3", true) as XRCheckBox;
                XRCheckBox chkInformasi4 = this.FindControl("chkInformasi4", true) as XRCheckBox;
                XRCheckBox chkInformasi5 = this.FindControl("chkInformasi5", true) as XRCheckBox;
                if (dv[0]["informasidiperoleh"].ToString().ToLower() == "iklan tv")
                {
                    chkInformasi1.Checked = true;
                }
                else if (dv[0]["informasidiperoleh"].ToString().ToLower() == "koran")
                {
                    chkInformasi2.Checked = true;
                }
                else if (dv[0]["informasidiperoleh"].ToString().ToLower() == "radio")
                {
                    chkInformasi3.Checked = true;
                }
                else if (dv[0]["informasidiperoleh"].ToString().ToLower() == "sosialisasi ke sekolah")
                {
                    chkInformasi4.Checked = true;
                }
                else if (dv[0]["informasidiperoleh"].ToString().ToLower() == "lainnya")
                {
                    chkInformasi5.Checked = true;
                }
            }
            else if (reportName == "rptKartuUjian.repx")
            {
                XRPictureBox pictureBox2 = this.FindControl("pictureBox2", true) as XRPictureBox;
                if (pictureBox2 != null)
                {
                    DataTable dt = this.DataSource as DataTable;
                    if (Convert.ToString(dt.Rows[0]["photo"]) != "")
                    {
                        pictureBox2.ImageUrl = @"http://registrasi.polibatam.ac.id/images/photos/" + Convert.ToString(dt.Rows[0]["photo"]);
                    }
                }
            }
            else if (reportName == "rptSlipGaji")
            {
                #region Slip Gaji
                DataSet dsReport = DataSource as DataSet;
                if (dsReport != null)
                {
                    DataTable dttbp_gaji = dsReport.Tables["tbp_gaji"];
                    if (dttbp_gaji != null)
                    {
                        if (Convert.ToString(dttbp_gaji.Rows[0]["diberikan"]).ToLower() == "tunai")
                        {
                            XRCheckBox chkTunai = this.FindControl("chkTunai", true) as XRCheckBox;
                            if (chkTunai != null)
                            {
                                chkTunai.Checked = true;
                            }
                        }
                        if (Convert.ToString(dttbp_gaji.Rows[0]["diberikan"]).ToLower() == "transfer")
                        {
                            XRCheckBox chkTransfer = this.FindControl("chkTransfer", true) as XRCheckBox;
                            chkTransfer.Checked = true;
                        }

                        XRTableCell tcTunjMengajar = this.FindControl("tcTunjMengajar", true) as XRTableCell;
                        if (tcTunjMengajar != null)
                        {
                            if (Convert.ToString(dttbp_gaji.Rows[0]["jenis_tenaga"]).ToLower() == "tenaga pendidik")
                            {
                                tcTunjMengajar.Text = "Tunj. Mengajar";
                            }
                            else
                            {
                                tcTunjMengajar.Text = "Tunj. Kerajinan";
                            }
                        }
                    }

                    #region TblPotongan
                    XRTable tblPotongan = this.FindControl("tblPotongan", true) as XRTable;
                    if (tblPotongan != null)
                    {
                        DataTable dtPotongan = dsReport.Tables["dtpotongan"];
                        if (dtPotongan != null)
                        {
                            decimal decJumlah = 0;
                            for (int i = 0; i < dtPotongan.Rows.Count; i++)
                            {
                                decimal decOut = 0; decimal.TryParse(dtPotongan.Rows[i]["jumlah_potongan"].ToString(), out decOut);
                                if (i == 0)
                                {
                                    tblPotongan.Rows[1].Cells[2].Text = dtPotongan.Rows[i]["namapotongan"].ToString();
                                    tblPotongan.Rows[1].Cells[3].Text = "Rp";
                                    tblPotongan.Rows[1].Cells[4].Text = decOut.ToString("#,##0");
                                    if (i == dtPotongan.Rows.Count - 1)
                                    {
                                        tblPotongan.Rows[1].Cells[2].Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tblPotongan.Rows[1].Cells[3].Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tblPotongan.Rows[1].Cells[4].Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                    }
                                }
                                else
                                {
                                    XRTableCell tc0 = new XRTableCell();
                                    tc0.WidthF = tblPotongan.Rows[1].Cells[0].WidthF;

                                    XRTableCell tc1 = new XRTableCell();
                                    tc1.WidthF = tblPotongan.Rows[1].Cells[1].WidthF;

                                    XRTableCell tc2 = new XRTableCell();
                                    tc2.WidthF = tblPotongan.Rows[1].Cells[2].WidthF;
                                    tc2.Text = dtPotongan.Rows[i]["namapotongan"].ToString();

                                    XRTableCell tc3 = new XRTableCell();
                                    tc3.WidthF = tblPotongan.Rows[1].Cells[3].WidthF;
                                    tc3.Text = "Rp";

                                    XRTableCell tc4 = new XRTableCell();
                                    tc4.WidthF = tblPotongan.Rows[1].Cells[4].WidthF;
                                    tc4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
                                    tc4.Text = decOut.ToString("#,##0");

                                    XRTableCell tc5 = new XRTableCell();
                                    tc5.WidthF = tblPotongan.Rows[1].Cells[5].WidthF;

                                    XRTableRow tr1 = new XRTableRow();
                                    tr1.Cells.AddRange(new XRTableCell[] { tc0, tc1, tc2, tc3, tc4, tc5 });
                                    tr1.HeightF = tblPotongan.Rows[1].HeightF;

                                    if (i == dtPotongan.Rows.Count - 1)
                                    {
                                        tc2.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tc3.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tc4.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                    }
                                    tblPotongan.Rows.Add(tr1);
                                }
                                decJumlah += decOut;
                            }
                            XRTableCell tc0_ = new XRTableCell();
                            tc0_.WidthF = tblPotongan.Rows[1].Cells[0].WidthF;

                            XRTableCell tc1_ = new XRTableCell();
                            tc1_.WidthF = tblPotongan.Rows[1].Cells[1].WidthF;

                            XRTableCell tc2_ = new XRTableCell();
                            tc2_.WidthF = tblPotongan.Rows[1].Cells[2].WidthF;
                            tc2_.Text = "Jumlah";
                            tc2_.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;

                            XRTableCell tc3_ = new XRTableCell();
                            tc3_.WidthF = tblPotongan.Rows[1].Cells[3].WidthF;
                            tc3_.Text = "Rp";

                            XRTableCell tc4_ = new XRTableCell();
                            tc4_.WidthF = tblPotongan.Rows[1].Cells[4].WidthF;
                            tc4_.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
                            tc4_.Text = decJumlah.ToString("#,##0");

                            tc3_.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                            tc4_.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                            tc3_.BorderDashStyle = DevExpress.XtraPrinting.BorderDashStyle.Double;
                            tc4_.BorderDashStyle = DevExpress.XtraPrinting.BorderDashStyle.Double;
                            tc3_.BorderWidth = 2;
                            tc4_.BorderWidth = 2;

                            XRTableCell tc5_ = new XRTableCell();
                            tc5_.WidthF = tblPotongan.Rows[1].Cells[5].WidthF;

                            XRTableRow tr1_ = new XRTableRow();
                            tr1_.Cells.AddRange(new XRTableCell[] { tc0_, tc1_, tc2_, tc3_, tc4_, tc5_ });
                            tr1_.HeightF = tblPotongan.Rows[1].HeightF;

                            tblPotongan.Rows.Add(tr1_);
                        }
                    }
                    #endregion

                    #region TblTambahan
                    XRTable tblTambahan = this.FindControl("tblTambahan", true) as XRTable;
                    if (tblTambahan != null)
                    {
                        DataTable dtTambahan = dsReport.Tables["dttambahan"];
                        if (dtTambahan != null)
                        {
                            decimal decJumlah = 0;
                            for (int i = 0; i < dtTambahan.Rows.Count; i++)
                            {
                                decimal decOut = 0; decimal.TryParse(dtTambahan.Rows[i]["jumlah_tambahan"].ToString(), out decOut);
                                if (i == 0)
                                {
                                    tblTambahan.Rows[3].Cells[3].Text = dtTambahan.Rows[i]["namatambahan"].ToString();
                                    tblTambahan.Rows[3].Cells[4].Text = "Rp";
                                    tblTambahan.Rows[3].Cells[5].Text = decOut.ToString("#,##0");
                                    if (i == dtTambahan.Rows.Count - 1)
                                    {
                                        tblTambahan.Rows[3].Cells[3].Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tblTambahan.Rows[3].Cells[4].Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tblTambahan.Rows[3].Cells[5].Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                    }
                                }
                                else
                                {
                                    XRTableCell tc0 = new XRTableCell();
                                    tc0.WidthF = tblTambahan.Rows[3].Cells[0].WidthF;

                                    XRTableCell tc1 = new XRTableCell();
                                    tc1.WidthF = tblTambahan.Rows[3].Cells[1].WidthF;

                                    XRTableCell tc2 = new XRTableCell();
                                    tc2.WidthF = tblTambahan.Rows[3].Cells[2].WidthF;

                                    XRTableCell tc3 = new XRTableCell();
                                    tc3.WidthF = tblTambahan.Rows[3].Cells[3].WidthF;
                                    tc3.Text = dtTambahan.Rows[i]["namatambahan"].ToString();

                                    XRTableCell tc4 = new XRTableCell();
                                    tc4.WidthF = tblTambahan.Rows[3].Cells[4].WidthF;
                                    tc4.Text = "Rp";

                                    XRTableCell tc5 = new XRTableCell();
                                    tc5.WidthF = tblTambahan.Rows[3].Cells[5].WidthF;
                                    tc5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
                                    tc5.Text = decOut.ToString("#,##0");

                                    XRTableCell tc6 = new XRTableCell();
                                    tc6.WidthF = tblTambahan.Rows[3].Cells[6].WidthF;

                                    XRTableRow tr1 = new XRTableRow();
                                    tr1.Cells.AddRange(new XRTableCell[] { tc0, tc1, tc2, tc3, tc4, tc5, tc6 });
                                    tr1.HeightF = tblTambahan.Rows[3].HeightF;

                                    if (i == dtTambahan.Rows.Count - 1)
                                    {
                                        tc3.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tc4.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                        tc5.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                                    }
                                    tblTambahan.Rows.Add(tr1);
                                }
                                decJumlah += decOut;
                            }

                            DataTable dtGaji = dsReport.Tables["tbp_gaji"];
                            decimal decOut1 = 0; decimal.TryParse(Convert.ToString(dtGaji.Rows[0]["tunj_kelebihan_mengajar"]), out decOut1);
                            decJumlah += decOut1;

                            XRTableCell tc0_ = new XRTableCell();
                            tc0_.WidthF = tblTambahan.Rows[3].Cells[0].WidthF;

                            XRTableCell tc1_ = new XRTableCell();
                            tc1_.WidthF = tblTambahan.Rows[3].Cells[1].WidthF;

                            XRTableCell tc2_ = new XRTableCell();
                            tc2_.WidthF = tblTambahan.Rows[3].Cells[2].WidthF;

                            XRTableCell tc3_ = new XRTableCell();
                            tc3_.WidthF = tblTambahan.Rows[3].Cells[3].WidthF;
                            tc3_.Text = "Jumlah";
                            tc3_.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;

                            XRTableCell tc4_ = new XRTableCell();
                            tc4_.WidthF = tblTambahan.Rows[3].Cells[4].WidthF;
                            tc4_.Text = "Rp";

                            XRTableCell tc5_ = new XRTableCell();
                            tc5_.WidthF = tblTambahan.Rows[3].Cells[5].WidthF;
                            tc5_.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleRight;
                            tc5_.Text = decJumlah.ToString("#,##0");

                            tc4_.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                            tc5_.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
                            tc4_.BorderDashStyle = DevExpress.XtraPrinting.BorderDashStyle.Double;
                            tc5_.BorderDashStyle = DevExpress.XtraPrinting.BorderDashStyle.Double;
                            tc4_.BorderWidth = 2;
                            tc5_.BorderWidth = 2;

                            XRTableCell tc6_ = new XRTableCell();
                            tc6_.WidthF = tblTambahan.Rows[3].Cells[6].WidthF;

                            XRTableRow tr1_ = new XRTableRow();
                            tr1_.Cells.AddRange(new XRTableCell[] { tc0_, tc1_, tc2_, tc3_, tc4_, tc5_, tc6_ });
                            tr1_.HeightF = tblTambahan.Rows[3].HeightF;

                            tblTambahan.Rows.Add(tr1_);
                        }
                    }
                    #endregion
                }
                #endregion
            }
        }

        private void Detail_BeforePrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            if (reportName == "rptProjectControl" || reportName == "rptprojectcontrol_physicalprogress")
            {
                #region "Project Control"
                XRTable xrTable1 = Detail.Controls["table1"] as XRTable;

                #region HEADER
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].Text = "Document No";
                //Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].WidthF = 200;

                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;
                //Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].WidthF = 300;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].Text = "Description";

                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].WidthF = 80;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;

                for (int i = 0; i < maxGate + 2; i++)
                {
                    XRTableCell tableCell = new XRTableCell();

                    tableCell.Name = "tableCell_" + i;
                    tableCell.Text = "";
                    if (i == maxGate)
                        tableCell.WidthF = 300;
                    else
                        tableCell.WidthF = 130;

                    tableCell.Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;
                    tableCell.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;

                    xrTable1.SuspendLayout();
                    xrTable1.WidthF = xrTable1.WidthF + tableCell.Width;
                    xrTable1.Rows[0].Cells.Add(tableCell);
                    xrTable1.PerformLayout();

                    #region "Table In Cell"
                    XRTable tableDetail = new XRTable();
                    tableDetail.SuspendLayout();
                    tableDetail.Name = "tableDetail_" + i;
                    tableDetail.BorderWidth = 1;
                    tableDetail.Borders = DevExpress.XtraPrinting.BorderSide.None;
                    tableDetail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
                    tableDetail.WidthF = tableCell.WidthF;
                    XRTableRow tableRow = new XRTableRow();
                    tableRow.Name = "tableRow_" + i;
                    XRTableRow tableRow1 = new XRTableRow();
                    tableRow1.Name = "tableRow1_" + i;

                    tableDetail.Rows.Add(tableRow);
                    tableDetail.Rows.Add(tableRow1);

                    XRTableCell tableCellGate = new XRTableCell();
                    tableCellGate.Name = "gate_" + i;
                    tableCellGate.Text = "gate_" + i;
                    tableCellGate.WidthF = tableDetail.WidthF;

                    XRTableCell tableCell2 = new XRTableCell();
                    tableCell2.Name = "actual_" + i;
                    tableCell2.Text = "Actual";
                    tableCell2.WidthF = tableDetail.WidthF;

                    tableRow.Cells.Add(tableCellGate);
                    tableRow1.Cells.Add(tableCell2);

                    #endregion
                    if (i < dv1.Count && i < maxGate)
                    {
                        tableCellGate.Text = dv1[i]["gatetypedesc"].ToString() + " (" + dv1[i]["wtg"].ToString() + ")";
                        //tableCellGate.BackColor = getColorGate(dv1.Count, i);
                        tableCellGate.BackColor = Color.White;

                        tableCell.Controls.Add(tableDetail);
                    }
                    else if (i == maxGate)
                    {

                        #region "Table In Cell"

                        XRTableCell tableCell1 = new XRTableCell();
                        tableCell1.Name = "plan_" + i;
                        tableCell1.Text = "Actual Gate %";
                        tableCell1.WidthF = 100;

                        tableCell2.Text = "Adjustment %";
                        tableCell2.WidthF = 100;

                        XRTableCell tableCell3 = new XRTableCell();
                        tableCell3.Name = "forecast_" + i;
                        tableCell3.Text = "Reported %";
                        tableCell3.WidthF = 100;

                        tableRow1.Cells.Add(tableCell1);
                        tableRow1.Cells.Add(tableCell3);
                        tableCell1.Index = 0;
                        tableCell2.Index = 1;
                        tableCell3.Index = 2;

                        #endregion

                        tableCellGate.Text = "Progress";
                        tableCellGate.BackColor = Color.White;

                        tableCell.Controls.Add(tableDetail);

                    }
                    else if (i == maxGate + 1)
                    {
                        tableCell.Text = "Remarks";
                        tableCell.WidthF = 150;
                        if (reportNameReal == "nondeliverables")
                        {
                            tableCell.WidthF = 300;
                        }
                        tableCell.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
                        tableCell.BackColor = Color.White;

                    }
                    tableDetail.PerformLayout();
                }

                #region "Re-Arrange control if margin higher than paper's width"
                XRCrossBandControl crossBandBox1 = this.CrossBandControls["crossBandBox1"] as XRCrossBandControl;
                if (crossBandBox1 != null)
                {
                    if (crossBandBox1.WidthF < xrTable1.WidthF)
                    {
                        crossBandBox1.SuspendLayout();
                        crossBandBox1.WidthF = xrTable1.WidthF;
                        crossBandBox1.PerformLayout();

                        XRTableCell tableCellDivisionDesc = this.FindControl("tableCellDivisionDesc", true) as XRTableCell;
                        if (tableCellDivisionDesc != null)
                        {
                            XRTable table6 = this.FindControl("table6", true) as XRTable;
                            if (table6 != null)
                            {
                                tableCellDivisionDesc.WidthF = xrTable1.WidthF - (table6.WidthF - tableCellDivisionDesc.WidthF + 1);

                            }
                        }

                        XRTable tableHeader = this.FindControl("tableHeader", true) as XRTable;
                        if (tableHeader != null)
                            tableHeader.WidthF = xrTable1.WidthF;

                        XRTableCell tableCellDepartmentDesc = this.FindControl("tableCellDepartmentDesc", true) as XRTableCell;
                        if (tableCellDepartmentDesc != null)
                        {
                            XRTable table5 = this.FindControl("table5", true) as XRTable;
                            if (table5 != null)
                                tableCellDepartmentDesc.WidthF = xrTable1.WidthF - (table5.WidthF - tableCellDepartmentDesc.WidthF + 1);
                        }
                        XRTableCell tableCellMilestoneTypeDesc = this.FindControl("tableCellMilestoneTypeDesc", true) as XRTableCell;
                        if (tableCellMilestoneTypeDesc != null)
                        {
                            XRTable table2 = this.FindControl("table2", true) as XRTable;
                            if (table2 != null)
                                tableCellMilestoneTypeDesc.WidthF = xrTable1.WidthF - (table2.WidthF - tableCellMilestoneTypeDesc.WidthF + 1);
                        }

                        XRTableCell tableCellCtrDesc = this.FindControl("tableCellCtrDesc", true) as XRTableCell;
                        if (tableCellCtrDesc != null)
                        {
                            XRTable tableCtr = this.FindControl("tableCtr", true) as XRTable;
                            if (tableCtr != null)
                                tableCellCtrDesc.WidthF = xrTable1.WidthF - (tableCtr.WidthF - tableCellCtrDesc.WidthF + 1);
                        }
                        //XRTableCell tableCellPhysProgress = this.FindControl("tableCellPhysProgress", true) as XRTableCell;
                        //if (tableCellPhysProgress != null)
                        //{
                        //    XRTable tableCtrFooter = this.FindControl("tableCtrFooter", true) as XRTable;
                        //    if (tableCtrFooter != null)
                        //        tableCellPhysProgress.WidthF = xrTable1.WidthF - (tableCtrFooter.WidthF - tableCellPhysProgress.WidthF + 1);
                        //}

                        XRLine linePageFooter = this.FindControl("linePageFooter", true) as XRLine;
                        if (linePageFooter != null)
                            linePageFooter.WidthF = xrTable1.WidthF;
                    }
                }
                #endregion "Re-Arrange control if margin higher than paper width"

                #endregion
                #endregion
            }
        }

        private void printReportProjectControl(object sender, DataSourceRowEventArgs e)
        {

            XRTable xrTable1 = Detail.Controls["table1"] as XRTable;
            XRTableRow xrTableRow1 = Detail.Controls["table1"].Controls["tableRow1"] as XRTableRow;

            dv1.RowFilter = "divisionid='" + dv[e.CurrentRow]["divisionid"].ToString() + @"'
                            and departmentid='" + dv[e.CurrentRow]["departmentid"].ToString() + @"'
                            and milestonetypeid='" + dv[e.CurrentRow]["milestonetypeid"].ToString() + "'";

            int intGateCount = dv1.Count;
            if (dv[e.CurrentRow]["documentid"].ToString() == "")
            {

                #region HEADER
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].Padding = 0;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].Text = "Document No";

                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].Text = "Description";

                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;

                string strText = "";

                for (int i = 0; i < maxGate + 2; i++)
                {
                    XRTableCell tableCell = this.FindControl("tableCell_" + i, true) as XRTableCell;
                    XRTableCell tableCellGate = this.FindControl("gate_" + i, true) as XRTableCell;
                    if (tableCellGate != null)
                    {
                        tableCellGate.Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;

                        if (i < dv1.Count && i < maxGate)
                        {
                            strText = dv1[i]["gatetypedesc"].ToString() + " (" + dv1[i]["wtg"].ToString() + ")";
                            tableCellGate.Text = strText;
                            //tableCellGate.BackColor = getColorGate(dv1.Count, i);
                            tableCellGate.BackColor = Color.White;
                            tableCellGate.ForeColor = Color.Black;
                        }
                        else if (i == maxGate)
                        {
                            tableCellGate.Text = "Progress";
                            tableCellGate.BackColor = Color.White;
                            tableCellGate.ForeColor = Color.Black;
                        }
                        else if (i >= intGateCount && i < maxGate)
                        {
                            tableCellGate.BackColor = Color.White;
                            tableCellGate.Text = "TEST";
                            tableCellGate.ForeColor = Color.Transparent;
                            //tableCellGate.Borders = DevExpress.XtraPrinting.BorderSide.None;
                        }


                    }
                    else
                    {

                        XRTable tableDetail = this.FindControl("tableDetail_" + i, true) as XRTable;
                        if (tableDetail != null)
                        {
                            tableDetail.BeginInit();

                            XRTableRow tableRow = new XRTableRow();
                            tableRow.Name = "tableRow_" + i;
                            XRTableRow tableRow1 = new XRTableRow();
                            tableRow1.Name = "tableRow1_" + i;

                            tableDetail.Rows.Insert(0, tableRow);
                            tableCellGate = new XRTableCell();
                            tableCellGate.Name = "gate_" + i;
                            if (i < dv1.Count && i < maxGate)
                            {
                                tableCellGate.Text = dv1[i]["gatetypedesc"].ToString() + " (" + dv1[i]["wtg"].ToString() + ")";
                                tableCellGate.ForeColor = Color.Black;
                            }
                            else if (i == maxGate)
                            {
                                tableCellGate.Text = "Progress";
                                tableCellGate.BackColor = Color.White;
                                tableCellGate.ForeColor = Color.Black;
                            }
                            else if (i >= intGateCount && i < maxGate)
                            {
                                tableCellGate.Text = "TEST";
                                tableCellGate.ForeColor = Color.Transparent;
                            }
                            tableCellGate.Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellGate.BackColor = Color.White;
                            tableRow.Cells.Add(tableCellGate);

                            tableDetail.EndInit();
                            //    else if (i >= intGateCount)
                            //{
                            //    tableCellGate.BackColor = Color.White;
                            //    //tableCellGate.Borders =   DevExpress.XtraPrinting.BorderSide.None;
                            //    tableCellGate.Text = "";
                            //}

                        }
                    }

                    XRTableCell tableCellActual = this.FindControl("actual_" + i, true) as XRTableCell;
                    if (tableCellActual != null)
                    {
                        tableCellActual.Borders = DevExpress.XtraPrinting.BorderSide.Bottom | DevExpress.XtraPrinting.BorderSide.Left;
                        tableCellActual.Text = "Actual";
                        if (i < dv1.Count && i < maxGate)
                        {
                            //tableCellActual.BackColor = getColorGate(dv1.Count, i);
                            tableCellActual.BackColor = Color.White;
                            tableCellActual.ForeColor = Color.Black;
                        }
                        else if (i == maxGate)
                        {
                            tableCellActual.Text = "Adjustment %";
                            tableCellGate.BackColor = Color.White;
                            tableCellGate.ForeColor = Color.Black;
                        }
                        else if (i >= intGateCount && i < maxGate)
                        {
                            tableCellActual.BackColor = Color.White;
                            //tableCellActual.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellActual.ForeColor = Color.Transparent;
                        }

                    }

                    if (i == maxGate)
                    {
                        XRTableCell tableCellPlan = this.FindControl("plan_" + i, true) as XRTableCell;
                        if (tableCellPlan != null)
                        {
                            tableCellPlan.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellPlan.Text = "Actual Gate %";
                            tableCellPlan.BackColor = Color.White;
                            tableCellPlan.ForeColor = Color.Black;
                        }

                        if (tableCellActual != null)
                        {
                            tableCellActual.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellActual.Text = "Adjustment %";
                            tableCellActual.BackColor = Color.White;
                            tableCellActual.ForeColor = Color.Black;
                        }

                        XRTableCell tableCellForecast = this.FindControl("forecast_" + i, true) as XRTableCell;
                        if (tableCellForecast != null)
                        {
                            tableCellForecast.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellForecast.Text = "Reported %";
                            tableCellForecast.BackColor = Color.White;
                            tableCellForecast.ForeColor = Color.Black;
                        }

                    }
                    else if (i == maxGate + 1)
                    {
                        XRTableCell tableCellRemark = this.FindControl("tableCell_" + i, true) as XRTableCell;
                        if (tableCellRemark != null)
                        {
                            tableCellRemark.Text = "Remark";
                            tableCellRemark.BackColor = Color.White;
                            tableCell.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
                        }

                        XRTableRow tableRow = this.FindControl("tableRow_" + i, true) as XRTableRow;
                        if (tableRow != null)
                        {
                            tableRow.Text = "Remark";
                            tableRow.BackColor = Color.White;
                            tableRow.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
                        }
                    }

                }

                #endregion "HEADER"
            }
            else
            {

                #region DETAIL

                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentcode"].Padding = 10;

                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;

                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].BackColor = Color.White;
                Detail.Controls["table1"].Controls["tableRow1"].Controls["revcode"].TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
                string strText = "";
                DateTime dt;
                for (int i = 0; i < maxGate + 2; i++)
                {
                    XRTableCell tableCell = this.FindControl("tableCell_" + i, true) as XRTableCell;
                    tableCell.BackColor = Color.White;

                    XRTableCell tableCellActual = this.FindControl("actual_" + i, true) as XRTableCell;
                    if (tableCellActual != null)
                    {
                        tableCellActual.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                        tableCellActual.BackColor = Color.White;

                        if (i < dv1.Count && i < maxGate)
                        {
                            //if (!DateTime.TryParse(dv[e.CurrentRow]["actual_" + i].ToString(), out dt))
                            //    dt = DateTime.MinValue;
                            //tableCellActual.Text = (dt == DateTime.MinValue ? " " : dt.ToString("dd-MMM-yyyy"));
                            tableCellActual.Text = Convert.ToString(dv[e.CurrentRow]["actual_" + i]);
                            //tableCellActual.BackColor = getColorGate(dv1.Count, i);
                        }
                        else if (i >= intGateCount && i < maxGate)
                        {
                            tableCellActual.Text = "";
                        }

                    }

                    if (i == maxGate)
                    {
                        XRTableCell tableCellPlan = this.FindControl("plan_" + i, true) as XRTableCell;
                        if (tableCellPlan != null)
                        {
                            tableCellPlan.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellPlan.BackColor = Color.White;
                            tableCellPlan.Text = (dv[e.CurrentRow]["actual_" + dv1.Count].ToString() == "" ? " " : dv[e.CurrentRow]["actual_" + dv1.Count].ToString());
                        }

                        if (tableCellActual != null)
                        {
                            tableCellActual.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellActual.BackColor = Color.White;
                            tableCellActual.Text = (dv[e.CurrentRow]["actual_" + (dv1.Count + 1)].ToString() == "" ? " " : dv[e.CurrentRow]["actual_" + (dv1.Count + 1)].ToString());
                        }

                        XRTableCell tableCellForecast = this.FindControl("forecast_" + i, true) as XRTableCell;
                        if (tableCellForecast != null)
                        {
                            tableCellForecast.Borders = DevExpress.XtraPrinting.BorderSide.Left;
                            tableCellForecast.BackColor = Color.White;
                            tableCellForecast.Text = (dv[e.CurrentRow]["actual_" + (dv1.Count + 2)].ToString() == "" ? " " : dv[e.CurrentRow]["actual_" + (dv1.Count + 2)].ToString());

                        }

                    }
                    else if (i == maxGate + 1)
                    {
                    }

                    XRTableCell tableCellGate = this.FindControl("gate_" + i, true) as XRTableCell;
                    if (tableCellGate != null)
                    {
                        XRTableRow tableRow = this.FindControl("tableRow_" + i, true) as XRTableRow;
                        if (tableRow != null)
                        {
                            XRTable tableDetail = this.FindControl("tableDetail_" + i, true) as XRTable;
                            if (tableDetail != null)
                            {
                                tableDetail.Rows.Remove(tableRow);
                                XRTableRow tableRow1 = this.FindControl("tableRow1_" + i, true) as XRTableRow;


                                if (tableRow1 != null)
                                    tableRow1.HeightF = Detail.Controls["table1"].Controls["tableRow1"].Controls["documentdesc"].HeightF + 10;

                            }
                            tableRow.Cells.RemoveAt(tableCellGate.Index);
                        }

                    }

                    if (tableCell != null)
                    {
                        tableCell.BackColor = Color.White;
                        tableCell.Borders = DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom;
                        if (i == maxGate + 1)
                        {
                            tableCell.Text = dv[e.CurrentRow]["remarks"].ToString();
                            tableCell.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
                        }

                    }
                }

                #endregion
            }

        }
    }
}
