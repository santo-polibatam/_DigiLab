﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.XtraEditors;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Drawing;
using DevExpress.XtraEditors.DXErrorProvider;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

using DevExpress.Utils;

namespace DIGILIB.Honor
{
    public partial class userControlReports : UserControl
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;

        List<String> workpackid_CopyList = new List<String>();
        int idxpaste = 0;
        private DataTable dtData, dtKaryawan, dtProdi, dtMK;
        private DataView filteredDataView;

        public userControlReports()
        {

            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            initgroupControl1_height = groupControl1.Height;
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
        public void refreshAll()
        {

            //loadData();
            treeList1.ExpandAll();
            getPenandaTangan();
            loadRepository();
            //clsRepository oRepository = new clsRepository();
            //lookUpEditBahanAjar.Properties.DataSource = oRepository.GetDataJenisBahanAjar();
            //lookUpEditBahanAjar.Properties.ValueMember = "pkid";
            //lookUpEditBahanAjar.Properties.DisplayMember = "deskripsi";

            //lookUpEditJenisUjian.Properties.DataSource =  oRepository.GetDataJenisUjian();
            //lookUpEditJenisUjian.Properties.ValueMember = "pkid";
            //lookUpEditJenisUjian.Properties.DisplayMember = "deskripsi";

            //lookUpEditModul.Properties.DataSource = oRepository.GetDataModul_lib();
            //lookUpEditModul.Properties.ValueMember = "pkid";
            //lookUpEditModul.Properties.DisplayMember = "deskripsi";
        }
        private DataTable getData()
        {
            setLoadDialog(true, "Loading data...");
            DataTable dt = new DataTable();
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string s_where = "";
                    string s_headerperiode = "";
                    int intx_bulan = 0;
                    string switch_on = Convert.ToString(treeList1.FocusedNode[treeListColumn1]);
                    string s_FocusedNode = switch_on;
                    if (treeList1.FocusedNode.Level == 2)
                    {
                        switch_on = Convert.ToString(treeList1.FocusedNode.ParentNode[treeListColumn1]);
                    }
                    if (chkFilterPeriode.Visible && (chkFilterPeriode.Checked && chkFilterPeriode.Enabled))
                    {
                        #region
                        switch (Convert.ToString(optPeriode.EditValue).ToLower())
                        {
                            case "tanggal":
                                {
                                    DateTime myDate1 = Convert.ToDateTime(dateTanggal1.EditValue);
                                    DateTime myDate2 = Convert.ToDateTime(dateTanggal2.EditValue);
                                    //if (switch_on == "Honor Dosen Wali")
                                    //{
                                    //    intx_bulan = (myDate2.Month - myDate1.Month) + 12 * (myDate2.Year - myDate1.Year);
                                    //    intx_bulan += 1;
                                    //    x_where = " and getTahunBulan(det.tanggalselesai)>=getTahunBulan('" + myDate1.ToString("yyyy-MM-dd") + "') and getTahunBulan('" + myDate2.ToString("yyyy-MM-dd") + "') >=getTahunBulan(det.tanggalmulai) ";
                                    //}
                                    //else
                                    //{
                                    if (dateTanggal2.Enabled && dateTanggal2.EditValue != null)
                                    {
                                        s_where = " and tglditerima::date>='" + myDate1.ToString("yyyy-MM-dd") + "' and tglditerima::date<='" + myDate2.ToString("yyyy-MM-dd") + "'";
                                        s_headerperiode = "Periode : " + myDate1.ToString("dd-MMM-yyyy") + " s/d " + myDate2.ToString("dd-MMM-yyyy");
                                    }
                                    else if (dateTanggal1.Enabled && dateTanggal1.EditValue != null)
                                    {
                                        s_where = " and tglditerima::date ='" + myDate1.ToString("yyyy-MM-dd") + "'";
                                        s_headerperiode = "Periode : " + myDate1.ToString("dd-MMM-yyyy");
                                    }
                                    //}
                                    break;
                                }
                            case "bulan":
                                {

                                    if (lookUpEditBulan2.Enabled && lookUpEditBulan2.EditValue != null)
                                    {
                                        s_where = " and getTahunBulan(tglditerima::date)>='" + Convert.ToString(lookUpEditBulan1.EditValue) + "' and getTahunBulan(tglditerima::date)<='" + Convert.ToString(lookUpEditBulan2.EditValue) + "'";
                                        s_headerperiode = "Periode : " + Convert.ToString(lookUpEditBulan1.Text) + " s/d " + Convert.ToString(lookUpEditBulan2.Text);
                                    }
                                    else if (lookUpEditBulan1.Enabled && lookUpEditBulan1.EditValue != null)
                                    {
                                        s_where = " and getTahunBulan(tglditerima::date)='" + Convert.ToString(lookUpEditBulan1.EditValue) + "'";
                                        s_headerperiode = "Periode : " + Convert.ToString(lookUpEditBulan1.Text);
                                    }
                                    break;
                                }
                            case "tahun":
                                {
                                    if (lookUpEditTahun2.Enabled && lookUpEditTahun2.EditValue != null)
                                    {
                                        s_where = " and EXTRACT(YEAR FROM tglditerima::date)::int>='" + Convert.ToString(lookUpEditTahun1.EditValue) + "' and EXTRACT(YEAR FROM tglditerima::date)::int<='" + Convert.ToString(lookUpEditTahun2.EditValue) + "'";
                                        s_headerperiode = "Periode : " + Convert.ToString(lookUpEditTahun1.Text) + " s/d " + Convert.ToString(lookUpEditTahun2.Text);
                                    }
                                    else if (lookUpEditTahun1.Enabled && lookUpEditTahun1.EditValue != null)
                                    {
                                        s_where = " and EXTRACT(YEAR FROM tglditerima::date)::int>='" + Convert.ToString(lookUpEditTahun1.EditValue) + "'";
                                        s_headerperiode = "Periode : " + Convert.ToString(lookUpEditTahun1.Text);
                                    }
                                    break;
                                }
                        }
                        #endregion
                    }
                    if (pnlRepository.Visible && cboStatusDenda.Visible == false)
                    {
                        #region
                        if (lookUpEditStatusActive.Enabled && Convert.ToString(lookUpEditStatusActive.EditValue) != "")
                        {
                            s_where += " and a.statusaktif='" + Convert.ToString(lookUpEditStatusActive.EditValue) + "'";
                        }
                        #endregion
                    }

                    //if ( Convert.ToString(lookUpEditTA.EditValue) != "")
                    //{
                    //    s_where += " and ta.tahunajaranid='"+ Convert.ToString(lookUpEditTA.EditValue) +"' ";
                    //}
                    //if (Convert.ToString(lookUpEditProdi.EditValue) != "")
                    //{
                    //    s_where += " and pro.kode='" + Convert.ToString(lookUpEditProdi.EditValue) + "' ";
                    //}
                    //if ( Convert.ToString(lookUpEditProgram.EditValue) != "")
                    //{
                    //    s_where += " and pba.program='" + Convert.ToString(lookUpEditProgram.EditValue) + "' ";
                    //}
                    //if (Convert.ToString(lookUpEditSemester.EditValue) != "")
                    //{
                    //    s_where += " and pba.semester='" + Convert.ToString(lookUpEditSemester.EditValue) + "' ";
                    //}
                    //if (lookUpEditPeriode.Visible && Convert.ToString(lookUpEditPeriode.EditValue) != "")
                    //{
                    //    s_where += " and getMyTgl(pba.periodemulai,'dd MMMM yyyy') || ' s/d ' || getMyTgl(pba.periodesampai,'dd MMMM yyyy')='" + Convert.ToString(lookUpEditPeriode.EditValue) + "' ";
                    //}
                    //string s_judul_prodi = "";
                    //if (checkedEditProdi.Visible && Convert.ToString(checkedEditProdi.EditValue) != "")
                    //{
                    //    string[] arrProdi = Convert.ToString(checkedEditProdi.EditValue).Split(',');
                    //    s_where += string.Format(" and pba.prodiid IN ('{0}' )", String.Join("','", arrProdi).Replace(" ", ""));

                    //    s_judul_prodi = Convert.ToString(checkedEditProdi.Text).ToUpper();
                    //    int pos = s_judul_prodi.LastIndexOf(',');
                    //    if (pos > 1)
                    //    {
                    //        s_judul_prodi = s_judul_prodi.Substring(0, pos) + " dan" + s_judul_prodi.Substring(pos + 1);
                    //    }
                    //}
                    oConn.Open();
                    string strSql = "";
                    switch (switch_on)
                    {
                        case "Laporan Jumlah Anggota Mahasiswa":
                            {
                                #region
                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Anggota Perpustakaan (Mahasiswa)' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            a.anggotaid, a.rfid, a.nim, a.nama, b.prodiid, b.prodicode, b.prodidesc, b.jurusandesc,
                            a.jeniskelamin, a.alamat, a.nohp, a.keterangan, a.statusaktif
                            from tbm_anggota a
                            left outer join
                            (
	                            select aa.prodiid, aa.prodicode, aa.prodidesc, bb.jurusanid, bb.jurusancode, bb.jurusandesc
	                            from tbm_prodi aa
	                            inner join tbm_jurusan bb on aa.jurusanid=bb.jurusanid and bb.dlt='0'
	                            where aa.dlt='0'
                            ) b on a.prodiid=b.prodiid
                            where a.dlt='0' and a.jenis='Mahasiswa' " + s_where + @"
                            order by a.nim, a.nama";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Anggota Perpustakaan (Mahasiswa)' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Jumlah Anggota Tenaga Pendidik dan Tenaga Kependidikan":
                            {
                                #region
                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Anggota Perpustakaan (Tenaga Pendidik dan Tenaga Kependidikan)' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            a.anggotaid, a.rfid, a.nim, a.nama, b.prodiid, b.prodicode, b.prodidesc, b.jurusandesc,
                            a.jeniskelamin, a.alamat, a.nohp, a.keterangan, a.statusaktif
                            from tbm_anggota a
                            left outer join
                            (
	                            select aa.prodiid, aa.prodicode, aa.prodidesc, bb.jurusanid, bb.jurusancode, bb.jurusandesc
	                            from tbm_prodi aa
	                            inner join tbm_jurusan bb on aa.jurusanid=bb.jurusanid and bb.dlt='0'
	                            where aa.dlt='0'
                            ) b on a.prodiid=b.prodiid
                            where a.dlt='0' and a.jenis='Staff' " + s_where + @"
                            order by a.nim, a.nama";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Anggota Perpustakaan (Tenaga Pendidik dan Tenaga Kependidikan)' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Jumlah Koleksi Perpustakaan":
                            {
                                #region
                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Jumlah Koleksi Perpustakaan' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            a.kode_makul,
                            b.jeniskoleksi, b.jenis_barang, count(a.inventarisid) as jummlahbuku
                            from tbm_inventaris a
                            inner join tbm_buku b on a.bukuid=b.bukuid and b.dlt='0' --and lower(b.jenis_barang)='buku'
                            where a.dlt='0' " + s_where + @"
                            GROUP BY a.kode_makul,
                            b.jeniskoleksi, b.jenis_barang
                            order by a.kode_makul,
                            b.jeniskoleksi, b.jenis_barang";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Jumlah Koleksi Perpustakaan' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Transaksi Peminjaman":
                            {
                                #region
                                s_where = s_where.Replace("tglditerima", "pjdet.tglpinjam");
                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Peminjaman' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status, 
                            sum(pjdet.jumlah) as jumlah,
                            prodi.prodiid, prodi.prodicode, prodi.prodidesc, '['||prodi.prodicode||'] '||prodi.prodidesc as prodiview,
                            case when lower(ag.jenis)='staff' then 'Karyawan/Dosen'
                            else ag.jenis
                            end as jenis
                            from tblpeminjaman pj
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamanid=pj.peminjamanid and pjdet.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on bk.bukuid=inv.bukuid and bk.dlt='0'
                            inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                            left outer join
                            (
	                            select b.jurusancode, b.jurusandesc, a.prodiid, a.prodicode, a.inisial, a.prodidesc
	                            from tbm_prodi a
	                            inner join tbm_jurusan b on a.jurusanid=b.jurusanid and b.dlt='0'
	                            where a.dlt='0'
	                            order by b.jurusancode, b.jurusandesc, a.prodicode, a.inisial, a.prodidesc
                            ) prodi on ag.prodiid=prodi.prodiid
                            where pj.dlt='0' " + s_where + @"
                            group by inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status,
                            prodi.prodiid, prodi.prodicode, prodi.prodidesc, prodiview, jenis
                            order by nib, judul, jeniskoleksi";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Peminjaman' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Transaksi Pengembalian":
                            {
                                #region
                                s_where = s_where.Replace("tglditerima", "pbdet.tglkembali");
                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Pengembalian' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status, 
                            sum(pbdet.jumlah) as jumlah,
                            prodi.prodiid, prodi.prodicode, prodi.prodidesc, '['||prodi.prodicode||'] '||prodi.prodidesc as prodiview,
                            case when lower(ag.jenis)='staff' then 'Karyawan/Dosen'
                            else ag.jenis
                            end as jenis
                            from tblpengembalian pb
                            inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamandetailsid=pbdet.peminjamandetailsid and pjdet.dlt='0'
                            inner join tblpeminjaman pj on pj.peminjamanid=pjdet.peminjamanid and pj.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on inv.bukuid=bk.bukuid and bk.dlt='0'
                            inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                            left outer join
                            (
	                            select b.jurusancode, b.jurusandesc, a.prodiid, a.prodicode, a.inisial, a.prodidesc
	                            from tbm_prodi a
	                            inner join tbm_jurusan b on a.jurusanid=b.jurusanid and b.dlt='0'
	                            where a.dlt='0'
	                            order by b.jurusancode, b.jurusandesc, a.prodicode, a.inisial, a.prodidesc
                            ) prodi on ag.prodiid=prodi.prodiid
                            where pb.dlt='0' " + s_where + @"
                            group by inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status,
                            prodi.prodiid, prodi.prodicode, prodi.prodidesc, prodiview, jenis
                            order by nib, judul, jeniskoleksi
                            ";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Pengembalian' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Denda":
                            {
                                #region
                                s_where = s_where.Replace("tglditerima", "pbdet.tglkembali");
                                if (Convert.ToString(cboStatusDenda.EditValue).ToLower() == "sudah lunas")
                                {
                                    s_where += " and pbdet.dendadibayar>=pbdet.jumlahdenda ";
                                }
                                else if (Convert.ToString(cboStatusDenda.EditValue).ToLower() == "belum lunas")
                                {
                                    s_where += " and coalesce(pbdet.dendadibayar,0)<coalesce(pbdet.jumlahdenda,0) ";
                                }

                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Denda' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, 
                            ag.anggotaid, ag.rfid, ag.nim as nimanggota, ag.nama as namaanggota, ag.nim ||' - ' || ag.nama as anggota, ag.photo, ag.alamat, ag.jenis, ag.statusaktif,
                            peg.anggotaid as petugasid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, peg.photo as photopetugas,
                            pj.peminjamanid, pj.anggotaid as anggotaid_pinjam, pj.petugasid as petugasid_pinjam, pj.nopeminjaman, pj.tglpinjam, pj.tgljatuhtempo, pj.maksbukudipinjam, pj.lamapeminjaman, pj.dendaperhari,
                            pjdet.peminjamandetailsid, pjdet.jumlah, pjdet.status, pjdet.tglpinjam, pjdet.tgljatuhtempo,

                            pb.pengembalianid, pb.nopengembalian, pb.tglkembali as tglkembalimaster, pb.petugasid, pb.keterangan as keteranganmaster, pb.regno,
                            pbdet.pengembaliandetailsid, pbdet.tglkembali, pbdet.jumlah as jumlahpengembalian, pbdet.jumlahdenda, pbdet.keterangan, pbdet.dendadibayar, pbdet.status,
                            case when (pbdet.tglkembali::date-pj.tgljatuhtempo::date) <0 then 0 else (pbdet.tglkembali::date-pj.tgljatuhtempo::date) end as terlambat,
                            case when coalesce(pbdet.pengembalianid,'')='' then false else true end  as kembalikan,
                            prodi.prodiid, prodi.prodicode, prodi.prodidesc, '['||prodi.prodicode||'] '||prodi.prodidesc as prodiview,
                            (
                                case when pbdet.dendadibayar>=pbdet.jumlahdenda then 'Sudah Lunas'
                                else 'Belum Lunas'
                                end
                            ) as statusdenda
                            from tblpengembalian pb
                            inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamandetailsid=pbdet.peminjamandetailsid and pjdet.dlt='0'
                            inner join tblpeminjaman pj on pj.peminjamanid=pjdet.peminjamanid and pj.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on inv.bukuid=bk.bukuid and bk.dlt='0'
                            inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                            left outer join tbm_anggota peg on peg.anggotaid=pb.petugasid and peg.dlt='0'
                            left outer join
                            (
	                            select b.jurusancode, b.jurusandesc, a.prodiid, a.prodicode, a.inisial, a.prodidesc
	                            from tbm_prodi a
	                            inner join tbm_jurusan b on a.jurusanid=b.jurusanid and b.dlt='0'
	                            where a.dlt='0'
	                            order by b.jurusancode, b.jurusandesc, a.prodicode, a.inisial, a.prodidesc
                            ) prodi on ag.prodiid=prodi.prodiid
                            where pb.dlt='0' and pbdet.jumlahdenda > 0 " + s_where + @"
                            order by nib, judul, jeniskoleksi, nopengembalian
                            ";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Denda' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Pembayaran Denda":
                            {
                                #region
                                s_where = s_where.Replace("tglditerima", "pb.tgldendadibayar");
                                s_where += " and pbdet.dendadibayar>0 ";

                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Denda' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, 
                            ag.anggotaid, ag.rfid, ag.nim as nimanggota, ag.nama as namaanggota, ag.nim ||' - ' || ag.nama as anggota, ag.photo, ag.alamat, ag.jenis, ag.statusaktif,
                            peg.anggotaid as petugasid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, peg.photo as photopetugas,
                            pj.peminjamanid, pj.anggotaid as anggotaid_pinjam, pj.petugasid as petugasid_pinjam, pj.nopeminjaman, pj.tglpinjam, pj.tgljatuhtempo, pj.maksbukudipinjam, pj.lamapeminjaman, pj.dendaperhari,
                            pjdet.peminjamandetailsid, pjdet.jumlah, pjdet.status, pjdet.tglpinjam, pjdet.tgljatuhtempo,

                            pb.pengembalianid, pb.nopengembalian, pb.tglkembali as tglkembalimaster, pb.petugasid, pb.keterangan as keteranganmaster, pb.regno,
                            pbdet.pengembaliandetailsid, pbdet.tglkembali, pbdet.jumlah as jumlahpengembalian, pbdet.jumlahdenda, pbdet.keterangan, pbdet.dendadibayar, pbdet.status,
                            case when (pbdet.tglkembali::date-pj.tgljatuhtempo::date) <0 then 0 else (pbdet.tglkembali::date-pj.tgljatuhtempo::date) end as terlambat,
                            case when coalesce(pbdet.pengembalianid,'')='' then false else true end  as kembalikan,
                            prodi.prodiid, prodi.prodicode, prodi.prodidesc, '['||prodi.prodicode||'] '||prodi.prodidesc as prodiview,
                            (
                                case when pbdet.dendadibayar>=pbdet.jumlahdenda then 'Sudah Lunas'
                                else 'Belum Lunas'
                                end
                            ) as statusdenda, pb.tgldendadibayar
                            from tblpengembalian pb
                            inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamandetailsid=pbdet.peminjamandetailsid and pjdet.dlt='0'
                            inner join tblpeminjaman pj on pj.peminjamanid=pjdet.peminjamanid and pj.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on inv.bukuid=bk.bukuid and bk.dlt='0'
                            inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                            left outer join tbm_anggota peg on peg.anggotaid=pb.petugasid and peg.dlt='0'
                            left outer join
                            (
	                            select b.jurusancode, b.jurusandesc, a.prodiid, a.prodicode, a.inisial, a.prodidesc
	                            from tbm_prodi a
	                            inner join tbm_jurusan b on a.jurusanid=b.jurusanid and b.dlt='0'
	                            where a.dlt='0'
	                            order by b.jurusancode, b.jurusandesc, a.prodicode, a.inisial, a.prodidesc
                            ) prodi on ag.prodiid=prodi.prodiid
                            where pb.dlt='0' and pbdet.jumlahdenda > 0 " + s_where + @"
                            order by nib, judul, jeniskoleksi, nopengembalian
                            ";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Denda' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        case "Laporan Daftar Buku Populer":
                            {
                                #region
                                s_where = s_where.Replace("tglditerima", "a.tglpinjam");
                                tbm_anggota oObject = new tbm_anggota();
                                oObject.Koneksi = oConn.Conn;
                                strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Daftar Buku Populer' as header2,
                            " + (chkttdkiri_tampilkan.Checked ? "'" + txtttdkiri_header.Text + "' as ttdkiri_header, '" + txtttdkiri_nama.Text + "' as ttdkiri_nama, '" + txtttdkiri_footer.Text + @"' as ttdkiri_footer," : "") + @"
                            " + (chkttdtengah_tampilkan.Checked ? "'" + txtttdtengah_header.Text + "' as ttdtengah_header, '" + txtttdtengah_nama.Text + "' as ttdtengah_nama, '" + txtttdtengah_footer.Text + @"' as ttdtengah_footer," : "") + @"
                            " + (chkttdkanan_tampilkan.Checked ? "'" + txtttdkanan_header.Text + "' as ttdkanan_header, '" + txtttdkanan_nama.Text + "' as ttdkanan_nama, '" + txtttdkanan_footer.Text + @"' as ttdkanan_footer," : "") + @"
                            '" + s_headerperiode + @"' as headerperiode,
                                aa.*
                                from
                                (
		                                select d.bukuid, d.noinduk, d.kodepanggil, d.judul, d.pengarang, d.badankorporat, d.edisi, d.penerbit, d.tempatterbit, d.tahunterbit, d.isbn, 
		                                d.deskripsi, d.supplemen, d.lokasikoleksi, d.jeniskoleksi, d.keterangan, count(a.inventarisid) as jmlpinjam
		                                from tblpeminjamandetails a
		                                inner join tblpeminjaman b on a.peminjamanid=b.peminjamanid and b.dlt='0'
		                                inner join tbm_inventaris c on a.inventarisid=c.inventarisid and c.dlt='0'
		                                inner join tbm_buku d on c.bukuid=d.bukuid and d.dlt='0'
		                                where a.dlt='0' " + s_where + @"
		                                group by d.bukuid, d.noinduk, d.kodepanggil, d.judul, d.pengarang, d.badankorporat, d.edisi, d.penerbit, d.tempatterbit, d.tahunterbit, d.isbn, 
		                                d.deskripsi, d.supplemen, d.lokasikoleksi, d.jeniskoleksi, d.keterangan
                                ) aa
                                order by jmlpinjam desc, noinduk, kodepanggil, judul;";

                                dt = oObject.GetData(strSql);
                                if (dt.Rows.Count <= 0)
                                {
                                    dt = oObject.GetData("select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Daftar Buku Populer' as header2, '" + s_headerperiode + @"' as headerperiode");
                                }
                                oObject = null;
                                break;
                                #endregion
                            }
                        default:
                            { break; }
                    }

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                }
            }
            return dt;
        }

        private void treeList1_FocusedNodeChanged(object sender, DevExpress.XtraTreeList.FocusedNodeChangedEventArgs e)
        {
            //loadData();
            loadRepository();
        }
        private void loadRepository()
        {
            setLoadDialog(true, "Loading Data...");
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string switch_on = Convert.ToString(treeList1.FocusedNode[treeListColumn1]);
                    string s_FocusedNode = switch_on;
                    if (treeList1.FocusedNode.Level == 2)
                    {
                        switch_on = Convert.ToString(treeList1.FocusedNode.ParentNode[treeListColumn1]);
                    }
                    oConn.Open();
                    string strSql = "";
                    string s_tableName = "";
                    string s_fieldName = "";
                    string s_where = "";
                    lookUpEditPeriode.Visible = false;
                    labelControl17.Visible = lookUpEditPeriode.Visible;

                    chkFilterPeriode.Enabled = switch_on != "Laporan Jumlah Anggota Mahasiswa" && switch_on != "Laporan Jumlah Anggota Tenaga Pendidik dan Tenaga Kependidikan";
                    pnlFilter.Visible = chkFilterPeriode.Visible;
                    pnlFilter.Enabled = (chkFilterPeriode.Checked && chkFilterPeriode.Enabled);

                    //optPeriode.Enabled = switch_on != "Honor Dosen Wali";

                    lblRepository.Text = "Status Aktif";
                    pnlRepository.Visible = true;
                    lookUpEditModul.Visible = false;
                    lookUpEditBahanAjar.Visible = false;
                    lookUpEditStatusActive.Visible = false;
                    cboStatusDenda.Visible = false;

                    switch (switch_on)
                    {
                        case "Laporan Jumlah Anggota Mahasiswa":
                        case "Laporan Jumlah Anggota Tenaga Pendidik dan Tenaga Kependidikan":
                            {
                                lookUpEditStatusActive.Visible = true;
                                strSql = @"(select '' as statusaktif, 1 as nourut
                                union
                                select distinct statusaktif, 2 as nourut
                                from tbm_anggota
                                where dlt='0'
                                ) order by nourut, statusaktif
                                ";
                                DataTable dtStatus = oConn.GetData(strSql);
                                lookUpEditStatusActive.Properties.DataSource = dtStatus;
                                lookUpEditStatusActive.Properties.DisplayMember = "statusaktif";
                                lookUpEditStatusActive.Properties.ValueMember = "statusaktif";

                                lookUpEditStatusActive.Visible = true;
                                pnlRepository.Visible = lookUpEditStatusActive.Visible;

                                s_tableName = "";
                                s_fieldName = "";
                                break;
                            }
                        case "Laporan Transaksi Peminjaman":
                            {
                                s_tableName = "tblpeminjamandetails";
                                s_fieldName = "tglpinjam";
                                break;
                            }
                        case "Laporan Transaksi Pengembalian":
                            {
                                s_tableName = "tblpengembaliandetails";
                                s_fieldName = "tglkembali";
                                break;
                            }
                        case "Laporan Denda":
                            {
                                s_tableName = "tblpengembaliandetails";
                                s_fieldName = "tglkembali";
                                lblRepository.Text = "Status Denda";
                                cboStatusDenda.Visible = true;
                                break;
                            }
                        case "Laporan Pembayaran Denda":
                            {
                                s_tableName = "tblpengembaliandetails";
                                s_fieldName = "tglkembali";
                                //lblRepository.Text = "Status Denda";
                                //cboStatusDenda.Visible = true;
                                break;
                            }
                        case "Laporan Jumlah Koleksi Perpustakaan":
                            {
                                s_tableName = "tbm_inventaris";
                                s_fieldName = "tglditerima";
                                break;
                            }
                        case "Laporan Daftar Buku Populer":
                            {
                                s_tableName = "tblpeminjamandetails";
                                s_fieldName = "tglpinjam";
                                break;
                            }
                        default:
                            { break; }
                    }

                    pnlRepository.Visible = lookUpEditModul.Visible || lookUpEditBahanAjar.Visible || lookUpEditStatusActive.Visible || cboStatusDenda.Visible;
                    if (!string.IsNullOrEmpty(s_fieldName))
                    {
                        strSql = @"select distinct getTahunBulan(" + s_fieldName + "::date) tahunbulan, getNamaBulanTahun(" + s_fieldName + "::date) bulantahun, getMyTgl(" + s_fieldName + @"::date, 'MMMM') as namabulan, 
                            EXTRACT(YEAR FROM " + s_fieldName + "::date)::int as tahun, EXTRACT(MONTH FROM " + s_fieldName + @"::date)::int as bulan 
                            from " + s_tableName + @" where dlt='0' " + s_where + " ORDER BY tahun desc, bulan";
                        DataTable dt = oConn.GetData(strSql);

                        lookUpEditBulan1.Properties.DataSource = dt;
                        lookUpEditBulan1.Properties.DisplayMember = "bulantahun";
                        lookUpEditBulan1.Properties.ValueMember = "tahunbulan";

                        lookUpEditBulan2.Properties.DataSource = dt;
                        lookUpEditBulan2.Properties.DisplayMember = "bulantahun";
                        lookUpEditBulan2.Properties.ValueMember = "tahunbulan";

                        strSql = @"select distinct EXTRACT(YEAR FROM " + s_fieldName + @"::date)::int as tahun
                            from " + s_tableName + @" where dlt='0' " + s_where + " ORDER BY tahun desc";
                        DataTable dtThn = oConn.GetData(strSql);

                        lookUpEditTahun1.Properties.DataSource = dtThn;
                        lookUpEditTahun1.Properties.DisplayMember = "tahun";
                        lookUpEditTahun1.Properties.ValueMember = "tahun";

                        lookUpEditTahun2.Properties.DataSource = dtThn;
                        lookUpEditTahun2.Properties.DisplayMember = "tahun";
                        lookUpEditTahun2.Properties.ValueMember = "tahun";
                    }
                    oConn.Close();

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                }
            }
        }


        private void userControlCTR_Load(object sender, EventArgs e)
        {
            //refreshAll();
        }

        private void dgData_EmbeddedNavigator_ButtonClick(object sender, NavigatorButtonClickEventArgs e)
        {
            try
            {
                if (e.Button.ButtonType == NavigatorButtonType.Append)
                {

                }
                else if (e.Button.ButtonType == NavigatorButtonType.EndEdit)
                {

                }
                else if (e.Button.ButtonType == NavigatorButtonType.Remove)
                {
                    e.Handled = true;
                    //string strMsg = "Are you sure to delete selected record?";
                    //if (gridView2.GetSelectedRows().Length > 1)
                    //{
                    //    strMsg = "Are you sure to delete selected records?";
                    //}
                    //if (XtraMessageBox.Show(strMsg, clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    //{
                    //    deleteRow();
                    //}
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }



        private void btnPreview_Click(object sender, EventArgs e)
        {
            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";

                string switch_on = Convert.ToString(treeList1.FocusedNode[treeListColumn1]);
                string s_FocusedNode = switch_on;
                if (treeList1.FocusedNode.Level == 2)
                {
                    switch_on = Convert.ToString(treeList1.FocusedNode.ParentNode[treeListColumn1]);
                }
                if (switch_on == "")
                {
                    XtraMessageBox.Show("Silahkan pilih salah satu jenis report!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string strHeader = "";
                bool bolFilterPriod = false;
                bool bolFilterPriod2 = false;
                switch (switch_on)
                {
                    case "Laporan Jumlah Anggota Mahasiswa":
                        {
                            filename = Application.StartupPath + @"\reports\rptJumlahAnggotaMahasiswa.repx";
                            reportName = "rptJumlahAnggotaMahasiswa";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Jumlah Anggota Tenaga Pendidik dan Tenaga Kependidikan":
                        {
                            filename = Application.StartupPath + @"\reports\rptJumlahAnggotaDosen.repx";
                            reportName = "rptJumlahAnggotaDosen";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Jumlah Koleksi Perpustakaan":
                        {
                            filename = Application.StartupPath + @"\reports\rptKoleksiPerpustakaan.repx";
                            reportName = "rptKoleksiPerpustakaan";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Transaksi Peminjaman":
                        {
                            filename = Application.StartupPath + @"\reports\rptTransaksiPeminjaman.repx";
                            reportName = "rptTransaksiPeminjaman";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Transaksi Pengembalian":
                        {
                            filename = Application.StartupPath + @"\reports\rptTransaksiPengembalian.repx";
                            reportName = "rptTransaksiPengembalian";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Denda":
                        {
                            filename = Application.StartupPath + @"\reports\rptDenda.repx";
                            reportName = "rptDenda";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Pembayaran Denda":
                        {
                            filename = Application.StartupPath + @"\reports\rptPembayaranDenda.repx";
                            reportName = "rptPembayaranDenda";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    case "Laporan Daftar Buku Populer":
                        {
                            filename = Application.StartupPath + @"\reports\rptDaftarBukuPopuler.repx";
                            reportName = "rptDaftarBukuPopuler";
                            strHeader = "";
                            bolFilterPriod = false;
                            break;
                        }
                    default:
                        {
                            XtraMessageBox.Show("Silahkan pilih salah satu jenis report!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                            break;
                        }
                }

                #region check filter selection
                if (bolFilterPriod)
                {
                    switch (Convert.ToString(optPeriode.EditValue).ToLower())
                    {
                        case "tanggal":
                            {
                                if (dateTanggal1.Enabled && dateTanggal1.EditValue == null)
                                {
                                    XtraMessageBox.Show("Silahkan pilih periode tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    dateTanggal1.Focus();
                                    return;
                                }
                                break;
                            }
                        case "bulan":
                            {
                                if (lookUpEditBulan1.Enabled && lookUpEditBulan1.EditValue == null)
                                {
                                    XtraMessageBox.Show("Silahkan pilih periode bulan!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    lookUpEditBulan1.Focus();
                                    return;
                                }
                                break;
                            }
                        case "tahun":
                            {
                                if (lookUpEditTahun1.Enabled && lookUpEditTahun1.EditValue == null)
                                {
                                    XtraMessageBox.Show("Silahkan pilih periode tahun!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    lookUpEditTahun1.Focus();
                                    return;
                                }
                                break;
                            }
                    }
                }

                if (bolFilterPriod2)
                {
                    switch (Convert.ToString(optPeriode.EditValue).ToLower())
                    {
                        case "tanggal":
                            {
                                if (dateTanggal2.Enabled && dateTanggal2.EditValue == null)
                                {
                                    XtraMessageBox.Show("Silahkan pilih periode tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    dateTanggal2.Focus();
                                    return;
                                }
                                break;
                            }
                        case "bulan":
                            {
                                if (lookUpEditBulan2.Enabled && lookUpEditBulan2.EditValue == null)
                                {
                                    XtraMessageBox.Show("Silahkan pilih periode bulan!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    lookUpEditBulan2.Focus();
                                    return;
                                }
                                break;
                            }
                        case "tahun":
                            {
                                if (lookUpEditTahun2.Enabled && lookUpEditTahun2.EditValue == null)
                                {
                                    XtraMessageBox.Show("Silahkan pilih periode tahun!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    lookUpEditTahun2.Focus();
                                    return;
                                }
                                break;
                            }
                    }
                }
                #endregion

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();

                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    DataTable dtMaster = getData();
                    if (dtMaster != null)
                    {
                        DataTable dtReport = dtMaster.Copy();
                        dtReport.TableName = "dtReportSource";
                        //System.Data.DataColumn newColumn = new System.Data.DataColumn("header", typeof(System.String));
                        //newColumn.DefaultValue = strHeader;
                        //dtReport.Columns.Add(newColumn);

                        mainReport.reportName = reportName;

                        mainReport.printReport(filename, dtReport);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                        btnPreview.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                btnPreview.Enabled = true;
                savePenandaTangan();
            }
        }

        int initgroupControl1_height;
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            groupControl1.BringToFront();
            if (groupControl1.Height <= 100)
            {
                groupControl1.Height = 420;
                groupControl1.Top = btnClose.Top - (groupControl1.Height - (btnClose.Height / 2));
                simpleButton1.Image = ribbonImageCollection.Images[12];
            }
            else
            {
                groupControl1.Height = initgroupControl1_height;
                groupControl1.Top = btnClose.Top - ((groupControl1.Height / 2) - (btnClose.Height / 2));
                simpleButton1.Image = ribbonImageCollection.Images[11];
            }
        }

        private void checkEdit4_CheckedChanged(object sender, EventArgs e)
        {
            dateTanggal2.Enabled = checkEdit4.Checked;
        }

        private void radioGroup1_SelectedIndexChanged(object sender, EventArgs e)
        {
            panelTgl.Enabled = Convert.ToString(optPeriode.EditValue) == "Tanggal";
            panelBln.Enabled = Convert.ToString(optPeriode.EditValue) == "Bulan";
            panelThn.Enabled = Convert.ToString(optPeriode.EditValue) == "Tahun";
        }

        private void checkEdit5_CheckedChanged(object sender, EventArgs e)
        {
            xBulan2.Enabled = checkEdit5.Checked;
            lookUpEditBulan2.Enabled = checkEdit5.Checked;
        }

        private void checkEdit6_CheckedChanged(object sender, EventArgs e)
        {
            lookUpEditTahun2.Enabled = checkEdit6.Checked;
        }

        private void checkEdit1_CheckedChanged(object sender, EventArgs e)
        {
            panelControl4.Enabled = chkttdkiri_tampilkan.Checked;
        }

        private void checkEdit2_CheckedChanged(object sender, EventArgs e)
        {
            panelControl3.Enabled = chkttdtengah_tampilkan.Checked;
        }

        private void checkEdit3_CheckedChanged(object sender, EventArgs e)
        {
            panelControl5.Enabled = chkttdkanan_tampilkan.Checked;
        }

        private void savePenandaTangan()
        {
            try
            {
                clsRegKey oReg = new clsRegKey();
                oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
                oReg.SaveSetting("TTD\\ttdkanan_tampilkan", Convert.ToString(chkttdkanan_tampilkan.Checked));
                oReg.SaveSetting("TTD\\ttdkanan_header", txtttdkanan_header.Text);
                oReg.SaveSetting("TTD\\ttdkanan_nama", txtttdkanan_nama.Text);
                oReg.SaveSetting("TTD\\ttdkanan_footer", txtttdkanan_footer.Text);

                oReg.SaveSetting("TTD\\ttdtengah_tampilkan", Convert.ToString(chkttdtengah_tampilkan.Checked));
                oReg.SaveSetting("TTD\\ttdtengah_header", txtttdtengah_header.Text);
                oReg.SaveSetting("TTD\\ttdtengah_nama", txtttdtengah_nama.Text);
                oReg.SaveSetting("TTD\\ttdtengah_footer", txtttdtengah_footer.Text);

                oReg.SaveSetting("TTD\\ttdkiri_tampilkan", Convert.ToString(chkttdkiri_tampilkan.Checked));
                oReg.SaveSetting("TTD\\ttdkiri_header", txtttdkiri_header.Text);
                oReg.SaveSetting("TTD\\ttdkiri_nama", txtttdkiri_nama.Text);
                oReg.SaveSetting("TTD\\ttdkiri_footer", txtttdkiri_footer.Text);

                oReg = null;
            }
            catch
            {
            }
        }
        private void getPenandaTangan()
        {
            try
            {
                clsRegKey oReg = new clsRegKey();
                oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
                chkttdkanan_tampilkan.Checked = clsGlobal.GetParseBoolean(oReg.getSetting("TTD\\ttdkanan_tampilkan"));
                txtttdkanan_header.Text = oReg.getSetting("TTD\\ttdkanan_header");
                txtttdkanan_nama.Text = oReg.getSetting("TTD\\ttdkanan_nama");
                txtttdkanan_footer.Text = oReg.getSetting("TTD\\ttdkanan_footer");

                chkttdtengah_tampilkan.Checked = clsGlobal.GetParseBoolean(oReg.getSetting("TTD\\ttdtengah_tampilkan"));
                txtttdtengah_header.Text = oReg.getSetting("TTD\\ttdtengah_header");
                txtttdtengah_nama.Text = oReg.getSetting("TTD\\ttdtengah_nama");
                txtttdtengah_footer.Text = oReg.getSetting("TTD\\ttdtengah_footer");

                chkttdkiri_tampilkan.Checked = clsGlobal.GetParseBoolean(oReg.getSetting("TTD\\ttdkiri_tampilkan"));
                txtttdkiri_header.Text = oReg.getSetting("TTD\\ttdkiri_header");
                txtttdkiri_nama.Text = oReg.getSetting("TTD\\ttdkiri_nama");
                txtttdkiri_footer.Text = oReg.getSetting("TTD\\ttdkiri_footer");

                oReg = null;
            }
            catch
            {
            }
        }

        private void chkFilterPeriode_CheckedChanged(object sender, EventArgs e)
        {
            pnlFilter.Enabled = (chkFilterPeriode.Checked && chkFilterPeriode.Enabled);
        }
    }
}
