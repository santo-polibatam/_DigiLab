﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using DevExpress.XtraReports.UserDesigner;
using DevExpress.LookAndFeel;
using Npgsql;
using Library;

namespace DIGILIB.MainReport
{

    public partial class frmMainReport : DevExpress.XtraEditors.XtraForm
    {
        public WaitDialogForm loadDialog;
        public frmMainReport()
        {
            loadDialog = new WaitDialogForm("Loading report...", "Please Wait...", new Size(250, 50));
            //Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading report...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                //loadDialog.TopMost = false;
                //loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
        XtraReport1 report = new XtraReport1();
        XtraSubReport1 xtrasubreport = new XtraSubReport1();
        XtraSubReport1 xtrasubreport1 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport2 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport3 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport4 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport5 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport6 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport7 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport8 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport9 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport10 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport11 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport12 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport13 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport14 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport15 = new XtraSubReport1();
        XtraSubReport1 xtrasubreport16 = new XtraSubReport1();

        public string filename
        {

            get;
            set;
        }

        public string reportName
        {
            get;
            set;
        }

        public string filenamesubreport
        {
            get;
            set;
        }
        public string subreportName
        {
            get;
            set;
        }
        public string[] arrfilenamesubreport
        {
            get;
            set;
        }
        public string[] arrsubreportName
        {
            get;
            set;
        }
        public object[] arrsubrptdataSource
        {
            get;
            set;
        }
        public bool showChartLabel
        {
            get;
            set;
        }
        public int maxGate { get; set; }

        public DataView dv1;
        public DataView dv2;

        public string strFilter = "";
        public DataTable dtGraph;
        public string nameReportReal { get; set; }

        public Image proImage { get; set; }
        public Image buImage { get; set; }

        private void runreportdesigner_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {

                setLoadDialog(true, "Loading report designer...");
                Application.DoEvents();
                report.LoadLayout(filename);
                report.Report.Name = reportName;
                report.showdesinerwizard = false;

                XRDesignForm form = new XRDesignForm();

                form.OpenReport(report);
                XRDesignPanel panel = form.ActiveDesignPanel;

                // Add a new command handler which saves a report in a custom way.
                panel.AddCommandHandler(new SaveCommandHandler(panel, filename));

                // Show the form.
                setLoadDialog(false, "");

                form.Show();
                if (arrfilenamesubreport.Length > 0)
                {
                    if (xtrasubreport != null && filenamesubreport != null)
                    {
                        xtrasubreport.LoadLayout(filenamesubreport);
                        xtrasubreport.Report.Name = subreportName;
                        xtrasubreport.showdesinerwizard = false;

                        //Create a design form and get its panel.
                        XRDesignForm form2 = new XRDesignForm();
                        form2.OpenReport(xtrasubreport);
                        form2.Show();
                    }
                }
                {
                    for (int idx = 0; idx < arrfilenamesubreport.Length; idx++)
                    {
                        xtrasubreport = new XtraSubReport1();
                        report.xtrasubreport1 = xtrasubreport;

                        xtrasubreport.DataSource = (DataTable)arrsubrptdataSource[idx];

                        xtrasubreport.LoadLayout(arrfilenamesubreport[idx]);
                        xtrasubreport.Report.Name = arrsubreportName[idx];
                        xtrasubreport.showdesinerwizard = false;

                        //Create a design form and get its panel.
                        XRDesignForm form2 = new XRDesignForm();
                        form2.OpenReport(xtrasubreport);
                        form2.Show();

                        #region "commented"
                        //if (idx == 0)
                        //{
                        //    xtrasubreport.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport);
                        //    form2.Show();
                        //}
                        //else if (idx == 1)
                        //{
                        //    xtrasubreport1.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport1.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport1.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport1);
                        //    form2.Show();
                        //}
                        //else if (idx == 2)
                        //{
                        //    xtrasubreport2.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport2.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport2.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport2);
                        //    form2.Show();
                        //}
                        //else if (idx == 3)
                        //{
                        //    xtrasubreport3.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport3.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport3.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport3);
                        //    form2.Show();
                        //}
                        //else if (idx == 4)
                        //{
                        //    xtrasubreport4.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport4.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport4.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport4);
                        //    form2.Show();
                        //}
                        //else if (idx == 5)
                        //{
                        //    xtrasubreport5.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport5.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport5.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport5);
                        //    form2.Show();
                        //}
                        //else if (idx == 6)
                        //{
                        //    xtrasubreport6.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport6.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport6.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport6);
                        //    form2.Show();
                        //}
                        //else if (idx == 7)
                        //{
                        //    xtrasubreport7.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport7.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport7.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport7);
                        //    form2.Show();
                        //}
                        //else if (idx == 8)
                        //{
                        //    xtrasubreport8.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport8.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport8.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport8);
                        //    form2.Show();
                        //}
                        //else if (idx == 9)
                        //{
                        //    xtrasubreport9.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport9.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport9.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport9);
                        //    form2.Show();
                        //}
                        //else if (idx == 10)
                        //{
                        //    xtrasubreport10.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport10.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport10.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport10);
                        //    form2.Show();
                        //}
                        //else if (idx == 11)
                        //{
                        //    xtrasubreport11.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport11.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport11.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport11);
                        //    form2.Show();
                        //}
                        //else if (idx == 12)
                        //{
                        //    xtrasubreport12.LoadLayout(arrfilenamesubreport[idx]);
                        //    xtrasubreport12.Report.Name = arrsubreportName[idx];
                        //    xtrasubreport12.showdesinerwizard = false;
                        //    XRDesignForm form2 = new XRDesignForm();
                        //    form2.OpenReport(xtrasubreport12);
                        //    form2.Show();
                        //}
                        #endregion

                    }
                }

            }
            catch
            {
                setLoadDialog(false, "");
            }
            finally
            {
                setLoadDialog(false, "");
            }

        }


        private void reportdesignerwizard_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                setLoadDialog(true, "Loading report designer...");
                Application.DoEvents();
                if (report != null)
                {
                    report.LoadLayout(filename);
                    report.showdesinerwizard = true;
                    setLoadDialog(false, "");

                    XRDesignForm form = new XRDesignForm();

                    form.OpenReport(report);
                    XRDesignPanel panel = form.ActiveDesignPanel;

                    // Add a new command handler which saves a report in a custom way.
                    panel.AddCommandHandler(new SaveCommandHandler(panel, filename));

                    form.Show();
                }

                if (xtrasubreport != null && filenamesubreport != null)
                {

                    xtrasubreport.LoadLayout(filenamesubreport);
                    xtrasubreport.showdesinerwizard = true;
                    setLoadDialog(false, "");

                    XRDesignForm form2 = new XRDesignForm();

                    form2.OpenReport(xtrasubreport);
                    form2.Show();

                }
            }
            catch
            {
                setLoadDialog(false, "");
            }
            finally
            {
                setLoadDialog(false, "");
            }
        }

        public void printReport(string rptFilePath, object dataSource)
        {
            try
            {
                if (string.IsNullOrEmpty(rptFilePath)) return;
                filename = rptFilePath;
                if (!System.IO.File.Exists(rptFilePath))
                {
                    report.SaveLayout(rptFilePath);
                }
                report.reportName = reportName;
                report.realPath = rptFilePath;
                report.LoadLayout(rptFilePath);
                report.DataSource = dataSource;

                report.strFilter = strFilter;
                report.reportName = reportName;
                report.showChartLabel = showChartLabel;
                //report.proImage = proImage;
                //report.buImage = buImage;
                if (reportName == "rptProjectControl" || reportName == "rptprojectcontrol_physicalprogress" || reportName == "rptDeliverables" || reportName == "rptNonDeliverables" || reportName == "rptDocumentRevisionHistory")
                {
                    report.dv1 = dv1;

                }
                else if (reportName == "rptEarnedValue" || reportName == "rptManhoursHistogram" || reportName == "rptDeliverablesCount" ||
                    reportName == "rptDashboardEarnValue" || reportName == "rptDashboardproduktivity" || reportName == "rptDashboardmanhours" || reportName == "rptDashboardactualManhours" || reportName == "rptDashboarddeliverablesCount")
                {
                    report.dtGraph = dtGraph;
                }
                else if (reportName == "rptActivityManhours")
                {
                    report.dv1 = dv1;
                }

                report.CreateDocument();

                printControl1.PrintingSystem = report.PrintingSystem;
                //fReport = report;
                this.Show();
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }

        }

        public void printReport(string rptFilePath, object dataSource, string subrptFilePath, object subrptdataSource)
        {
            try
            {
                if (string.IsNullOrEmpty(rptFilePath)) return;
                filename = rptFilePath;
                filenamesubreport = subrptFilePath;
                if (!System.IO.File.Exists(rptFilePath))
                {
                    report.SaveLayout(rptFilePath);
                }
                report.reportName = reportName;
                report.realPath = rptFilePath;
                report.LoadLayout(rptFilePath);
                report.DataSource = dataSource;

                report.strFilter = strFilter;
                report.reportName = reportName;
                report.showChartLabel = showChartLabel;
                //report.proImage = proImage;
                //report.buImage = buImage;
                if (reportName == "rptdocumentreview" || reportName == "rptdocumenttransmittal")
                {
                    report.xtrasubreport1 = xtrasubreport;
                    xtrasubreport.LoadLayout(subrptFilePath);
                    xtrasubreport.DataSource = subrptdataSource;

                }

                report.CreateDocument();

                printControl1.PrintingSystem = report.PrintingSystem;
                //fReport = report;
                this.Show();

            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
        }
        public void printReport(string rptFilePath, string sql)
        {
            try
            {
                if (string.IsNullOrEmpty(rptFilePath)) return;
                clsConnection xconn = new clsConnection();
                xconn.Open();

                NpgsqlDataAdapter da = new NpgsqlDataAdapter();
                DataSet ds = new DataSet();
                da.SelectCommand = new NpgsqlCommand();

                da.SelectCommand.Connection = xconn.Conn;
                da.SelectCommand.CommandText = sql; ;

                ds.Clear();
                da.Fill(ds);

                filename = rptFilePath;
                if (!System.IO.File.Exists(rptFilePath))
                {
                    report.SaveLayout(rptFilePath);
                }

                report.LoadLayout(rptFilePath);
                report.DataSource = ds;
                //report.proImage = proImage;
                //report.buImage = buImage;
                report.CreateDocument();

                printControl1.PrintingSystem = report.PrintingSystem;
                this.Show();



                xconn.Close();
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
        }

        public void printReport(string rptFilePath, object dataSource, string[] strParameterVal)
        {
            try
            {
            filename = rptFilePath;
            if (!System.IO.File.Exists(rptFilePath))
            {
                report.SaveLayout(rptFilePath);
            }
            report.reportName = reportName;
            report.realPath = rptFilePath;
            report.LoadLayout(rptFilePath);
            report.DataSource = dataSource;

            report.strFilter = strFilter;
            report.reportName = reportName;
            report.showChartLabel = showChartLabel;
            //report.proImage = proImage;
            //report.buImage = buImage;
            for (int i = 0; i < strParameterVal.Length; i++)
            {
                report.Parameters[i].Value = strParameterVal[i];
            }
            report.RequestParameters = false;
            report.CreateDocument();

            printControl1.PrintingSystem = report.PrintingSystem;
            //fReport = report;
            this.Show();

            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
        }

        public void printReport(string rptFilePath, object dataSource, string[] subrptFilePath, object[] subrptdataSource, string[] subreportName)
        {
            try
            {
                if (string.IsNullOrEmpty(rptFilePath)) return;
                filename = rptFilePath;
                //filenamesubreport = subrptFilePath;
                if (!System.IO.File.Exists(rptFilePath))
                {
                    report.SaveLayout(rptFilePath);
                }
                report.reportName = reportName;
                report.realPath = rptFilePath;
                report.LoadLayout(rptFilePath);
                report.DataSource = dataSource;

                report.strFilter = strFilter;
                report.reportName = reportName;
                report.showChartLabel = showChartLabel;
                //report.proImage = proImage;
                //report.buImage = buImage;
                arrfilenamesubreport = subrptFilePath;
                arrsubrptdataSource = subrptdataSource;
                arrsubreportName = subreportName;
                for (int idx = 0; idx < subrptFilePath.Length; idx++)
                {
                    //subreport = new XtraSubReport1();
                    //subreport.Name = subreportName[idx];
                    //subreport.LoadLayout(subrptFilePath[idx]);
                    //subreport.DataSource = subrptdataSource[idx];
                    //report.xtrasubreport1 = subreport;
                    switch (idx)
                    {
                        case 0:
                            {
                                report.xtrasubreport = xtrasubreport;
                                xtrasubreport.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 1:
                            {
                                report.xtrasubreport1 = xtrasubreport1;
                                xtrasubreport1.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport1.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 2:
                            {
                                report.xtrasubreport2 = xtrasubreport2;
                                xtrasubreport2.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport2.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 3:
                            {
                                report.xtrasubreport3 = xtrasubreport3;
                                xtrasubreport3.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport3.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 4:
                            {
                                report.xtrasubreport4 = xtrasubreport4;
                                xtrasubreport4.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport4.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 5:
                            {
                                report.xtrasubreport5 = xtrasubreport5;
                                xtrasubreport5.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport5.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 6:
                            {
                                report.xtrasubreport6 = xtrasubreport6;
                                xtrasubreport6.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport6.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 7:
                            {
                                report.xtrasubreport7 = xtrasubreport7;
                                xtrasubreport7.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport7.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 8:
                            {
                                report.xtrasubreport8 = xtrasubreport8;
                                xtrasubreport8.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport8.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 9:
                            {
                                report.xtrasubreport9 = xtrasubreport9;
                                xtrasubreport9.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport9.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 10:
                            {
                                report.xtrasubreport10 = xtrasubreport10;
                                xtrasubreport10.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport10.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 11:
                            {
                                report.xtrasubreport11 = xtrasubreport11;
                                xtrasubreport11.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport11.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 12:
                            {
                                report.xtrasubreport12 = xtrasubreport12;
                                xtrasubreport12.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport12.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 13:
                            {
                                report.xtrasubreport13 = xtrasubreport13;
                                xtrasubreport13.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport13.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 14:
                            {
                                report.xtrasubreport14 = xtrasubreport14;
                                xtrasubreport14.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport14.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 15:
                            {
                                report.xtrasubreport15 = xtrasubreport15;
                                xtrasubreport15.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport15.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                        case 16:
                            {
                                report.xtrasubreport16 = xtrasubreport16;
                                xtrasubreport16.LoadLayout(subrptFilePath[idx]);
                                xtrasubreport16.DataSource = (DataTable)subrptdataSource[idx];
                                break;
                            }
                    }
                }

                report.CreateDocument();

                printControl1.PrintingSystem = report.PrintingSystem;
                //fReport = report;
                this.Show();

            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
        }

        public string printReportToPDF(string rptFilePath, object dataSource, string rptFilename)
        {
            string strSavePath = "";
            try
            {
                if (string.IsNullOrEmpty(rptFilePath)) return "";
                filename = rptFilePath;
                if (!System.IO.File.Exists(rptFilePath))
                {
                    report.SaveLayout(rptFilePath);
                }
                report.reportName = reportName;
                report.realPath = rptFilePath;
                report.LoadLayout(rptFilePath);
                report.DataSource = dataSource;

                report.strFilter = strFilter;
                report.reportName = reportName;
                report.showChartLabel = showChartLabel;
                //report.proImage = proImage;
                //report.buImage = buImage;
                if (reportName == "rptProjectControl" || reportName == "rptprojectcontrol_physicalprogress" || reportName == "rptDeliverables" || reportName == "rptNonDeliverables" || reportName == "rptDocumentRevisionHistory")
                {
                    report.dv1 = dv1;

                }
                else if (reportName == "rptEarnedValue" || reportName == "rptManhoursHistogram" || reportName == "rptDeliverablesCount" ||
                    reportName == "rptDashboardEarnValue" || reportName == "rptDashboardproduktivity" || reportName == "rptDashboardmanhours" || reportName == "rptDashboardactualManhours" || reportName == "rptDashboarddeliverablesCount")
                {
                    report.dtGraph = dtGraph;
                }
                else if (reportName == "rptActivityManhours")
                {
                    report.dv1 = dv1;
                }

                string strDir = Application.StartupPath + @"\temp\";
                if (!System.IO.Directory.Exists(strDir))
                {
                    System.IO.Directory.CreateDirectory(strDir);
                }
                //strSavePath = strDir + reportName + "_" + System.DateTime.Now.ToString("ddMMMyy_hhmmss") + ".pdf";
                strSavePath = strDir + rptFilename + System.DateTime.Now.ToString("ddMMMyy") + "].pdf";
                report.ExportToPdf(strSavePath, new DevExpress.XtraPrinting.PdfExportOptions() { ShowPrintDialogOnOpen = false });
                //report.CreateDocument();

                //printControl1.PrintingSystem = report.PrintingSystem;
                //fReport = report;
                //this.Show();

            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
            return strSavePath;
        }


        public string printReportToThermalPrinter(string rptFilePath, object dataSource)
        {
            string strSavePath = "";
            try
            {
                if (string.IsNullOrEmpty(rptFilePath)) return "";
                filename = rptFilePath;
                if (!System.IO.File.Exists(rptFilePath))
                {
                    report.SaveLayout(rptFilePath);
                }
                report.reportName = reportName;
                report.realPath = rptFilePath;
                report.LoadLayout(rptFilePath);
                report.DataSource = dataSource;

                report.strFilter = strFilter;
                report.reportName = reportName;
                report.showChartLabel = showChartLabel;

                report.Print(printerName); 
                ;

            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
            return strSavePath;
        }

        public string printerName = "EPSON TM-T81 Receipt";
    }


    public class SaveCommandHandler : ICommandHandler
    {
        XRDesignPanel panel;

        public SaveCommandHandler(XRDesignPanel panel, string sfilename)
        {
            this.panel = panel;
            filename = sfilename;
            bolReportCommandClosing = false;
        }

        protected string m_filename;

        public string filename
        {
            get { return m_filename; }
            set { m_filename = value; }
        }

        protected static bool bolReportState = false;
        protected static string savedFilepath = "";
        protected static bool bolReportCommandClosing = false;

        public virtual void HandleCommand(ReportCommand command, object[] args, ref bool handled)
        {
            if (!CanHandleCommand(command)) return;
            if (panel.ReportState != ReportState.Saved)
                // Save a report.
                Save();

            // Set handled to true to avoid the standard saving procedure to be called.
            handled = true;
        }

        public virtual bool CanHandleCommand(ReportCommand command)
        {
            // This handler is used for SaveFile, SaveFileAs and Closing commands.
            if (command == ReportCommand.Closing)
                bolReportCommandClosing = true;

            return command == ReportCommand.SaveFile ||
                command == ReportCommand.SaveFileAs ||
                command == ReportCommand.Closing;
        }

        void Save()
        {
            try
            {
                // Write your custom saving here.
                // ...

                // For instance:
                string sPath = System.IO.Path.GetDirectoryName(filename);
                string sFile = System.IO.Path.GetFileName(filename);
                string[] sFileExt = sFile.Split('.');
                sFile = sFileExt[0] + "_mdf." + sFileExt[1];
                string sFilePath = System.IO.Path.Combine(sPath, sFile);
                //if (System.IO.File.Exists(sFilePath))
                //    sFilePath = System.IO.Path.Combine(sPath, sFileExt[0] + "_mdf_2." + sFileExt[1]);

                if (bolReportState == false)
                {
                    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    saveFileDialog1.InitialDirectory = sPath;
                    saveFileDialog1.Title = "Save as " + sFile;
                    saveFileDialog1.Filter = "Report Files(*.repx)|*.repx";
                    saveFileDialog1.FileName = sFile;
                    saveFileDialog1.FilterIndex = 0;

                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        sFilePath = saveFileDialog1.FileName;
                        panel.Report.SaveLayout(sFilePath);
                        panel.ReportState = ReportState.Saved;

                        bolReportState = true;
                        savedFilepath = sFilePath;
                        xmlReportList(savedFilepath);
                    }
                }
                else
                {

                    panel.Report.SaveLayout(savedFilepath);
                    panel.ReportState = ReportState.Saved;
                    xmlReportList(savedFilepath);
                }


                if (bolReportCommandClosing)
                {
                    bolReportState = false;
                }

            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        void xmlReportList(string sRptFile)
        {
            string sPath = System.IO.Path.GetDirectoryName(sRptFile);
            string[] sFile = System.IO.Path.GetFileName(sRptFile).Split('.');
            string[] sFileOnly = sFile[0].Split(new string[1] { "_mdf" }, StringSplitOptions.RemoveEmptyEntries);

            if (sFileOnly.Length <= 0) return;

            string xmlFile = System.IO.Path.Combine(sPath, sFileOnly[0] + ".xml");

            DataSet ds = new DataSet();
            DataTable rptTable = ds.Tables.Add("rptTable");
            DataColumn reportCol = rptTable.Columns.Add("reportname");
            rptTable.Columns.AddRange(new DataColumn[] { 
                new DataColumn("filepath", typeof(string)), 
                new DataColumn("no", typeof(int)) 
            });

            DataColumn[] keys = new DataColumn[1];
            keys[0] = reportCol;
            rptTable.PrimaryKey = keys;

            if (System.IO.File.Exists(xmlFile))
            {
                ds.ReadXml(xmlFile);
                DataRow foundRow = ds.Tables[0].Rows.Find(System.IO.Path.GetFileName(sRptFile).ToString());

                if (foundRow != null)
                {

                }
                else
                {
                    DataRow newDataRow = ds.Tables[0].NewRow();

                    newDataRow[0] = System.IO.Path.GetFileName(sRptFile).ToString();
                    newDataRow[1] = sRptFile;
                    newDataRow[2] = ds.Tables[0].Rows.Count;

                    ds.Tables[0].Rows.Add(newDataRow);
                }

                System.IO.File.Delete(xmlFile);
                if (ds != null)
                    ds.WriteXml(xmlFile);
            }
            else
            {

                DataRow myNewRow;
                //keep original
                myNewRow = rptTable.NewRow();
                myNewRow[0] = sFileOnly[0] + ".repx";
                myNewRow[1] = System.IO.Path.Combine(sPath, sFileOnly[0] + ".repx").ToString();
                myNewRow[2] = 0;
                rptTable.Rows.Add(myNewRow);

                if (System.IO.Path.Combine(sPath, sFileOnly[0] + ".repx").ToString() != sRptFile.ToString())
                {
                    myNewRow = rptTable.NewRow();
                    myNewRow[0] = System.IO.Path.GetFileName(sRptFile).ToString();
                    myNewRow[1] = sRptFile.ToString();
                    myNewRow[2] = 1;

                    rptTable.Rows.Add(myNewRow);
                }
                if (rptTable != null || rptTable.DataSet != null)
                {
                    rptTable.DataSet.WriteXml(xmlFile);
                }
            }

        }
    }
}