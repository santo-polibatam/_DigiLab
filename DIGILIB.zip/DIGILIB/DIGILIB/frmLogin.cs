﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Library;
using Npgsql;

namespace DIGILIB
{
    public partial class frmLogin : DevExpress.XtraEditors.XtraForm
    {
        public frmLogin()
        {
            InitializeComponent();

            SelectICard();
            SetupReaderList();
            LoadApduList();
            comboReader_SelectedIndexChanged(null, null);
        }


        #region Smartcard
        delegate void SetValueLookUpEditDelegate(DevExpress.XtraEditors.LookUpEdit cbo, string editvalue);
        private GemCard.CardBase m_iCard = null;
        private GemCard.APDUPlayer m_apduPlayer = null;
        private GemCard.APDUParam m_apduParam = null;
        const string DefaultReader = "Gemplus USB Smart Card Reader 0";
        private TextBox txtboxATR;
        private Label label10;
        string reader = "ACS ACR122 0";
        const string ApduListFile = "ApduList.xml";


        public string GetScardErrMsg(string ReturnCode)
        {
            string strresult = ReturnCode;
            switch (ReturnCode)
            {
                case "9000":
                    strresult = "9000 : The operation completed succesfully.";
                    break;
                case "6300":
                    strresult = "6300 : The operation failed.";
                    break;
                case "6A81":
                    strresult = "6A81 : Function not supported.";
                    break;
            }
            return strresult;
        }

        private void SelectICard()
        {
            try
            {
                if (m_iCard != null)
                    m_iCard.Disconnect(GemCard.DISCONNECT.Unpower);

                m_iCard = new GemCard.CardNative();
                //statusBarPanel_Info.Text = "CardNative implementation used";              

                m_iCard.OnCardInserted += new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved += new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);

            }
            catch (Exception ex)
            {
                //btnConnect.Enabled = false;
                //btnDisconnect.Enabled = false;
                //btnTransmit.Enabled = false;

                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        /// <summary>
        /// CardRemovedEventHandler
        /// </summary>
        private void m_iCard_OnCardRemoved(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, false });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });

        }

        /// <summary>
        /// CardInsertedEventHandler
        /// </summary>
        private void m_iCard_OnCardInserted(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, true });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });
            //if (btnConnect.Enabled)
            //{
            try
            {
                m_iCard.Connect("ACS ACR122 0", GemCard.SHARE.Shared, GemCard.PROTOCOL.T0orT1);

                try
                {
                    // Get the ATR of the card
                    byte[] atrValue = m_iCard.GetAttribute(GemCard.SCARD_ATTR_VALUE.ATR_STRING);
                    //txtboxATR.Text = ByteArrayToString(atrValue);
                }
                catch (Exception)
                {
                    //txtboxATR.Text = "Cannot get ATR";
                }

                //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, btnConnect.Enabled });

                GemCard.APDUResponse apduResp = m_apduPlayer.ProcessCommand("Get UID", BuildParam());
                if (apduResp.Data != null)
                {
                    StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                    for (int nI = 0; nI < apduResp.Data.Length; nI++)
                        sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    if (apduResp.Data != null)
                    {

                        string strRFID = Convert.ToString(ByteArrayToString(apduResp.Data));
                        Login(strRFID, "", "");

                    }
                }

            }
            catch (Exception ex)
            {
                //XtraMessageBox.Show(ex.Message, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            //btnConnect_Click(btnConnect, null);
            //}
        }

        protected void SetValueLookUpEdit(DevExpress.XtraEditors.LookUpEdit lookupedit, object editValue)
        {
            lookupedit.EditValue = Convert.ToString(editValue);
        }
        protected void EnableButton(Button btn, bool enable)
        {
            btn.Enabled = enable;
        }

        static private string ByteArrayToString(byte[] data)
        {
            StringBuilder sDataOut;

            if (data != null)
            {
                sDataOut = new StringBuilder(data.Length * 2);
                for (int nI = 0; nI < data.Length; nI++)
                    sDataOut.AppendFormat("{0:X02}", data[nI]);
            }
            else
                sDataOut = new StringBuilder();

            return sDataOut.ToString();
        }
        string textClass = "";
        string textIns = "";
        string textP1 = "";
        string textP2 = "";
        string textLe = "";
        string textData = "";
        private GemCard.APDUParam BuildParam()
        {
            //byte bP1 = byte.Parse(textP1.Text, NumberStyles.AllowHexSpecifier);
            //byte bP2 = byte.Parse(textP2.Text, NumberStyles.AllowHexSpecifier);
            //byte bLe = byte.Parse(textLe.Text);

            byte bP1 = byte.Parse(textP1, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bP2 = byte.Parse(textP2, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bLe = byte.Parse(textLe);

            GemCard.APDUParam apduParam = new GemCard.APDUParam();
            apduParam.P1 = bP1;
            apduParam.P2 = bP2;
            apduParam.Le = bLe;

            // Update Current param
            m_apduParam = apduParam.Clone();

            return apduParam;
        }
        private void DisplayAPDUCommand(GemCard.APDUCommand apduCmd)
        {
            if (apduCmd != null)
            {
                textClass = string.Format("{0:X02}", apduCmd.Class);
                textIns = string.Format("{0:X02}", apduCmd.Ins);
                textP1 = string.Format("{0:X02}", apduCmd.P1);
                textP2 = string.Format("{0:X02}", apduCmd.P2);
                textLe = apduCmd.Le.ToString();

                if (apduCmd.Data != null)
                {
                    StringBuilder sData = new StringBuilder(apduCmd.Data.Length * 2);
                    for (int nI = 0; nI < apduCmd.Data.Length; nI++)
                        sData.AppendFormat("{0:X02}", apduCmd.Data[nI]);

                    textData = sData.ToString();
                }
                else
                    textData = "";

                m_apduParam = new GemCard.APDUParam();

                m_apduParam.P1 = apduCmd.P1;
                m_apduParam.P2 = apduCmd.P2;
                m_apduParam.Le = apduCmd.Le;
            }
        }

        private void SetupReaderList()
        {
            try
            {
                string[] sListReaders = m_iCard.ListReaders();
                //comboReader.Items.Clear();

                if (sListReaders != null)
                {
                    for (int nI = 0; nI < sListReaders.Length; nI++)
                    {
                        reader = Convert.ToString(sListReaders[nI]);
                        //    comboReader.Items.Add(sListReaders[nI]);
                    }
                    //comboReader.SelectedIndex = 0;

                    //btnConnect.Enabled = false;
                    //btnDisconnect.Enabled = false;
                    //btnTransmit.Enabled = false;

                    //// Start waiting for a card
                    //string reader = (string)comboReader.SelectedItem;
                    //m_iCard.StartCardEvents(reader);

                    //statusBarPanel_Info.Text = "Waiting for a card";
                }
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        /// <summary>
        /// Loads the APDU list
        /// </summary>
        private void LoadApduList()
        {
            try
            {
                // Create the APDU player
                m_apduPlayer = new GemCard.APDUPlayer(ApduListFile, m_iCard);

                // Get the list of APDUs and setup teh combo
                //comboApdu.Items.AddRange(m_apduPlayer.APDUNames);
                //comboApdu.SelectedIndex = 0;
                DisplayAPDUCommand(m_apduPlayer.APDUByName("Get UID"));
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        private void comboReader_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                m_iCard.StopCardEvents();

                // Get the current selection
                //int idx = comboReader.SelectedIndex;
                //if (idx != -1)
                //{
                // Start waiting for a card

                m_iCard.StartCardEvents(reader);

                //statusBarPanel_Info.Text = "Waiting for a card";
                //}
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        private void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //    m_iCard.Disconnect(DISCONNECT.Unpower);

                //    m_iCard.StopCardEvents();
                m_iCard.OnCardInserted -= new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved -= new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);
            }
            catch
            {
            }
        }
        #endregion


        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(textEdit1.Text) == "")
            {
                XtraMessageBox.Show("Username tidak boleh kosong!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                textEdit1.Focus();
                return;
            }
            else if (Convert.ToString(textEdit2.Text) == "")
            {
                XtraMessageBox.Show("Password tidak boleh kosong!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                textEdit2.Focus();
                return;
            }
            Login("", textEdit1.Text, textEdit2.Text);
        }
        private void Login(string strRFID, string strUsername, string strPass)
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    clsEncryption oEncryption = new clsEncryption();
                    NpgsqlCommand ocmd = new NpgsqlCommand();
                    oConn.Open();
                    ocmd.Connection = oConn.Conn;

                    string strsql = @"";

                    ocmd = new NpgsqlCommand();
                    ocmd.Connection = oConn.Conn;
                    if (string.IsNullOrEmpty(strRFID))
                    {
                        strsql = @"
                            select userid, username, hak_akses, nama
                            from tbp_user 
                            where dlt='0' and username=@username and passwd=@passwd";
                        ocmd.Parameters.Add("@username", NpgsqlTypes.NpgsqlDbType.Varchar).Value = oEncryption.Encrypt(strUsername.ToString().ToUpper());
                        ocmd.Parameters.Add("@passwd", NpgsqlTypes.NpgsqlDbType.Varchar).Value = oEncryption.Encrypt(strPass);
                    }
                    else
                    {
                        strsql = @"
                            select userid, username, hak_akses, nama
                            from tbp_user 
                            where dlt='0' and rfid=@rfid";
                        ocmd.Parameters.Add("@rfid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = strRFID;
                    }
                    ocmd.CommandText = strsql;
                    NpgsqlDataReader dr;
                    dr = ocmd.ExecuteReader();
                    if (dr.Read())
                    {
                        clsGlobal.strUserName = oEncryption.Decrypt(Convert.ToString(dr["username"]));
                        clsGlobal.strUserID = dr["userid"].ToString();
                        clsGlobal.strHakAkses = dr["hak_akses"].ToString();
                        clsGlobal.strNamaPetugas = dr["nama"].ToString();
                        //clsGlobal.str_Tahun = comboBoxEdit1.EditValue.ToString();
                        //clsGlobal.str_Tahun = Convert.ToString(luTahunAjaran.EditValue);
                        clsGlobal.strUserType = "User";

                        clsRegKey oReg = new clsRegKey();
                        oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
                        oReg.SaveSetting("Tahun", clsGlobal.str_Tahun);
                        oReg = null;
                    }
                    else
                    {
                        XtraMessageBox.Show("Invalid username or password .!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        strPass = "";
                        if (string.IsNullOrEmpty(strRFID))
                        {
                            textEdit2.Focus();
                        }
                        ocmd = null;
                        oEncryption = null;
                        return;
                    }
                    ocmd = null;
                    oEncryption = null;
                    //clsGlobal.xupdatedatabase();
                    this.DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                catch (Exception ex)
                {
                    XtraMessageBox.Show("Unable connect to database server, please configure the database connection first", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    frmSeverInitialize frm = new frmSeverInitialize();
                    frm.ShowDialog();
                    //loadTahun();
                }
            }
        }

        private void frmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm_FormClosed(sender, e);
            if (this.DialogResult != System.Windows.Forms.DialogResult.OK)
            {
                Application.Exit();
                Environment.Exit(1);
            }
        }

        private void textEdit2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Tab)
            {
                btnLogin.Focus();
            }
        }

        private void textEdit1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textEdit2.Focus();
            }
        }

        private void hyperLinkEdit1_OpenLink(object sender, DevExpress.XtraEditors.Controls.OpenLinkEventArgs e)
        {
            frmSeverInitialize frm = new frmSeverInitialize();
            frm.ShowDialog();
            //loadTahun();
        }

        private void loadTahun()
        {
            using (clsConnection oConn = new clsConnection())
            {
                string strSql = "select tahunajaranid, tahunajaran, isactive from tba_tahunajaran where dlt='0' order by tahunajaran";
                DataTable dt = oConn.GetData(strSql);
                luTahunAjaran.Properties.DataSource = dt;
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            try
            {
                clsRegKey oReg = new clsRegKey();
                clsEncryption oEncryption = new clsEncryption();
                oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
                clsGlobal.str_Server = oReg.getSetting("Server");
                clsGlobal.str_User = oEncryption.Decrypt(oReg.getSetting("User"));
                clsGlobal.str_Password = oEncryption.Decrypt(oReg.getSetting("Password"));
                clsGlobal.str_Database = oReg.getSetting("Database");
                clsGlobal.str_Port = oReg.getSetting("Port");

                string strTahun = oReg.getSetting("Tahun");
                //luTahunAjaran.EditValue = strTahun;
                oReg = null;
                oEncryption = null;
                //loadTahun();
            }
            catch (NpgsqlException ex)
            {
                XtraMessageBox.Show("Unable connect to database server, please configure the database connection first", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                frmSeverInitialize frm = new frmSeverInitialize();
                frm.ShowDialog();
                //loadTahun();
                frm = null;
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Could not write/read Registry System.!\nCall Your System Administrator\n", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}