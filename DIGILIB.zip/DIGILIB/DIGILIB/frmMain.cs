using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.Skins;
using DevExpress.LookAndFeel;
using DevExpress.UserSkins;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraBars.Helpers;
using Library;
using DevExpress.XtraEditors;


namespace DIGILIB
{
    public partial class frmMain : XtraForm
    {
        delegate void EnableButtonDelegate(Button btn, bool state);
        public frmMain()
        {
            InitializeComponent();
            InitSkinGallery();
            frmLogin formLogin = new frmLogin();
            if (formLogin.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                doCheckUpdate();
                clsGlobal.setFTP();
            }
            initmainPanelcontrols = mainPanel.Controls.Count;
        }

        private void mainPanel_ControlAdded(object sender, ControlEventArgs e)
        {
            bciClose.Enabled = true;
        }
        int initmainPanelcontrols = 0;
        private void mainPanel_ControlRemoved(object sender, ControlEventArgs e)
        {
            if (mainPanel.Controls.Count == initmainPanelcontrols)
            {
                bciClose.Enabled = false;
            }
        }
        #region Skin

        void InitSkinGallery()
        {
            SkinHelper.InitSkinGallery(bciSkinGallery, true);
        }

        void SaveCurrentSkin(string sSkinName)
        {
            clsRegKey oReg = new clsRegKey();
            oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
            oReg.SaveSetting("Skin", sSkinName);
            //if (string.IsNullOrEmpty(sSkinName))
            //{ 
            //}
            //else
            //{
            //    UserLookAndFeel.Default.ActiveLookAndFeel.SkinName = clsGlobal.DefaultSkinName;
            //}
        }

        void LoadCurrentSkin()
        {
            clsRegKey oReg = new clsRegKey();
            oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;
            string sSkinName = oReg.getSetting("Skin");
            if (string.IsNullOrEmpty(sSkinName))
            {
                UserLookAndFeel.Default.ActiveLookAndFeel.SkinName = clsGlobal.DefaultSkinName;
            }
            else
            {
                UserLookAndFeel.Default.ActiveLookAndFeel.SkinName = sSkinName;
            }
        }
        private void bciSkinGallery_ItemClick(object sender, ItemClickEventArgs e)
        {
            try
            {
                SaveCurrentSkin(e.Item.Name);
            }
            catch { }
        }

        private void bciSkinGallery_Gallery_ItemClick(object sender, DevExpress.XtraBars.Ribbon.GalleryItemClickEventArgs e)
        {
            try
            {
                SaveCurrentSkin(e.Item.Caption);
            }
            catch { }
        }


        private void skinGrp_CaptionButtonClick(object sender, DevExpress.XtraBars.Ribbon.RibbonPageGroupEventArgs e)
        {
            popupMenu1.ShowPopup(Control.MousePosition);
        }

        private void barDefaultSkin_ItemClick(object sender, ItemClickEventArgs e)
        {
            SaveCurrentSkin(clsGlobal.DefaultSkinName);
            LoadCurrentSkin();
        }
        #endregion



        #region "new update app. reminder"
        private void doCheckUpdate()
        {
            //check downloader file
            if (!System.IO.File.Exists(Application.StartupPath.ToString() + "\\UpdateDIGILIB.exe")) return;
            //do nothing if Updated Today
            //if (oAutoUpdate.IsAppUpdatedToday()) return;

            Application.DoEvents();
            clsCheckForUpdate oUpdateWorker = new clsCheckForUpdate();
            string sMessage;

            string sExeName = System.IO.Path.GetFileName(Application.ExecutablePath).ToString();

            try
            {
                oUpdateWorker.RetrieveConfiguration();

                oUpdateWorker.ApplicationInstance = sExeName;
                oUpdateWorker.AppStartupPath = System.AppDomain.CurrentDomain.BaseDirectory;

                oUpdateWorker.checkUpdateEventMsg += new clsCheckForUpdate.checkUpdateApp(this.doCheckUpdate_updateEventMsg);
                oUpdateWorker.StartCheckUpdate();
            }
            catch (Exception ex)
            {
                sMessage = ex.Message;
                setMessage(sMessage, false);
            }
        }

        private void doCheckUpdate_updateEventMsg(object sender, bool msg)
        {
            if (msg)
            {
                //ShowLoadAlert();
                showUpdateApp(false);
            }
        }

        private void setMessage(string sMsg, bool bIsAuto)
        {
            try
            {
                clsTextGenerator oTextGenerator = new clsTextGenerator();
                if (!bIsAuto)
                    oTextGenerator.AppendTLog(sMsg);
            }
            catch
            { }
        }

        #endregion

        #region "Update Application"

        private clsAutoUpdate oAutoUpdate = new clsAutoUpdate();

        private void showUpdateApp(bool bIsNotShowMsgBox)
        {
            try
            {
                oAutoUpdate = new clsAutoUpdate();
                if (System.IO.File.Exists(Application.StartupPath.ToString() + "\\" + "UpdateDIGILIB.exe"))
                {
                    //updateUserLog();

                    string strUser = "user";
                    if (clsGlobal.strUserName.ToLower() == "superadmin")
                    {
                        strUser = "superadmin";
                    }
                    else
                    {
                        strUser = "user";
                    }
                    oAutoUpdate.DoUpdateApp("DIGILIB.exe|" + bIsNotShowMsgBox + "|DIGILIB|" + strUser, "UpdateDIGILIB.exe");
                }
                else
                {
                    XtraMessageBox.Show("Application can't check the latest update due to one of the components is missing.\n\n" +
                                     "Please contact your system administrator if you face this problem again.", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Application.Exit();
                }
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show(ex.Message.ToString() + "\n\nPlease contact your system administrator if you face this problem again.", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Application.Exit();
                Environment.Exit(1);
            }
        }
        private void showLoginForm()
        {
            frmLogin formLogin = new frmLogin();
            formLogin.Show();
        }
        #endregion

        #region Privileges
        private void setPrivelegesMenu()
        {
            if (clsGlobal.strUserName.ToLower() == "superadmin")
            { }
            else
            {
                using (clsConnection oConn = new clsConnection())
                {
                    string strSql = @"select a.moduleid, a.groupcode, a.groupname, a.groupcode||' - '||a.groupname as groupview, a.modulename,
                        b.usermoduleid, b.userid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                        coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload
                        from tbp_module a
                        left outer join tbp_usermodule b on a.moduleid=b.moduleid and b.dlt='0' and b.userid='" + clsGlobal.strUserID + @"'
                        where a.dlt='0'";
                    DataTable dt = oConn.GetData(strSql);

                    try
                    {


                        for (int j = 0; j < dt.Rows.Count; j++)
                        {
                            for (int i = 0; i < ribbonControl.Pages.Count; i++)
                            {
                                for (int i2 = 0; i2 < ribbonControl.Pages[i].Groups.Count; i2++)
                                {
                                    for (int i3 = 0; i3 < ribbonControl.Pages[i].Groups[i2].ItemLinks.Count; i3++)
                                    {
                                        if ((ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem) != null)
                                        {
                                            string strCaption = "";
                                            string strTag = "";
                                            try
                                            {
                                                strCaption = (ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Caption;
                                                strTag = (ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Tag.ToString();
                                            }
                                            catch (Exception)
                                            {

                                            }
                                            if (strCaption == "Close" || strCaption == "Exit")
                                            {
                                                (ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Enabled = true;
                                            }
                                            else
                                            {
                                                if (strTag.ToLower() == dt.Rows[j]["modulename"].ToString().ToLower())
                                                {
                                                    bool isRead = Convert.ToBoolean(dt.Rows[j]["isread"].ToString());
                                                    bool isAdd = Convert.ToBoolean(dt.Rows[j]["isadd"].ToString());
                                                    bool isEdit = Convert.ToBoolean(dt.Rows[j]["isedit"].ToString());
                                                    bool isDel = Convert.ToBoolean(dt.Rows[j]["isdelete"].ToString());
                                                    bool isPrint = Convert.ToBoolean(dt.Rows[j]["isprint"].ToString());
                                                    bool isDownload = Convert.ToBoolean(dt.Rows[j]["isdownload"].ToString());
                                                    bool isUpload = Convert.ToBoolean(dt.Rows[j]["isupload"].ToString());
                                                    (ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Enabled = isRead || isAdd || isEdit || isDel || isPrint || isDownload || isUpload;
                                                }
                                            }
                                        }

                                    }

                                }

                            }

                        }

                    }
                    catch (Exception)
                    {

                    }
                }
            }
        }

        private void setPrivilegesButton(object sender, ItemClickEventArgs e)
        {
            if (clsGlobal.strUserName.ToLower() == "superadmin")
            {
                clsGlobal.bolRead = true;
                clsGlobal.bolAdd = true;
                clsGlobal.bolEdit = true;
                clsGlobal.bolDelete = true;
                clsGlobal.bolPrint = true;
                clsGlobal.bolDownload = true;
                clsGlobal.bolUpload = true;
            }
            else
            {
                using (clsConnection oConn = new clsConnection())
                {
                    string strSql = @"select a.moduleid, a.groupcode, a.groupname, a.groupcode||' - '||a.groupname as groupview, a.modulename,
                            b.usermoduleid, b.userid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                            coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload
                            from tbp_module a
                            left outer join tbp_usermodule b on a.moduleid=b.moduleid and b.dlt='0' and b.userid='" + clsGlobal.strUserID + @"'
                            where a.dlt='0' and lower(a.modulename)='" + (e.Item as BarCheckItem).Tag.ToString().ToLower() + "'";
                    DataTable dt = oConn.GetData(strSql);
                    if (dt.Rows.Count > 0)
                    {
                        clsGlobal.bolRead = Convert.ToBoolean(dt.Rows[0]["isread"].ToString());
                        clsGlobal.bolAdd = Convert.ToBoolean(dt.Rows[0]["isadd"].ToString());
                        clsGlobal.bolEdit = Convert.ToBoolean(dt.Rows[0]["isedit"].ToString());
                        clsGlobal.bolDelete = Convert.ToBoolean(dt.Rows[0]["isdelete"].ToString());
                        clsGlobal.bolPrint = Convert.ToBoolean(dt.Rows[0]["isprint"].ToString());
                        clsGlobal.bolDownload = Convert.ToBoolean(dt.Rows[0]["isdownload"].ToString());
                        clsGlobal.bolUpload = Convert.ToBoolean(dt.Rows[0]["isupload"].ToString());
                    }
                }
            }
        }
        #endregion

        private void bciExit_CheckedChanged(object sender, ItemClickEventArgs e)
        {
            try
            {
                if (bciExit.Checked == true)
                {
                    this.Close();
                    Application.Exit();
                    Environment.Exit(1);

                }
            }
            catch (Exception)
            {
            }

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            clsGlobal.bolRead = true;
            clsGlobal.bolAdd = true;
            clsGlobal.bolEdit = true;
            clsGlobal.bolDelete = true;
            clsGlobal.bolPrint = true;
            //tba_tahunajaran oObject = new tba_tahunajaran();
            //clsConnection oConn = new clsConnection();
            //oConn.Open();
            //oObject.Koneksi = oConn.Conn;
            //oObject.GetByPrimaryKey(clsGlobal.str_Tahun);
            //bsiTahun.Caption = "Tahun Ajaran : " + oObject.tahunajaran;
            //oConn.Close(); oConn = null; oObject = null;

            bsiUsername.Caption = "Username : " + clsGlobal.strUserName;
            bsiServer.Caption = "Server : " + clsGlobal.str_Server;
            bsiDatabase.Caption = "Database : " + clsGlobal.str_Database;
            setPrivelegesMenu();
        }

        #region Click & Close
        private void setCheckedBCI(object sender, ItemClickEventArgs e)
        {
            if ((e.Item as BarCheckItem).Checked == false)
            {
                (e.Item as BarCheckItem).Checked = true;
            }
            for (int i = 0; i < ribbonControl.Pages.Count; i++)
            {
                for (int i2 = 0; i2 < ribbonControl.Pages[i].Groups.Count; i2++)
                {
                    for (int i3 = 0; i3 < ribbonControl.Pages[i].Groups[i2].ItemLinks.Count; i3++)
                    {
                        //if ((ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Name != e.Item.Name)
                        //{
                        //    (ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Checked = false;
                        //}
                        BarCheckItem bci = ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem;
                        if (bci == null) continue;
                        if (bci.Name != e.Item.Name)
                        {
                            if (bci.Checked == true)
                            {
                                bci.Checked = false;
                            }
                        }
                    }
                }
            }
            setPrivilegesButton(sender, e);
        }

        public void closeUC()
        {
            for (int i = 0; i < ribbonControl.Pages.Count; i++)
            {
                for (int i2 = 0; i2 < ribbonControl.Pages[i].Groups.Count; i2++)
                {
                    for (int i3 = 0; i3 < ribbonControl.Pages[i].Groups[i2].ItemLinks.Count; i3++)
                    {
                        //if ((ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Checked == true)
                        //{
                        //    (ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem).Checked = false;
                        //}
                        BarCheckItem bci = ribbonControl.Pages[i].Groups[i2].ItemLinks[i3].Item as BarCheckItem;
                        if (bci == null) continue;
                        if (bci.Checked == true)
                        {
                            bci.Checked = false;
                        }
                    }
                }
            }

            if (mainPanel.Controls.Count > 0)
            {
                foreach (Control ctl in mainPanel.Controls)
                {
                    ctl.Dispose();
                    Application.DoEvents();
                }
            }
        }
        #endregion

        private void bciClose_CheckedChanged(object sender, ItemClickEventArgs e)
        {
            closeUC();
            bciClose.Checked = false;
        }

        #region Add Form

        private Utility.ucUtility formUtility;
        private void bciUtility_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciUtility.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formUtility = new Utility.ucUtility();
            mainPanel.Controls.Add(formUtility);
            formUtility.Dock = DockStyle.Fill;
            formUtility.formMain = this;
            bciUtility.Enabled = true;
        }

        private Utility.ucManagementUser formManagementUser;
        private void bciManagementUser_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciManagementUser.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formManagementUser = new Utility.ucManagementUser();
            mainPanel.Controls.Add(formManagementUser);
            formManagementUser.Dock = DockStyle.Fill;
            formManagementUser.formMain = this;
            formManagementUser.refreshAll();
            bciManagementUser.Enabled = true;
        }

        #endregion

        private void bciCheckUpdate_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciCheckUpdate.Enabled = false;
            closeUC();
            //setCheckedBCI(sender, e);
            if (XtraMessageBox.Show("Are you sure want to check latest update of application?\n\n" +
                               "Application will be closed during checking update.", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                showUpdateApp(false);
            }
            bciCheckUpdate.Enabled = true;
        }

        private DIGILIB.Honor.userControlReports UCReports;
        private void bciReports_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciReports.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCReports = new DIGILIB.Honor.userControlReports();
            mainPanel.Controls.Add(UCReports);
            UCReports.Dock = DockStyle.Fill;
            UCReports.formMain = this;
            UCReports.refreshAll();
            bciReports.Enabled = true;

        }

        private DIGILIB.Transaksi.ucPeminjaman formPeminjaman;
        private void bciPeminjaman_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciPeminjaman.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formPeminjaman = new Transaksi.ucPeminjaman();
            mainPanel.Controls.Add(formPeminjaman);
            formPeminjaman.Dock = DockStyle.Fill;
            formPeminjaman.formMain = this;
            formPeminjaman.refreshAll();
            bciPeminjaman.Enabled = true;
        }

        private DIGILIB.MasterData.ucPengadaan formPengadaan;
        private void bciDaftarGaji_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciPengadaan.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formPengadaan = new MasterData.ucPengadaan();
            mainPanel.Controls.Add(formPengadaan);
            formPengadaan.Dock = DockStyle.Fill;
            formPengadaan.formMain = this;
            formPengadaan.loadData();
            bciPengadaan.Enabled = true;
        }

        private DIGILIB.MasterData.ucBuku formBuku;
        private void bciBuku_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciBuku.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formBuku = new MasterData.ucBuku();
            mainPanel.Controls.Add(formBuku);
            formBuku.Dock = DockStyle.Fill;
            formBuku.formMain = this;
            formBuku.loadDataProdi();
            formBuku.loadData();
            bciBuku.Enabled = true;
        }

        private DIGILIB.Utility.ucNumberingPrefix formPrefixNumber;
        private void bciPrefixNumber_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciPrefixNumber.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formPrefixNumber = new Utility.ucNumberingPrefix();
            mainPanel.Controls.Add(formPrefixNumber);
            formPrefixNumber.Dock = DockStyle.Fill;
            formPrefixNumber.formMain = this;
            formPrefixNumber.refreshAll();
            bciPrefixNumber.Enabled = true;
        }

        private DIGILIB.MasterData.ucAnggota formAnggota;
        private void bciAnggota_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciAnggota.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formAnggota = new MasterData.ucAnggota();
            mainPanel.Controls.Add(formAnggota);
            formAnggota.Dock = DockStyle.Fill;
            formAnggota.formMain = this;
            formAnggota.loadData();
            bciAnggota.Enabled = true;
        }

        Transaksi.ucPengembalian formPengembalian;
        private void bciPengembalian_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciPengembalian.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formPengembalian = new Transaksi.ucPengembalian();
            mainPanel.Controls.Add(formPengembalian);
            formPengembalian.Dock = DockStyle.Fill;
            formPengembalian.formMain = this;
            formPengembalian.refreshAll();
            bciPengembalian.Enabled = true;
        }

        private DIGILIB.MasterData.ucMultimedia formMultimedia;
        private void bciMultimedia_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciMultimedia.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            formMultimedia = new MasterData.ucMultimedia();
            mainPanel.Controls.Add(formMultimedia);
            formMultimedia.Dock = DockStyle.Fill;
            formMultimedia.formMain = this;
            formMultimedia.loadData();
            bciMultimedia.Enabled = true;
        }
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private DIGILIB.WebAdmin.UserControlNews UCNews;
        private void bciNews_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciNews.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCNews = new WebAdmin.UserControlNews();
            mainPanel.Controls.Add(UCNews);
            UCNews.Dock = DockStyle.Fill;
            UCNews.formMain = this;
            UCNews.refreshAll();
            bciNews.Enabled = true;
        }

        private DIGILIB.WebAdmin.UserControlAgenda UCAgenda;
        private void bciAgenda_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciAgenda.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCAgenda = new WebAdmin.UserControlAgenda();
            mainPanel.Controls.Add(UCAgenda);
            UCAgenda.Dock = DockStyle.Fill;
            UCAgenda.formMain = this;
            UCAgenda.refreshAll();
            bciAgenda.Enabled = true;
        }

        private DIGILIB.Utility.ucTanggalLibur UCTglMerah;
        private void bciSettingTanggalMerah_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciSettingTanggalMerah.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCTglMerah = new Utility.ucTanggalLibur();
            mainPanel.Controls.Add(UCTglMerah);
            UCTglMerah.Dock = DockStyle.Fill;
            UCTglMerah.formMain = this;
            bciSettingTanggalMerah.Enabled = true;
        }

        private DIGILIB.Transaksi.ucBookStatus UCcBookStatus;
        private void bciStatusBuku_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciStatusBuku.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCcBookStatus = new Transaksi.ucBookStatus();
            mainPanel.Controls.Add(UCcBookStatus);
            UCcBookStatus.Dock = DockStyle.Fill;
            UCcBookStatus.formMain = this;
            UCcBookStatus.Refresh();
            bciStatusBuku.Enabled = true;
        }

        private DIGILIB.Transaksi.ucPengunjung UCPengunjung;
        private void bciPengunjung_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciPengunjung.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCPengunjung = new Transaksi.ucPengunjung();
            mainPanel.Controls.Add(UCPengunjung);
            UCPengunjung.Dock = DockStyle.Fill;
            UCPengunjung.formMain = this;
            UCPengunjung.Refresh();
            bciPengunjung.Enabled = true;
        }

        private DIGILIB.Transaksi.ucReminderJatuhTempo UCReminderJatuhTempo;
        private void bciReminderMendekatiJatuhTempo_ItemClick(object sender, ItemClickEventArgs e)
        {
            bciReminderMendekatiJatuhTempo.Enabled = false;
            closeUC();
            setCheckedBCI(sender, e);
            UCReminderJatuhTempo = new Transaksi.ucReminderJatuhTempo();
            mainPanel.Controls.Add(UCReminderJatuhTempo);
            UCReminderJatuhTempo.Dock = DockStyle.Fill;
            UCReminderJatuhTempo.formMain = this;
            UCReminderJatuhTempo.Refresh();
            bciReminderMendekatiJatuhTempo.Enabled = true;
        }
    }
}