﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;

namespace DIGILIB.Utility
{
    public partial class ucUtility : DevExpress.XtraEditors.XtraUserControl
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;

        public ucUtility()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void btnPatchMapping_Click(object sender, EventArgs e)
        {
            //btnPatchMapping.Enabled = false;
            //setLoadDialog(true, "Moving data Mapped...");
            //oconn.Open();
            //clstbl_mappingunit oObject = new clstbl_mappingunit();
            //oObject.Koneksi = oconn.Conn;
            //string strSql = @"select makdetailid, unitid from tbm_makdetail where dlt='0' and tahun='" + clsGlobal.str_Tahun + "' and (unitid is not null or unitid<>'')";
            //DataTable dtMakdetail = oObject.GetData(strSql);
            //int jmldata = 0;
            //for (int i = 0; i < dtMakdetail.Rows.Count; i++ )
            //{
            //    jmldata = 0;
            //    strSql = "select count(*) from tbl_mappingunit where dlt='0' and tahun='" + clsGlobal.str_Tahun + "' and unitid='" + dtMakdetail.Rows[i]["unitid"].ToString() + "' and makdetailid='" + dtMakdetail.Rows[i]["makdetailid"].ToString() + "'";
            //    jmldata = Convert.ToInt32(clsGlobal.getData1Field(strSql));
            //    if (jmldata == 0)
            //    {
            //        oObject.makdetailid = dtMakdetail.Rows[i]["makdetailid"].ToString();
            //        oObject.unitid = dtMakdetail.Rows[i]["unitid"].ToString();
            //        oObject.mappingunitid = oObject.NewID();
            //        oObject.op_add = clsGlobal.strUserName;
            //        oObject.pc_add = SystemInformation.ComputerName;
            //        oObject.tahun = clsGlobal.str_Tahun;
            //        oObject.Insert();
            //    }
            //}
            //oconn.Close();
            //oObject = null;
            //setLoadDialog(false, "");
            //btnPatchMapping.Enabled = true;
        }

        private void ucUtility_Leave(object sender, EventArgs e)
        {
            loadDialog.Close();
            loadDialog.Dispose();
        }

        private void btnPachDatabase_Click(object sender, EventArgs e)
        {
            btnPachDatabase.Enabled=false;
            setLoadDialog(true, "Patching Database...");
            clsGlobal.setupdatabase();
            setLoadDialog(false, "");
            btnPachDatabase.Enabled = true;
        }
    }
}
