﻿namespace DIGILIB.Utility
{
    partial class frmBookHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBookHistory));
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.lblRFID = new DevExpress.XtraEditors.LabelControl();
            this.lblNIB = new DevExpress.XtraEditors.LabelControl();
            this.lblBibli = new DevExpress.XtraEditors.LabelControl();
            this.lblJudul = new DevExpress.XtraEditors.LabelControl();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.peminjamanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.anggotaid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.petugasid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopeminjaman = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglpinjam = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tgljatuhtempo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfidanggota = new DevExpress.XtraGrid.Columns.GridColumn();
            this.namaanggota = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nimanggota = new DevExpress.XtraGrid.Columns.GridColumn();
            this.keterangan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.namapetugas = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopengembalian = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglkembali = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jumlahdenda = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dendadibayar = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.timerScan = new System.Windows.Forms.Timer(this.components);
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.btnScan = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(831, 426);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(91, 24);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl1.Location = new System.Drawing.Point(12, 10);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(27, 13);
            this.labelControl1.TabIndex = 15;
            this.labelControl1.Text = "RFID";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl2.Location = new System.Drawing.Point(92, 10);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(3, 13);
            this.labelControl2.TabIndex = 16;
            this.labelControl2.Text = ":";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl3.Location = new System.Drawing.Point(92, 29);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(3, 13);
            this.labelControl3.TabIndex = 18;
            this.labelControl3.Text = ":";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl4.Location = new System.Drawing.Point(12, 29);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(19, 13);
            this.labelControl4.TabIndex = 17;
            this.labelControl4.Text = "NIB";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl5.Location = new System.Drawing.Point(469, 10);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(3, 13);
            this.labelControl5.TabIndex = 20;
            this.labelControl5.Text = ":";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl6.Location = new System.Drawing.Point(389, 10);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(23, 13);
            this.labelControl6.TabIndex = 19;
            this.labelControl6.Text = "Bibli";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl7.Location = new System.Drawing.Point(469, 29);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(3, 13);
            this.labelControl7.TabIndex = 22;
            this.labelControl7.Text = ":";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl8.Location = new System.Drawing.Point(389, 29);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(61, 13);
            this.labelControl8.TabIndex = 21;
            this.labelControl8.Text = "Judul Buku";
            // 
            // lblRFID
            // 
            this.lblRFID.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblRFID.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblRFID.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.lblRFID.Location = new System.Drawing.Point(101, 10);
            this.lblRFID.Name = "lblRFID";
            this.lblRFID.Size = new System.Drawing.Size(265, 13);
            this.lblRFID.TabIndex = 23;
            this.lblRFID.Text = "RFID";
            // 
            // lblNIB
            // 
            this.lblNIB.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblNIB.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblNIB.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.lblNIB.Location = new System.Drawing.Point(101, 29);
            this.lblNIB.Name = "lblNIB";
            this.lblNIB.Size = new System.Drawing.Size(265, 13);
            this.lblNIB.TabIndex = 24;
            this.lblNIB.Text = "NIB";
            // 
            // lblBibli
            // 
            this.lblBibli.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblBibli.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblBibli.Location = new System.Drawing.Point(478, 10);
            this.lblBibli.Name = "lblBibli";
            this.lblBibli.Size = new System.Drawing.Size(27, 13);
            this.lblBibli.TabIndex = 25;
            this.lblBibli.Text = "RFID";
            // 
            // lblJudul
            // 
            this.lblJudul.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblJudul.Location = new System.Drawing.Point(478, 29);
            this.lblJudul.Name = "lblJudul";
            this.lblJudul.Size = new System.Drawing.Size(27, 13);
            this.lblJudul.TabIndex = 26;
            this.lblJudul.Text = "RFID";
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.Location = new System.Drawing.Point(12, 52);
            this.dgData.MainView = this.gridView1;
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1});
            this.dgData.Size = new System.Drawing.Size(910, 368);
            this.dgData.TabIndex = 67;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridView1.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.peminjamanid,
            this.anggotaid,
            this.petugasid,
            this.nopeminjaman,
            this.tglpinjam,
            this.tgljatuhtempo,
            this.rfidanggota,
            this.namaanggota,
            this.nimanggota,
            this.keterangan,
            this.namapetugas,
            this.nopengembalian,
            this.tglkembali,
            this.jumlahdenda,
            this.dendadibayar});
            this.gridView1.GridControl = this.dgData;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.RowAutoHeight = true;
            this.gridView1.OptionsView.ShowAutoFilterRow = true;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // peminjamanid
            // 
            this.peminjamanid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.peminjamanid.AppearanceHeader.Options.UseFont = true;
            this.peminjamanid.AppearanceHeader.Options.UseTextOptions = true;
            this.peminjamanid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.peminjamanid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.peminjamanid.Caption = "peminjamanid";
            this.peminjamanid.FieldName = "peminjamanid";
            this.peminjamanid.Name = "peminjamanid";
            // 
            // anggotaid
            // 
            this.anggotaid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.anggotaid.AppearanceHeader.Options.UseFont = true;
            this.anggotaid.AppearanceHeader.Options.UseTextOptions = true;
            this.anggotaid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.anggotaid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.anggotaid.Caption = "anggotaid";
            this.anggotaid.FieldName = "anggotaid";
            this.anggotaid.Name = "anggotaid";
            // 
            // petugasid
            // 
            this.petugasid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.petugasid.AppearanceHeader.Options.UseFont = true;
            this.petugasid.AppearanceHeader.Options.UseTextOptions = true;
            this.petugasid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.petugasid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.petugasid.Caption = "petugasid";
            this.petugasid.FieldName = "petugasid";
            this.petugasid.MinWidth = 120;
            this.petugasid.Name = "petugasid";
            this.petugasid.Width = 130;
            // 
            // nopeminjaman
            // 
            this.nopeminjaman.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nopeminjaman.AppearanceHeader.Options.UseFont = true;
            this.nopeminjaman.AppearanceHeader.Options.UseTextOptions = true;
            this.nopeminjaman.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nopeminjaman.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nopeminjaman.Caption = "No Peminjaman";
            this.nopeminjaman.FieldName = "nopeminjaman";
            this.nopeminjaman.MinWidth = 180;
            this.nopeminjaman.Name = "nopeminjaman";
            this.nopeminjaman.Visible = true;
            this.nopeminjaman.VisibleIndex = 0;
            this.nopeminjaman.Width = 201;
            // 
            // tglpinjam
            // 
            this.tglpinjam.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tglpinjam.AppearanceHeader.Options.UseFont = true;
            this.tglpinjam.AppearanceHeader.Options.UseTextOptions = true;
            this.tglpinjam.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam.Caption = "Tgl Pinjam";
            this.tglpinjam.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.tglpinjam.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglpinjam.FieldName = "tglpinjam";
            this.tglpinjam.MinWidth = 120;
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.Visible = true;
            this.tglpinjam.VisibleIndex = 1;
            this.tglpinjam.Width = 171;
            // 
            // tgljatuhtempo
            // 
            this.tgljatuhtempo.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tgljatuhtempo.AppearanceHeader.Options.UseFont = true;
            this.tgljatuhtempo.AppearanceHeader.Options.UseTextOptions = true;
            this.tgljatuhtempo.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo.Caption = "Tgl Jatuh Tempo";
            this.tgljatuhtempo.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.tgljatuhtempo.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tgljatuhtempo.FieldName = "tgljatuhtempo";
            this.tgljatuhtempo.MinWidth = 120;
            this.tgljatuhtempo.Name = "tgljatuhtempo";
            this.tgljatuhtempo.Visible = true;
            this.tgljatuhtempo.VisibleIndex = 2;
            this.tgljatuhtempo.Width = 130;
            // 
            // rfidanggota
            // 
            this.rfidanggota.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfidanggota.AppearanceHeader.Options.UseFont = true;
            this.rfidanggota.AppearanceHeader.Options.UseTextOptions = true;
            this.rfidanggota.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfidanggota.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfidanggota.Caption = "RFID Anggota";
            this.rfidanggota.FieldName = "rfidanggota";
            this.rfidanggota.MinWidth = 150;
            this.rfidanggota.Name = "rfidanggota";
            this.rfidanggota.Width = 150;
            // 
            // namaanggota
            // 
            this.namaanggota.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.namaanggota.AppearanceHeader.Options.UseFont = true;
            this.namaanggota.AppearanceHeader.Options.UseTextOptions = true;
            this.namaanggota.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.namaanggota.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.namaanggota.Caption = "Nama Anggota";
            this.namaanggota.FieldName = "namaanggota";
            this.namaanggota.MinWidth = 180;
            this.namaanggota.Name = "namaanggota";
            this.namaanggota.Visible = true;
            this.namaanggota.VisibleIndex = 4;
            this.namaanggota.Width = 180;
            // 
            // nimanggota
            // 
            this.nimanggota.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nimanggota.AppearanceHeader.Options.UseFont = true;
            this.nimanggota.AppearanceHeader.Options.UseTextOptions = true;
            this.nimanggota.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nimanggota.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nimanggota.Caption = "NIM/NIK";
            this.nimanggota.FieldName = "nimanggota";
            this.nimanggota.MinWidth = 180;
            this.nimanggota.Name = "nimanggota";
            this.nimanggota.Visible = true;
            this.nimanggota.VisibleIndex = 3;
            this.nimanggota.Width = 180;
            // 
            // keterangan
            // 
            this.keterangan.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.keterangan.AppearanceHeader.Options.UseFont = true;
            this.keterangan.AppearanceHeader.Options.UseTextOptions = true;
            this.keterangan.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.keterangan.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.keterangan.Caption = "Keterangan";
            this.keterangan.FieldName = "keterangan";
            this.keterangan.MinWidth = 200;
            this.keterangan.Name = "keterangan";
            this.keterangan.Width = 200;
            // 
            // namapetugas
            // 
            this.namapetugas.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.namapetugas.AppearanceHeader.Options.UseFont = true;
            this.namapetugas.AppearanceHeader.Options.UseTextOptions = true;
            this.namapetugas.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.namapetugas.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.namapetugas.Caption = "Nama Petugas";
            this.namapetugas.FieldName = "namapetugas";
            this.namapetugas.MinWidth = 180;
            this.namapetugas.Name = "namapetugas";
            this.namapetugas.Width = 180;
            // 
            // nopengembalian
            // 
            this.nopengembalian.Caption = "No Pengembalian";
            this.nopengembalian.FieldName = "nopengembalian";
            this.nopengembalian.MinWidth = 150;
            this.nopengembalian.Name = "nopengembalian";
            this.nopengembalian.Visible = true;
            this.nopengembalian.VisibleIndex = 5;
            this.nopengembalian.Width = 150;
            // 
            // tglkembali
            // 
            this.tglkembali.Caption = "Tgl Kembali";
            this.tglkembali.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.tglkembali.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglkembali.FieldName = "tglkembali";
            this.tglkembali.MinWidth = 120;
            this.tglkembali.Name = "tglkembali";
            this.tglkembali.Visible = true;
            this.tglkembali.VisibleIndex = 6;
            this.tglkembali.Width = 120;
            // 
            // jumlahdenda
            // 
            this.jumlahdenda.Caption = "Jml Denda";
            this.jumlahdenda.DisplayFormat.FormatString = "#,##0";
            this.jumlahdenda.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.jumlahdenda.FieldName = "jumlahdenda";
            this.jumlahdenda.MinWidth = 120;
            this.jumlahdenda.Name = "jumlahdenda";
            this.jumlahdenda.Visible = true;
            this.jumlahdenda.VisibleIndex = 7;
            this.jumlahdenda.Width = 120;
            // 
            // dendadibayar
            // 
            this.dendadibayar.Caption = "Denda Dibayar";
            this.dendadibayar.DisplayFormat.FormatString = "#,##0";
            this.dendadibayar.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.dendadibayar.FieldName = "dendadibayar";
            this.dendadibayar.MinWidth = 140;
            this.dendadibayar.Name = "dendadibayar";
            this.dendadibayar.Visible = true;
            this.dendadibayar.VisibleIndex = 8;
            this.dendadibayar.Width = 140;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // timerScan
            // 
            this.timerScan.Interval = 1000;
            this.timerScan.Tick += new System.EventHandler(this.timerScan_Tick);
            // 
            // panelControl1
            // 
            this.panelControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl1.Controls.Add(this.labelControl9);
            this.panelControl1.Controls.Add(this.pictureEdit1);
            this.panelControl1.Location = new System.Drawing.Point(12, 12);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(910, 172);
            this.panelControl1.TabIndex = 68;
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold);
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl9.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl9.Location = new System.Drawing.Point(141, 36);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(654, 73);
            this.labelControl9.TabIndex = 1;
            this.labelControl9.Text = "SILAHKAN SCAN BUKU YANG DIINGINKAN...";
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.EditValue = ((object)(resources.GetObject("pictureEdit1.EditValue")));
            this.pictureEdit1.Location = new System.Drawing.Point(23, 36);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.pictureEdit1.Properties.Appearance.Options.UseBackColor = true;
            this.pictureEdit1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.pictureEdit1.Size = new System.Drawing.Size(70, 73);
            this.pictureEdit1.TabIndex = 0;
            // 
            // btnScan
            // 
            this.btnScan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnScan.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnScan.Appearance.Options.UseFont = true;
            this.btnScan.Enabled = false;
            this.btnScan.Image = ((System.Drawing.Image)(resources.GetObject("btnScan.Image")));
            this.btnScan.Location = new System.Drawing.Point(12, 426);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(142, 24);
            this.btnScan.TabIndex = 69;
            this.btnScan.Text = "Scan Buku Lainnya";
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // frmBookHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 462);
            this.Controls.Add(this.btnScan);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.dgData);
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblBibli);
            this.Controls.Add(this.lblNIB);
            this.Controls.Add(this.lblRFID);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.btnClose);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmBookHistory";
            this.Text = "Book History";
            this.Load += new System.EventHandler(this.frmBookHistory_Load);
            this.Leave += new System.EventHandler(this.frmBookHistory_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl lblRFID;
        private DevExpress.XtraEditors.LabelControl lblNIB;
        private DevExpress.XtraEditors.LabelControl lblBibli;
        private DevExpress.XtraEditors.LabelControl lblJudul;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamanid;
        private DevExpress.XtraGrid.Columns.GridColumn anggotaid;
        private DevExpress.XtraGrid.Columns.GridColumn petugasid;
        private DevExpress.XtraGrid.Columns.GridColumn nopeminjaman;
        private DevExpress.XtraGrid.Columns.GridColumn tglpinjam;
        private DevExpress.XtraGrid.Columns.GridColumn tgljatuhtempo;
        private DevExpress.XtraGrid.Columns.GridColumn rfidanggota;
        private DevExpress.XtraGrid.Columns.GridColumn namaanggota;
        private DevExpress.XtraGrid.Columns.GridColumn nimanggota;
        private DevExpress.XtraGrid.Columns.GridColumn keterangan;
        private DevExpress.XtraGrid.Columns.GridColumn namapetugas;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private System.Windows.Forms.Timer timerScan;
        private DevExpress.XtraGrid.Columns.GridColumn nopengembalian;
        private DevExpress.XtraGrid.Columns.GridColumn tglkembali;
        private DevExpress.XtraGrid.Columns.GridColumn jumlahdenda;
        private DevExpress.XtraGrid.Columns.GridColumn dendadibayar;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        public DevExpress.XtraEditors.SimpleButton btnScan;
    }
}