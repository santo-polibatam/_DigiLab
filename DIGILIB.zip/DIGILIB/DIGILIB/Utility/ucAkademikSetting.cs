﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;

namespace DIGILIB.akademik
{
    public partial class ucAkademikSetting : DevExpress.XtraEditors.XtraUserControl
    {

        public frmMain formMain;
        WaitDialogForm loadDialog;

        public ucAkademikSetting()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void ucUtility_Leave(object sender, EventArgs e)
        {
            loadDialog.Close();
            loadDialog.Dispose();
        }

        private void btnSemester1_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();
                clstba_config oObject = new clstba_config();
                oObject.Koneksi = oConn.Conn;
                string strSql = @"select configid, configvalue from tba_config where dlt='0' and configname='semester'";
                string strconfigID = clsGlobal.getData1Field(strSql);
                oObject.GetByPrimaryKey(strconfigID);
                oObject.configvalue = "1";
                oObject.configname = "semester";
                if (oObject.configid == null || oObject.configid == "")
                {
                    oObject.configid = oObject.NewID();
                    oObject.op_add = clsGlobal.strUserName;
                    oObject.pc_add = SystemInformation.ComputerName;
                    oObject.Insert();
                }
                else
                {
                    oObject.op_edit = clsGlobal.strUserName;
                    oObject.pc_edit = SystemInformation.ComputerName;
                    oObject.Update();
                }
                oObject = null;
                setLoadDialog(false, "");
            }
            loadData();
        }

        private void btnSemester2_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();
                clstba_config oObject = new clstba_config();
                oObject.Koneksi = oConn.Conn;
                string strSql = @"select configid, configvalue from tba_config where dlt='0' and configname='semester'";
                string strconfigID = clsGlobal.getData1Field(strSql);
                oObject.GetByPrimaryKey(strconfigID);
                oObject.configvalue = "2";
                oObject.configname = "semester";
                if (oObject.configid == null || oObject.configid == "")
                {
                    oObject.configid = oObject.NewID();
                    oObject.op_add = clsGlobal.strUserName;
                    oObject.pc_add = SystemInformation.ComputerName;
                    oObject.Insert();
                }
                else
                {
                    oObject.op_edit = clsGlobal.strUserName;
                    oObject.pc_edit = SystemInformation.ComputerName;
                    oObject.Update();
                }
                oObject = null;
                setLoadDialog(false, "");
            }
            loadData();
        }

        private void loadData()
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();
                clstba_config oObject = new clstba_config();
                oObject.Koneksi = oConn.Conn;
                string strSql = @"select configvalue from tba_config where dlt='0' and configname='semester'";
                string strconfigValue = clsGlobal.getData1Field(strSql);
                oConn.Close();
                if (strconfigValue == "1")
                {
                    btnSemester1.Enabled = false;
                    btnSemester2.Enabled = true;
                    btnSemester1.ForeColor = Color.LightGray;
                    btnSemester2.ForeColor = Color.ForestGreen;
                    lblSemester.Text = "Semester Genap";

                }
                else if (strconfigValue == "2")
                {
                    btnSemester2.Enabled = false;
                    btnSemester1.Enabled = true;
                    btnSemester1.ForeColor = Color.Blue;
                    btnSemester2.ForeColor = Color.LightGray;
                    lblSemester.Text = "Semester Ganjil";
                }
                oObject = null;
                setLoadDialog(false, "");
            }
        }

        private void ucAkademikSetting_Load(object sender, EventArgs e)
        {
            loadData();
            loadDataBiaya();
            loadDataGelombang();
            loadDataMataPelajaran();
            loadDataPublish();
        }

        public void loadDataBiaya()
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();
                tba_tahunajaran oObject = new tba_tahunajaran();
                oObject.Koneksi = oConn.Conn;
                string strSql = @"select tahunajaranid, tahunajaran, isactive from tba_tahunajaran where dlt='0' order by tahunajaran";
                DataTable dt = oObject.GetData(strSql);
                dgDataTahunAjaran.DataSource = dt;
                oConn.Close();
                setLoadDialog(false, "");
                if (dt.Rows.Count == 0)
                {
                    btnEditBiaya.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                    btnDelBiaya.Enabled = false;
                }
                else
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToBoolean(dt.Rows[i]["isactive"]))
                        {
                            lblTahunAjaran.Text = "Tahun Ajaran Aktif : " + dt.Rows[i]["tahunajaran"];
                            break;
                        }
                    }
                    btnDelBiaya.Enabled = clsGlobal.bolDelete;
                    btnEditBiaya.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                }
            }
        }

        public void loadDataGelombang()
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();

                string strSQL = "select gelombangid, jalurmasuk, gelombang, reguler, karyawan, jamujian from tba_gelombang where dlt='0' and tahun='" + clsGlobal.str_Tahun + "' order by gelombang asc";
                NpgsqlCommand cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataSet ds = new DataSet();
                DataTable dt = ds.Tables.Add("tbldetail");
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tbldetail");

                strSQL = @"(select 'UMPN' as jalurmasuk, 1 as nourut)
                        union
                        (select 'UMPB' as jalurmasuk, 2 as nourut)
                        union
                        (select 'PMDK' as jalurmasuk, 3 as nourut)
                        union
                        (select 'D4' as jalurmasuk, 4 as nourut)
                        union
                        (select 'PPL' as jalurmasuk, 4 as nourut)
                        order by nourut";
                cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataTable dt1 = ds.Tables.Add("tblmaster");
                da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tblmaster");
                ds.Relations.Add(new DataRelation("detailData", dt1.Columns["jalurmasuk"], dt.Columns["jalurmasuk"]));
                dgGelombang.DataSource = dt1;

                dgGelombang.LevelTree.Nodes.Add("detailData", gridViewDetail);
                for (int i = 0; i < gridViewMaster.RowCount; i++)
                {
                    gridViewMaster.SetMasterRowExpandedEx(i, 0, true);
                }

                oConn.Close();
                setLoadDialog(false, "");
                btnEditGelombang.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                btnDelGelombang.Enabled = clsGlobal.bolDelete;
            }
        }

        public void loadDataMataPelajaran()
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();

                string strSQL = "select matapelajaranid, jalurmasuk, kode, nama from tba_matapelajaran where tahun='" + clsGlobal.str_Tahun + "' and dlt='0' order by lu_add";
                NpgsqlCommand cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataSet ds = new DataSet();
                DataTable dt = ds.Tables.Add("tbldetail");
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tbldetail");

                strSQL = @"(select 'UMPN' as jalurmasuk, 1 as nourut)
                        union
                        (select 'UMPB' as jalurmasuk, 2 as nourut)
                        union
                        (select 'PMDK' as jalurmasuk, 3 as nourut)
                        union
                        (select 'D4' as jalurmasuk, 4 as nourut)
                        /*union
                        (select 'PPL' as jalurmasuk, 4 as nourut)*/
                        order by nourut";
                cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataTable dt1 = ds.Tables.Add("tblmaster");
                da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tblmaster");
                ds.Relations.Add(new DataRelation("detailData", dt1.Columns["jalurmasuk"], dt.Columns["jalurmasuk"]));
                dgMataPelajaran.DataSource = dt1;

                dgMataPelajaran.LevelTree.Nodes.Add("detailData", gridViewMataPelajaran1);
                for (int i = 0; i < gridViewMataPelajaran2.RowCount; i++)
                {
                    gridViewMataPelajaran2.SetMasterRowExpandedEx(i, 0, true);
                }

                oConn.Close();
                setLoadDialog(false, "");

                btnEditPelajaran.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                btnDelPelajaran.Enabled = clsGlobal.bolDelete;
            }
        }

        public void loadDataPublish()
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Please wait...");
                oConn.Open();

                string strSQL = @"select a.jalurmasuk, b.gelombangid, b.tanggal, b.gelombang, b.jeniskelas, c.publishkelulusanid, coalesce(c.ispublish,false) as ispublish
                            from
                            (
	                            (select 'UMPN' as jalurmasuk, 1 as nourut)
	                            union
	                            (select 'UMPB' as jalurmasuk, 2 as nourut)
	                            union
	                            (select 'PMDK' as jalurmasuk, 3 as nourut)
	                            union
	                            (select 'D4' as jalurmasuk, 4 as nourut)
	                            union
	                            (select 'PPL' as jalurmasuk, 5 as nourut)
	                            order by nourut
                            ) a
                            inner join 
                            (
	                            (
		                            select gelombangid, jalurmasuk, reguler as tanggal, gelombang, 'Reguler' as jeniskelas, 1 as nourut2
		                            from tba_gelombang 
		                            where dlt='0' and tahun='" + clsGlobal.str_Tahun + @"' and reguler is not null
		                            order by gelombang
	                            )
	                            union 
	                            (
		                            select gelombangid, jalurmasuk, karyawan as tanggal, gelombang, 'Karyawan' as jeniskelas, 2 as nourut2
		                            from tba_gelombang 
		                            where dlt='0' and tahun='" + clsGlobal.str_Tahun + @"' and karyawan is not null
		                            order by gelombang
	                            )
                            ) b on lower(a.jalurmasuk)=lower(b.jalurmasuk)
                            left outer join tba_publishkelulusan c on lower(a.jalurmasuk)=lower(c.jalurmasuk) and c.dlt='0' and c.tahun='" + clsGlobal.str_Tahun + @"' and b.gelombangid=c.gelombangid and lower(b.jeniskelas)=lower(c.jeniskelas)
                            order by a.nourut, b.nourut2, b.gelombang;";
                dgPublish.DataSource = oConn.GetData(strSQL);
                oConn.Close();
                setLoadDialog(false, "");
                btnEditGelombang.Enabled = clsGlobal.bolEdit;
            }
        }

        private void btnEditBiaya_Click(object sender, EventArgs e)
        {
            gridViewDataTahun.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            btnEditBiaya.Enabled = false;
            btnDelBiaya.Enabled = false;
            btnCancelBiaya.Enabled = true;
            gridViewDataTahun.OptionsBehavior.Editable = true;
        }

        private void btnCancelBiaya_Click(object sender, EventArgs e)
        {
            gridViewDataTahun.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None;
            btnEditBiaya.Enabled = true;
            btnDelBiaya.Enabled = true;
            btnCancelBiaya.Enabled = false;
            gridViewDataTahun.OptionsBehavior.Editable = false;
        }

        private void gridViewDataBiaya_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                tba_tahunajaran oObject = new tba_tahunajaran();
                oObject.Koneksi = oConn.Conn;
                string strBiayaID = "";
                strBiayaID = Convert.ToString(gridViewDataTahun.GetFocusedRowCellValue(tahunajaranid));
                oObject.GetByPrimaryKey(strBiayaID);
                oObject.tahunajaran = Convert.ToString(gridViewDataTahun.GetFocusedRowCellValue(tahunajaran));
                bool bolOut = false;
                bool.TryParse(Convert.ToString(gridViewDataTahun.GetFocusedRowCellValue(isactive)), out bolOut);
                oObject.isactive = bolOut;
                if (strBiayaID == "" || strBiayaID == null)
                {
                    oObject.op_add = clsGlobal.strUserName;
                    oObject.pc_add = SystemInformation.ComputerName;
                    oObject.tahunajaranid = oObject.NewID();
                    if (oObject.Insert())
                    {
                        gridViewDataTahun.SetFocusedRowCellValue(tahunajaranid, oObject.tahunajaranid);
                        gridViewDataTahun.SetFocusedRowCellValue(isactive, oObject.isactive);
                    }
                    else
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                else
                {
                    oObject.op_edit = clsGlobal.strUserName;
                    oObject.pc_edit = SystemInformation.ComputerName;
                    if (oObject.Update() == false)
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                oObject = null;
            }
            return;
        }

        private void btnDelBiaya_Click(object sender, EventArgs e)
        {
            if (gridViewDataTahun.RowCount > 0)
            {
                if (XtraMessageBox.Show("Anda yakin menghapus data ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    using (clsConnection oConn = new clsConnection())
                    {
                        tba_tahunajaran oObject = new tba_tahunajaran();
                        oConn.Open();
                        oObject.Koneksi = oConn.Conn;
                        oObject.GetByPrimaryKey(Convert.ToString(gridViewDataTahun.GetFocusedRowCellValue(tahunajaranid)));
                        if (oObject.tahunajaranid == null || oObject.tahunajaranid == "")
                        { }
                        else
                        {
                            oObject.op_edit = clsGlobal.strUserName;
                            oObject.pc_edit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                            gridViewDataTahun.DeleteSelectedRows();
                        }
                        oConn.Close();
                        oObject = null;
                    }
                }
            }
        }

        private void btnEditGelombang_Click(object sender, EventArgs e)
        {
            btnEditGelombang.Enabled = false;
            btnDelGelombang.Enabled = false;
            btnCancelGelombang.Enabled = true;
            gridViewDetail.OptionsBehavior.Editable = true;
            gridViewDetail.OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
        }

        private void btnCancelGelombang_Click(object sender, EventArgs e)
        {
            btnEditGelombang.Enabled = true;
            btnDelGelombang.Enabled = true;
            btnCancelGelombang.Enabled = false;
            gridViewDetail.OptionsBehavior.Editable = false;
            gridViewDetail.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
        }

        private void dgGelombang_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        {
            if (e.View != null && e.View.ParentView != null)
            {
                ColumnView view = e.View.ParentView as ColumnView;
                view.FocusedRowHandle = e.View.SourceRowHandle;
            }
        }

        private void btnEditPelajaran_Click(object sender, EventArgs e)
        {
            btnEditPelajaran.Enabled = false;
            btnDelPelajaran.Enabled = false;
            btnCancelPelajaran.Enabled = true;
            gridViewMataPelajaran1.OptionsBehavior.Editable = true;
        }

        private void btnCancelPelajaran_Click(object sender, EventArgs e)
        {
            btnEditPelajaran.Enabled = true;
            btnDelPelajaran.Enabled = true;
            btnCancelPelajaran.Enabled = false;
            gridViewMataPelajaran1.OptionsBehavior.Editable = false;
        }

        private void dgMataPelajaran_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        {
            if (e.View != null && e.View.ParentView != null)
            {
                ColumnView view = e.View.ParentView as ColumnView;
                view.FocusedRowHandle = e.View.SourceRowHandle;
            }
        }

        private void btnAktifTahun_Click(object sender, EventArgs e)
        {
            if (gridViewDataTahun.RowCount > 0)
            {
                using (clsConnection oConn = new clsConnection())
                {
                    string strIDActive = clsGlobal.getData1Field("select tahunajaranid from tba_tahunajaran where dlt='0' and isactive='1'");
                    tba_tahunajaran oObject = new tba_tahunajaran();
                    oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(Convert.ToString(gridViewDataTahun.GetFocusedRowCellValue(tahunajaranid)));
                    if (XtraMessageBox.Show("Anda yakin untuk aktifkan tahun ajaran : " + oObject.tahunajaran + " ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        if (oObject.tahunajaranid == null || oObject.tahunajaranid == "")
                        { }
                        else
                        {
                            oObject.isactive = true;
                            oObject.op_edit = clsGlobal.strUserName;
                            oObject.pc_edit = SystemInformation.ComputerName;
                            oObject.Update();
                            lblTahunAjaran.Text = "Tahun Ajaran Aktif : " + oObject.tahunajaran;
                            gridViewDataTahun.SetFocusedRowCellValue(isactive, true);

                            oObject.tahunajaranid = "";
                            oObject.GetByPrimaryKey(strIDActive);
                            oObject.isactive = false;
                            oObject.op_edit = clsGlobal.strUserName;
                            oObject.pc_edit = SystemInformation.ComputerName;
                            oObject.Update();

                            for (int i = 0; i < gridViewDataTahun.RowCount; i++)
                            {
                                if (Convert.ToString(gridViewDataTahun.GetRowCellValue(i, tahunajaranid)) == oObject.tahunajaranid)
                                {
                                    gridViewDataTahun.SetRowCellValue(i, isactive, false); break;
                                }
                            }
                        }
                    }

                    oObject = null;
                }
            }
        }

        private void gridViewDataTahun_RowStyle(object sender, RowStyleEventArgs e)
        {
            if (e.RowHandle >= 0 && Convert.ToBoolean(gridViewDataTahun.GetRowCellValue(e.RowHandle, isactive)))
            {
                e.Appearance.BackColor = Color.DarkGreen;
                e.Appearance.BackColor2 = Color.LightGreen;
            }
        }

        private void btnEditPublish_Click(object sender, EventArgs e)
        {
            chkPublishAll.Enabled = true;
            btnEditPublish.Enabled = false;
            btnEndEditPublish.Enabled = true;
            gridViewPublish.OptionsBehavior.Editable = true;
        }

        private void btnEndEditPublish_Click(object sender, EventArgs e)
        {
            chkPublishAll.Enabled = false;
            btnEditPublish.Enabled = clsGlobal.bolEdit;
            btnEndEditPublish.Enabled = false;
            gridViewPublish.OptionsBehavior.Editable = false;
        }

        private void chkPublishAll_CheckedChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < gridViewPublish.RowCount; i++)
            {
                if (Convert.ToString(gridViewPublish.GetRowCellValue(i, gelombangid5)) != "")
                {
                    gridViewPublish.SetRowCellValue(i, ispublish, chkPublishAll.Checked);
                }
            }
        }

        private void gridViewPublish_RowStyle(object sender, RowStyleEventArgs e)
        {
            if (e.RowHandle >= 0)
            {
                if (Convert.ToBoolean(gridViewPublish.GetRowCellValue(e.RowHandle, ispublish)) == true)
                {
                    e.Appearance.BackColor = Color.DarkGreen;
                    e.Appearance.BackColor2 = Color.LightGreen;
                }
            }
        }

        private void repositorychkPublish_EditValueChanged(object sender, EventArgs e)
        {
            gridViewPublish.PostEditor();
        }
    }
}
