﻿namespace DIGILIB.Utility
{
    partial class ucManagementUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucManagementUser));
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnEndEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnDel = new DevExpress.XtraEditors.SimpleButton();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.dgUSer = new DevExpress.XtraGrid.GridControl();
            this.gridViewUser = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.userid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nik = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nama = new DevExpress.XtraGrid.Columns.GridColumn();
            this.username = new DevExpress.XtraGrid.Columns.GridColumn();
            this.passwd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryTextPasswd = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.usergroupid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryLUGroup = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.photo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.dgGroup = new DevExpress.XtraGrid.GridControl();
            this.gridViewGroup = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.usergroupid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupname = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.xtraTabControl2 = new DevExpress.XtraTab.XtraTabControl();
            this.tabPrivilegeModule = new DevExpress.XtraTab.XtraTabPage();
            this.dgPrivilege = new DevExpress.XtraGrid.GridControl();
            this.gridViewPrivilege = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.moduleid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupview = new DevExpress.XtraGrid.Columns.GridColumn();
            this.modulename = new DevExpress.XtraGrid.Columns.GridColumn();
            this.usermoduleid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.userid2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isread = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.isadd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isedit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isdelete = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isprint = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isdownload = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isupload = new DevExpress.XtraGrid.Columns.GridColumn();
            this.usergroupmoduleid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.usergroupid2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tabPrivilegeProdi = new DevExpress.XtraTab.XtraTabPage();
            this.dgProdi = new DevExpress.XtraGrid.GridControl();
            this.gridViewProdi = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.userprodiid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodiid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jurusanview = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodiview = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.chkRead = new DevExpress.XtraEditors.CheckEdit();
            this.chkAdd = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit = new DevExpress.XtraEditors.CheckEdit();
            this.chkDelete = new DevExpress.XtraEditors.CheckEdit();
            this.chkPrint = new DevExpress.XtraEditors.CheckEdit();
            this.chkExport = new DevExpress.XtraEditors.CheckEdit();
            this.chkImport = new DevExpress.XtraEditors.CheckEdit();
            this.btnSavePriv = new DevExpress.XtraEditors.SimpleButton();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnBrowse = new DevExpress.XtraEditors.SimpleButton();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgUSer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryTextPasswd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUGroup)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl2)).BeginInit();
            this.xtraTabControl2.SuspendLayout();
            this.tabPrivilegeModule.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrivilege)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPrivilege)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            this.tabPrivilegeProdi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProdi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewProdi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRead.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDelete.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkPrint.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkExport.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkImport.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.labelControl1.Appearance.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl1.LineVisible = true;
            this.labelControl1.Location = new System.Drawing.Point(0, 0);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.labelControl1.Size = new System.Drawing.Size(1011, 20);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Management User";
            this.labelControl1.Leave += new System.EventHandler(this.labelControl1_Leave);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.btnEndEdit);
            this.panelControl1.Controls.Add(this.btnDel);
            this.panelControl1.Controls.Add(this.btnEdit);
            this.panelControl1.Controls.Add(this.btnClose);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl1.Location = new System.Drawing.Point(0, 466);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1011, 32);
            this.panelControl1.TabIndex = 3;
            // 
            // btnEndEdit
            // 
            this.btnEndEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEndEdit.Enabled = false;
            this.btnEndEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEndEdit.Image")));
            this.btnEndEdit.Location = new System.Drawing.Point(166, 5);
            this.btnEndEdit.Name = "btnEndEdit";
            this.btnEndEdit.Size = new System.Drawing.Size(80, 23);
            this.btnEndEdit.TabIndex = 80;
            this.btnEndEdit.Text = "&End Edit";
            this.btnEndEdit.Click += new System.EventHandler(this.btnEndEdit_Click);
            // 
            // btnDel
            // 
            this.btnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDel.Image = ((System.Drawing.Image)(resources.GetObject("btnDel.Image")));
            this.btnDel.Location = new System.Drawing.Point(87, 5);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(73, 23);
            this.btnDel.TabIndex = 76;
            this.btnDel.Text = "Hapus";
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(5, 5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(76, 23);
            this.btnEdit.TabIndex = 75;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(926, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "&Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(488, 446);
            this.xtraTabControl1.TabIndex = 0;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            this.xtraTabControl1.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControl1_SelectedPageChanged);
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.dgUSer);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(482, 418);
            this.xtraTabPage1.Text = "Daftar User";
            // 
            // dgUSer
            // 
            this.dgUSer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgUSer.Location = new System.Drawing.Point(0, 0);
            this.dgUSer.MainView = this.gridViewUser;
            this.dgUSer.Name = "dgUSer";
            this.dgUSer.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryLUGroup,
            this.repositoryTextPasswd});
            this.dgUSer.Size = new System.Drawing.Size(482, 418);
            this.dgUSer.TabIndex = 1;
            this.dgUSer.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewUser});
            // 
            // gridViewUser
            // 
            this.gridViewUser.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.userid,
            this.rfid,
            this.nik,
            this.nama,
            this.username,
            this.passwd,
            this.usergroupid,
            this.photo});
            this.gridViewUser.GridControl = this.dgUSer;
            this.gridViewUser.Name = "gridViewUser";
            this.gridViewUser.OptionsBehavior.Editable = false;
            this.gridViewUser.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewUser.OptionsCustomization.AllowGroup = false;
            this.gridViewUser.OptionsFind.AlwaysVisible = true;
            this.gridViewUser.OptionsView.ShowGroupPanel = false;
            this.gridViewUser.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewUser_FocusedRowChanged);
            this.gridViewUser.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewUser_ValidateRow);
            // 
            // userid
            // 
            this.userid.Caption = "userid";
            this.userid.FieldName = "userid";
            this.userid.Name = "userid";
            // 
            // rfid
            // 
            this.rfid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid.AppearanceHeader.Options.UseFont = true;
            this.rfid.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid.Caption = "RFID/Tag No";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 120;
            this.rfid.Name = "rfid";
            this.rfid.Visible = true;
            this.rfid.VisibleIndex = 0;
            this.rfid.Width = 120;
            // 
            // nik
            // 
            this.nik.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nik.AppearanceHeader.Options.UseFont = true;
            this.nik.AppearanceHeader.Options.UseTextOptions = true;
            this.nik.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nik.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nik.Caption = "NIK";
            this.nik.FieldName = "nik";
            this.nik.MinWidth = 120;
            this.nik.Name = "nik";
            this.nik.Visible = true;
            this.nik.VisibleIndex = 1;
            this.nik.Width = 120;
            // 
            // nama
            // 
            this.nama.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nama.AppearanceHeader.Options.UseFont = true;
            this.nama.AppearanceHeader.Options.UseTextOptions = true;
            this.nama.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nama.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nama.Caption = "Nama";
            this.nama.FieldName = "nama";
            this.nama.MinWidth = 180;
            this.nama.Name = "nama";
            this.nama.Visible = true;
            this.nama.VisibleIndex = 2;
            this.nama.Width = 200;
            // 
            // username
            // 
            this.username.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.username.AppearanceHeader.Options.UseFont = true;
            this.username.AppearanceHeader.Options.UseTextOptions = true;
            this.username.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.username.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.username.Caption = "Username";
            this.username.FieldName = "username";
            this.username.MaxWidth = 150;
            this.username.MinWidth = 150;
            this.username.Name = "username";
            this.username.Visible = true;
            this.username.VisibleIndex = 3;
            this.username.Width = 150;
            // 
            // passwd
            // 
            this.passwd.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.passwd.AppearanceHeader.Options.UseFont = true;
            this.passwd.AppearanceHeader.Options.UseTextOptions = true;
            this.passwd.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.passwd.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.passwd.Caption = "Password";
            this.passwd.ColumnEdit = this.repositoryTextPasswd;
            this.passwd.FieldName = "passwd";
            this.passwd.MaxWidth = 120;
            this.passwd.MinWidth = 120;
            this.passwd.Name = "passwd";
            this.passwd.Visible = true;
            this.passwd.VisibleIndex = 4;
            this.passwd.Width = 120;
            // 
            // repositoryTextPasswd
            // 
            this.repositoryTextPasswd.AutoHeight = false;
            this.repositoryTextPasswd.Name = "repositoryTextPasswd";
            this.repositoryTextPasswd.PasswordChar = '*';
            // 
            // usergroupid
            // 
            this.usergroupid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.usergroupid.AppearanceHeader.Options.UseFont = true;
            this.usergroupid.AppearanceHeader.Options.UseTextOptions = true;
            this.usergroupid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.usergroupid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.usergroupid.Caption = "User Group";
            this.usergroupid.ColumnEdit = this.repositoryLUGroup;
            this.usergroupid.FieldName = "usergroupid";
            this.usergroupid.MinWidth = 180;
            this.usergroupid.Name = "usergroupid";
            this.usergroupid.Visible = true;
            this.usergroupid.VisibleIndex = 5;
            this.usergroupid.Width = 180;
            // 
            // repositoryLUGroup
            // 
            this.repositoryLUGroup.AutoHeight = false;
            this.repositoryLUGroup.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUGroup.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("usergroupid", "usergroupid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupname", "groupname")});
            this.repositoryLUGroup.DisplayMember = "groupname";
            this.repositoryLUGroup.DropDownRows = 10;
            this.repositoryLUGroup.Name = "repositoryLUGroup";
            this.repositoryLUGroup.NullText = "";
            this.repositoryLUGroup.ShowHeader = false;
            this.repositoryLUGroup.ValueMember = "usergroupid";
            // 
            // photo
            // 
            this.photo.Caption = "Photo";
            this.photo.FieldName = "photo";
            this.photo.Name = "photo";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.dgGroup);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(482, 418);
            this.xtraTabPage2.Text = "Daftar User Group";
            // 
            // dgGroup
            // 
            this.dgGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgGroup.Location = new System.Drawing.Point(0, 0);
            this.dgGroup.MainView = this.gridViewGroup;
            this.dgGroup.Name = "dgGroup";
            this.dgGroup.Size = new System.Drawing.Size(482, 418);
            this.dgGroup.TabIndex = 1;
            this.dgGroup.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewGroup});
            // 
            // gridViewGroup
            // 
            this.gridViewGroup.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.usergroupid1,
            this.groupname});
            this.gridViewGroup.GridControl = this.dgGroup;
            this.gridViewGroup.Name = "gridViewGroup";
            this.gridViewGroup.OptionsBehavior.Editable = false;
            this.gridViewGroup.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewGroup.OptionsCustomization.AllowFilter = false;
            this.gridViewGroup.OptionsCustomization.AllowGroup = false;
            this.gridViewGroup.OptionsView.ShowGroupPanel = false;
            this.gridViewGroup.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewGroup_FocusedRowChanged);
            this.gridViewGroup.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewGroup_ValidateRow);
            // 
            // usergroupid1
            // 
            this.usergroupid1.Caption = "usergroupid";
            this.usergroupid1.FieldName = "usergroupid";
            this.usergroupid1.Name = "usergroupid1";
            // 
            // groupname
            // 
            this.groupname.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupname.AppearanceHeader.Options.UseFont = true;
            this.groupname.AppearanceHeader.Options.UseTextOptions = true;
            this.groupname.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupname.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.groupname.Caption = "User Group";
            this.groupname.FieldName = "groupname";
            this.groupname.Name = "groupname";
            this.groupname.Visible = true;
            this.groupname.VisibleIndex = 0;
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.Controls.Add(this.xtraTabControl2);
            this.groupControl1.Controls.Add(this.chkRead);
            this.groupControl1.Controls.Add(this.chkAdd);
            this.groupControl1.Controls.Add(this.checkEdit);
            this.groupControl1.Controls.Add(this.chkDelete);
            this.groupControl1.Controls.Add(this.chkPrint);
            this.groupControl1.Controls.Add(this.chkExport);
            this.groupControl1.Controls.Add(this.chkImport);
            this.groupControl1.Controls.Add(this.btnSavePriv);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl1.Location = new System.Drawing.Point(0, 93);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(518, 353);
            this.groupControl1.TabIndex = 6;
            this.groupControl1.Text = "Privileges";
            // 
            // xtraTabControl2
            // 
            this.xtraTabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.xtraTabControl2.Location = new System.Drawing.Point(8, 25);
            this.xtraTabControl2.Name = "xtraTabControl2";
            this.xtraTabControl2.SelectedTabPage = this.tabPrivilegeModule;
            this.xtraTabControl2.Size = new System.Drawing.Size(507, 292);
            this.xtraTabControl2.TabIndex = 84;
            this.xtraTabControl2.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.tabPrivilegeModule,
            this.tabPrivilegeProdi});
            this.xtraTabControl2.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControl2_SelectedPageChanged);
            // 
            // tabPrivilegeModule
            // 
            this.tabPrivilegeModule.Controls.Add(this.dgPrivilege);
            this.tabPrivilegeModule.Name = "tabPrivilegeModule";
            this.tabPrivilegeModule.Size = new System.Drawing.Size(501, 264);
            this.tabPrivilegeModule.Text = "Hak Akses Module";
            // 
            // dgPrivilege
            // 
            this.dgPrivilege.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgPrivilege.Location = new System.Drawing.Point(0, 0);
            this.dgPrivilege.MainView = this.gridViewPrivilege;
            this.dgPrivilege.Name = "dgPrivilege";
            this.dgPrivilege.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.dgPrivilege.Size = new System.Drawing.Size(501, 264);
            this.dgPrivilege.TabIndex = 2;
            this.dgPrivilege.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewPrivilege});
            // 
            // gridViewPrivilege
            // 
            this.gridViewPrivilege.ColumnPanelRowHeight = 35;
            this.gridViewPrivilege.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.moduleid,
            this.groupview,
            this.modulename,
            this.usermoduleid,
            this.userid2,
            this.isread,
            this.isadd,
            this.isedit,
            this.isdelete,
            this.isprint,
            this.isdownload,
            this.isupload,
            this.usergroupmoduleid,
            this.usergroupid2});
            this.gridViewPrivilege.GridControl = this.dgPrivilege;
            this.gridViewPrivilege.GroupCount = 1;
            this.gridViewPrivilege.Name = "gridViewPrivilege";
            this.gridViewPrivilege.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewPrivilege.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewPrivilege.OptionsCustomization.AllowFilter = false;
            this.gridViewPrivilege.OptionsCustomization.AllowGroup = false;
            this.gridViewPrivilege.OptionsCustomization.AllowSort = false;
            this.gridViewPrivilege.OptionsView.ShowGroupPanel = false;
            this.gridViewPrivilege.OptionsView.ShowIndicator = false;
            this.gridViewPrivilege.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.groupview, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // moduleid
            // 
            this.moduleid.Caption = "moduleid";
            this.moduleid.FieldName = "moduleid";
            this.moduleid.Name = "moduleid";
            // 
            // groupview
            // 
            this.groupview.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupview.AppearanceHeader.Options.UseFont = true;
            this.groupview.AppearanceHeader.Options.UseTextOptions = true;
            this.groupview.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupview.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.groupview.Caption = "Group";
            this.groupview.FieldName = "groupview";
            this.groupview.Name = "groupview";
            this.groupview.OptionsColumn.AllowEdit = false;
            this.groupview.Visible = true;
            this.groupview.VisibleIndex = 0;
            // 
            // modulename
            // 
            this.modulename.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.modulename.AppearanceHeader.Options.UseFont = true;
            this.modulename.AppearanceHeader.Options.UseTextOptions = true;
            this.modulename.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.modulename.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.modulename.Caption = "Module Name";
            this.modulename.FieldName = "modulename";
            this.modulename.MinWidth = 140;
            this.modulename.Name = "modulename";
            this.modulename.OptionsColumn.AllowEdit = false;
            this.modulename.Visible = true;
            this.modulename.VisibleIndex = 0;
            this.modulename.Width = 161;
            // 
            // usermoduleid
            // 
            this.usermoduleid.Caption = "usermoduleid";
            this.usermoduleid.FieldName = "usermoduleid";
            this.usermoduleid.Name = "usermoduleid";
            // 
            // userid2
            // 
            this.userid2.Caption = "userid";
            this.userid2.FieldName = "userid";
            this.userid2.Name = "userid2";
            // 
            // isread
            // 
            this.isread.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isread.AppearanceHeader.Options.UseFont = true;
            this.isread.AppearanceHeader.Options.UseTextOptions = true;
            this.isread.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isread.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isread.Caption = "Read";
            this.isread.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isread.FieldName = "isread";
            this.isread.MaxWidth = 65;
            this.isread.MinWidth = 65;
            this.isread.Name = "isread";
            this.isread.Visible = true;
            this.isread.VisibleIndex = 1;
            this.isread.Width = 65;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // isadd
            // 
            this.isadd.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isadd.AppearanceHeader.Options.UseFont = true;
            this.isadd.AppearanceHeader.Options.UseTextOptions = true;
            this.isadd.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isadd.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isadd.Caption = "Add";
            this.isadd.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isadd.FieldName = "isadd";
            this.isadd.MaxWidth = 65;
            this.isadd.MinWidth = 65;
            this.isadd.Name = "isadd";
            this.isadd.Visible = true;
            this.isadd.VisibleIndex = 2;
            this.isadd.Width = 65;
            // 
            // isedit
            // 
            this.isedit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isedit.AppearanceHeader.Options.UseFont = true;
            this.isedit.AppearanceHeader.Options.UseTextOptions = true;
            this.isedit.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isedit.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isedit.Caption = "Edit";
            this.isedit.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isedit.FieldName = "isedit";
            this.isedit.MaxWidth = 65;
            this.isedit.MinWidth = 65;
            this.isedit.Name = "isedit";
            this.isedit.Visible = true;
            this.isedit.VisibleIndex = 3;
            this.isedit.Width = 65;
            // 
            // isdelete
            // 
            this.isdelete.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isdelete.AppearanceHeader.Options.UseFont = true;
            this.isdelete.AppearanceHeader.Options.UseTextOptions = true;
            this.isdelete.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isdelete.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isdelete.Caption = "Delete";
            this.isdelete.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isdelete.FieldName = "isdelete";
            this.isdelete.MaxWidth = 65;
            this.isdelete.MinWidth = 65;
            this.isdelete.Name = "isdelete";
            this.isdelete.Visible = true;
            this.isdelete.VisibleIndex = 4;
            this.isdelete.Width = 65;
            // 
            // isprint
            // 
            this.isprint.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isprint.AppearanceHeader.Options.UseFont = true;
            this.isprint.AppearanceHeader.Options.UseTextOptions = true;
            this.isprint.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isprint.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isprint.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.isprint.Caption = "Print / Preview";
            this.isprint.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isprint.FieldName = "isprint";
            this.isprint.MaxWidth = 75;
            this.isprint.MinWidth = 75;
            this.isprint.Name = "isprint";
            this.isprint.Visible = true;
            this.isprint.VisibleIndex = 5;
            // 
            // isdownload
            // 
            this.isdownload.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isdownload.AppearanceHeader.Options.UseFont = true;
            this.isdownload.AppearanceHeader.Options.UseTextOptions = true;
            this.isdownload.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isdownload.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isdownload.Caption = "Export";
            this.isdownload.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isdownload.FieldName = "isdownload";
            this.isdownload.MaxWidth = 65;
            this.isdownload.MinWidth = 65;
            this.isdownload.Name = "isdownload";
            this.isdownload.Visible = true;
            this.isdownload.VisibleIndex = 6;
            this.isdownload.Width = 65;
            // 
            // isupload
            // 
            this.isupload.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.isupload.AppearanceHeader.Options.UseFont = true;
            this.isupload.AppearanceHeader.Options.UseTextOptions = true;
            this.isupload.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isupload.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isupload.Caption = "Import";
            this.isupload.ColumnEdit = this.repositoryItemCheckEdit1;
            this.isupload.FieldName = "isupload";
            this.isupload.MaxWidth = 65;
            this.isupload.MinWidth = 65;
            this.isupload.Name = "isupload";
            this.isupload.Visible = true;
            this.isupload.VisibleIndex = 7;
            this.isupload.Width = 65;
            // 
            // usergroupmoduleid
            // 
            this.usergroupmoduleid.Caption = "usergroupmoduleid";
            this.usergroupmoduleid.FieldName = "usergroupmoduleid";
            this.usergroupmoduleid.Name = "usergroupmoduleid";
            // 
            // usergroupid2
            // 
            this.usergroupid2.Caption = "usergroupid";
            this.usergroupid2.FieldName = "usergroupid";
            this.usergroupid2.Name = "usergroupid2";
            // 
            // tabPrivilegeProdi
            // 
            this.tabPrivilegeProdi.Controls.Add(this.dgProdi);
            this.tabPrivilegeProdi.Name = "tabPrivilegeProdi";
            this.tabPrivilegeProdi.PageVisible = false;
            this.tabPrivilegeProdi.Size = new System.Drawing.Size(501, 264);
            this.tabPrivilegeProdi.Text = "Hak Akses Prodi";
            // 
            // dgProdi
            // 
            this.dgProdi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgProdi.Location = new System.Drawing.Point(0, 0);
            this.dgProdi.MainView = this.gridViewProdi;
            this.dgProdi.Name = "dgProdi";
            this.dgProdi.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2});
            this.dgProdi.Size = new System.Drawing.Size(501, 264);
            this.dgProdi.TabIndex = 3;
            this.dgProdi.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewProdi});
            // 
            // gridViewProdi
            // 
            this.gridViewProdi.ColumnPanelRowHeight = 35;
            this.gridViewProdi.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.userprodiid,
            this.prodiid,
            this.jurusanview,
            this.prodiview,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12});
            this.gridViewProdi.GridControl = this.dgProdi;
            this.gridViewProdi.GroupCount = 1;
            this.gridViewProdi.Name = "gridViewProdi";
            this.gridViewProdi.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewProdi.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewProdi.OptionsCustomization.AllowGroup = false;
            this.gridViewProdi.OptionsCustomization.AllowSort = false;
            this.gridViewProdi.OptionsView.ShowIndicator = false;
            this.gridViewProdi.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.jurusanview, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // userprodiid
            // 
            this.userprodiid.Caption = "userprodiid";
            this.userprodiid.FieldName = "userprodiid";
            this.userprodiid.Name = "userprodiid";
            // 
            // prodiid
            // 
            this.prodiid.Caption = "prodiid";
            this.prodiid.FieldName = "prodiid";
            this.prodiid.Name = "prodiid";
            // 
            // jurusanview
            // 
            this.jurusanview.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.jurusanview.AppearanceHeader.Options.UseFont = true;
            this.jurusanview.AppearanceHeader.Options.UseTextOptions = true;
            this.jurusanview.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jurusanview.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jurusanview.Caption = "Jurusan";
            this.jurusanview.FieldName = "jurusanview";
            this.jurusanview.Name = "jurusanview";
            this.jurusanview.OptionsColumn.AllowEdit = false;
            this.jurusanview.Visible = true;
            this.jurusanview.VisibleIndex = 0;
            // 
            // prodiview
            // 
            this.prodiview.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.prodiview.AppearanceHeader.Options.UseFont = true;
            this.prodiview.AppearanceHeader.Options.UseTextOptions = true;
            this.prodiview.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.prodiview.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.prodiview.Caption = "Program Studi";
            this.prodiview.FieldName = "prodiview";
            this.prodiview.Name = "prodiview";
            this.prodiview.OptionsColumn.AllowEdit = false;
            this.prodiview.Visible = true;
            this.prodiview.VisibleIndex = 0;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "userid";
            this.gridColumn5.FieldName = "userid";
            this.gridColumn5.Name = "gridColumn5";
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn6.AppearanceHeader.Options.UseFont = true;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn6.Caption = "Read";
            this.gridColumn6.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn6.FieldName = "isread";
            this.gridColumn6.MaxWidth = 65;
            this.gridColumn6.MinWidth = 65;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 1;
            this.gridColumn6.Width = 65;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn7.AppearanceHeader.Options.UseFont = true;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn7.Caption = "Add";
            this.gridColumn7.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn7.FieldName = "isadd";
            this.gridColumn7.MaxWidth = 65;
            this.gridColumn7.MinWidth = 65;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Width = 65;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn8.AppearanceHeader.Options.UseFont = true;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn8.Caption = "Edit";
            this.gridColumn8.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn8.FieldName = "isedit";
            this.gridColumn8.MaxWidth = 65;
            this.gridColumn8.MinWidth = 65;
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Width = 65;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn9.AppearanceHeader.Options.UseFont = true;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn9.Caption = "Delete";
            this.gridColumn9.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn9.FieldName = "isdelete";
            this.gridColumn9.MaxWidth = 65;
            this.gridColumn9.MinWidth = 65;
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Width = 65;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn10.AppearanceHeader.Options.UseFont = true;
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn10.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn10.Caption = "Print / Preview";
            this.gridColumn10.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn10.FieldName = "isprint";
            this.gridColumn10.MaxWidth = 75;
            this.gridColumn10.MinWidth = 75;
            this.gridColumn10.Name = "gridColumn10";
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn11.AppearanceHeader.Options.UseFont = true;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn11.Caption = "Export";
            this.gridColumn11.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn11.FieldName = "isdownload";
            this.gridColumn11.MaxWidth = 65;
            this.gridColumn11.MinWidth = 65;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Width = 65;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn12.AppearanceHeader.Options.UseFont = true;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn12.Caption = "Import";
            this.gridColumn12.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn12.FieldName = "isupload";
            this.gridColumn12.MaxWidth = 65;
            this.gridColumn12.MinWidth = 65;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Width = 65;
            // 
            // chkRead
            // 
            this.chkRead.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkRead.Location = new System.Drawing.Point(129, 327);
            this.chkRead.Name = "chkRead";
            this.chkRead.Properties.Caption = "Read";
            this.chkRead.Size = new System.Drawing.Size(47, 19);
            this.chkRead.TabIndex = 83;
            this.chkRead.CheckedChanged += new System.EventHandler(this.chkRead_CheckedChanged);
            // 
            // chkAdd
            // 
            this.chkAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkAdd.Location = new System.Drawing.Point(182, 327);
            this.chkAdd.Name = "chkAdd";
            this.chkAdd.Properties.Caption = "Add";
            this.chkAdd.Size = new System.Drawing.Size(41, 19);
            this.chkAdd.TabIndex = 82;
            this.chkAdd.CheckedChanged += new System.EventHandler(this.chkAdd_CheckedChanged);
            // 
            // checkEdit
            // 
            this.checkEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.checkEdit.Location = new System.Drawing.Point(229, 327);
            this.checkEdit.Name = "checkEdit";
            this.checkEdit.Properties.Caption = "Edit";
            this.checkEdit.Size = new System.Drawing.Size(46, 19);
            this.checkEdit.TabIndex = 81;
            this.checkEdit.CheckedChanged += new System.EventHandler(this.checkEdit_CheckedChanged);
            // 
            // chkDelete
            // 
            this.chkDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkDelete.Location = new System.Drawing.Point(281, 327);
            this.chkDelete.Name = "chkDelete";
            this.chkDelete.Properties.Caption = "Delete";
            this.chkDelete.Size = new System.Drawing.Size(54, 19);
            this.chkDelete.TabIndex = 80;
            this.chkDelete.CheckedChanged += new System.EventHandler(this.chkDelete_CheckedChanged);
            // 
            // chkPrint
            // 
            this.chkPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkPrint.Location = new System.Drawing.Point(341, 327);
            this.chkPrint.Name = "chkPrint";
            this.chkPrint.Properties.Caption = "Print";
            this.chkPrint.Size = new System.Drawing.Size(45, 19);
            this.chkPrint.TabIndex = 79;
            this.chkPrint.CheckedChanged += new System.EventHandler(this.chkPrint_CheckedChanged);
            // 
            // chkExport
            // 
            this.chkExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkExport.Location = new System.Drawing.Point(392, 327);
            this.chkExport.Name = "chkExport";
            this.chkExport.Properties.Caption = "Export";
            this.chkExport.Size = new System.Drawing.Size(55, 19);
            this.chkExport.TabIndex = 78;
            this.chkExport.CheckedChanged += new System.EventHandler(this.chkExport_CheckedChanged);
            // 
            // chkImport
            // 
            this.chkImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chkImport.Location = new System.Drawing.Point(453, 327);
            this.chkImport.Name = "chkImport";
            this.chkImport.Properties.Caption = "Import";
            this.chkImport.Size = new System.Drawing.Size(60, 19);
            this.chkImport.TabIndex = 77;
            this.chkImport.CheckedChanged += new System.EventHandler(this.chkImport_CheckedChanged);
            // 
            // btnSavePriv
            // 
            this.btnSavePriv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSavePriv.Image = ((System.Drawing.Image)(resources.GetObject("btnSavePriv.Image")));
            this.btnSavePriv.Location = new System.Drawing.Point(6, 323);
            this.btnSavePriv.Name = "btnSavePriv";
            this.btnSavePriv.Size = new System.Drawing.Size(114, 23);
            this.btnSavePriv.TabIndex = 76;
            this.btnSavePriv.Text = "Save Privileges";
            this.btnSavePriv.Click += new System.EventHandler(this.btnSavePriv_Click);
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.pictureBox2);
            this.groupControl2.Controls.Add(this.btnBrowse);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl2.Location = new System.Drawing.Point(0, 0);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(518, 93);
            this.groupControl2.TabIndex = 7;
            this.groupControl2.Text = "Update Photo";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = global::DIGILIB.Properties.Resources.imgunavail;
            this.pictureBox2.InitialImage = global::DIGILIB.PrintRibbonControllerResources.imgunavail;
            this.pictureBox2.Location = new System.Drawing.Point(5, 21);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(80, 67);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 98;
            this.pictureBox2.TabStop = false;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowse.Location = new System.Drawing.Point(91, 64);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 97;
            this.btnBrowse.Text = "Update Photo";
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 20);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.xtraTabControl1);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.groupControl1);
            this.splitContainerControl1.Panel2.Controls.Add(this.groupControl2);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1011, 446);
            this.splitContainerControl1.SplitterPosition = 488;
            this.splitContainerControl1.TabIndex = 8;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // ucManagementUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainerControl1);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.labelControl1);
            this.Name = "ucManagementUser";
            this.Size = new System.Drawing.Size(1011, 498);
            this.Load += new System.EventHandler(this.ucManagementUser_Load);
            this.Leave += new System.EventHandler(this.ucManagementUser_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgUSer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryTextPasswd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUGroup)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl2)).EndInit();
            this.xtraTabControl2.ResumeLayout(false);
            this.tabPrivilegeModule.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgPrivilege)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPrivilege)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            this.tabPrivilegeProdi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgProdi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewProdi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkRead.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAdd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDelete.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkPrint.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkExport.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkImport.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        public DevExpress.XtraEditors.SimpleButton btnDel;
        public DevExpress.XtraEditors.SimpleButton btnEdit;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraGrid.GridControl dgUSer;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewUser;
        private DevExpress.XtraGrid.GridControl dgGroup;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewGroup;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        public DevExpress.XtraEditors.SimpleButton btnEndEdit;
        private DevExpress.XtraGrid.Columns.GridColumn userid;
        private DevExpress.XtraGrid.Columns.GridColumn username;
        private DevExpress.XtraGrid.Columns.GridColumn passwd;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryTextPasswd;
        private DevExpress.XtraGrid.Columns.GridColumn usergroupid;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUGroup;
        private DevExpress.XtraGrid.GridControl dgPrivilege;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewPrivilege;
        private DevExpress.XtraGrid.Columns.GridColumn moduleid;
        private DevExpress.XtraGrid.Columns.GridColumn groupview;
        private DevExpress.XtraGrid.Columns.GridColumn modulename;
        private DevExpress.XtraGrid.Columns.GridColumn usermoduleid;
        private DevExpress.XtraGrid.Columns.GridColumn userid2;
        private DevExpress.XtraGrid.Columns.GridColumn isread;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn isadd;
        private DevExpress.XtraGrid.Columns.GridColumn isedit;
        private DevExpress.XtraGrid.Columns.GridColumn isdelete;
        private DevExpress.XtraGrid.Columns.GridColumn isprint;
        private DevExpress.XtraGrid.Columns.GridColumn isdownload;
        private DevExpress.XtraGrid.Columns.GridColumn isupload;
        private DevExpress.XtraGrid.Columns.GridColumn usergroupid1;
        private DevExpress.XtraGrid.Columns.GridColumn groupname;
        private DevExpress.XtraGrid.Columns.GridColumn usergroupmoduleid;
        private DevExpress.XtraGrid.Columns.GridColumn usergroupid2;
        public DevExpress.XtraEditors.SimpleButton btnSavePriv;
        private DevExpress.XtraEditors.CheckEdit chkExport;
        private DevExpress.XtraEditors.CheckEdit chkImport;
        private DevExpress.XtraEditors.CheckEdit chkPrint;
        private DevExpress.XtraEditors.CheckEdit chkDelete;
        private DevExpress.XtraEditors.CheckEdit chkRead;
        private DevExpress.XtraEditors.CheckEdit chkAdd;
        private DevExpress.XtraEditors.CheckEdit checkEdit;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl2;
        private DevExpress.XtraTab.XtraTabPage tabPrivilegeModule;
        private DevExpress.XtraTab.XtraTabPage tabPrivilegeProdi;
        private DevExpress.XtraGrid.GridControl dgProdi;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewProdi;
        private DevExpress.XtraGrid.Columns.GridColumn prodiid;
        private DevExpress.XtraGrid.Columns.GridColumn userprodiid;
        private DevExpress.XtraGrid.Columns.GridColumn jurusanview;
        private DevExpress.XtraGrid.Columns.GridColumn prodiview;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        private DevExpress.XtraGrid.Columns.GridColumn nik;
        private DevExpress.XtraGrid.Columns.GridColumn nama;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private DevExpress.XtraEditors.SimpleButton btnBrowse;
        private DevExpress.XtraGrid.Columns.GridColumn photo;
    }
}
