﻿namespace DIGILIB.Utility
{
    partial class ucUtility
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.btnPatchMapping = new DevExpress.XtraEditors.SimpleButton();
            this.btnPachDatabase = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.labelControl1.Appearance.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl1.LineVisible = true;
            this.labelControl1.Location = new System.Drawing.Point(0, 0);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.labelControl1.Size = new System.Drawing.Size(687, 20);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Utility";
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.btnPachDatabase);
            this.groupControl1.Controls.Add(this.btnPatchMapping);
            this.groupControl1.Location = new System.Drawing.Point(3, 26);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(341, 260);
            this.groupControl1.TabIndex = 2;
            this.groupControl1.Text = "Database";
            // 
            // btnPatchMapping
            // 
            this.btnPatchMapping.Appearance.Options.UseTextOptions = true;
            this.btnPatchMapping.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.btnPatchMapping.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.btnPatchMapping.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.btnPatchMapping.Enabled = false;
            this.btnPatchMapping.Location = new System.Drawing.Point(5, 25);
            this.btnPatchMapping.Name = "btnPatchMapping";
            this.btnPatchMapping.Size = new System.Drawing.Size(98, 43);
            this.btnPatchMapping.TabIndex = 0;
            this.btnPatchMapping.Text = "Patch Mapping Makdetail to Unit";
            this.btnPatchMapping.Click += new System.EventHandler(this.btnPatchMapping_Click);
            // 
            // btnPachDatabase
            // 
            this.btnPachDatabase.Appearance.Options.UseTextOptions = true;
            this.btnPachDatabase.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.btnPachDatabase.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.btnPachDatabase.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.btnPachDatabase.Image = global::DIGILIB.Properties.Resources.Software_Update_icon32;
            this.btnPachDatabase.Location = new System.Drawing.Point(109, 25);
            this.btnPachDatabase.Name = "btnPachDatabase";
            this.btnPachDatabase.Size = new System.Drawing.Size(130, 43);
            this.btnPachDatabase.TabIndex = 1;
            this.btnPachDatabase.Text = "Patch Database";
            this.btnPachDatabase.Click += new System.EventHandler(this.btnPachDatabase_Click);
            // 
            // ucUtility
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.labelControl1);
            this.Name = "ucUtility";
            this.Size = new System.Drawing.Size(687, 403);
            this.Leave += new System.EventHandler(this.ucUtility_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnPatchMapping;
        private DevExpress.XtraEditors.SimpleButton btnPachDatabase;
    }
}
