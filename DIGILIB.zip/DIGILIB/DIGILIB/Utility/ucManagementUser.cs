﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Library;
using DevExpress.Utils;
using DevExpress.XtraGrid.Views.Grid;
using System.IO;
using Npgsql;

namespace DIGILIB.Utility
{
    public partial class ucManagementUser : DevExpress.XtraEditors.XtraUserControl
    {
        public ucManagementUser()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();

            SelectICard();
            SetupReaderList();
            LoadApduList();
            comboReader_SelectedIndexChanged(null, null);

            setLoadDialog(false, "");
        }


        #region Smartcard

        delegate void SetValueLookUpEditDelegate(DevExpress.XtraGrid.Views.Grid.GridView cbo, string editvalue);
        private GemCard.CardBase m_iCard = null;
        private GemCard.APDUPlayer m_apduPlayer = null;
        private GemCard.APDUParam m_apduParam = null;
        const string DefaultReader = "Gemplus USB Smart Card Reader 0";
        private TextBox txtboxATR;
        private Label label10;
        string reader = "ACS ACR122 0";
        const string ApduListFile = "ApduList.xml";


        public string GetScardErrMsg(string ReturnCode)
        {
            string strresult = ReturnCode;
            switch (ReturnCode)
            {
                case "9000":
                    strresult = "9000 : The operation completed succesfully.";
                    break;
                case "6300":
                    strresult = "6300 : The operation failed.";
                    break;
                case "6A81":
                    strresult = "6A81 : Function not supported.";
                    break;
            }
            return strresult;
        }

        private void SelectICard()
        {
            try
            {
                if (m_iCard != null)
                    m_iCard.Disconnect(GemCard.DISCONNECT.Unpower);

                m_iCard = new GemCard.CardNative();
                //statusBarPanel_Info.Text = "CardNative implementation used";              

                m_iCard.OnCardInserted += new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved += new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);

            }
            catch (Exception ex)
            {
                //btnConnect.Enabled = false;
                //btnDisconnect.Enabled = false;
                //btnTransmit.Enabled = false;

                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        /// <summary>
        /// CardRemovedEventHandler
        /// </summary>
        private void m_iCard_OnCardRemoved(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, false });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });

        }

        /// <summary>
        /// CardInsertedEventHandler
        /// </summary>
        private void m_iCard_OnCardInserted(string reader)
        {
            if (gridViewUser.OptionsBehavior.Editable == false)
            {
                if (btnEdit.Enabled)
                {
                    XtraMessageBox.Show("Clik button Edit untuk mengubah data user", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                return;
            }
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, true });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });
            //if (btnConnect.Enabled)
            //{
            try
            {
                m_iCard.Connect("ACS ACR122 0", GemCard.SHARE.Shared, GemCard.PROTOCOL.T0orT1);

                try
                {
                    // Get the ATR of the card
                    byte[] atrValue = m_iCard.GetAttribute(GemCard.SCARD_ATTR_VALUE.ATR_STRING);
                    //txtboxATR.Text = ByteArrayToString(atrValue);
                }
                catch (Exception)
                {
                    //txtboxATR.Text = "Cannot get ATR";
                }

                //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, btnConnect.Enabled });

                GemCard.APDUResponse apduResp = m_apduPlayer.ProcessCommand("Get UID", BuildParam());
                if (apduResp.Data != null)
                {
                    StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                    for (int nI = 0; nI < apduResp.Data.Length; nI++)
                        sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    if (apduResp.Data != null)
                    {

                        string editvalue = Convert.ToString(ByteArrayToString(apduResp.Data));

                        dgUSer.Invoke(new SetValueLookUpEditDelegate(SetValueLookUpEdit), new object[] { gridViewUser, editvalue });
                        //gridViewUser.SetFocusedRowCellValue(rfid,editvalue);

                        //MessageBox.Show(ByteArrayToString(apduResp.Data));
                    }
                }


            }
            catch (Exception ex)
            {
                //XtraMessageBox.Show(ex.Message, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            //btnConnect_Click(btnConnect, null);
            //}
        }

        protected void SetValueLookUpEdit(DevExpress.XtraGrid.Views.Grid.GridView view, object editValue)
        {
            view.SetFocusedRowCellValue(rfid, Convert.ToString(editValue));
        }
        protected void EnableButton(Button btn, bool enable)
        {
            btn.Enabled = enable;
        }

        static private string ByteArrayToString(byte[] data)
        {
            StringBuilder sDataOut;

            if (data != null)
            {
                sDataOut = new StringBuilder(data.Length * 2);
                for (int nI = 0; nI < data.Length; nI++)
                    sDataOut.AppendFormat("{0:X02}", data[nI]);
            }
            else
                sDataOut = new StringBuilder();

            return sDataOut.ToString();
        }
        string textClass = "";
        string textIns = "";
        string textP1 = "";
        string textP2 = "";
        string textLe = "";
        string textData = "";
        private GemCard.APDUParam BuildParam()
        {
            //byte bP1 = byte.Parse(textP1.Text, NumberStyles.AllowHexSpecifier);
            //byte bP2 = byte.Parse(textP2.Text, NumberStyles.AllowHexSpecifier);
            //byte bLe = byte.Parse(textLe.Text);

            byte bP1 = byte.Parse(textP1, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bP2 = byte.Parse(textP2, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bLe = byte.Parse(textLe);

            GemCard.APDUParam apduParam = new GemCard.APDUParam();
            apduParam.P1 = bP1;
            apduParam.P2 = bP2;
            apduParam.Le = bLe;

            // Update Current param
            m_apduParam = apduParam.Clone();

            return apduParam;
        }
        private void DisplayAPDUCommand(GemCard.APDUCommand apduCmd)
        {
            if (apduCmd != null)
            {
                textClass = string.Format("{0:X02}", apduCmd.Class);
                textIns = string.Format("{0:X02}", apduCmd.Ins);
                textP1 = string.Format("{0:X02}", apduCmd.P1);
                textP2 = string.Format("{0:X02}", apduCmd.P2);
                textLe = apduCmd.Le.ToString();

                if (apduCmd.Data != null)
                {
                    StringBuilder sData = new StringBuilder(apduCmd.Data.Length * 2);
                    for (int nI = 0; nI < apduCmd.Data.Length; nI++)
                        sData.AppendFormat("{0:X02}", apduCmd.Data[nI]);

                    textData = sData.ToString();
                }
                else
                    textData = "";

                m_apduParam = new GemCard.APDUParam();

                m_apduParam.P1 = apduCmd.P1;
                m_apduParam.P2 = apduCmd.P2;
                m_apduParam.Le = apduCmd.Le;
            }
        }

        private void SetupReaderList()
        {
            try
            {
                string[] sListReaders = m_iCard.ListReaders();
                //comboReader.Items.Clear();

                if (sListReaders != null)
                {
                    for (int nI = 0; nI < sListReaders.Length; nI++)
                    {
                        reader = Convert.ToString(sListReaders[nI]);
                        //    comboReader.Items.Add(sListReaders[nI]);
                    }
                    //comboReader.SelectedIndex = 0;

                    //btnConnect.Enabled = false;
                    //btnDisconnect.Enabled = false;
                    //btnTransmit.Enabled = false;

                    //// Start waiting for a card
                    //string reader = (string)comboReader.SelectedItem;
                    //m_iCard.StartCardEvents(reader);

                    //statusBarPanel_Info.Text = "Waiting for a card";
                }
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        /// <summary>
        /// Loads the APDU list
        /// </summary>
        private void LoadApduList()
        {
            try
            {
                // Create the APDU player
                m_apduPlayer = new GemCard.APDUPlayer(ApduListFile, m_iCard);

                // Get the list of APDUs and setup teh combo
                //comboApdu.Items.AddRange(m_apduPlayer.APDUNames);
                //comboApdu.SelectedIndex = 0;
                DisplayAPDUCommand(m_apduPlayer.APDUByName("Get UID"));
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        private void comboReader_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                m_iCard.StopCardEvents();

                // Get the current selection
                //int idx = comboReader.SelectedIndex;
                //if (idx != -1)
                //{
                // Start waiting for a card

                m_iCard.StartCardEvents(reader);

                //statusBarPanel_Info.Text = "Waiting for a card";
                //}
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        private void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //    m_iCard.Disconnect(DISCONNECT.Unpower);

                //    m_iCard.StopCardEvents();
                m_iCard.OnCardInserted -= new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved -= new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);
            }
            catch
            {
            }
        }
        #endregion


        public frmMain formMain;
        WaitDialogForm loadDialog;

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void loadDataUser()
        {
            setLoadDialog(true, "Loading Data User...");
            try
            {
                using (clsConnection oConn = new clsConnection())
                {
                    oConn.Open();
                    string strSql = @"select a.userid, a.username, a.passwd, a.usergroupid, a.rfid, a.nik, a.nama, a.photo,
                                b.groupname
                                from tbp_user a
                                left outer join tbp_usergroup b on a.usergroupid=b.usergroupid and b.dlt='0'
                                where a.dlt='0'
                                order by a.username;";
                    DataTable dt = oConn.GetData(strSql);
                    oConn.Close();

                    clsEncryption oEncrypt = new clsEncryption();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dt.Rows[i]["username"] = oEncrypt.Decrypt(dt.Rows[i]["username"].ToString());
                        dt.Rows[i]["passwd"] = oEncrypt.Decrypt(dt.Rows[i]["passwd"].ToString());
                    }
                    DataView dv = new DataView(dt);
                    dv.RowFilter = "username<>'SUPERADMIN'";
                    oEncrypt = null;

                    dgUSer.DataSource = dv.ToTable();
                }
            }
            catch (Exception)
            { }
            setLoadDialog(false, "");
        }

        private void loadDataUserGroup()
        {
            setLoadDialog(true, "Loading Data User Group...");
            try
            {
                using (clsConnection oConn = new clsConnection())
                {
                    oConn.Open();
                    string strSql = @"select usergroupid, groupname 
                                from tbp_usergroup 
                                where dlt='0' order by groupname;";
                    DataTable dt = oConn.GetData(strSql);
                    dgGroup.DataSource = dt;
                }
            }
            catch (Exception)
            { }

            setLoadDialog(false, "");
        }

        private void loadDataLUUserGroup()
        {
            setLoadDialog(true, "Loading Data User Group...");
            try
            {
                using (clsConnection oConn = new clsConnection())
                {
                    oConn.Open();
                    string strSql = @"select usergroupid, groupname 
                                from tbp_usergroup 
                                where dlt='0' order by groupname;";
                    DataTable dt = oConn.GetData(strSql);
                    repositoryLUGroup.DataSource = dt;
                }
            }
            catch (Exception)
            { }

            setLoadDialog(false, "");
        }

        private void loadDataUserModule()
        {
            if (xtraTabControl1.SelectedTabPage == xtraTabPage1)
            {
                setLoadDialog(true, "Loading Data Privileges...");
                try
                {
                    using (clsConnection oConn = new clsConnection())
                    {
                        oConn.Open();
                        string strSql = @"select a.moduleid, a.groupcode, a.groupname, a.groupcode||' - '||a.groupname as groupview, a.modulename,
                                b.usermoduleid, b.userid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                                coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload, 
                                '' as usergroupmoduleid,'' as usergroupid
                                from tbp_module a
                                left outer join tbp_usermodule b on a.moduleid=b.moduleid and b.dlt='0' and b.userid='" + Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid)) + @"'
                                where a.dlt='0'
                                order by a.groupcode, a.groupname, a.moduleid::numeric;";
                        DataTable dt = oConn.GetData(strSql);
                        dgPrivilege.DataSource = dt;
                    }
                }
                catch (Exception)
                { }
                setLoadDialog(false, "");
            }
        }
        private void loadDataUserProdi()
        {
            if (xtraTabControl1.SelectedTabPage == xtraTabPage1)
            {
                setLoadDialog(true, "Loading Data Privileges...");
                try
                {
                    using (clsConnection oConn = new clsConnection())
                    {
                        oConn.Open();
                        string strSql = @"select jr.jurusancode, jr.jurusandesc, jr.jurusancode||' - '||jr.jurusandesc as jurusanview,
                        a.prodiid, a.prodicode, a.prodidesc, a.prodicode||' - '||a.prodidesc as prodiview, a.prodidesc,
                        b.userprodiid, b.userid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                        coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload
                        from tbp_prodi a
                        inner join tbp_jurusan jr on a.jurusanid=jr.jurusanid and jr.dlt='0'
                        left outer join tbp_userprodi b on a.prodiid=b.prodiid and b.dlt='0' and b.userid='" + Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid)) + @"'
                        where a.dlt='0'
                        order by jurusanview, prodiview";
                        DataTable dt = oConn.GetData(strSql);
                        dgProdi.DataSource = dt;
                    }
                }
                catch (Exception)
                { }
                setLoadDialog(false, "");
            }
        }
        private void loadDataUserGroupModule()
        {
            if (xtraTabControl1.SelectedTabPage == xtraTabPage2)
            {
                setLoadDialog(true, "Loading Data Privileges...");
                try
                {
                    using (clsConnection oConn = new clsConnection())
                    {
                        oConn.Open();
                        string strSql = @"select a.moduleid, a.groupcode, a.groupname, a.groupcode||' - '||a.groupname as groupview, a.modulename,
                                b.usergroupmoduleid, b.usergroupid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                                coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload,
                                '' as usermoduleid, '' as userid
                                from tbp_module a
                                left outer join tbp_usergroupmodule b on a.moduleid=b.moduleid and b.dlt='0' and b.usergroupid='" + Convert.ToString(gridViewGroup.GetFocusedRowCellValue(usergroupid1)) + @"'
                                where a.dlt='0'
                                order by a.groupcode, a.groupname, a.moduleid::numeric;";
                        DataTable dt = oConn.GetData(strSql);
                        dgPrivilege.DataSource = dt;
                    }
                }
                catch (Exception)
                { }
                setLoadDialog(false, "");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void ucManagementUser_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        private void ucManagementUser_Load(object sender, EventArgs e)
        {

        }
        public void refreshAll()
        {
            btnEdit.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
            btnDel.Enabled = clsGlobal.bolDelete;
            btnSavePriv.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
            dgPrivilege.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;

            loadDataLUUserGroup();
            loadDataUser();
            loadDataUserGroup();
        }
        private void gridViewUser_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            string strphoto = Convert.ToString(gridViewUser.GetFocusedRowCellValue(photo));
            if (!string.IsNullOrEmpty(strphoto))
            {
                pictureBox2.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + strphoto;
            }
            else
            {
                pictureBox2.Image = pictureBox2.InitialImage;
            }
            loadDataUserModule();
            //loadDataUserProdi();
        }

        private void gridViewGroup_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            loadDataUserGroupModule();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (xtraTabControl1.SelectedTabPage == xtraTabPage1)
            {
                strAct = "edit_user";
            }
            else
            {
                strAct = "edit_group";
            }
            setEditControl(true);
        }

        string strAct = "loadData";

        private void setEnChk(bool isEnabled)
        {
            chkRead.Enabled = isEnabled;
            chkAdd.Enabled = isEnabled;
            checkEdit.Enabled = isEnabled;
            chkDelete.Enabled = isEnabled;
            chkPrint.Enabled = isEnabled;
            chkExport.Enabled = isEnabled;
            chkImport.Enabled = isEnabled;
        }

        private void setEditControl(bool isEdit)
        {
            if (xtraTabControl1.SelectedTabPage == xtraTabPage1 && strAct == "edit_user" && isEdit == true)
            {
                btnEdit.Enabled = false;
                btnDel.Enabled = false;
                btnEndEdit.Enabled = true;
                gridViewUser.OptionsBehavior.Editable = true;
                gridViewUser.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
                dgPrivilege.Enabled = false;
                btnSavePriv.Enabled = false;
                setEnChk(btnSavePriv.Enabled);
            }
            else if (xtraTabControl1.SelectedTabPage == xtraTabPage2 && strAct == "edit_group" && isEdit == true)
            {
                btnEdit.Enabled = false;
                btnDel.Enabled = false;
                btnEndEdit.Enabled = true;
                gridViewGroup.OptionsBehavior.Editable = true;
                gridViewGroup.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
                dgPrivilege.Enabled = false;
                btnSavePriv.Enabled = false;
                setEnChk(btnSavePriv.Enabled);
            }
            else
            {
                if (xtraTabControl1.SelectedTabPage == xtraTabPage1)
                {
                    if (gridViewUser.RowCount > 0)
                    {
                        btnDel.Enabled = clsGlobal.bolDelete;
                        dgPrivilege.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                        btnSavePriv.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                        setEnChk(btnSavePriv.Enabled);
                    }
                    else
                    {
                        btnDel.Enabled = false;
                        dgPrivilege.Enabled = false;
                        btnSavePriv.Enabled = false;
                        setEnChk(btnSavePriv.Enabled);
                    }
                }
                else if (xtraTabControl1.SelectedTabPage == xtraTabPage2)
                {
                    if (gridViewGroup.RowCount > 0)
                    {
                        btnDel.Enabled = clsGlobal.bolDelete;
                        dgPrivilege.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                        btnSavePriv.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                        setEnChk(btnSavePriv.Enabled);
                    }
                    else
                    {
                        btnDel.Enabled = false;
                        dgPrivilege.Enabled = false;
                        btnSavePriv.Enabled = false;
                        setEnChk(btnSavePriv.Enabled);
                    }
                }
                btnEdit.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                btnEndEdit.Enabled = false;
                gridViewUser.OptionsBehavior.Editable = false;
                gridViewGroup.OptionsBehavior.Editable = false;
                gridViewUser.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None;
                gridViewGroup.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None;
            }
        }

        private void xtraTabControl1_SelectedPageChanged(object sender, DevExpress.XtraTab.TabPageChangedEventArgs e)
        {
            if (strAct == "loadData")
            {
                setEditControl(false);
            }
            else
            {
                setEditControl(true);
            }

            if (e.Page == xtraTabPage1)
            {
                loadDataUserModule();
            }
            else
            {
                loadDataUserGroupModule();
            }

            //tabPrivilegeProdi.PageVisible = e.Page == xtraTabPage1;
        }

        private void btnEndEdit_Click(object sender, EventArgs e)
        {
            strAct = "loadData";
            setEditControl(false);
        }

        private void gridViewUser_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            if (Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, username)) == "")
            {
                e.ErrorText = "Username tidak boleh kosong!";
                gridViewUser.FocusedColumn = username;
                e.Valid = false;
                return;
            }
            if (Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, passwd)) == "")
            {
                e.ErrorText = "Password tidak boleh kosong!";
                gridViewUser.FocusedColumn = passwd;
                e.Valid = false;
                return;
            }

            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                clstbp_user oObject = new clstbp_user();
                clsEncryption oEncrypt = new clsEncryption();
                oObject.Koneksi = oConn.Conn;
                string strUserID = "";
                strUserID = Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, userid));
                oObject.GetByPrimaryKey(strUserID);
                oObject.username = oEncrypt.Encrypt(Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, username)).ToUpper());
                oObject.passwd = oEncrypt.Encrypt(Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, passwd)));
                oObject.usergroupid = Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, usergroupid));
                oObject.rfid = Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, rfid));
                oObject.nik = Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, nik));
                oObject.nama = Convert.ToString(gridViewUser.GetRowCellValue(e.RowHandle, nama));

                if (strUserID == "" || strUserID == null)
                {
                    oObject.op_add = clsGlobal.strUserName;
                    oObject.pc_add = SystemInformation.ComputerName;
                    oObject.userid = oObject.NewID();
                    if (oObject.Insert())
                    {
                        gridViewUser.SetFocusedRowCellValue(userid, oObject.userid);
                        if (oObject.usergroupid != "")
                        {
                            setLoadDialog(true, "Saving Privileges..");
                            string strSql = @"select a.moduleid, a.groupcode, a.groupname, a.groupcode||' - '||a.groupname as groupview, a.modulename,
                                b.usergroupmoduleid, b.usergroupid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                                coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload
                                from tbp_module a
                                left outer join tbp_usergroupmodule b on a.moduleid=b.moduleid and b.dlt='0' and b.usergroupid='" + oObject.usergroupid + @"'
                                where a.dlt='0'";
                            DataTable dt = oConn.GetData(strSql);
                            tbp_usermodule oUserModule = new tbp_usermodule();
                            oUserModule.Koneksi = oConn.Conn;
                            if (oConn.Conn.State == ConnectionState.Closed) { oConn.Open(); }
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                oUserModule.isread = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isread"]));
                                oUserModule.isadd = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isadd"]));
                                oUserModule.isedit = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isedit"]));
                                oUserModule.isdelete = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isdelete"]));
                                oUserModule.isprint = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isprint"]));
                                oUserModule.isdownload = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isdownload"]));
                                oUserModule.isupload = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isupload"]));
                                oUserModule.moduleid = Convert.ToString(dt.Rows[i]["moduleid"]);
                                oUserModule.userid = oObject.userid;
                                oUserModule.usermoduleid = oObject.NewID();
                                oUserModule.op_add = clsGlobal.strUserName;
                                oUserModule.pc_add = SystemInformation.ComputerName;
                                oUserModule.Insert();
                            }
                            oUserModule = null;
                            setLoadDialog(false, "");
                            loadDataUserModule();
                        }
                    }
                    else
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                else
                {
                    oObject.op_edit = clsGlobal.strUserName;
                    oObject.pc_edit = SystemInformation.ComputerName;

                    if (oObject.usergroupid != "")
                    {
                        clstbp_user oUser2 = new clstbp_user();
                        oUser2.Koneksi = oConn.Conn;
                        oUser2.GetByPrimaryKey(oObject.userid);
                        if (oUser2.usergroupid != oObject.usergroupid)
                        {
                            setLoadDialog(true, "Saving Privileges..");
                            oConn.ExecuteCommand("update tbp_usermodule set dlt='1' where userid='" + oObject.userid + "' and dlt='0'");

                            string strSql = @"select a.moduleid, a.groupcode, a.groupname, a.groupcode||' - '||a.groupname as groupview, a.modulename,
                                b.usergroupmoduleid, b.usergroupid, coalesce(b.isread,false) as isread, coalesce(b.isadd,false) as isadd, coalesce(b.isedit,false) as isedit, 
                                coalesce(b.isdelete,false) as isdelete, coalesce(b.isprint,false) as isprint, coalesce(b.isdownload, false) as isdownload, coalesce(b.isupload, false) as isupload
                                from tbp_module a
                                left outer join tbp_usergroupmodule b on a.moduleid=b.moduleid and b.dlt='0' and b.usergroupid='" + oObject.usergroupid + @"'
                                where a.dlt='0'";
                            DataTable dt = oConn.GetData(strSql);
                            tbp_usermodule oUserModule = new tbp_usermodule();
                            oUserModule.Koneksi = oConn.Conn;
                            if (oConn.Conn.State == ConnectionState.Closed) { oConn.Open(); }
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                oUserModule.isread = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isread"]));
                                oUserModule.isadd = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isadd"]));
                                oUserModule.isedit = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isedit"]));
                                oUserModule.isdelete = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isdelete"]));
                                oUserModule.isprint = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isprint"]));
                                oUserModule.isdownload = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isdownload"]));
                                oUserModule.isupload = Convert.ToBoolean(Convert.ToString(dt.Rows[i]["isupload"]));
                                oUserModule.moduleid = Convert.ToString(dt.Rows[i]["moduleid"]);
                                oUserModule.userid = oObject.userid;
                                oUserModule.usermoduleid = oObject.NewID();
                                oUserModule.op_add = clsGlobal.strUserName;
                                oUserModule.pc_add = SystemInformation.ComputerName;
                                oUserModule.Insert();
                            }
                            oUserModule = null;
                            setLoadDialog(false, "");
                            loadDataUserModule();
                        }
                        oUser2 = null;
                    }

                    if (oObject.Update() == false)
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                oObject = null; oEncrypt = null;
            }
        }

        private void gridViewGroup_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            if (Convert.ToString(gridViewGroup.GetFocusedRowCellValue(groupname)) == "")
            {
                e.ErrorText = "Nama User Group tidak boleh kosong!";
                gridViewGroup.FocusedColumn = groupname;
                e.Valid = false;
                return;
            }

            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                tbp_usergroup oObject = new tbp_usergroup();
                oObject.Koneksi = oConn.Conn;
                string strUserGroupID = "";
                strUserGroupID = Convert.ToString(gridViewGroup.GetFocusedRowCellValue(usergroupid1));
                oObject.GetByPrimaryKey(strUserGroupID);
                oObject.groupname = Convert.ToString(gridViewGroup.GetFocusedRowCellValue(groupname));

                if (strUserGroupID == "" || strUserGroupID == null)
                {
                    oObject.op_add = clsGlobal.strUserName;
                    oObject.pc_add = SystemInformation.ComputerName;
                    oObject.usergroupid = oObject.NewID();
                    if (oObject.Insert())
                    {
                        gridViewGroup.SetFocusedRowCellValue(usergroupid1, oObject.usergroupid);
                    }
                    else
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                else
                {
                    oObject.op_edit = clsGlobal.strUserName;
                    oObject.pc_edit = SystemInformation.ComputerName;
                    if (oObject.Update() == false)
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                oObject = null;
            }
            loadDataLUUserGroup();
        }

        private void btnSavePriv_Click(object sender, EventArgs e)
        {
            setLoadDialog(true, "Saving Privileges...");
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                if (xtraTabControl1.SelectedTabPage == xtraTabPage1)
                {
                    tbp_usermodule oObject = new tbp_usermodule();
                    oObject.Koneksi = oConn.Conn;
                    for (int i = 0; i < gridViewPrivilege.RowCount; i++)
                    {
                        if (Convert.ToString(gridViewPrivilege.GetRowCellValue(i, moduleid)) != "")
                        {
                            oObject.usermoduleid = "";
                            oObject.GetByPrimaryKey(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, usermoduleid)));
                            oObject.isread = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isread)));
                            oObject.isadd = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isadd)));
                            oObject.isedit = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isedit)));
                            oObject.isdelete = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isdelete)));
                            oObject.isprint = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isprint)));
                            oObject.isdownload = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isdownload)));
                            oObject.isupload = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isupload)));
                            oObject.moduleid = Convert.ToString(gridViewPrivilege.GetRowCellValue(i, moduleid));
                            oObject.userid = Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid));

                            if (oObject.usermoduleid == null || oObject.usermoduleid == "")
                            {
                                oObject.usermoduleid = oObject.NewID();
                                oObject.op_add = clsGlobal.strUserName;
                                oObject.pc_add = SystemInformation.ComputerName;
                                oObject.Insert();
                            }
                            else
                            {
                                oObject.op_edit = clsGlobal.strUserName;
                                oObject.pc_edit = SystemInformation.ComputerName;
                                oObject.Update();
                            }
                        }
                    }
                    oObject = null;
                    if (tabPrivilegeProdi.PageVisible)
                    {
                        clstbp_userprodi otbp_userprodi = new clstbp_userprodi();
                        otbp_userprodi.Koneksi = oConn.Conn;
                        for (int i = 0; i < gridViewProdi.RowCount; i++)
                        {
                            if (Convert.ToString(gridViewProdi.GetRowCellValue(i, prodiid)) != "")
                            {
                                otbp_userprodi.userprodiid = "";
                                otbp_userprodi.GetByPrimaryKey(Convert.ToString(gridViewProdi.GetRowCellValue(i, userprodiid)));
                                otbp_userprodi.isread = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isread)));
                                otbp_userprodi.isadd = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isadd)));
                                otbp_userprodi.isedit = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isedit)));
                                otbp_userprodi.isdelete = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isdelete)));
                                otbp_userprodi.isprint = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isprint)));
                                otbp_userprodi.isdownload = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isdownload)));
                                otbp_userprodi.isupload = Convert.ToBoolean(Convert.ToString(gridViewProdi.GetRowCellValue(i, isupload)));
                                otbp_userprodi.prodiid = Convert.ToString(gridViewProdi.GetRowCellValue(i, prodiid));
                                otbp_userprodi.userid = Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid));

                                if (otbp_userprodi.userprodiid == null || otbp_userprodi.userprodiid == "")
                                {
                                    otbp_userprodi.userprodiid = otbp_userprodi.NewID();
                                    otbp_userprodi.op_add = clsGlobal.strUserName;
                                    otbp_userprodi.pc_add = SystemInformation.ComputerName;
                                    otbp_userprodi.Insert();
                                }
                                else
                                {
                                    otbp_userprodi.op_edit = clsGlobal.strUserName;
                                    otbp_userprodi.pc_edit = SystemInformation.ComputerName;
                                    otbp_userprodi.Update();
                                }
                            }
                        }
                    }
                }
                else
                {
                    tbp_usergroupmodule oObject = new tbp_usergroupmodule();
                    oObject.Koneksi = oConn.Conn;
                    for (int i = 0; i < gridViewPrivilege.RowCount; i++)
                    {
                        if (Convert.ToString(gridViewPrivilege.GetRowCellValue(i, moduleid)) != "")
                        {
                            oObject.usergroupmoduleid = "";
                            oObject.GetByPrimaryKey(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, usergroupmoduleid)));
                            oObject.isread = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isread)));
                            oObject.isadd = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isadd)));
                            oObject.isedit = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isedit)));
                            oObject.isdelete = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isdelete)));
                            oObject.isprint = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isprint)));
                            oObject.isdownload = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isdownload)));
                            oObject.isupload = Convert.ToBoolean(Convert.ToString(gridViewPrivilege.GetRowCellValue(i, isupload)));
                            oObject.moduleid = Convert.ToString(gridViewPrivilege.GetRowCellValue(i, moduleid));
                            oObject.usergroupid = Convert.ToString(gridViewGroup.GetFocusedRowCellValue(usergroupid1));

                            if (oObject.usergroupmoduleid == null || oObject.usergroupmoduleid == "")
                            {
                                oObject.usergroupmoduleid = oObject.NewID();
                                oObject.op_add = clsGlobal.strUserName;
                                oObject.pc_add = SystemInformation.ComputerName;
                                oObject.Insert();
                            }
                            else
                            {
                                oObject.op_edit = clsGlobal.strUserName;
                                oObject.pc_edit = SystemInformation.ComputerName;
                                oObject.Update();
                            }
                        }
                    }
                    oObject = null;
                }
                XtraMessageBox.Show("Hak Akses berhasil di simpan!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            setLoadDialog(false, "");
        }

        private void chkImport_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isupload, chkImport.Checked);
                }
            }
        }

        private void chkExport_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isdownload, chkExport.Checked);
                }
            }
        }

        private void chkPrint_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isprint, chkPrint.Checked);
                }
            }
        }

        private void chkDelete_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isdelete, chkDelete.Checked);
                }
            }
        }

        private void checkEdit_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isedit, checkEdit.Checked);
                }
            }
        }

        private void chkAdd_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isadd, chkAdd.Checked);
                }
            }
        }

        private void chkRead_CheckedChanged(object sender, EventArgs e)
        {
            GridView gridview = gridViewPrivilege as GridView;
            string strFieldName = moduleid.FieldName;
            if (xtraTabControl2.SelectedTabPage == tabPrivilegeProdi)
            {
                gridview = gridViewProdi as GridView;
                strFieldName = prodiid.FieldName;
            }

            for (int i = 0; i < gridview.RowCount; i++)
            {
                if (Convert.ToString(gridview.GetRowCellValue(i, strFieldName)) != "")
                {
                    gridview.SetRowCellValue(i, isread, chkRead.Checked);
                }
            }

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (xtraTabControl1.SelectedTabPage == xtraTabPage1)
            {
                if (gridViewUser.RowCount > 0)
                {
                    if (Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid)) != "")
                    {
                        if (XtraMessageBox.Show("Anda yakin menghapus data ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (clsConnection oConn = new clsConnection())
                            {
                                clstbp_user oObject = new clstbp_user();
                                oConn.Open();
                                oObject.Koneksi = oConn.Conn;
                                oObject.GetByPrimaryKey(Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid)));
                                if (oObject.userid == null || oObject.userid == "")
                                { }
                                else
                                {
                                    oObject.op_edit = clsGlobal.strUserName;
                                    oObject.pc_edit = SystemInformation.ComputerName;
                                    oObject.SoftDelete();
                                    gridViewUser.DeleteSelectedRows();
                                }
                                oObject = null;
                            }
                        }
                    }
                }
            }
            else
            {
                if (gridViewGroup.RowCount > 0)
                {
                    if (Convert.ToString(gridViewGroup.GetFocusedRowCellValue(usergroupid1)) != "")
                    {
                        if (XtraMessageBox.Show("Anda yakin menghapus data ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (clsConnection oConn = new clsConnection())
                            {
                                tbp_usergroup oObject = new tbp_usergroup();
                                oConn.Open();
                                oObject.Koneksi = oConn.Conn;
                                oObject.GetByPrimaryKey(Convert.ToString(gridViewGroup.GetFocusedRowCellValue(usergroupid1)));
                                if (oObject.usergroupid == null || oObject.usergroupid == "")
                                { }
                                else
                                {
                                    oObject.op_edit = clsGlobal.strUserName;
                                    oObject.pc_edit = SystemInformation.ComputerName;
                                    oObject.SoftDelete();
                                    gridViewGroup.DeleteSelectedRows();
                                }
                                oObject = null;
                            }
                        }
                    }
                }
            }
        }

        private void xtraTabControl2_SelectedPageChanged(object sender, DevExpress.XtraTab.TabPageChangedEventArgs e)
        {
            chkAdd.Visible = e.Page != tabPrivilegeProdi;
            chkDelete.Visible = e.Page != tabPrivilegeProdi;
            chkExport.Visible = e.Page != tabPrivilegeProdi;
            chkImport.Visible = e.Page != tabPrivilegeProdi;
            chkPrint.Visible = e.Page != tabPrivilegeProdi;
            checkEdit.Visible = e.Page != tabPrivilegeProdi;
        }

        private void labelControl1_Leave(object sender, EventArgs e)
        {
            frm_FormClosed(sender, null);
        }

        public string strRenamePhoto = "";
        public string strFileName = "";

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Browse Photo...";
            fdlg.Filter = "JPEG (*.jpg)|*.jpg|PNG (*.png)|*.png|GIF (*.gif)|*.gif";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                using (clsConnection oConn = new clsConnection())
                {
                    try
                    {
                        string strYM = clsGlobal.getData1Field("select to_char(now(),'yyyymmddHH24MISS');");
                        string path = Application.StartupPath + "\\photos\\";
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }
                        string strTempPath = path + strYM + Path.GetExtension(fdlg.FileName);
                        Image img1 = ScaleImage(Image.FromFile(fdlg.FileName), 114, 152); //3cm x 4cm
                        img1.Save(strTempPath);
                        pictureBox2.Image = img1;

                        strRenamePhoto = strYM + Path.GetExtension(fdlg.FileName);
                        strFileName = strTempPath;

                        setLoadDialog(true, "Update photo...");
                        oConn.Open();
                        clstbp_user oObject = new clstbp_user();
                        clsEncryption oEncrypt = new clsEncryption();
                        oObject.Koneksi = oConn.Conn;
                        string strUserID = Convert.ToString(gridViewUser.GetFocusedRowCellValue(userid));
                        oObject.GetByPrimaryKey(strUserID);

                        clsGlobal.Upload(clsGlobal.strFTP_host, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, clsGlobal.strftpcoverpath, strFileName, strRenamePhoto);
                        oObject.photo = strRenamePhoto;

                        if (!string.IsNullOrEmpty(strUserID))
                        {
                            oObject.op_edit = clsGlobal.strUserName;
                            oObject.pc_edit = SystemInformation.ComputerName;
                            if (oObject.Update() == false)
                            {
                                XtraMessageBox.Show("Photo gagal di update", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            }
                        }
                    }
                    catch (NpgsqlException ex)
                    {
                        clsGlobal.generateErrMessageAndSendmail(ex, false);
                    }
                    catch (Exception ex)
                    {
                        clsGlobal.generateErrMessageAndSendmail(ex, false);
                    }
                    finally
                    {
                        setLoadDialog(false, "");
                    }
                }
            }
        }

        private Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);
            Graphics.FromImage(newImage).DrawImage(image, 0, 0, newWidth, newHeight);
            return newImage;
        }
    }
}
