﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Library;
using Npgsql;
using DevExpress.XtraEditors;
using DevExpress.Utils;

namespace DIGILIB.Utility
{
    public partial class ucNumberingPrefix : UserControl
    {
        WaitDialogForm loadDialog;
        public frmMain formMain;

        public ucNumberingPrefix()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Close();
            loadDialog.Dispose();
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog==null || loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
         
        public void refreshAll()
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    loadDialog = new WaitDialogForm();
                    setLoadDialog(true, "Loading data client...");

                    string strSql = @"select a.description, b.numberingformat, b.prefix, b.startfrom, b.restartevery, b.numberingprefixid
                                from 
                                (
	                                (select 'Nomor Induk Buku'::varchar as description, 1 as nourut)
                                    union (select 'Nomor inventaris Buku'::varchar as description, 2 as nourut)
                                    union (select 'Nomor Induk Multimedia'::varchar as description, 3 as nourut)
                                    union (select 'Nomor inventaris Multimedia'::varchar as description, 4 as nourut)
                                    union (select 'Nomor Pengadaan'::varchar as description, 5 as nourut)
                                    union (select 'Nomor Peminjaman Buku'::varchar as description, 6 as nourut)
                                    union (select 'Nomor Pengembalian Buku'::varchar as description, 7 as nourut)

                                ) a
                                left outer join tbm_projectnumberingprefix b on b.dlt='0' and lower(a.description)=lower(b.description)
                                order by a.nourut";
                    dgData.DataSource = oConn.GetData(strSql);
                    enableControl(true);
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                }
            }
        }

        private void userControlProjectPeriods_Leave(object sender, EventArgs e)
        {
            loadDialog.Close();
            loadDialog.Dispose();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            enableControl(false);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            refreshAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                tbm_projectnumberingprefix oObject = new tbm_projectnumberingprefix();
                try
                {
                    if (XtraMessageBox.Show("Are you sure to delete selected record?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        string[] strConstraintTable = { };
                        if (gridView1.SelectedRowsCount == 0)
                        {
                            gridView1.SelectRow(gridView1.FocusedRowHandle);
                            gridView1.MakeRowVisible(gridView1.FocusedRowHandle, false);
                        }
                        int[] arrSelectedRows = gridView1.GetSelectedRows();

                        for (int i = 0; i < arrSelectedRows.Length; i++)
                        {
                            if (gridView1.IsGroupRow(arrSelectedRows[i]))
                            {
                                gridView1.UnselectRow(arrSelectedRows[i]);
                                continue;
                            }

                            if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                            oObject.Koneksi = oConn.Conn;
                            oObject.GetByPrimaryKey(Convert.ToString(gridView1.GetRowCellValue(arrSelectedRows[i], numberingprefixid)));
                            oObject.opedit = clsGlobal.strUserName;
                            oObject.pcedit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                        }
                        if (arrSelectedRows.Length > 0)
                        {
                            gridView1.DeleteSelectedRows();
                        }

                        refreshAll();
                    }

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {

                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Saving data...");
                tbm_projectnumberingprefix oObject;
                for (int intindex = 0; intindex < gridView1.RowCount; intindex++)
                {
                    oObject = new tbm_projectnumberingprefix();
                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oObject.Koneksi = oConn.Conn;

                    oObject.GetByPrimaryKey(Convert.ToString(gridView1.GetRowCellValue(intindex, numberingprefixid)));
                    oObject.numberingformat = Convert.ToString(gridView1.GetRowCellValue(intindex, numberingformat));
                    oObject.prefix = Convert.ToString(gridView1.GetRowCellValue(intindex, prefix));
                    oObject.startfrom = Convert.ToString(gridView1.GetRowCellValue(intindex, startfrom));
                    oObject.restartevery = Convert.ToString(gridView1.GetRowCellValue(intindex, restartevery));
                    oObject.description = Convert.ToString(gridView1.GetRowCellValue(intindex, description));
                    if (oObject.numberingprefixid == null || oObject.numberingprefixid == "")
                    {
                        oObject.numberingprefixid = oObject.NewID();
                        oObject.opadd = clsGlobal.strUserName;
                        oObject.pcadd = SystemInformation.ComputerName;
                        oObject.Insert();
                    }
                    else
                    {
                        oObject.opedit = clsGlobal.strUserName;
                        oObject.pcedit = SystemInformation.ComputerName;
                        oObject.Update();
                    }
                }
                XtraMessageBox.Show("Numbering prefix informations has been saved", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                enableControl(true);

                setLoadDialog(false, "");
            }
        }

        private void enableControl(bool bState)
        {
            btnEdit.Enabled = bState && (clsGlobal.bolEdit||clsGlobal.bolAdd);
            btnDelete.Enabled = bState && clsGlobal.bolDelete;
            btnSave.Enabled = !bState;
            btnCancel.Enabled = !bState;
            gridView1.OptionsBehavior.Editable = !bState;
             
        }
         
        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void dockPanel1_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            groupControl1.Visible = false;
        }

        private void ucNumberingPrefix_Load(object sender, EventArgs e)
        {
            //refreshAll();
        }
         
    }
}
