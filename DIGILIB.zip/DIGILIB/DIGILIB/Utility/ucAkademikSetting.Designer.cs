﻿namespace DIGILIB.akademik
{
    partial class ucAkademikSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraGrid.GridLevelNode gridLevelNode3 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucAkademikSetting));
            this.gridViewDetail = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gelombangid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jalurmasukG2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gelombang = new DevExpress.XtraGrid.Columns.GridColumn();
            this.reguler = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.karyawan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jamujian = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTimeEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit();
            this.dgGelombang = new DevExpress.XtraGrid.GridControl();
            this.gridViewMaster = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.jalurmasukG1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.gridViewMataPelajaran1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.matapelajaranid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kodePelajaran = new DevExpress.XtraGrid.Columns.GridColumn();
            this.namaPelajaran = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dgMataPelajaran = new DevExpress.XtraGrid.GridControl();
            this.gridViewMataPelajaran2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.jalurmasukPelajaran = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.lblSemester = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.btnSemester1 = new DevExpress.XtraEditors.SimpleButton();
            this.btnSemester2 = new DevExpress.XtraEditors.SimpleButton();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.btnCancelPelajaran = new DevExpress.XtraEditors.SimpleButton();
            this.btnDelPelajaran = new DevExpress.XtraEditors.SimpleButton();
            this.btnEditPelajaran = new DevExpress.XtraEditors.SimpleButton();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.btnAktifTahun = new DevExpress.XtraEditors.SimpleButton();
            this.lblTahunAjaran = new DevExpress.XtraEditors.LabelControl();
            this.btnCancelBiaya = new DevExpress.XtraEditors.SimpleButton();
            this.btnDelBiaya = new DevExpress.XtraEditors.SimpleButton();
            this.btnEditBiaya = new DevExpress.XtraEditors.SimpleButton();
            this.dgDataTahunAjaran = new DevExpress.XtraGrid.GridControl();
            this.gridViewDataTahun = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tahunajaranid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tahunajaran = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isactive = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.btnCancelGelombang = new DevExpress.XtraEditors.SimpleButton();
            this.btnDelGelombang = new DevExpress.XtraEditors.SimpleButton();
            this.btnEditGelombang = new DevExpress.XtraEditors.SimpleButton();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.groupControl5 = new DevExpress.XtraEditors.GroupControl();
            this.chkPublishAll = new DevExpress.XtraEditors.CheckEdit();
            this.btnEndEditPublish = new DevExpress.XtraEditors.SimpleButton();
            this.btnEditPublish = new DevExpress.XtraEditors.SimpleButton();
            this.dgPublish = new DevExpress.XtraGrid.GridControl();
            this.gridViewPublish = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.publishkelulusanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gelombangid5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jalurmasuk = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jeniskelas = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ispublish = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositorychkPublish = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gelombang5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tanggal = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemComboBox4 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemDateEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemTimeEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgGelombang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMataPelajaran1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgMataPelajaran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMataPelajaran2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDataTahunAjaran)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDataTahun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).BeginInit();
            this.groupControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkPublishAll.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPublish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPublish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositorychkPublish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEdit2)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewDetail
            // 
            this.gridViewDetail.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gelombangid,
            this.jalurmasukG2,
            this.gelombang,
            this.reguler,
            this.karyawan,
            this.jamujian});
            this.gridViewDetail.GridControl = this.dgGelombang;
            this.gridViewDetail.Name = "gridViewDetail";
            this.gridViewDetail.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewDetail.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewDetail.OptionsBehavior.Editable = false;
            this.gridViewDetail.OptionsView.ShowGroupPanel = false;
            // 
            // gelombangid
            // 
            this.gelombangid.Caption = "gelombangid";
            this.gelombangid.FieldName = "gelombangid";
            this.gelombangid.Name = "gelombangid";
            // 
            // jalurmasukG2
            // 
            this.jalurmasukG2.Caption = "jalurmasuk";
            this.jalurmasukG2.FieldName = "jalurmasuk";
            this.jalurmasukG2.Name = "jalurmasukG2";
            // 
            // gelombang
            // 
            this.gelombang.AppearanceCell.Options.UseTextOptions = true;
            this.gelombang.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gelombang.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gelombang.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gelombang.AppearanceHeader.Options.UseFont = true;
            this.gelombang.AppearanceHeader.Options.UseTextOptions = true;
            this.gelombang.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gelombang.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gelombang.Caption = "Gelombang";
            this.gelombang.FieldName = "gelombang";
            this.gelombang.MaxWidth = 80;
            this.gelombang.Name = "gelombang";
            this.gelombang.Visible = true;
            this.gelombang.VisibleIndex = 0;
            this.gelombang.Width = 80;
            // 
            // reguler
            // 
            this.reguler.AppearanceCell.Options.UseTextOptions = true;
            this.reguler.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.reguler.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.reguler.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reguler.AppearanceHeader.Options.UseFont = true;
            this.reguler.AppearanceHeader.Options.UseTextOptions = true;
            this.reguler.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.reguler.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.reguler.Caption = "Reguler";
            this.reguler.ColumnEdit = this.repositoryItemDateEdit1;
            this.reguler.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.reguler.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.reguler.FieldName = "reguler";
            this.reguler.Name = "reguler";
            this.reguler.Visible = true;
            this.reguler.VisibleIndex = 1;
            this.reguler.Width = 123;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // karyawan
            // 
            this.karyawan.AppearanceCell.Options.UseTextOptions = true;
            this.karyawan.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.karyawan.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.karyawan.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.karyawan.AppearanceHeader.Options.UseFont = true;
            this.karyawan.AppearanceHeader.Options.UseTextOptions = true;
            this.karyawan.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.karyawan.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.karyawan.Caption = "Karyawan";
            this.karyawan.ColumnEdit = this.repositoryItemDateEdit1;
            this.karyawan.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.karyawan.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.karyawan.FieldName = "karyawan";
            this.karyawan.Name = "karyawan";
            this.karyawan.Visible = true;
            this.karyawan.VisibleIndex = 2;
            this.karyawan.Width = 126;
            // 
            // jamujian
            // 
            this.jamujian.AppearanceCell.Options.UseTextOptions = true;
            this.jamujian.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jamujian.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jamujian.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.jamujian.AppearanceHeader.Options.UseFont = true;
            this.jamujian.AppearanceHeader.Options.UseTextOptions = true;
            this.jamujian.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jamujian.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jamujian.Caption = "Jam Ujian";
            this.jamujian.ColumnEdit = this.repositoryItemTimeEdit1;
            this.jamujian.FieldName = "jamujian";
            this.jamujian.MaxWidth = 100;
            this.jamujian.Name = "jamujian";
            this.jamujian.Visible = true;
            this.jamujian.VisibleIndex = 3;
            this.jamujian.Width = 100;
            // 
            // repositoryItemTimeEdit1
            // 
            this.repositoryItemTimeEdit1.AutoHeight = false;
            this.repositoryItemTimeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemTimeEdit1.Name = "repositoryItemTimeEdit1";
            // 
            // dgGelombang
            // 
            this.dgGelombang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            gridLevelNode3.LevelTemplate = this.gridViewDetail;
            gridLevelNode3.RelationName = "Level1";
            this.dgGelombang.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode3});
            this.dgGelombang.Location = new System.Drawing.Point(5, 24);
            this.dgGelombang.MainView = this.gridViewMaster;
            this.dgGelombang.Name = "dgGelombang";
            this.dgGelombang.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit2,
            this.repositoryItemCheckEdit2,
            this.repositoryItemComboBox2,
            this.repositoryItemDateEdit1,
            this.repositoryItemTimeEdit1});
            this.dgGelombang.Size = new System.Drawing.Size(392, 393);
            this.dgGelombang.TabIndex = 3;
            this.dgGelombang.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewMaster,
            this.gridViewDetail});
            this.dgGelombang.FocusedViewChanged += new DevExpress.XtraGrid.ViewFocusEventHandler(this.dgGelombang_FocusedViewChanged);
            // 
            // gridViewMaster
            // 
            this.gridViewMaster.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.jalurmasukG1});
            this.gridViewMaster.GridControl = this.dgGelombang;
            this.gridViewMaster.Name = "gridViewMaster";
            this.gridViewMaster.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewMaster.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewMaster.OptionsBehavior.Editable = false;
            this.gridViewMaster.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridViewMaster.OptionsDetail.ShowDetailTabs = false;
            this.gridViewMaster.OptionsView.RowAutoHeight = true;
            this.gridViewMaster.OptionsView.ShowColumnHeaders = false;
            this.gridViewMaster.OptionsView.ShowGroupPanel = false;
            // 
            // jalurmasukG1
            // 
            this.jalurmasukG1.AppearanceCell.Options.UseTextOptions = true;
            this.jalurmasukG1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.jalurmasukG1.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jalurmasukG1.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jalurmasukG1.AppearanceHeader.Options.UseFont = true;
            this.jalurmasukG1.AppearanceHeader.Options.UseTextOptions = true;
            this.jalurmasukG1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jalurmasukG1.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jalurmasukG1.Caption = "Jalur Masuk";
            this.jalurmasukG1.FieldName = "jalurmasuk";
            this.jalurmasukG1.Name = "jalurmasukG1";
            this.jalurmasukG1.Visible = true;
            this.jalurmasukG1.VisibleIndex = 0;
            this.jalurmasukG1.Width = 20;
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "UMPN",
            "UMPB"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            this.repositoryItemComboBox2.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // gridViewMataPelajaran1
            // 
            this.gridViewMataPelajaran1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.matapelajaranid,
            this.gridColumn2,
            this.kodePelajaran,
            this.namaPelajaran});
            this.gridViewMataPelajaran1.GridControl = this.dgMataPelajaran;
            this.gridViewMataPelajaran1.Name = "gridViewMataPelajaran1";
            this.gridViewMataPelajaran1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewMataPelajaran1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewMataPelajaran1.OptionsBehavior.Editable = false;
            this.gridViewMataPelajaran1.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridViewMataPelajaran1.OptionsView.ShowGroupPanel = false;
            // 
            // matapelajaranid
            // 
            this.matapelajaranid.Caption = "matapelajaranid";
            this.matapelajaranid.FieldName = "matapelajaranid";
            this.matapelajaranid.Name = "matapelajaranid";
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "jalurmasuk";
            this.gridColumn2.FieldName = "jalurmasuk";
            this.gridColumn2.Name = "gridColumn2";
            // 
            // kodePelajaran
            // 
            this.kodePelajaran.AppearanceCell.Options.UseTextOptions = true;
            this.kodePelajaran.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.kodePelajaran.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.kodePelajaran.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kodePelajaran.AppearanceHeader.Options.UseFont = true;
            this.kodePelajaran.AppearanceHeader.Options.UseTextOptions = true;
            this.kodePelajaran.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.kodePelajaran.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.kodePelajaran.Caption = "Kode";
            this.kodePelajaran.FieldName = "kode";
            this.kodePelajaran.MaxWidth = 80;
            this.kodePelajaran.Name = "kodePelajaran";
            this.kodePelajaran.Visible = true;
            this.kodePelajaran.VisibleIndex = 0;
            this.kodePelajaran.Width = 80;
            // 
            // namaPelajaran
            // 
            this.namaPelajaran.AppearanceCell.Options.UseTextOptions = true;
            this.namaPelajaran.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.namaPelajaran.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.namaPelajaran.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namaPelajaran.AppearanceHeader.Options.UseFont = true;
            this.namaPelajaran.AppearanceHeader.Options.UseTextOptions = true;
            this.namaPelajaran.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.namaPelajaran.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.namaPelajaran.Caption = "Mata Pelajaran";
            this.namaPelajaran.FieldName = "nama";
            this.namaPelajaran.Name = "namaPelajaran";
            this.namaPelajaran.Visible = true;
            this.namaPelajaran.VisibleIndex = 1;
            this.namaPelajaran.Width = 123;
            // 
            // dgMataPelajaran
            // 
            this.dgMataPelajaran.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            gridLevelNode1.LevelTemplate = this.gridViewMataPelajaran1;
            gridLevelNode1.RelationName = "Level1";
            this.dgMataPelajaran.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.dgMataPelajaran.Location = new System.Drawing.Point(5, 24);
            this.dgMataPelajaran.MainView = this.gridViewMataPelajaran2;
            this.dgMataPelajaran.Name = "dgMataPelajaran";
            this.dgMataPelajaran.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit3,
            this.repositoryItemCheckEdit3,
            this.repositoryItemComboBox3,
            this.repositoryItemDateEdit2});
            this.dgMataPelajaran.Size = new System.Drawing.Size(488, 396);
            this.dgMataPelajaran.TabIndex = 4;
            this.dgMataPelajaran.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewMataPelajaran2,
            this.gridViewMataPelajaran1});
            this.dgMataPelajaran.FocusedViewChanged += new DevExpress.XtraGrid.ViewFocusEventHandler(this.dgMataPelajaran_FocusedViewChanged);
            // 
            // gridViewMataPelajaran2
            // 
            this.gridViewMataPelajaran2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.jalurmasukPelajaran});
            this.gridViewMataPelajaran2.GridControl = this.dgMataPelajaran;
            this.gridViewMataPelajaran2.Name = "gridViewMataPelajaran2";
            this.gridViewMataPelajaran2.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewMataPelajaran2.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewMataPelajaran2.OptionsBehavior.Editable = false;
            this.gridViewMataPelajaran2.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridViewMataPelajaran2.OptionsDetail.ShowDetailTabs = false;
            this.gridViewMataPelajaran2.OptionsView.RowAutoHeight = true;
            this.gridViewMataPelajaran2.OptionsView.ShowColumnHeaders = false;
            this.gridViewMataPelajaran2.OptionsView.ShowGroupPanel = false;
            // 
            // jalurmasukPelajaran
            // 
            this.jalurmasukPelajaran.AppearanceCell.Options.UseTextOptions = true;
            this.jalurmasukPelajaran.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.jalurmasukPelajaran.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jalurmasukPelajaran.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jalurmasukPelajaran.AppearanceHeader.Options.UseFont = true;
            this.jalurmasukPelajaran.AppearanceHeader.Options.UseTextOptions = true;
            this.jalurmasukPelajaran.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jalurmasukPelajaran.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jalurmasukPelajaran.Caption = "Jalur Masuk";
            this.jalurmasukPelajaran.FieldName = "jalurmasuk";
            this.jalurmasukPelajaran.Name = "jalurmasukPelajaran";
            this.jalurmasukPelajaran.Visible = true;
            this.jalurmasukPelajaran.VisibleIndex = 0;
            this.jalurmasukPelajaran.Width = 20;
            // 
            // repositoryItemMemoEdit3
            // 
            this.repositoryItemMemoEdit3.Name = "repositoryItemMemoEdit3";
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Items.AddRange(new object[] {
            "UMPN",
            "UMPB"});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            this.repositoryItemComboBox3.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit2.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit2.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            this.repositoryItemDateEdit2.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.labelControl1.Appearance.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl1.LineVisible = true;
            this.labelControl1.Location = new System.Drawing.Point(0, 0);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.labelControl1.Size = new System.Drawing.Size(975, 20);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Setting Akademik";
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.Controls.Add(this.labelControl7);
            this.groupControl1.Controls.Add(this.lblSemester);
            this.groupControl1.Controls.Add(this.labelControl3);
            this.groupControl1.Controls.Add(this.btnSemester1);
            this.groupControl1.Controls.Add(this.btnSemester2);
            this.groupControl1.Location = new System.Drawing.Point(3, 3);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(555, 85);
            this.groupControl1.TabIndex = 2;
            this.groupControl1.Text = "Setting Semester Aktif";
            // 
            // labelControl7
            // 
            this.labelControl7.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl7.Location = new System.Drawing.Point(244, 27);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(1, 53);
            this.labelControl7.TabIndex = 5;
            // 
            // lblSemester
            // 
            this.lblSemester.Appearance.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSemester.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblSemester.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.lblSemester.Location = new System.Drawing.Point(264, 49);
            this.lblSemester.Name = "lblSemester";
            this.lblSemester.Size = new System.Drawing.Size(283, 25);
            this.lblSemester.TabIndex = 4;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl3.Location = new System.Drawing.Point(264, 26);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(165, 17);
            this.labelControl3.TabIndex = 3;
            this.labelControl3.Text = "Semester Aktif :";
            // 
            // btnSemester1
            // 
            this.btnSemester1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSemester1.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.btnSemester1.Appearance.Options.UseFont = true;
            this.btnSemester1.Appearance.Options.UseForeColor = true;
            this.btnSemester1.Appearance.Options.UseTextOptions = true;
            this.btnSemester1.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.btnSemester1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSemester1.Location = new System.Drawing.Point(7, 26);
            this.btnSemester1.Name = "btnSemester1";
            this.btnSemester1.Size = new System.Drawing.Size(105, 50);
            this.btnSemester1.TabIndex = 1;
            this.btnSemester1.Text = "Semester Genap";
            this.btnSemester1.Click += new System.EventHandler(this.btnSemester1_Click);
            // 
            // btnSemester2
            // 
            this.btnSemester2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSemester2.Appearance.ForeColor = System.Drawing.Color.ForestGreen;
            this.btnSemester2.Appearance.Options.UseFont = true;
            this.btnSemester2.Appearance.Options.UseForeColor = true;
            this.btnSemester2.Appearance.Options.UseTextOptions = true;
            this.btnSemester2.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.btnSemester2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSemester2.Location = new System.Drawing.Point(118, 26);
            this.btnSemester2.Name = "btnSemester2";
            this.btnSemester2.Size = new System.Drawing.Size(105, 50);
            this.btnSemester2.TabIndex = 0;
            this.btnSemester2.Text = "Semester Ganjil";
            this.btnSemester2.Click += new System.EventHandler(this.btnSemester2_Click);
            // 
            // groupControl4
            // 
            this.groupControl4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupControl4.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl4.AppearanceCaption.Options.UseFont = true;
            this.groupControl4.Controls.Add(this.btnCancelPelajaran);
            this.groupControl4.Controls.Add(this.btnDelPelajaran);
            this.groupControl4.Controls.Add(this.btnEditPelajaran);
            this.groupControl4.Controls.Add(this.dgMataPelajaran);
            this.groupControl4.Location = new System.Drawing.Point(3, 3);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(499, 454);
            this.groupControl4.TabIndex = 5;
            this.groupControl4.Text = "Setting Mata Pelajaran";
            // 
            // btnCancelPelajaran
            // 
            this.btnCancelPelajaran.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancelPelajaran.Enabled = false;
            this.btnCancelPelajaran.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelPelajaran.Image")));
            this.btnCancelPelajaran.Location = new System.Drawing.Point(176, 426);
            this.btnCancelPelajaran.Name = "btnCancelPelajaran";
            this.btnCancelPelajaran.Size = new System.Drawing.Size(80, 23);
            this.btnCancelPelajaran.TabIndex = 82;
            this.btnCancelPelajaran.Text = "&End Edit";
            this.btnCancelPelajaran.Click += new System.EventHandler(this.btnCancelPelajaran_Click);
            // 
            // btnDelPelajaran
            // 
            this.btnDelPelajaran.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelPelajaran.Image = ((System.Drawing.Image)(resources.GetObject("btnDelPelajaran.Image")));
            this.btnDelPelajaran.Location = new System.Drawing.Point(97, 426);
            this.btnDelPelajaran.Name = "btnDelPelajaran";
            this.btnDelPelajaran.Size = new System.Drawing.Size(73, 23);
            this.btnDelPelajaran.TabIndex = 81;
            this.btnDelPelajaran.Text = "Hapus";
            // 
            // btnEditPelajaran
            // 
            this.btnEditPelajaran.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEditPelajaran.Image = ((System.Drawing.Image)(resources.GetObject("btnEditPelajaran.Image")));
            this.btnEditPelajaran.Location = new System.Drawing.Point(15, 426);
            this.btnEditPelajaran.Name = "btnEditPelajaran";
            this.btnEditPelajaran.Size = new System.Drawing.Size(76, 23);
            this.btnEditPelajaran.TabIndex = 80;
            this.btnEditPelajaran.Text = "Edit";
            this.btnEditPelajaran.Click += new System.EventHandler(this.btnEditPelajaran_Click);
            // 
            // groupControl2
            // 
            this.groupControl2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupControl2.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl2.AppearanceCaption.Options.UseFont = true;
            this.groupControl2.Controls.Add(this.btnAktifTahun);
            this.groupControl2.Controls.Add(this.lblTahunAjaran);
            this.groupControl2.Controls.Add(this.btnCancelBiaya);
            this.groupControl2.Controls.Add(this.btnDelBiaya);
            this.groupControl2.Controls.Add(this.btnEditBiaya);
            this.groupControl2.Controls.Add(this.dgDataTahunAjaran);
            this.groupControl2.Location = new System.Drawing.Point(3, 94);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(555, 363);
            this.groupControl2.TabIndex = 3;
            this.groupControl2.Text = "Setting Tahun Ajaran";
            // 
            // btnAktifTahun
            // 
            this.btnAktifTahun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAktifTahun.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAktifTahun.Appearance.ForeColor = System.Drawing.Color.Red;
            this.btnAktifTahun.Appearance.Options.UseFont = true;
            this.btnAktifTahun.Appearance.Options.UseForeColor = true;
            this.btnAktifTahun.Image = ((System.Drawing.Image)(resources.GetObject("btnAktifTahun.Image")));
            this.btnAktifTahun.Location = new System.Drawing.Point(5, 298);
            this.btnAktifTahun.Name = "btnAktifTahun";
            this.btnAktifTahun.Size = new System.Drawing.Size(173, 23);
            this.btnAktifTahun.TabIndex = 81;
            this.btnAktifTahun.Text = "Aktifkan Tahun Ajaran";
            this.btnAktifTahun.Click += new System.EventHandler(this.btnAktifTahun_Click);
            // 
            // lblTahunAjaran
            // 
            this.lblTahunAjaran.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTahunAjaran.Appearance.BackColor = System.Drawing.Color.White;
            this.lblTahunAjaran.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTahunAjaran.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblTahunAjaran.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.lblTahunAjaran.Location = new System.Drawing.Point(5, 327);
            this.lblTahunAjaran.Name = "lblTahunAjaran";
            this.lblTahunAjaran.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.lblTahunAjaran.Size = new System.Drawing.Size(543, 31);
            this.lblTahunAjaran.TabIndex = 80;
            this.lblTahunAjaran.Text = "Tahun Ajaran Aktif :";
            // 
            // btnCancelBiaya
            // 
            this.btnCancelBiaya.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancelBiaya.Enabled = false;
            this.btnCancelBiaya.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelBiaya.Image")));
            this.btnCancelBiaya.Location = new System.Drawing.Point(168, 269);
            this.btnCancelBiaya.Name = "btnCancelBiaya";
            this.btnCancelBiaya.Size = new System.Drawing.Size(80, 23);
            this.btnCancelBiaya.TabIndex = 79;
            this.btnCancelBiaya.Text = "&End Edit";
            this.btnCancelBiaya.Click += new System.EventHandler(this.btnCancelBiaya_Click);
            // 
            // btnDelBiaya
            // 
            this.btnDelBiaya.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelBiaya.Image = ((System.Drawing.Image)(resources.GetObject("btnDelBiaya.Image")));
            this.btnDelBiaya.Location = new System.Drawing.Point(89, 269);
            this.btnDelBiaya.Name = "btnDelBiaya";
            this.btnDelBiaya.Size = new System.Drawing.Size(73, 23);
            this.btnDelBiaya.TabIndex = 78;
            this.btnDelBiaya.Text = "Hapus";
            this.btnDelBiaya.Click += new System.EventHandler(this.btnDelBiaya_Click);
            // 
            // btnEditBiaya
            // 
            this.btnEditBiaya.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEditBiaya.Image = ((System.Drawing.Image)(resources.GetObject("btnEditBiaya.Image")));
            this.btnEditBiaya.Location = new System.Drawing.Point(7, 269);
            this.btnEditBiaya.Name = "btnEditBiaya";
            this.btnEditBiaya.Size = new System.Drawing.Size(76, 23);
            this.btnEditBiaya.TabIndex = 77;
            this.btnEditBiaya.Text = "Edit";
            this.btnEditBiaya.Click += new System.EventHandler(this.btnEditBiaya_Click);
            // 
            // dgDataTahunAjaran
            // 
            this.dgDataTahunAjaran.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgDataTahunAjaran.Location = new System.Drawing.Point(5, 24);
            this.dgDataTahunAjaran.MainView = this.gridViewDataTahun;
            this.dgDataTahunAjaran.Name = "dgDataTahunAjaran";
            this.dgDataTahunAjaran.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemComboBox1});
            this.dgDataTahunAjaran.Size = new System.Drawing.Size(545, 239);
            this.dgDataTahunAjaran.TabIndex = 3;
            this.dgDataTahunAjaran.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewDataTahun});
            // 
            // gridViewDataTahun
            // 
            this.gridViewDataTahun.Appearance.FocusedRow.BackColor = System.Drawing.Color.Transparent;
            this.gridViewDataTahun.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridViewDataTahun.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.tahunajaranid,
            this.tahunajaran,
            this.isactive});
            this.gridViewDataTahun.GridControl = this.dgDataTahunAjaran;
            this.gridViewDataTahun.Name = "gridViewDataTahun";
            this.gridViewDataTahun.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewDataTahun.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewDataTahun.OptionsBehavior.Editable = false;
            this.gridViewDataTahun.OptionsView.RowAutoHeight = true;
            this.gridViewDataTahun.OptionsView.ShowGroupPanel = false;
            this.gridViewDataTahun.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridViewDataTahun_RowStyle);
            this.gridViewDataTahun.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewDataBiaya_ValidateRow);
            // 
            // tahunajaranid
            // 
            this.tahunajaranid.Caption = "tahunajaranid";
            this.tahunajaranid.FieldName = "tahunajaranid";
            this.tahunajaranid.Name = "tahunajaranid";
            // 
            // tahunajaran
            // 
            this.tahunajaran.AppearanceCell.Options.UseTextOptions = true;
            this.tahunajaran.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tahunajaran.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tahunajaran.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tahunajaran.AppearanceHeader.Options.UseFont = true;
            this.tahunajaran.AppearanceHeader.Options.UseTextOptions = true;
            this.tahunajaran.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tahunajaran.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tahunajaran.Caption = "Tahun Ajaran";
            this.tahunajaran.FieldName = "tahunajaran";
            this.tahunajaran.Name = "tahunajaran";
            this.tahunajaran.Visible = true;
            this.tahunajaran.VisibleIndex = 0;
            this.tahunajaran.Width = 100;
            // 
            // isactive
            // 
            this.isactive.Caption = "isactive";
            this.isactive.FieldName = "isactive";
            this.isactive.Name = "isactive";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "UMPN",
            "UMPB",
            "PMDK",
            "D4",
            "PPL"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            this.repositoryItemComboBox1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // groupControl3
            // 
            this.groupControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControl3.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl3.AppearanceCaption.Options.UseFont = true;
            this.groupControl3.Controls.Add(this.btnCancelGelombang);
            this.groupControl3.Controls.Add(this.btnDelGelombang);
            this.groupControl3.Controls.Add(this.btnEditGelombang);
            this.groupControl3.Controls.Add(this.dgGelombang);
            this.groupControl3.Location = new System.Drawing.Point(564, 3);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(402, 454);
            this.groupControl3.TabIndex = 4;
            this.groupControl3.Text = "Setting Gelombang";
            // 
            // btnCancelGelombang
            // 
            this.btnCancelGelombang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancelGelombang.Enabled = false;
            this.btnCancelGelombang.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelGelombang.Image")));
            this.btnCancelGelombang.Location = new System.Drawing.Point(168, 423);
            this.btnCancelGelombang.Name = "btnCancelGelombang";
            this.btnCancelGelombang.Size = new System.Drawing.Size(80, 23);
            this.btnCancelGelombang.TabIndex = 79;
            this.btnCancelGelombang.Text = "&End Edit";
            this.btnCancelGelombang.Click += new System.EventHandler(this.btnCancelGelombang_Click);
            // 
            // btnDelGelombang
            // 
            this.btnDelGelombang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelGelombang.Image = ((System.Drawing.Image)(resources.GetObject("btnDelGelombang.Image")));
            this.btnDelGelombang.Location = new System.Drawing.Point(89, 423);
            this.btnDelGelombang.Name = "btnDelGelombang";
            this.btnDelGelombang.Size = new System.Drawing.Size(73, 23);
            this.btnDelGelombang.TabIndex = 78;
            this.btnDelGelombang.Text = "Hapus";
            // 
            // btnEditGelombang
            // 
            this.btnEditGelombang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEditGelombang.Image = ((System.Drawing.Image)(resources.GetObject("btnEditGelombang.Image")));
            this.btnEditGelombang.Location = new System.Drawing.Point(7, 423);
            this.btnEditGelombang.Name = "btnEditGelombang";
            this.btnEditGelombang.Size = new System.Drawing.Size(76, 23);
            this.btnEditGelombang.TabIndex = 77;
            this.btnEditGelombang.Text = "Edit";
            this.btnEditGelombang.Click += new System.EventHandler(this.btnEditGelombang_Click);
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 20);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(975, 488);
            this.xtraTabControl1.TabIndex = 6;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.groupControl1);
            this.xtraTabPage1.Controls.Add(this.groupControl3);
            this.xtraTabPage1.Controls.Add(this.groupControl2);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(969, 460);
            this.xtraTabPage1.Text = "Tahun dan gelombang ujian";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.groupControl5);
            this.xtraTabPage2.Controls.Add(this.groupControl4);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(969, 460);
            this.xtraTabPage2.Text = "Mata pelajaran dan publish kelulusan";
            // 
            // groupControl5
            // 
            this.groupControl5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControl5.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupControl5.AppearanceCaption.Options.UseFont = true;
            this.groupControl5.Controls.Add(this.chkPublishAll);
            this.groupControl5.Controls.Add(this.btnEndEditPublish);
            this.groupControl5.Controls.Add(this.btnEditPublish);
            this.groupControl5.Controls.Add(this.dgPublish);
            this.groupControl5.Location = new System.Drawing.Point(508, 3);
            this.groupControl5.Name = "groupControl5";
            this.groupControl5.Size = new System.Drawing.Size(458, 454);
            this.groupControl5.TabIndex = 5;
            this.groupControl5.Text = "Publish Gelombang Kelulusan";
            // 
            // chkPublishAll
            // 
            this.chkPublishAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkPublishAll.Enabled = false;
            this.chkPublishAll.Location = new System.Drawing.Point(5, 427);
            this.chkPublishAll.Name = "chkPublishAll";
            this.chkPublishAll.Properties.Caption = "Publish All";
            this.chkPublishAll.Size = new System.Drawing.Size(75, 19);
            this.chkPublishAll.TabIndex = 80;
            this.chkPublishAll.CheckedChanged += new System.EventHandler(this.chkPublishAll_CheckedChanged);
            // 
            // btnEndEditPublish
            // 
            this.btnEndEditPublish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEndEditPublish.Enabled = false;
            this.btnEndEditPublish.Image = ((System.Drawing.Image)(resources.GetObject("btnEndEditPublish.Image")));
            this.btnEndEditPublish.Location = new System.Drawing.Point(166, 426);
            this.btnEndEditPublish.Name = "btnEndEditPublish";
            this.btnEndEditPublish.Size = new System.Drawing.Size(80, 23);
            this.btnEndEditPublish.TabIndex = 79;
            this.btnEndEditPublish.Text = "&End Edit";
            this.btnEndEditPublish.Click += new System.EventHandler(this.btnEndEditPublish_Click);
            // 
            // btnEditPublish
            // 
            this.btnEditPublish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEditPublish.Image = ((System.Drawing.Image)(resources.GetObject("btnEditPublish.Image")));
            this.btnEditPublish.Location = new System.Drawing.Point(84, 426);
            this.btnEditPublish.Name = "btnEditPublish";
            this.btnEditPublish.Size = new System.Drawing.Size(76, 23);
            this.btnEditPublish.TabIndex = 77;
            this.btnEditPublish.Text = "Edit";
            this.btnEditPublish.Click += new System.EventHandler(this.btnEditPublish_Click);
            // 
            // dgPublish
            // 
            this.dgPublish.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgPublish.Location = new System.Drawing.Point(5, 24);
            this.dgPublish.MainView = this.gridViewPublish;
            this.dgPublish.Name = "dgPublish";
            this.dgPublish.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit4,
            this.repositorychkPublish,
            this.repositoryItemComboBox4,
            this.repositoryItemDateEdit3,
            this.repositoryItemTimeEdit2});
            this.dgPublish.Size = new System.Drawing.Size(448, 396);
            this.dgPublish.TabIndex = 3;
            this.dgPublish.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewPublish});
            // 
            // gridViewPublish
            // 
            this.gridViewPublish.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.publishkelulusanid,
            this.gelombangid5,
            this.jalurmasuk,
            this.jeniskelas,
            this.ispublish,
            this.gelombang5,
            this.tanggal});
            this.gridViewPublish.GridControl = this.dgPublish;
            this.gridViewPublish.GroupCount = 2;
            this.gridViewPublish.Name = "gridViewPublish";
            this.gridViewPublish.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewPublish.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewPublish.OptionsBehavior.Editable = false;
            this.gridViewPublish.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewPublish.OptionsCustomization.AllowFilter = false;
            this.gridViewPublish.OptionsCustomization.AllowGroup = false;
            this.gridViewPublish.OptionsCustomization.AllowQuickHideColumns = false;
            this.gridViewPublish.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridViewPublish.OptionsDetail.ShowDetailTabs = false;
            this.gridViewPublish.OptionsView.RowAutoHeight = true;
            this.gridViewPublish.OptionsView.ShowGroupPanel = false;
            this.gridViewPublish.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.jalurmasuk, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.jeniskelas, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridViewPublish.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridViewPublish_RowStyle);
            // 
            // publishkelulusanid
            // 
            this.publishkelulusanid.Caption = "publishkelulusanid";
            this.publishkelulusanid.FieldName = "publishkelulusanid";
            this.publishkelulusanid.Name = "publishkelulusanid";
            // 
            // gelombangid5
            // 
            this.gelombangid5.Caption = "gelombangid";
            this.gelombangid5.FieldName = "gelombangid";
            this.gelombangid5.Name = "gelombangid5";
            // 
            // jalurmasuk
            // 
            this.jalurmasuk.Caption = "Jalur Masuk";
            this.jalurmasuk.FieldName = "jalurmasuk";
            this.jalurmasuk.Name = "jalurmasuk";
            this.jalurmasuk.Visible = true;
            this.jalurmasuk.VisibleIndex = 1;
            // 
            // jeniskelas
            // 
            this.jeniskelas.Caption = "Jenis Kelas";
            this.jeniskelas.FieldName = "jeniskelas";
            this.jeniskelas.Name = "jeniskelas";
            this.jeniskelas.Visible = true;
            this.jeniskelas.VisibleIndex = 3;
            // 
            // ispublish
            // 
            this.ispublish.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.ispublish.AppearanceHeader.Options.UseFont = true;
            this.ispublish.AppearanceHeader.Options.UseTextOptions = true;
            this.ispublish.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ispublish.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.ispublish.Caption = "Publish";
            this.ispublish.ColumnEdit = this.repositorychkPublish;
            this.ispublish.FieldName = "ispublish";
            this.ispublish.MaxWidth = 90;
            this.ispublish.MinWidth = 90;
            this.ispublish.Name = "ispublish";
            this.ispublish.Visible = true;
            this.ispublish.VisibleIndex = 0;
            this.ispublish.Width = 132;
            // 
            // repositorychkPublish
            // 
            this.repositorychkPublish.AutoHeight = false;
            this.repositorychkPublish.Name = "repositorychkPublish";
            this.repositorychkPublish.EditValueChanged += new System.EventHandler(this.repositorychkPublish_EditValueChanged);
            // 
            // gelombang5
            // 
            this.gelombang5.AppearanceCell.Options.UseTextOptions = true;
            this.gelombang5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gelombang5.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gelombang5.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gelombang5.AppearanceHeader.Options.UseFont = true;
            this.gelombang5.AppearanceHeader.Options.UseTextOptions = true;
            this.gelombang5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gelombang5.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gelombang5.Caption = "Gelombang";
            this.gelombang5.FieldName = "gelombang";
            this.gelombang5.MaxWidth = 120;
            this.gelombang5.Name = "gelombang5";
            this.gelombang5.OptionsColumn.AllowEdit = false;
            this.gelombang5.Visible = true;
            this.gelombang5.VisibleIndex = 1;
            // 
            // tanggal
            // 
            this.tanggal.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tanggal.AppearanceHeader.Options.UseFont = true;
            this.tanggal.AppearanceHeader.Options.UseTextOptions = true;
            this.tanggal.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tanggal.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tanggal.Caption = "Tanggal Ujian";
            this.tanggal.DisplayFormat.FormatString = "dd MMM yyyy";
            this.tanggal.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tanggal.FieldName = "tanggal";
            this.tanggal.Name = "tanggal";
            this.tanggal.OptionsColumn.AllowEdit = false;
            this.tanggal.Visible = true;
            this.tanggal.VisibleIndex = 2;
            // 
            // repositoryItemMemoEdit4
            // 
            this.repositoryItemMemoEdit4.Name = "repositoryItemMemoEdit4";
            // 
            // repositoryItemComboBox4
            // 
            this.repositoryItemComboBox4.AutoHeight = false;
            this.repositoryItemComboBox4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox4.Items.AddRange(new object[] {
            "UMPN",
            "UMPB"});
            this.repositoryItemComboBox4.Name = "repositoryItemComboBox4";
            this.repositoryItemComboBox4.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // repositoryItemDateEdit3
            // 
            this.repositoryItemDateEdit3.AutoHeight = false;
            this.repositoryItemDateEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit3.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit3.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit3.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit3.Name = "repositoryItemDateEdit3";
            this.repositoryItemDateEdit3.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemTimeEdit2
            // 
            this.repositoryItemTimeEdit2.AutoHeight = false;
            this.repositoryItemTimeEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemTimeEdit2.Name = "repositoryItemTimeEdit2";
            // 
            // ucAkademikSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.labelControl1);
            this.Name = "ucAkademikSetting";
            this.Size = new System.Drawing.Size(975, 508);
            this.Load += new System.EventHandler(this.ucAkademikSetting_Load);
            this.Leave += new System.EventHandler(this.ucUtility_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgGelombang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMataPelajaran1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgMataPelajaran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMataPelajaran2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDataTahunAjaran)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDataTahun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).EndInit();
            this.groupControl5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkPublishAll.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPublish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPublish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositorychkPublish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEdit2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnSemester2;
        private DevExpress.XtraEditors.SimpleButton btnSemester1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl lblSemester;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.GridControl dgDataTahunAjaran;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDataTahun;
        private DevExpress.XtraGrid.Columns.GridColumn tahunajaranid;
        private DevExpress.XtraGrid.Columns.GridColumn tahunajaran;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        public DevExpress.XtraEditors.SimpleButton btnDelBiaya;
        public DevExpress.XtraEditors.SimpleButton btnEditBiaya;
        public DevExpress.XtraEditors.SimpleButton btnCancelBiaya;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        public DevExpress.XtraEditors.SimpleButton btnCancelGelombang;
        public DevExpress.XtraEditors.SimpleButton btnDelGelombang;
        public DevExpress.XtraEditors.SimpleButton btnEditGelombang;
        private DevExpress.XtraGrid.GridControl dgGelombang;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMaster;
        private DevExpress.XtraGrid.Columns.GridColumn jalurmasukG1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDetail;
        private DevExpress.XtraGrid.Columns.GridColumn gelombangid;
        private DevExpress.XtraGrid.Columns.GridColumn jalurmasukG2;
        private DevExpress.XtraGrid.Columns.GridColumn gelombang;
        private DevExpress.XtraGrid.Columns.GridColumn reguler;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn karyawan;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        public DevExpress.XtraEditors.SimpleButton btnCancelPelajaran;
        public DevExpress.XtraEditors.SimpleButton btnDelPelajaran;
        public DevExpress.XtraEditors.SimpleButton btnEditPelajaran;
        private DevExpress.XtraGrid.GridControl dgMataPelajaran;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMataPelajaran1;
        private DevExpress.XtraGrid.Columns.GridColumn matapelajaranid;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn kodePelajaran;
        private DevExpress.XtraGrid.Columns.GridColumn namaPelajaran;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMataPelajaran2;
        private DevExpress.XtraGrid.Columns.GridColumn jalurmasukPelajaran;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraEditors.LabelControl lblTahunAjaran;
        public DevExpress.XtraEditors.SimpleButton btnAktifTahun;
        private DevExpress.XtraGrid.Columns.GridColumn isactive;
        private DevExpress.XtraGrid.Columns.GridColumn jamujian;
        private DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit repositoryItemTimeEdit1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraEditors.GroupControl groupControl5;
        public DevExpress.XtraEditors.SimpleButton btnEndEditPublish;
        public DevExpress.XtraEditors.SimpleButton btnEditPublish;
        private DevExpress.XtraGrid.GridControl dgPublish;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit repositoryItemTimeEdit2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewPublish;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit4;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositorychkPublish;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox4;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.CheckEdit chkPublishAll;
        private DevExpress.XtraGrid.Columns.GridColumn publishkelulusanid;
        private DevExpress.XtraGrid.Columns.GridColumn gelombangid5;
        private DevExpress.XtraGrid.Columns.GridColumn jalurmasuk;
        private DevExpress.XtraGrid.Columns.GridColumn jeniskelas;
        private DevExpress.XtraGrid.Columns.GridColumn ispublish;
        private DevExpress.XtraGrid.Columns.GridColumn gelombang5;
        private DevExpress.XtraGrid.Columns.GridColumn tanggal;
    }
}
