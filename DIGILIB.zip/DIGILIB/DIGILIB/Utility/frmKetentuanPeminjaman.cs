﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.Utils;
using Npgsql;

namespace DIGILIB.Utility.Perpus
{
    public partial class frmKetentuanPeminjaman : DevExpress.XtraEditors.XtraForm
    {
        public frmKetentuanPeminjaman()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        public string strID = "";

        WaitDialogForm loadDialog;

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null || loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void frmSlipGaji_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                setLoadDialog(true, "Saving Data...");
                try
                {
                    clstblketentuanpeminjaman oketentuanpeminjaman = new clstblketentuanpeminjaman();
                    oConn.Open();
                    oketentuanpeminjaman.Koneksi = oConn.Conn;
                    string sql = "select ketentuanpeminjamanid from tblketentuanpeminjaman where dlt='0'";
                    oketentuanpeminjaman.ketentuanpeminjamanid = clsGlobal.getData1Field(sql);
                    if (!string.IsNullOrEmpty(oketentuanpeminjaman.ketentuanpeminjamanid))
                    {
                        oketentuanpeminjaman.GetByPrimaryKey(oketentuanpeminjaman.ketentuanpeminjamanid);
                    }
                    oketentuanpeminjaman.lamapeminjaman = clsGlobal.GetParseDecimal(txtlamapeminjaman.Text);
                    oketentuanpeminjaman.dendaperhari = clsGlobal.GetParseDecimal(txtdendaperhari.Text);
                    oketentuanpeminjaman.maksbukudipinjam = clsGlobal.GetParseDecimal(txtmaksbukudipinjam.Text);
                    oketentuanpeminjaman.ketentuanpeminjaman = "";
                    oketentuanpeminjaman.op = clsGlobal.strUserName;
                    oketentuanpeminjaman.pc = clsGlobal.strComputerName();
                    oketentuanpeminjaman.dlt = false;
                    if (string.IsNullOrEmpty(oketentuanpeminjaman.ketentuanpeminjamanid))
                    {
                        oketentuanpeminjaman.ketentuanpeminjamanid = oketentuanpeminjaman.NewID();
                        oketentuanpeminjaman.Insert();
                    }
                    else
                    {
                        oketentuanpeminjaman.Update();
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                setLoadDialog(false, "");
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
        }

        private void frmSlipGaji_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void loadData()
        {
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                setLoadDialog(true, "Loading Data...");
                try
                {
                    clsRepository oRepository = new clsRepository();
                    DataTable dtKetentuanPeminjaman = oRepository.GetDataKetentuanPeminjaman();
                    if (dtKetentuanPeminjaman != null && dtKetentuanPeminjaman.Rows.Count > 0)
                    {
                        txtlamapeminjaman.Text = Convert.ToString(dtKetentuanPeminjaman.Rows[0]["lamapeminjaman"]);
                        txtdendaperhari.Text = Convert.ToString(dtKetentuanPeminjaman.Rows[0]["dendaperhari"]);
                        txtmaksbukudipinjam.Text = Convert.ToString(dtKetentuanPeminjaman.Rows[0]["maksbukudipinjam"]);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }

                setLoadDialog(false, "");
            }
        }

        private void frmSlipGaji_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }


    }
}
