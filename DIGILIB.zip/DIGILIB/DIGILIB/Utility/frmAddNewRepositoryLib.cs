﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Library;
using DevExpress.Utils;
using Npgsql;

namespace DIGILIB
{
    public partial class frmAddNewRepositoryLib : DevExpress.XtraEditors.XtraForm
    {
        WaitDialogForm loadDialog;
        string m_tablename;
        string m_pkey;
        string m_fieldname;
        public String table_name
        {
            get { return m_tablename; }
            set { m_tablename = value; }
        }
        public String pkey
        {
            get { return m_pkey; }
            set { m_pkey = value; }
        }
        public String fieldname
        {
            get { return m_fieldname; }
            set { m_fieldname = value; }
        }
        public frmAddNewRepositoryLib()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void btnCreateNew_Click(object sender, EventArgs e)
        {
            btnEndEdit.Enabled = true;
            btnDelete.Enabled = false;
            btnEdit.Enabled = false;
            gridViewData.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            gridViewData.OptionsBehavior.Editable = true;
        }

        private void loadData()
        {
            if (fieldname == "" || fieldname == null || pkey == "" || pkey == null || table_name == "" || table_name == null)
                return;
            setLoadDialog(true, "Loading Data Trade...");
            try
            {
                using (clsConnection oConn = new clsConnection())
                {
                    string strSql = @"select " + pkey + @" as pkid, " + fieldname + @" as description 
                                from " + table_name + " where dlt='0' order by " + fieldname;
                    DataTable dt = oConn.GetData(strSql);
                    oConn.Close();
                    dgData.DataSource = dt;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            setLoadDialog(false, "");
        }

        private void btnEndEdit_Click(object sender, EventArgs e)
        {
            btnEndEdit.Enabled = false;
            btnDelete.Enabled = clsGlobal.bolDelete;
            btnEdit.Enabled = (clsGlobal.bolAdd || clsGlobal.bolEdit);
            gridViewData.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.None;
            gridViewData.OptionsBehavior.Editable = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(description)) != "")
            {
                if (XtraMessageBox.Show("Apakah Anda yakin ingin menghapus data yang dipilih?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    using (clsConnection oConn = new clsConnection())
                    {
                        if (gridViewData.SelectedRowsCount == 0)
                        {
                            gridViewData.SelectRow(gridViewData.FocusedRowHandle);
                            gridViewData.MakeRowVisible(gridViewData.FocusedRowHandle, false);
                        }
                        int[] arrSelectedRows = gridViewData.GetSelectedRows();
                        for (int i = 0; i < arrSelectedRows.Length; i++)
                        {
                            if (table_name.ToLower() == "tbp_modul_lib")
                            {
                                #region
                                string[] strConstraintTable = { "tbp_pembuatmodul" };
                                string strExistConstraint = "";
                                clstbp_modul_lib oobject = new clstbp_modul_lib();


                                if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                                oobject.Koneksi = oConn.Conn;
                                oobject.modul_libid = (Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                                if (clsGlobal.cekConstraint(pkey, oobject.modul_libid, strConstraintTable, ref strExistConstraint))
                                {
                                    string sDesc = Convert.ToString(gridViewData.GetRowCellValue(arrSelectedRows[i], description));
                                    //if (strExistConstraint == "") 
                                    strExistConstraint = "prosess yang lain";
                                    XtraMessageBox.Show("Modul [" + sDesc + "] tidak bisa dihapus, data ini sudah dipakai " + strExistConstraint, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    gridViewData.UnselectRow(arrSelectedRows[i]);
                                    continue;
                                }
                                else
                                {
                                    if (oobject.SoftDelete())
                                    {

                                    }
                                }
                                #endregion
                            }
                            else if (table_name.ToLower() == "tbp_jenisujian")
                            {
                                #region
                                string[] strConstraintTable = { "tbp_pembuatmodul" };
                                string strExistConstraint = "";
                                clstbp_jenisujian oobject = new clstbp_jenisujian();


                                if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                                oobject.Koneksi = oConn.Conn;
                                oobject.jenisujianid = (Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                                if (clsGlobal.cekConstraint(pkey, oobject.jenisujianid, strConstraintTable, ref strExistConstraint))
                                {
                                    string sDesc = Convert.ToString(gridViewData.GetRowCellValue(arrSelectedRows[i], description));
                                    //if (strExistConstraint == "") 
                                    strExistConstraint = "prosess yang lain";
                                    XtraMessageBox.Show("Data ini [" + sDesc + "] tidak bisa dihapus, data ini sudah dipakai " + strExistConstraint, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    gridViewData.UnselectRow(arrSelectedRows[i]);
                                    continue;
                                }
                                else
                                {
                                    if (oobject.SoftDelete())
                                    {

                                    }
                                }
                                #endregion
                            }
                            else if (table_name.ToLower() == "tbp_program")
                            {
                                #region
                                string[] strConstraintTable = { "tbp_kehadirandosen", "tbp_tarif_honor" };
                                string strExistConstraint = "";
                                clstbp_program oobject = new clstbp_program();


                                if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                                oobject.Koneksi = oConn.Conn;
                                oobject.programid = (Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                                if (clsGlobal.cekConstraint("program", oobject.programid, strConstraintTable, ref strExistConstraint))
                                {
                                    string sDesc = Convert.ToString(gridViewData.GetRowCellValue(arrSelectedRows[i], description));
                                    //if (strExistConstraint == "") 
                                    strExistConstraint = "prosess yang lain";
                                    XtraMessageBox.Show("Data ini [" + sDesc + "] tidak bisa dihapus, data ini sudah dipakai " + strExistConstraint, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    gridViewData.UnselectRow(arrSelectedRows[i]);
                                    continue;
                                }
                                else
                                {
                                    if (oobject.SoftDelete())
                                    {

                                    }
                                }
                                #endregion
                            }
                            else if (table_name.ToLower() == "tbp_jenisbahanajar")
                            {
                                #region
                                string[] strConstraintTable = { "tbp_pembuatbahanajar" };
                                string strExistConstraint = "";
                                clstbp_jenisbahanajar oobject = new clstbp_jenisbahanajar();


                                if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                                oobject.Koneksi = oConn.Conn;
                                oobject.jenisbahanajarid = (Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                                if (clsGlobal.cekConstraint(pkey, oobject.jenisbahanajarid, strConstraintTable, ref strExistConstraint))
                                {
                                    string sDesc = Convert.ToString(gridViewData.GetRowCellValue(arrSelectedRows[i], description));
                                    //if (strExistConstraint == "") 
                                    strExistConstraint = "prosess yang lain";
                                    XtraMessageBox.Show("Data ini [" + sDesc + "] tidak bisa dihapus, data ini sudah dipakai " + strExistConstraint, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    gridViewData.UnselectRow(arrSelectedRows[i]);
                                    continue;
                                }
                                else
                                {
                                    if (oobject.SoftDelete())
                                    {

                                    }
                                }
                                #endregion
                            }
                            gridViewData.DeleteSelectedRows();
                        }
                    }
                    loadData();
                }
            }
        }

        private void frmAddNewRepositoryLib_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void gridViewData_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {

            if (pkey == "" || pkey == null || table_name == "" || table_name == null)
                return;
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(description)) == "")
                return;


            string sql = "select count(" + fieldname + ") as description from " + table_name + " where dlt='0' and lower(" + fieldname + ")=lower(@description) ";
            NpgsqlCommand pgcmd = new NpgsqlCommand(sql);
            pgcmd.Parameters.Add("@description", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Convert.ToString(gridViewData.GetFocusedRowCellValue(description));

            if (Convert.ToInt32(clsGlobal.getData1Field(pgcmd)) >= 1)
            {
                string strMsg = "Data ini [" + Convert.ToString(gridViewData.GetFocusedRowCellValue(description)) + "] sudah ada di database, sistem tidak bisa menyimpan data yang sama.\n";
                e.Valid = false;
                e.ErrorText = strMsg;
                //gridViewData.SetColumnError(tradedesc, "The value must be unique");
                return;
            }
            if (table_name.ToLower() == "tbp_modul_lib")
            {
                #region
                using (clsConnection oConn = new clsConnection())
                {
                    clstbp_modul_lib oObject = new clstbp_modul_lib();
                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                    oObject.deskripsi = Convert.ToString(gridViewData.GetFocusedRowCellValue(description));
                    oObject.tahunajaranid = clsGlobal.str_Tahun;
                    oObject.dlt = false;
                    if (Convert.ToString(oObject.modul_libid) == "" || oObject.modul_libid == null)
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.modul_libid = oObject.NewID();
                        oObject.Insert();
                        gridViewData.SetRowCellValue(e.RowHandle, pkid, oObject.modul_libid);
                    }
                    else
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.Update();
                    }
                    oObject = null;
                }
                #endregion
            }
            else if (table_name.ToLower() == "tbp_jenisujian")
            {
                #region
                using (clsConnection oConn = new clsConnection())
                {
                    clstbp_jenisujian oObject = new clstbp_jenisujian();
                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                    oObject.deskripsi = Convert.ToString(gridViewData.GetFocusedRowCellValue(description));
                    oObject.tahunajaranid = clsGlobal.str_Tahun;
                    oObject.dlt = false;
                    if (Convert.ToString(oObject.jenisujianid) == "" || oObject.jenisujianid == null)
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.jenisujianid = oObject.NewID();
                        oObject.Insert();
                        gridViewData.SetRowCellValue(e.RowHandle, pkid, oObject.jenisujianid);
                    }
                    else
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.Update();
                    }
                    oObject = null;
                }
                #endregion
            }
            else if (table_name.ToLower() == "tbp_program")
            {
                #region
                using (clsConnection oConn = new clsConnection())
                {
                    clstbp_program oObject = new clstbp_program();
                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                    oObject.namaprogram = Convert.ToString(gridViewData.GetFocusedRowCellValue(description));
                    oObject.tahunajaranid = clsGlobal.str_Tahun;
                    oObject.dlt = false;
                    if (Convert.ToString(oObject.programid) == "" || oObject.programid == null)
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.programid = oObject.NewID();
                        oObject.Insert();
                        gridViewData.SetRowCellValue(e.RowHandle, pkid, oObject.programid);
                    }
                    else
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.Update();
                    }
                    oObject = null;
                }
                #endregion
            }
            else if (table_name.ToLower() == "tbp_jenisbahanajar")
            {
                #region
                using (clsConnection oConn = new clsConnection())
                {
                    clstbp_jenisbahanajar oObject = new clstbp_jenisbahanajar();
                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(Convert.ToString(gridViewData.GetFocusedRowCellValue(pkid)));
                    oObject.deskripsi = Convert.ToString(gridViewData.GetFocusedRowCellValue(description));
                    oObject.tahunajaranid = clsGlobal.str_Tahun;
                    oObject.dlt = false;
                    if (Convert.ToString(oObject.jenisbahanajarid) == "" || oObject.jenisbahanajarid == null)
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.jenisbahanajarid = oObject.NewID();
                        oObject.Insert();
                        gridViewData.SetRowCellValue(e.RowHandle, pkid, oObject.jenisbahanajarid);
                    }
                    else
                    {
                        oObject.op_add = clsGlobal.strUserName;
                        oObject.pc_add = SystemInformation.ComputerName;
                        oObject.Update();
                    }
                    oObject = null;
                }
                #endregion
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gridViewData_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            try
            {
                //int currentRow = gridViewData.FocusedRowHandle;
                //if (gridViewData.FocusedColumn.Name == description.FieldName)
                //{
                //    string strade = Convert.ToString(e.Value);

                //    string smaterialtype = Convert.ToString(gridViewData.GetRowCellValue(gridViewData.FocusedRowHandle, description));
                //    if (strade == "")
                //    {
                //        string strMsg = "Trade can't be empty.\n";
                //        e.Valid = false;
                //        e.ErrorText = strMsg;

                //        return;
                //    }
                //    else
                //    {

                //    }
                //}
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }
    }
}