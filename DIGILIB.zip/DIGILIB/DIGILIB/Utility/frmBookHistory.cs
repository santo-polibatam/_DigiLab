﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Library;
using ReaderA;
using Npgsql;
using DevExpress.Utils;

namespace DIGILIB.Utility
{
    public partial class frmBookHistory : DevExpress.XtraEditors.XtraForm
    {
        WaitDialogForm loadDialog;
        public frmBookHistory()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void loadData(string strRFID)
        {
            timerScan.Enabled = false;
            lblRFID.Text = strRFID;
            setLoadDialog(true, "Loading data...");
            clsConnection oconn = new clsConnection();
            try
            {
                string strSql = @"select pm.peminjamanid, pm.nopeminjaman, pm.tglpinjam, pm.tgljatuhtempo, pm.status, pm.keterangan,
                                pm.lamapeminjaman, pm.dendaperhari, pm.maksbukudipinjam,
                                ag.anggotaid, ag.rfid as rfidanggota, ag.nim as nimanggota, ag.nama as namaanggota, ag.photo, ag.alamat, ag.jenis, ag.statusaktif,
                                peg.anggotaid as petugasid, peg.nim as nik, peg.nama as namapetugas, peg.nama||' - ' || peg.nim as petugas, peg.photo as photopetugas,
                                kem.pengembalianid, kem.pengembaliandetailsid, kem.nopengembalian, kem.tglkembali, kem.jumlahdenda, kem.dendadibayar,
                                inv.nib, bu.kodepanggil, bu.judul
                                from tblpeminjaman pm 
                                left outer join tbm_anggota ag on ag.anggotaid=pm.anggotaid and ag.dlt='0'
                                left outer join tbm_anggota peg on peg.anggotaid=pm.petugasid and peg.dlt='0'
                                inner join tblpeminjamandetails det on pm.peminjamanid=det.peminjamanid and det.dlt='0'
                                inner join tbm_inventaris inv on det.inventarisid=inv.inventarisid and inv.dlt='0'
                                inner join tbm_buku bu on bu.bukuid=inv.bukuid and bu.dlt='0'
                                left outer join 
                                (
	                                select a.pengembalianid, b.pengembaliandetailsid, b.peminjamandetailsid, a.nopengembalian, b.tglkembali, b.jumlahdenda, b.dendadibayar
	                                from tblpengembalian a
	                                inner join tblpengembaliandetails b on a.pengembalianid=b.pengembalianid and b.dlt='0'
	                                where a.dlt='0'
                                ) kem on det.peminjamandetailsid=kem.peminjamandetailsid
                                where pm.dlt='0' and inv.rfid='" + strRFID + @"'
                                order by pm.tglpinjam desc;";
                DataTable dtData=oconn.GetData(strSql);
                dgData.DataSource = dtData;
                if (dtData.Rows.Count > 0)
                {
                    lblNIB.Text = dtData.Rows[0]["nib"] + "";
                    lblBibli.Text = dtData.Rows[0]["kodepanggil"] + "";
                    lblJudul.Text = dtData.Rows[0]["judul"] + "";
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                oconn.Close();
                oconn = null;
                setLoadDialog(false, "");
            }
            btnScan.Enabled = true;
            closePort();
        }

        private void timerScan_Tick(object sender, EventArgs e)
        {
            try
            {
                byte state = 0;
                byte AFI = 0;
                byte[] DSFIDAndUID = new byte[9];
                byte cardNumber = 0;
                string strDSFIDAndUID = "";

                int fCmdRetInv = StaticClassReaderA.Inventory(ref clsGlobal.comAddr, ref state, ref AFI, DSFIDAndUID, ref cardNumber, clsGlobal.portIndex);

                if (fCmdRetInv == 0)
                {
                    strDSFIDAndUID = clsGlobal.ByteArrayToHexString(DSFIDAndUID).Replace(" ", "");
                    if (strDSFIDAndUID != "")
                    {
                        loadData(strDSFIDAndUID);
                        panelControl1.Visible = false;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        private void openPort()
        {
            if (Convert.ToDecimal(clsGlobal.portIndex) == -1)
            {
                clsGlobal.fCmdRet = StaticClassReaderA.AutoOpenComPort(ref clsGlobal.portNumber, ref clsGlobal.comAddr, clsGlobal.baud, ref clsGlobal.portIndex);
            }
        }

        private void closePort()
        {
            if (Convert.ToDecimal(clsGlobal.portIndex) != -1)
            {
                clsGlobal.fCmdRet = StaticClassReaderA.CloseSpecComPort(clsGlobal.portIndex);
                clsGlobal.portIndex = -1;
            }
        }

        private void frmBookHistory_Load(object sender, EventArgs e)
        {
            openPort();
            timerScan.Enabled = true;
        }

        private void frmBookHistory_Leave(object sender, EventArgs e)
        {
            closePort();
            timerScan.Enabled = false;
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            panelControl1.Visible = true;
            dgData.DataSource = null;
            lblRFID.Text = "";
            lblBibli.Text = "";
            lblJudul.Text = "";
            lblNIB.Text = "";
            openPort();
            timerScan.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmBookHistory_Leave(null, null);
            this.Close();
        }
    }
}