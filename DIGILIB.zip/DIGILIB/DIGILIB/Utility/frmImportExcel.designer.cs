﻿namespace DIGILIB
{
    partial class frmImportExcel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmImportExcel));
            this.gcNewData = new DevExpress.XtraGrid.GridControl();
            this.gridViewNewData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gcFailedList = new DevExpress.XtraGrid.GridControl();
            this.gridViewFailedList = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gcExistingData = new DevExpress.XtraGrid.GridControl();
            this.gridViewExistingData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.tabReview = new DevExpress.XtraTab.XtraTabPage();
            this.radioGroup1 = new DevExpress.XtraEditors.RadioGroup();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.chkSelectNewData = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnInsertToDatabase = new DevExpress.XtraEditors.SimpleButton();
            this.btnGetExcelData = new DevExpress.XtraEditors.SimpleButton();
            this.chkSelectAllExisting = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.btnExportToXls = new DevExpress.XtraEditors.SimpleButton();
            this.btnUpdateToDatabase = new DevExpress.XtraEditors.SimpleButton();
            this.tabFailedToImport = new DevExpress.XtraTab.XtraTabPage();
            this.btnfailExportToXls = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            ((System.ComponentModel.ISupportInitialize)(this.gcNewData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewNewData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcFailedList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewFailedList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcExistingData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewExistingData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.tabReview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelectNewData.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelectAllExisting.Properties)).BeginInit();
            this.tabFailedToImport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gcNewData
            // 
            this.gcNewData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gcNewData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gcNewData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcNewData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcNewData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcNewData.Location = new System.Drawing.Point(3, 31);
            this.gcNewData.MainView = this.gridViewNewData;
            this.gcNewData.Name = "gcNewData";
            this.gcNewData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1});
            this.gcNewData.Size = new System.Drawing.Size(540, 325);
            this.gcNewData.TabIndex = 0;
            this.gcNewData.UseEmbeddedNavigator = true;
            this.gcNewData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewNewData});
            // 
            // gridViewNewData
            // 
            this.gridViewNewData.Appearance.EvenRow.BackColor = System.Drawing.Color.DarkOrange;
            this.gridViewNewData.Appearance.EvenRow.BackColor2 = System.Drawing.Color.Gold;
            this.gridViewNewData.Appearance.EvenRow.ForeColor = System.Drawing.Color.White;
            this.gridViewNewData.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridViewNewData.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridViewNewData.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridViewNewData.GridControl = this.gcNewData;
            this.gridViewNewData.Name = "gridViewNewData";
            this.gridViewNewData.OptionsCustomization.AllowSort = false;
            this.gridViewNewData.OptionsFind.AlwaysVisible = true;
            this.gridViewNewData.OptionsView.ColumnAutoWidth = false;
            this.gridViewNewData.RowCountChanged += new System.EventHandler(this.gridViewNewData_RowCountChanged);
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.QueryCheckStateByValue += new DevExpress.XtraEditors.Controls.QueryCheckStateByValueEventHandler(this.repositoryItemCheckEdit1_QueryCheckStateByValue);
            // 
            // gcFailedList
            // 
            this.gcFailedList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gcFailedList.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gcFailedList.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcFailedList.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcFailedList.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcFailedList.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gcFailedList.Location = new System.Drawing.Point(11, 47);
            this.gcFailedList.MainView = this.gridViewFailedList;
            this.gcFailedList.Name = "gcFailedList";
            this.gcFailedList.Size = new System.Drawing.Size(1083, 358);
            this.gcFailedList.TabIndex = 1;
            this.gcFailedList.UseEmbeddedNavigator = true;
            this.gcFailedList.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewFailedList});
            // 
            // gridViewFailedList
            // 
            this.gridViewFailedList.GridControl = this.gcFailedList;
            this.gridViewFailedList.Name = "gridViewFailedList";
            this.gridViewFailedList.OptionsBehavior.Editable = false;
            this.gridViewFailedList.OptionsView.ColumnAutoWidth = false;
            // 
            // gcExistingData
            // 
            this.gcExistingData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gcExistingData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gcExistingData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcExistingData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcExistingData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcExistingData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gcExistingData.Location = new System.Drawing.Point(4, 31);
            this.gcExistingData.MainView = this.gridViewExistingData;
            this.gcExistingData.Name = "gcExistingData";
            this.gcExistingData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2});
            this.gcExistingData.Size = new System.Drawing.Size(532, 325);
            this.gcExistingData.TabIndex = 2;
            this.gcExistingData.UseEmbeddedNavigator = true;
            this.gcExistingData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewExistingData});
            // 
            // gridViewExistingData
            // 
            this.gridViewExistingData.GridControl = this.gcExistingData;
            this.gridViewExistingData.Name = "gridViewExistingData";
            this.gridViewExistingData.OptionsBehavior.Editable = false;
            this.gridViewExistingData.OptionsFind.AlwaysVisible = true;
            this.gridViewExistingData.OptionsView.ColumnAutoWidth = false;
            this.gridViewExistingData.RowCountChanged += new System.EventHandler(this.gridViewExistingData_RowCountChanged);
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.QueryCheckStateByValue += new DevExpress.XtraEditors.Controls.QueryCheckStateByValueEventHandler(this.repositoryItemCheckEdit1_QueryCheckStateByValue);
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold);
            this.xtraTabControl1.Appearance.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.Header.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold);
            this.xtraTabControl1.AppearancePage.Header.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.xtraTabControl1.AppearancePage.HeaderActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.xtraTabControl1.AppearancePage.HeaderActive.Font = new System.Drawing.Font("Trebuchet MS", 9.5F, System.Drawing.FontStyle.Bold);
            this.xtraTabControl1.AppearancePage.HeaderActive.ForeColor = System.Drawing.Color.Blue;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseBackColor = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseForeColor = true;
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 92);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.tabReview;
            this.xtraTabControl1.Size = new System.Drawing.Size(1107, 495);
            this.xtraTabControl1.TabIndex = 3;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.tabReview,
            this.tabFailedToImport});
            // 
            // tabReview
            // 
            this.tabReview.Appearance.PageClient.BackColor = System.Drawing.Color.Black;
            this.tabReview.Appearance.PageClient.Options.UseBackColor = true;
            this.tabReview.Controls.Add(this.radioGroup1);
            this.tabReview.Controls.Add(this.splitContainerControl1);
            this.tabReview.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.tabReview.Name = "tabReview";
            this.tabReview.Size = new System.Drawing.Size(1101, 462);
            this.tabReview.Text = "Review Data";
            // 
            // radioGroup1
            // 
            this.radioGroup1.AllowHtmlTextInToolTip = DevExpress.Utils.DefaultBoolean.True;
            this.radioGroup1.Location = new System.Drawing.Point(5, 16);
            this.radioGroup1.Name = "radioGroup1";
            this.radioGroup1.Properties.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Bold);
            this.radioGroup1.Properties.Appearance.ForeColor = System.Drawing.Color.MediumBlue;
            this.radioGroup1.Properties.Appearance.Options.UseFont = true;
            this.radioGroup1.Properties.Appearance.Options.UseForeColor = true;
            this.radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Buku", "Buku")});
            this.radioGroup1.Size = new System.Drawing.Size(1089, 27);
            this.radioGroup1.TabIndex = 4;
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainerControl1.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 49);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.btnClose);
            this.splitContainerControl1.Panel1.Controls.Add(this.chkSelectNewData);
            this.splitContainerControl1.Panel1.Controls.Add(this.labelControl1);
            this.splitContainerControl1.Panel1.Controls.Add(this.btnInsertToDatabase);
            this.splitContainerControl1.Panel1.Controls.Add(this.btnGetExcelData);
            this.splitContainerControl1.Panel1.Controls.Add(this.gcNewData);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.chkSelectAllExisting);
            this.splitContainerControl1.Panel2.Controls.Add(this.labelControl2);
            this.splitContainerControl1.Panel2.Controls.Add(this.btnExportToXls);
            this.splitContainerControl1.Panel2.Controls.Add(this.btnUpdateToDatabase);
            this.splitContainerControl1.Panel2.Controls.Add(this.gcExistingData);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1105, 415);
            this.splitContainerControl1.SplitterPosition = 552;
            this.splitContainerControl1.TabIndex = 3;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(414, 371);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(78, 37);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // chkSelectNewData
            // 
            this.chkSelectNewData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkSelectNewData.Location = new System.Drawing.Point(13, 383);
            this.chkSelectNewData.Name = "chkSelectNewData";
            this.chkSelectNewData.Properties.Caption = "Select All";
            this.chkSelectNewData.Size = new System.Drawing.Size(75, 19);
            this.chkSelectNewData.TabIndex = 7;
            this.chkSelectNewData.CheckedChanged += new System.EventHandler(this.chkSelectNewData_CheckedChanged);
            // 
            // labelControl1
            // 
            this.labelControl1.AllowHtmlString = true;
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.MediumBlue;
            this.labelControl1.Location = new System.Drawing.Point(5, 6);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(117, 24);
            this.labelControl1.TabIndex = 6;
            this.labelControl1.Text = "New Records";
            // 
            // btnInsertToDatabase
            // 
            this.btnInsertToDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnInsertToDatabase.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnInsertToDatabase.Appearance.Options.UseFont = true;
            this.btnInsertToDatabase.Image = ((System.Drawing.Image)(resources.GetObject("btnInsertToDatabase.Image")));
            this.btnInsertToDatabase.Location = new System.Drawing.Point(238, 371);
            this.btnInsertToDatabase.Name = "btnInsertToDatabase";
            this.btnInsertToDatabase.Size = new System.Drawing.Size(170, 37);
            this.btnInsertToDatabase.TabIndex = 5;
            this.btnInsertToDatabase.Text = "Insert To Database";
            this.btnInsertToDatabase.Click += new System.EventHandler(this.btnImportToDatabase_Click);
            // 
            // btnGetExcelData
            // 
            this.btnGetExcelData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGetExcelData.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnGetExcelData.Appearance.Options.UseFont = true;
            this.btnGetExcelData.Image = ((System.Drawing.Image)(resources.GetObject("btnGetExcelData.Image")));
            this.btnGetExcelData.Location = new System.Drawing.Point(95, 371);
            this.btnGetExcelData.Name = "btnGetExcelData";
            this.btnGetExcelData.Size = new System.Drawing.Size(137, 37);
            this.btnGetExcelData.TabIndex = 4;
            this.btnGetExcelData.Text = "Open Excel File";
            this.btnGetExcelData.Click += new System.EventHandler(this.btnGetExcelData_Click);
            // 
            // chkSelectAllExisting
            // 
            this.chkSelectAllExisting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkSelectAllExisting.Location = new System.Drawing.Point(4, 383);
            this.chkSelectAllExisting.Name = "chkSelectAllExisting";
            this.chkSelectAllExisting.Properties.Caption = "Select All";
            this.chkSelectAllExisting.Size = new System.Drawing.Size(75, 19);
            this.chkSelectAllExisting.TabIndex = 9;
            this.chkSelectAllExisting.Visible = false;
            this.chkSelectAllExisting.CheckedChanged += new System.EventHandler(this.chkSelectAllExisting_CheckedChanged);
            // 
            // labelControl2
            // 
            this.labelControl2.AllowHtmlString = true;
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DarkOrange;
            this.labelControl2.Location = new System.Drawing.Point(3, 6);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(256, 24);
            this.labelControl2.TabIndex = 8;
            this.labelControl2.Text = "<b>Existing Records In Database</b>";
            // 
            // btnExportToXls
            // 
            this.btnExportToXls.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExportToXls.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExportToXls.Appearance.Options.UseFont = true;
            this.btnExportToXls.Image = global::DIGILIB.Properties.Resources.export_excel_icon;
            this.btnExportToXls.Location = new System.Drawing.Point(269, 371);
            this.btnExportToXls.Name = "btnExportToXls";
            this.btnExportToXls.Size = new System.Drawing.Size(133, 37);
            this.btnExportToXls.TabIndex = 7;
            this.btnExportToXls.Text = "Export To Xls";
            this.btnExportToXls.Click += new System.EventHandler(this.btnExportToXls_Click);
            // 
            // btnUpdateToDatabase
            // 
            this.btnUpdateToDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnUpdateToDatabase.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnUpdateToDatabase.Appearance.Options.UseFont = true;
            this.btnUpdateToDatabase.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdateToDatabase.Image")));
            this.btnUpdateToDatabase.Location = new System.Drawing.Point(85, 371);
            this.btnUpdateToDatabase.Name = "btnUpdateToDatabase";
            this.btnUpdateToDatabase.Size = new System.Drawing.Size(174, 37);
            this.btnUpdateToDatabase.TabIndex = 6;
            this.btnUpdateToDatabase.Text = "Update To Database";
            this.btnUpdateToDatabase.Click += new System.EventHandler(this.btnUpdateToDatabase_Click);
            // 
            // tabFailedToImport
            // 
            this.tabFailedToImport.Controls.Add(this.btnfailExportToXls);
            this.tabFailedToImport.Controls.Add(this.labelControl3);
            this.tabFailedToImport.Controls.Add(this.gcFailedList);
            this.tabFailedToImport.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabFailedToImport.Name = "tabFailedToImport";
            this.tabFailedToImport.Size = new System.Drawing.Size(1101, 462);
            this.tabFailedToImport.Text = "Failed To Import";
            // 
            // btnfailExportToXls
            // 
            this.btnfailExportToXls.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnfailExportToXls.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnfailExportToXls.Appearance.Options.UseFont = true;
            this.btnfailExportToXls.Image = global::DIGILIB.Properties.Resources.export_excel_icon;
            this.btnfailExportToXls.Location = new System.Drawing.Point(11, 411);
            this.btnfailExportToXls.Name = "btnfailExportToXls";
            this.btnfailExportToXls.Size = new System.Drawing.Size(132, 46);
            this.btnfailExportToXls.TabIndex = 10;
            this.btnfailExportToXls.Text = "Export To Xls";
            this.btnfailExportToXls.Click += new System.EventHandler(this.btnfailExportToXls_Click);
            // 
            // labelControl3
            // 
            this.labelControl3.AllowHtmlString = true;
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.labelControl3.Location = new System.Drawing.Point(11, 16);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(371, 24);
            this.labelControl3.TabIndex = 9;
            this.labelControl3.Text = "<b>List of incomplete data (failed to upload)</b>";
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.EditValue = global::DIGILIB.Properties.Resources.Excel_3;
            this.pictureEdit1.Location = new System.Drawing.Point(5, 12);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.pictureEdit1.Properties.Appearance.Options.UseBackColor = true;
            this.pictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit1.Size = new System.Drawing.Size(100, 64);
            this.pictureEdit1.TabIndex = 4;
            // 
            // labelControl4
            // 
            this.labelControl4.AllowHtmlString = true;
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.DarkOrange;
            this.labelControl4.Location = new System.Drawing.Point(137, 13);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(177, 24);
            this.labelControl4.TabIndex = 9;
            this.labelControl4.Text = "<b>Import Excel Utility</b>";
            // 
            // labelControl5
            // 
            this.labelControl5.AllowHtmlString = true;
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelControl5.Location = new System.Drawing.Point(137, 43);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(442, 36);
            this.labelControl5.TabIndex = 10;
            this.labelControl5.Text = "This feature help database administrator to import excel file to the database.\r\nN" +
                "ote : only specific format will be imported";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.pictureEdit1);
            this.panelControl1.Controls.Add(this.labelControl5);
            this.panelControl1.Controls.Add(this.labelControl4);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1107, 92);
            this.panelControl1.TabIndex = 11;
            // 
            // frmImportExcel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 587);
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.panelControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmImportExcel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Import Excel";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmImportExcel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gcNewData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewNewData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcFailedList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewFailedList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcExistingData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewExistingData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.tabReview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radioGroup1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkSelectNewData.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSelectAllExisting.Properties)).EndInit();
            this.tabFailedToImport.ResumeLayout(false);
            this.tabFailedToImport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gcNewData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewNewData;
        private DevExpress.XtraGrid.GridControl gcFailedList;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewFailedList;
        private DevExpress.XtraGrid.GridControl gcExistingData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewExistingData;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage tabReview;
        private DevExpress.XtraTab.XtraTabPage tabFailedToImport;
        private DevExpress.XtraEditors.SimpleButton btnInsertToDatabase;
        private DevExpress.XtraEditors.SimpleButton btnGetExcelData;
        private DevExpress.XtraEditors.SimpleButton btnExportToXls;
        private DevExpress.XtraEditors.SimpleButton btnUpdateToDatabase;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.CheckEdit chkSelectNewData;
        private DevExpress.XtraEditors.CheckEdit chkSelectAllExisting;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.SimpleButton btnfailExportToXls;
        private DevExpress.XtraEditors.RadioGroup radioGroup1;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        public DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
    }
}