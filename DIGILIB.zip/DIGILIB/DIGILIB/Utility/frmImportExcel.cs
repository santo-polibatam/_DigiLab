﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Library;
using Npgsql;
using DevExpress.Utils;
using DevExpress.XtraGrid.Views.Grid;
using System.Collections;
using DevExpress.XtraGrid;

namespace DIGILIB
{
    public partial class frmImportExcel : DevExpress.XtraEditors.XtraForm
    {

        WaitDialogForm loadDialog;
        public Form fMain = null;
        private DataTable dtExcel = new DataTable();
        private DataTable dtNewRecord = new DataTable();
        private DataTable dtExistRecord = new DataTable();

        private string strSheetName;
        private string strmodulName;
        public string pstrmasterid = "";
        public frmImportExcel()
        {
            InitializeComponent();
        }
        public frmImportExcel(string modulName)
        {
            InitializeComponent();
            strmodulName = modulName;
            radioGroup1.Properties.Items.Clear();

            radioGroup1.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(modulName, modulName)});
            try
            {
                int inTaskBarHeight = Screen.PrimaryScreen.Bounds.Bottom - Screen.PrimaryScreen.WorkingArea.Bottom;
                this.Size = new System.Drawing.Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height - (inTaskBarHeight + 23));
                this.StartPosition = FormStartPosition.Manual;
                this.WindowState = FormWindowState.Normal;
                this.Location = new Point(0, 0);
            }
            catch
            {
                this.StartPosition = FormStartPosition.CenterScreen;
                this.WindowState = FormWindowState.Maximized;
            }
        }
        private void frmImportExcel_Load(object sender, EventArgs e)
        {
            if (strmodulName != "" && strmodulName != null)
            {
                for (int ix = 0; ix < radioGroup1.Properties.Items.Count; ix++)
                {
                    radioGroup1.Properties.Items[ix].Enabled = (strmodulName == Convert.ToString(radioGroup1.Properties.Items[ix].Value));
                }
                radioGroup1.EditValue = strmodulName;

            }

            btnInsertToDatabase.Enabled = gridViewNewData.RowCount > 0;
            btnUpdateToDatabase.Enabled = gridViewExistingData.RowCount > 0;
            btnExportToXls.Enabled = gridViewExistingData.RowCount > 0;
        }


        #region "Import Excel"
        private string sMessage;

        private void btnGetExcelData_Click(object sender, EventArgs e)
        {
            GetDataExcels();
        }
        private void GetDataExcels()
        {
            Application.DoEvents();
            loadDialog = new WaitDialogForm("Loading Data...");


            frmMain oMain = fMain as frmMain;
            using (clsConnection oConn = new clsConnection())
            {
                bool bolImportResult = false;
                try
                {
                    sMessage = "";
                    string sFileSource = "";
                    string sFileName;
                    string sFileType;
                    string m_DestinationTable;
                    OpenFileDialog OpenFileDialog1 = new OpenFileDialog();
                    OpenFileDialog1.Title = "Please select the folder which contains the needed file: ";
                    OpenFileDialog1.FileName = "";// "Import Data.xls";
                    OpenFileDialog1.DefaultExt = "*.xlsx|*.xls";
                    OpenFileDialog1.Filter = "Excel Workbook (*.xlsx)|*.xlsx|Excel 97-2003 Workbook(*.xls)|*.xls";

                    if (OpenFileDialog1.ShowDialog() == DialogResult.OK)
                        sFileSource = OpenFileDialog1.FileName;

                    if ((sFileSource == ""))
                    {
                        XtraMessageBox.Show("Please specify the data source...", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }

                    sFileName = sFileSource.Substring(sFileSource.LastIndexOf("\\") + 1, (sFileSource.Length) - sFileSource.LastIndexOf("\\") - 1);

                    sFileType = sFileName.Substring(sFileName.LastIndexOf(".") + 1, (sFileName.Length) - sFileName.LastIndexOf(".") - 1);


                    intMax = 0;

                    oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
                    oMain.repositoryItemProgressBar1.Minimum = 0;
                    oMain.pbarMain.EditValue = 0;
                    oMain.repositoryItemProgressBar1.BeginUpdate();

                    string sql = "";
                    string sTransid = "";
                    NpgsqlCommand pgcmd;
                    int iTotalRow, iColExcel;
                    decimal decOut = 0;
                    double dblOut = 0;
                    DateTime dateOut;
                    string refString;

                    if (Convert.ToString(radioGroup1.EditValue).ToLower() == ("Buku").ToLower() || Convert.ToString(radioGroup1.EditValue).ToLower() == ("Multimedia").ToLower())
                    {
                        #region "Buku"
                        tbm_buku obuku = new tbm_buku();

                        obuku.FileSource = sFileSource;
                        obuku.TableName = "pcms_tblmtodetails";
                        obuku.ExcelType = sFileType.ToUpper();//"XLS";
                        strSheetName = strmodulName;
                        obuku.SheetName = strSheetName;
                        obuku.discipline = strdiscipline;
                        dtExcel = obuku.getExcelData();

                        dtExistRecord = dtExcel.Clone();
                        dtNewRecord = dtExcel.Clone();

                        //dtExistRecord.Clear();
                        //dtNewRecord.Clear();

                        iTotalRow = dtExcel.Rows.Count;
                        iColExcel = dtExcel.Columns.Count;
                        object[] val = new object[iColExcel];
                        for (int iRow = 0; iRow < iTotalRow; iRow++)
                        {
                            for (int iCol = 0; iCol <= iColExcel - 1; iCol++)
                            {
                                if (dtExcel.Rows[iRow][iCol] == null)
                                    val[iCol] = "";
                                else
                                    val[iCol] = dtExcel.Rows[iRow][iCol];
                            }

                            dtNewRecord.Rows.Add(val);
                        }
                        #endregion
                    }

                    gcNewData.DataSource = dtNewRecord;
                    gridViewNewData.PopulateColumns();
                    gridViewNewData.Columns[0].ColumnEdit = repositoryItemCheckEdit1;
                    for (int idx = 1; idx < dtNewRecord.Columns.Count - 1; idx++)
                    {
                        gridViewNewData.Columns[idx].OptionsColumn.AllowEdit = false;
                    }

                    gcExistingData.DataSource = dtExistRecord;
                    gridViewExistingData.PopulateColumns();
                    gridViewExistingData.Columns[0].ColumnEdit = repositoryItemCheckEdit1;
                    gridViewExistingData.OptionsView.ColumnAutoWidth = false;
                    intMax = 0;
                    bolImportResult = true;
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, true);

                }
                finally
                {
                    loadDialog.Close();
                    loadDialog.Dispose();
                    intMax = 0;

                    oMain.repositoryItemProgressBar1.EndUpdate();
                    oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                    if (!bolImportResult)
                        XtraMessageBox.Show("Import Data fail\n\n" + sMessage, "Import Data fail :: " + clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }


        //        private void GetDataExcels()
        //        {
        //            frmMain oMain = fMain as frmMain;
        //            clsConnection oconn = new clsConnection();
        //            bool bolImportResult = false;
        //            try
        //            {
        //                sMessage = "";
        //                string sFileSource = "";
        //                string sFileName;
        //                string sFileType;
        //                string m_DestinationTable;
        //                OpenFileDialog OpenFileDialog1 = new OpenFileDialog();
        //                OpenFileDialog1.Title = "Please select the folder which contains the needed file: ";
        //                OpenFileDialog1.FileName = "";// "Import Data.xls";
        //                OpenFileDialog1.DefaultExt = "*.xls|*.xlsx";
        //                OpenFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";

        //                if (OpenFileDialog1.ShowDialog() == DialogResult.OK)
        //                    sFileSource = OpenFileDialog1.FileName;

        //                if ((sFileSource == ""))
        //                {
        //                    XtraMessageBox.Show("Please specify the data source...", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        //                    return;
        //                }

        //                sFileName = sFileSource.Substring(sFileSource.LastIndexOf("\\") + 1, (sFileSource.Length) - sFileSource.LastIndexOf("\\") - 1);

        //                sFileType = sFileName.Substring(sFileName.LastIndexOf(".") + 1, (sFileName.Length) - sFileName.LastIndexOf(".") - 1);


        //                intMax = 0;

        //                oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
        //                oMain.repositoryItemProgressBar1.Minimum = 0;
        //                oMain.pbarMain.EditValue = 0;
        //                oMain.repositoryItemProgressBar1.BeginUpdate();

        //                clsImportExcel oImportExcel = new clsImportExcel();

        //                //oconn.Open();
        //                //oDocument.Koneksi = oconn.Conn;
        //                oImportExcel.FileSource = sFileSource;
        //                oImportExcel.TableName = "tbldocument";
        //                oImportExcel.ExcelType = sFileType.ToUpper();//"XLS";
        //                oImportExcel.SheetName = "isometric";

        //                ////this is for update progress bar                
        //                //oDocument.updateEventMsg += new updateProgressBar(this.importExcel_updateEventMsg);


        //                ////oMain.repositoryItemProgressBar1.Maximum = intMax;
        //                //oMain.pbarMain.Caption = "Import data from sheet " + oDocument.SheetName + "...Please wait import data in progress..";

        //                dtExcel = oImportExcel.getExcelData();
        //                //newDatagridCtrl.DataSource = dtExcel;

        //                //newExcelDataView = new DataView(dtExcel);
        //                //List<string> keys1 = new List<string>();
        //                //List<string> keys2 = new List<string>();
        //                //List<string> keys3 = new List<string>(); 

        //                string[] keys1={};
        //                string[] keys2 = { };
        //                string[] keys3 = { }; 
        //                DataView newExcelDataView;
        //                DataView existingExcelDataView;
        //                NpgsqlDataReader ndr = oconn.ReadData(@" SELECT array_to_string(array(SELECT distinct coalesce(documentcode,'') FROM tbldocument where dlt='0' /*and coalesce(documentcode,'')<>''*/   ), '|') as documentcode,
        //                    array_to_string(array(SELECT distinct coalesce(sheet,'') FROM tbldocument where dlt='0' /*and  coalesce(sheet,'')<>''*/   ), '|') as sheet,
        //                    array_to_string(array(SELECT distinct coalesce(revisionno,'') FROM tbldocument where dlt='0' /*and coalesce(revisionno,'')<>''*/ ), '|') as revisionno");
        //                while (ndr.Read())
        //                {
        //                    keys1 = (ndr["documentcode"]).ToString().Split('|');
        //                    keys2 = ndr["sheet"].ToString().Split('|');
        //                    keys3 = ndr["revisionno"].ToString().Split('|');
        //                }
        //                if (ndr != null) ndr.Dispose();

        //                newExcelDataView = new DataView(dtExcel);
        //                newDatagridCtrl.DataSource = newExcelDataView;
        //                newExcelDataView.RowFilter = string.Format("DocumentCode NOT IN ('{0}') and sheet NOT IN ('{1}') and RevisionNo NOT IN ('{2}')", String.Join("','", keys1), String.Join("','", keys2), String.Join("','", keys3));
        //                //newExcelDataView.RowFilter = string.Format("DocumentCode NOT IN ( '{0}' ) and sheet NOT IN ('{1}' )", String.Join("','", keys1), String.Join("','", keys2));
        //                //newExcelDataView.RowFilter = string.Format("DocumentCode NOT IN ( '{0}' ) and sheet NOT IN ('{1}' )", String.Join("','", keys1), String.Join("','", keys2));


        //                existingExcelDataView = new DataView(dtExcel);
        //                existingDataGridCtrl.DataSource = existingExcelDataView;
        //                existingExcelDataView.RowFilter = string.Format("DocumentCode IN ('{0}') and sheet IN ( '{1}' ) and RevisionNo IN ( '{2}' )", String.Join("','", keys1), String.Join("','", keys2), String.Join("','", keys3));
        //                //existingExcelDataView.RowFilter = string.Format(" documentcode IN ('{0}') and sheet IN ('{1}')", String.Join("','", keys1), String.Join("','", keys2));


        //                //oDocument.UpdateDB();
        //                //sMessage = sMessage + "\n" + sFileSource + " - " + clsDocument.iUpdatedRow.ToString() + " row(s) had been uploaded to database server.";

        //                intMax = 0;
        //                bolImportResult = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                clsGlobal.generateErrMessageAndSendmail(ex, true);

        //            }
        //            finally
        //            {
        //                intMax = 0;

        //                oMain.repositoryItemProgressBar1.EndUpdate();
        //                oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
        //                if (bolImportResult)
        //                    XtraMessageBox.Show("Import Data has been succeeded\n\n" + sMessage, "Import Data has been succeeded :: " + clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                else
        //                    XtraMessageBox.Show("Import Data fail\n\n" + sMessage, "Import Data fail :: " + clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        //            }
        //        }

        //this is handle for update progress bar
        private static int intMax = 0;
        private void importExcel_updateEventMsg(object sender, string msg)
        {
            frmMain oMain = fMain as frmMain;
            if (intMax == 0)
                intMax = Convert.ToInt32(msg);

            if (oMain != null)
            {
                oMain.repositoryItemProgressBar1.Maximum = intMax;

                oMain.pbarMain.EditValue = (int)oMain.pbarMain.EditValue + 1;

                if (loadDialog.IsDisposed == false && loadDialog != null)
                    loadDialog.SetCaption("Importing Data : " + oMain.pbarMain.EditValue + " of " + intMax);
            }
        }



        #endregion

        private void repositoryItemCheckEdit1_QueryCheckStateByValue(object sender, DevExpress.XtraEditors.Controls.QueryCheckStateByValueEventArgs e)
        {
            string val = e.Value.ToString();
            switch (val)
            {
                case "True":
                    e.CheckState = CheckState.Checked;
                    break;
                case "False":
                    e.CheckState = CheckState.Unchecked;
                    break;
                case "Yes":
                    goto case "True";
                case "No":
                    goto case "False";
                case "-1":
                case "1":
                    goto case "True";
                case "0":
                    goto case "False";
                default:
                    e.CheckState = CheckState.Indeterminate;
                    break;
            }
            e.Handled = true;
        }


        private void btnImportToDatabase_Click(object sender, EventArgs e)
        {
            insertToDatabase(gcNewData);
        }
        private void insertToDatabase(GridControl gridControlImported)
        {
            Application.DoEvents();
            loadDialog = new WaitDialogForm("Loading data...");

            frmMain oMain = fMain as frmMain;
            using (clsConnection oConn = new clsConnection())
            {
                DataTable filteredDt = new DataTable();

                bool bolImportResult = false;
                btnInsertToDatabase.Enabled = false;
                btnUpdateToDatabase.Enabled = false;
                btnExportToXls.Enabled = false;
                btnGetExcelData.Enabled = false;
                btnClose.Enabled = false;
                Application.DoEvents();
                try
                {
                    sMessage = "";

                    intMax = 0;

                    oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
                    oMain.repositoryItemProgressBar1.Minimum = 0;
                    oMain.pbarMain.EditValue = 0;
                    oMain.repositoryItemProgressBar1.BeginUpdate();

                    oConn.Open();
                    if (Convert.ToString(radioGroup1.EditValue).ToLower() == ("Buku").ToLower() || Convert.ToString(radioGroup1.EditValue).ToLower() == ("Multimedia").ToLower())
                    {
                        #region "Buku"
                        tbm_buku oObject = new tbm_buku();
                        oObject.Koneksi = oConn.Conn;
                        //this is for update progress bar                
                        oObject.updateEventMsg += new updateProgressBar(this.importExcel_updateEventMsg);
                        //oMain.repositoryItemProgressBar1.Maximum = intMax;
                        oMain.pbarMain.Caption = "Import data from sheet " + oObject.SheetName + "...Please wait import data in progress..";

                        DataTable dt = gridControlImported.DataSource as DataTable;
                        if (dt == null) return;
                        DataView filteredDataView = new DataView(dt);
                        filteredDataView.RowFilter = "[select]=true";
                        filteredDt = filteredDataView.ToTable();
                        oObject.SheetName = strSheetName;
                        oObject.jenis_barang = Convert.ToString(radioGroup1.EditValue).ToLower();
                        //do import here
                        gcFailedList.DataSource = oObject.ImportNewData(filteredDt);

                        gridViewFailedList.Columns[0].ColumnEdit = repositoryItemCheckEdit1;

                        if (gridViewFailedList.RowCount > 0)
                        {
                            xtraTabControl1.SelectedTabPageIndex = 1;
                            xtraTabControl1.Text = gridViewFailedList.RowCount.ToString() + "row(s) failed to update";
                        }

                        filteredDataView.RowFilter = "[select]=false";

                        gridControlImported.DataSource = filteredDataView.ToTable();

                        sMessage = sMessage + "\n" + (tbm_buku.iFailUpdatedRow > 0 ? tbm_buku.iFailUpdatedRow.ToString() + " row(s) failed to upload.\n" : "")
                            + tbm_buku.iUpdatedRow.ToString() + " row(s) had been uploaded to database server.\n";

                        #endregion "Material-Heat No"
                    }

                    intMax = 0;
                    bolImportResult = true;
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, true);

                }
                finally
                {
                    btnInsertToDatabase.Enabled = gridViewNewData.RowCount > 0;
                    btnUpdateToDatabase.Enabled = gridViewExistingData.RowCount > 0;
                    btnExportToXls.Enabled = gridViewExistingData.RowCount > 0;
                    btnGetExcelData.Enabled = true;
                    btnClose.Enabled = true;
                    intMax = 0;
                    loadDialog.Close();
                    loadDialog.Dispose();
                    oMain.repositoryItemProgressBar1.EndUpdate();
                    oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                    if (bolImportResult)
                        XtraMessageBox.Show("Import Data has been finished\n" + sMessage, "Import Data has been finished :: " + clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        if (filteredDt.Rows.Count <= 0)
                            sMessage = "No data selected in data grid";

                        XtraMessageBox.Show("Import Data fail\n\n" + sMessage, "Import Data fail :: " + clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
            }
        }


        private void chkSelectNewData_CheckedChanged(object sender, EventArgs e)
        {
            for (int idx = 0; idx < gridViewNewData.RowCount; idx++)
            {
                gridViewNewData.SetRowCellValue(idx, "select", chkSelectNewData.Checked);
            }
        }

        private void chkSelectAllExisting_CheckedChanged(object sender, EventArgs e)
        {
            for (int idx = 0; idx < gridViewExistingData.RowCount; idx++)
            {
                gridViewExistingData.SetRowCellValue(idx, "select", chkSelectAllExisting.Checked);
            }
        }

        private void checkEdit1_CheckedChanged(object sender, EventArgs e)
        {
            for (int idx = 0; idx < gridViewExistingData.RowCount; idx++)
            {
                gridViewExistingData.SetRowCellValue(idx, "select", chkSelectAllExisting.Checked);
            }
        }

        private void btnExportToXls_Click(object sender, EventArgs e)
        {
            if (gridViewExistingData.RowCount <= 0)
            {
                XtraMessageBox.Show("Export fail...No data in current grid", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            string sFilePath = clsGlobal.pstrAppPath;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            //saveFileDialog1.InitialDirectory = sFilePath;
            saveFileDialog1.Title = "Save as Excel Workbook";
            saveFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";
            saveFileDialog1.FileName = "Existing Data" + DateTime.Now.ToString("yyyyMMddHH") + ".xlsx";
            saveFileDialog1.FilterIndex = 2;


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (clsGlobal.isFileOpened(saveFileDialog1.FileName))
                {
                    XtraMessageBox.Show("Download fail, this file [" + saveFileDialog1.FileName + "] is currenlty opened", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                gridViewExistingData.Columns[gridViewExistingData.Columns.Count - 1].Visible = false;
                gridViewExistingData.Columns[0].Visible = false;
                sFilePath = saveFileDialog1.FileName;
                if (saveFileDialog1.FilterIndex == 2)
                    gcExistingData.ExportToXlsx(sFilePath, new DevExpress.XtraPrinting.XlsxExportOptions { SheetName = "isometric" });
                else
                    gcExistingData.ExportToXls(sFilePath, new DevExpress.XtraPrinting.XlsExportOptions { SheetName = "isometric" });

                gridViewExistingData.Columns[0].Visible = true;
                gridViewExistingData.Columns[gridViewExistingData.Columns.Count - 1].Visible = true;

                if (XtraMessageBox.Show("Do you want to open file", clsGlobal.pstrAppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    System.Diagnostics.Process.Start(sFilePath);
            }

        }

        private void btnfailExportToXls_Click(object sender, EventArgs e)
        {
            if (gridViewFailedList.RowCount <= 0)
            {
                XtraMessageBox.Show("Export fail...No data in current grid", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            string sFilePath = clsGlobal.pstrAppPath;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            //saveFileDialog1.InitialDirectory = sFilePath;
            saveFileDialog1.Title = "Save as Excel Workbook";
            saveFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";
            saveFileDialog1.FileName = "List of failed to uploads" + DateTime.Now.ToString("yyyyMMddHH") + ".xlsx";
            saveFileDialog1.FilterIndex = 2;


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (clsGlobal.isFileOpened(saveFileDialog1.FileName))
                {
                    XtraMessageBox.Show("Download fail, this file [" + saveFileDialog1.FileName + "] is currenlty opened", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                gridViewFailedList.Columns[0].Visible = false;
                gridViewFailedList.Columns[gridViewFailedList.Columns.Count - 1].Visible = false;

                sFilePath = saveFileDialog1.FileName;
                if (saveFileDialog1.FilterIndex == 2)
                    gcFailedList.ExportToXlsx(sFilePath, new DevExpress.XtraPrinting.XlsxExportOptions { SheetName = strSheetName });
                else
                    gcExistingData.ExportToXls(sFilePath, new DevExpress.XtraPrinting.XlsExportOptions { SheetName = strSheetName });

                gridViewFailedList.Columns[0].Visible = true;
                gridViewFailedList.Columns[gridViewFailedList.Columns.Count - 1].Visible = true;
                if (XtraMessageBox.Show("Do you want to open file", clsGlobal.pstrAppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    System.Diagnostics.Process.Start(sFilePath);
            }

        }

        private void btnUpdateToDatabase_Click(object sender, EventArgs e)
        {
            insertToDatabase(gcExistingData);
        }

        private void gridViewNewData_RowCountChanged(object sender, EventArgs e)
        {
            btnInsertToDatabase.Enabled = gridViewNewData.RowCount > 0;
        }

        private void gridViewExistingData_RowCountChanged(object sender, EventArgs e)
        {
            btnUpdateToDatabase.Enabled = gridViewExistingData.RowCount > 0;
            btnExportToXls.Enabled = gridViewExistingData.RowCount > 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public string strdiscipline;
    }
}