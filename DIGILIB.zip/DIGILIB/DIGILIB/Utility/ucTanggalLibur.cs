﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.Utils;
using Library;
using DevExpress.XtraEditors;
using DevExpress.XtraScheduler;

namespace DIGILIB.Utility
{
    public partial class ucTanggalLibur : UserControl
    {
        WaitDialogForm loadDialog;
        public frmMain formMain;
        public ucTanggalLibur()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Processing...Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Processing...Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void ucTanggalLibur_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }


        public void loadData()
        {
            setLoadDialog(true, "Loading data...");

            int iCount = dateNavigator1.Selection.Count;
            for (int i = 0; i < iCount; i++)
            {
                dateNavigator1.Selection.RemoveAt(0);
            }

            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                string strSql = @"select holidayid, tgl, remarks from tbm_holiday where dlt='0' order by tgl;";
                DataTable dt = oConn.GetData(strSql);
                
                dgData.DataSource = dt;

                schedulerControl1.WorkDays.Clear();
                schedulerControl1.WorkDays.Add(WeekDays.WorkDays);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DateTime dtOut = DateTime.MinValue; DateTime.TryParse(dt.Rows[i]["tgl"] + "", out dtOut);
                    if (dtOut != DateTime.MinValue)
                    {
                        schedulerControl1.WorkDays.AddHoliday(dtOut, "");
                    }
                }
            }
            dateNavigator1.Refresh();
            setLoadDialog(false, "");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show("Anda yakin menyimpan data libur ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                setLoadDialog(true, "Saving data...");
                bool isSave = false;
                using (clsConnection oConn = new clsConnection())
                {
                    oConn.Open();
                    tbm_holiday oObject;
                    for (int i = 0; i < dateNavigator1.Selection.Count; i++)
                    {
                        string strCount = clsGlobal.getData1Field("select count(*) from tbm_holiday where dlt='0' and tgl::date='" + dateNavigator1.Selection[i].Date.ToString("yyyy-MM-dd") + "'::date");
                        if (strCount == "0")
                        {
                            oObject = new tbm_holiday();
                            oObject.Koneksi = oConn.Conn;
                            oObject.holidayid = oObject.NewID();
                            oObject.tgl = dateNavigator1.Selection[i].Date;
                            oObject.opadd = clsGlobal.strUserName;
                            oObject.pcadd = SystemInformation.ComputerName;
                            oObject.Insert();
                            oObject = null;
                            isSave = true;
                        }
                    }
                    oObject = null;
                }
                setLoadDialog(false, "");

                if (isSave)
                {
                    loadData();
                }
            }
        }

        private void ucTanggalLibur_Load(object sender, EventArgs e)
        {
            loadData();
            btnSave.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
            btnDel.Enabled = clsGlobal.bolDelete;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show("Anda yakin menghapus data libur ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                setLoadDialog(true, "Deleting data...");
                bool isdelete = false;
                using (clsConnection oConn = new clsConnection())
                {
                    oConn.Open();
                    tbm_holiday oObject;
                    for (int i = 0; i < dateNavigator1.Selection.Count; i++)
                    {
                        string strID = clsGlobal.getData1Field("select holidayid from tbm_holiday where dlt='0' and tgl::date='" + dateNavigator1.Selection[i].Date.ToString("yyyy-MM-dd") + "'::date");
                        if (!string.IsNullOrEmpty(strID))
                        {
                            oObject = new tbm_holiday();
                            oObject.Koneksi = oConn.Conn;
                            oObject.GetByPrimaryKey(strID);
                            oObject.opedit = clsGlobal.strUserName;
                            oObject.pcedit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                            oObject = null;
                            isdelete = true;
                        }
                    }
                    oObject = null;
                }
                setLoadDialog(false, "");
                if (isdelete)
                {
                    loadData();
                }
            }
        }
    }
}
