﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Npgsql;
using Library;

namespace DIGILIB
{
    public partial class frmSeverInitialize : DevExpress.XtraEditors.XtraForm
    {
        public frmSeverInitialize()
        {
            InitializeComponent();
        }
        
        clsRegKey oReg = new clsRegKey();
        private clsEncryption oEncryption = new clsEncryption();

        private void btnTry_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlConnection cn = new NpgsqlConnection("Server=" + txtServer.Text + ";User Id=" + txtUsername.Text + ";Password=" + txtpassword.Text + ";Database=postgres;Port=" + txtPort.Text + "");

                cn.Open();
                string strSql;

                strSql = "SELECT datname FROM pg_database where datname not like '%template%' order by datname";
                NpgsqlCommand cmd = new NpgsqlCommand(strSql, cn);

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                da.Fill(dt);
                cboDatabase.Properties.DataSource = dt;
                cboDatabase.Properties.DisplayMember = "datname";
                cboDatabase.Properties.ValueMember = "datname";
                cn.Close();
                XtraMessageBox.Show("Connection Success !", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (dt.Rows.Count > 0)
                {
                    cboDatabase.Text = "";
                }
            }
            catch (Exception ee)
            {
                XtraMessageBox.Show("Could not connect to the server .!\nCall Your System Administrator\n", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void frmSeverInitialize_Load(object sender, EventArgs e)
        {
            try
            {
                oReg.RegistryPathCurrenUser = clsGlobal.s_FullRegKey;

                txtServer.Text = oReg.getSetting("Server");
                txtUsername.Text = oEncryption.Decrypt(oReg.getSetting("User"));
                txtpassword.Text = oEncryption.Decrypt(oReg.getSetting("Password"));
                cboDatabase.Properties.NullText = oReg.getSetting("Database");
                txtPort.Text = oReg.getSetting("Port");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Could not write/read Registry System.!\nCall Your System Administrator\n", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    oConn.Server = txtServer.Text;
                    oConn.User = txtUsername.Text;
                    oConn.Password = txtpassword.Text;
                    oConn.Database = cboDatabase.Text;
                    oConn.Port = txtPort.Text;

                    oConn.OpenTesting();
                    XtraMessageBox.Show("Congratulation\n You have been connected to server : " + txtServer.Text, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    oReg.SaveSetting("Server", txtServer.Text);
                    oReg.SaveSetting("User", oEncryption.Encrypt(txtUsername.Text));
                    oReg.SaveSetting("Password", oEncryption.Encrypt(txtpassword.Text));
                    oReg.SaveSetting("Database", cboDatabase.Text);
                    oReg.SaveSetting("Port", txtPort.Text);

                    oConn.Server = oReg.getSetting("Server");
                    oConn.User = oReg.getSetting("User");
                    oConn.Password = oReg.getSetting("Password");
                    oConn.Database = oReg.getSetting("Database");
                    oConn.Port = oReg.getSetting("Port");

                    clsGlobal.str_Server = oConn.Server;
                    clsGlobal.str_User = txtUsername.Text;
                    clsGlobal.str_Password = txtpassword.Text;
                    clsGlobal.str_Database = oConn.Database;
                    clsGlobal.str_Port = oConn.Port;

                    this.Dispose();
                }
                catch (Exception ee)
                {
                    XtraMessageBox.Show("Could not connect to the server .!\nCall Your System Administrator\n", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void txtUsernameUnlock_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            if (txtUsernameUnlock.Text.ToLower() == "digilib" && txtPasswordUnlock.Text.ToLower() == "myp455w0rd")
            {
                groupControl1.Enabled = true;
                groupControl2.Visible = false;
            }
        }

        private void txtPasswordUnlock_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                simpleButton2_Click(sender, e);
            }
            else if (e.KeyCode == Keys.Tab)
            {
                simpleButton2.Focus();
            }
        }
    }
}