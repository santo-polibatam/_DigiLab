﻿namespace DIGILIB.WebAdmin
{
    partial class UserControlNews
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlNews));
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridViewData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.newsid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.news = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglterbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isterbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nourut = new DevExpress.XtraGrid.Columns.GridColumn();
            this.news_html = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.repositoryItemRichTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            this.btnCreate = new DevExpress.XtraEditors.SimpleButton();
            this.btnDelete = new DevExpress.XtraEditors.SimpleButton();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.Location = new System.Drawing.Point(3, 22);
            this.dgData.MainView = this.gridViewData;
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemPictureEdit1,
            this.repositoryItemRichTextEdit1,
            this.repositoryItemMemoEdit1});
            this.dgData.Size = new System.Drawing.Size(899, 447);
            this.dgData.TabIndex = 108;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewData});
            // 
            // gridViewData
            // 
            this.gridViewData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.newsid,
            this.judul,
            this.news,
            this.tglterbit,
            this.isterbit,
            this.nourut,
            this.news_html});
            this.gridViewData.GridControl = this.dgData;
            this.gridViewData.Name = "gridViewData";
            this.gridViewData.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridViewData.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridViewData.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewData.OptionsBehavior.Editable = false;
            this.gridViewData.OptionsSelection.MultiSelect = true;
            this.gridViewData.OptionsView.AutoCalcPreviewLineCount = true;
            this.gridViewData.OptionsView.RowAutoHeight = true;
            this.gridViewData.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewData_FocusedRowChanged);
            this.gridViewData.DoubleClick += new System.EventHandler(this.btnEdit_Click);
            // 
            // newsid
            // 
            this.newsid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newsid.AppearanceHeader.Options.UseFont = true;
            this.newsid.AppearanceHeader.Options.UseTextOptions = true;
            this.newsid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.newsid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.newsid.Caption = "newsid";
            this.newsid.FieldName = "newsid";
            this.newsid.Name = "newsid";
            // 
            // judul
            // 
            this.judul.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.judul.AppearanceHeader.Options.UseFont = true;
            this.judul.AppearanceHeader.Options.UseTextOptions = true;
            this.judul.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.judul.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.judul.Caption = "Judul";
            this.judul.FieldName = "judul";
            this.judul.MinWidth = 200;
            this.judul.Name = "judul";
            this.judul.Visible = true;
            this.judul.VisibleIndex = 0;
            this.judul.Width = 200;
            // 
            // news
            // 
            this.news.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.news.AppearanceHeader.Options.UseFont = true;
            this.news.AppearanceHeader.Options.UseTextOptions = true;
            this.news.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.news.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.news.Caption = "Berita";
            this.news.FieldName = "news";
            this.news.MinWidth = 200;
            this.news.Name = "news";
            this.news.Visible = true;
            this.news.VisibleIndex = 1;
            this.news.Width = 661;
            // 
            // tglterbit
            // 
            this.tglterbit.AppearanceCell.Options.UseTextOptions = true;
            this.tglterbit.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglterbit.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglterbit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tglterbit.AppearanceHeader.Options.UseFont = true;
            this.tglterbit.AppearanceHeader.Options.UseTextOptions = true;
            this.tglterbit.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglterbit.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglterbit.Caption = "Tanggal Terbit";
            this.tglterbit.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.tglterbit.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglterbit.FieldName = "tglterbit";
            this.tglterbit.MaxWidth = 120;
            this.tglterbit.MinWidth = 120;
            this.tglterbit.Name = "tglterbit";
            this.tglterbit.Visible = true;
            this.tglterbit.VisibleIndex = 2;
            this.tglterbit.Width = 120;
            // 
            // isterbit
            // 
            this.isterbit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isterbit.AppearanceHeader.Options.UseFont = true;
            this.isterbit.AppearanceHeader.Options.UseTextOptions = true;
            this.isterbit.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.isterbit.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.isterbit.Caption = "Terbitkan?";
            this.isterbit.FieldName = "isterbit";
            this.isterbit.MaxWidth = 100;
            this.isterbit.MinWidth = 100;
            this.isterbit.Name = "isterbit";
            this.isterbit.Visible = true;
            this.isterbit.VisibleIndex = 3;
            this.isterbit.Width = 100;
            // 
            // nourut
            // 
            this.nourut.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nourut.AppearanceHeader.Options.UseFont = true;
            this.nourut.AppearanceHeader.Options.UseTextOptions = true;
            this.nourut.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nourut.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nourut.Caption = "nourut";
            this.nourut.FieldName = "nourut";
            this.nourut.MinWidth = 100;
            this.nourut.Name = "nourut";
            this.nourut.Width = 100;
            // 
            // news_html
            // 
            this.news_html.Caption = "news_html";
            this.news_html.FieldName = "news_html";
            this.news_html.MinWidth = 200;
            this.news_html.Name = "news_html";
            this.news_html.Width = 359;
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            // 
            // repositoryItemRichTextEdit1
            // 
            this.repositoryItemRichTextEdit1.Name = "repositoryItemRichTextEdit1";
            this.repositoryItemRichTextEdit1.ShowCaretInReadOnly = false;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // lblTitle
            // 
            this.lblTitle.AllowHtmlString = true;
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(103, 16);
            this.lblTitle.TabIndex = 104;
            this.lblTitle.Text = "Halaman Berita";
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Image = ((System.Drawing.Image)(resources.GetObject("btnPreview.Image")));
            this.btnPreview.Location = new System.Drawing.Point(782, 479);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(120, 28);
            this.btnPreview.TabIndex = 109;
            this.btnPreview.Text = "&Print Preview";
            this.btnPreview.Visible = false;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCreate.Image = ((System.Drawing.Image)(resources.GetObject("btnCreate.Image")));
            this.btnCreate.Location = new System.Drawing.Point(6, 481);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(108, 26);
            this.btnCreate.TabIndex = 107;
            this.btnCreate.Text = "Tambah Berita";
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Enabled = false;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(227, 481);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(103, 26);
            this.btnDelete.TabIndex = 106;
            this.btnDelete.Text = "Hapus";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Enabled = false;
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(118, 481);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(103, 26);
            this.btnEdit.TabIndex = 105;
            this.btnEdit.Text = "Edit Berita";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(336, 481);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 26);
            this.btnClose.TabIndex = 111;
            this.btnClose.Text = "&Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // UserControlNews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.dgData);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblTitle);
            this.Name = "UserControlNews";
            this.Size = new System.Drawing.Size(905, 515);
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraGrid.GridControl dgData;
        public DevExpress.XtraGrid.Views.Grid.GridView gridViewData;
        private DevExpress.XtraGrid.Columns.GridColumn newsid;
        private DevExpress.XtraGrid.Columns.GridColumn news;
        private DevExpress.XtraGrid.Columns.GridColumn isterbit;
        private DevExpress.XtraGrid.Columns.GridColumn nourut;
        private DevExpress.XtraGrid.Columns.GridColumn tglterbit;
        public DevExpress.XtraEditors.SimpleButton btnCreate;
        public DevExpress.XtraEditors.SimpleButton btnDelete;
        public DevExpress.XtraEditors.SimpleButton btnEdit;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit repositoryItemRichTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn news_html;
        private DevExpress.XtraGrid.Columns.GridColumn judul;
        public DevExpress.XtraEditors.SimpleButton btnClose;
    }
}
