﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraBars;
using DevExpress.XtraRichEdit;
using Library;
using Npgsql;
using DevExpress.Utils;
using System.IO;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors;

namespace DIGILIB.WebAdmin
{
    public partial class frmCreateNews : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public string pstrnewsid = "";
        string psFileSource = "";
        WaitDialogForm loadDialog;
        public frmMain fMain;
        public frmCreateNews()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Processing...Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
           
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Processing...Please Wait...", new Size(250, 50));
            }
            Application.DoEvents();
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                //loadDialog.TopMost = false;
                //loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
            }
        }


        public void refreshAll()
        {
            loadData();
        }


        private void loadData()
        {
            clstbp_news oObject = new clstbp_news();
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    setLoadDialog(true, "Loading data...");
                    if (string.IsNullOrEmpty(pstrnewsid))
                    {
                        datetglterbit.EditValue = clsGlobal.getServerDate();
                        txtnews.HtmlText = "";
                        chkisterbit.Checked = true;
                        txtJudul.Text = "";
                    }
                    else
                    {

                        oConn.Open();

                        oObject.Koneksi = oConn.Conn;
                        oObject.GetByPrimaryKey(pstrnewsid);
                        datetglterbit.EditValue = clsGlobal.GetParseDate(oObject.tglterbit);
                        txtJudul.Text = Convert.ToString(oObject.judul);
                        txtnews.HtmlText = Convert.ToString(oObject.news_html);
                        chkisterbit.Checked = clsGlobal.GetParseBoolean(oObject.isterbit);

                        setModifiedState();
                    }
                    setLoadDialog(false, "");
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    oObject = null;
                    setLoadDialog(false, "");
                }
            }
        }



        private void savebarButtonItem_ItemClick(object sender, ItemClickEventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {

                    if (txtnews.Text == "")
                    {
                        XtraMessageBox.Show("Silahkan isi berita...", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtnews.Focus();
                        return;
                    }
                    string sql = "select newsid from tbp_news where dlt='0' and trim(lower(news_html))=trim(lower(@news_html)) and newsid<>@newsid limit 1";
                    NpgsqlCommand pgcmd = new NpgsqlCommand(sql);
                    pgcmd.Parameters.Add("@news_html", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Convert.ToString(txtnews.Text);
                    pgcmd.Parameters.Add("@newsid", NpgsqlTypes.NpgsqlDbType.Varchar).Value = Convert.ToString(pstrnewsid);

                    if (clsGlobal.getData1Field(pgcmd) != "")
                    {
                        string strMsg = "Berita ini " + txtnews.Text + " sudah ada di database dan tidak bisa di simpan dengan berita yang sama\n";

                        XtraMessageBox.Show(strMsg, clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }


                    setLoadDialog(true, "Saving data...");
                    oConn.Open();
                    clstbp_news oObject = new clstbp_news();
                    oObject.Koneksi = oConn.Conn;
                    oObject.newsid = pstrnewsid;
                    if (!string.IsNullOrEmpty(oObject.newsid))
                    {
                        oObject.GetByPrimaryKey(oObject.newsid);
                    }

                    //Plain Text
                    oObject.tglterbit = clsGlobal.GetParseDate(datetglterbit.EditValue);
                    oObject.judul = txtJudul.Text.Trim();
                    oObject.news = txtnews.Text.Trim();
                    oObject.news_html = txtnews.HtmlText.Trim();
                    oObject.isterbit = chkisterbit.Checked;

                    if (string.IsNullOrEmpty(oObject.newsid))
                    {
                        string strnourut = clsGlobal.getData1Field("select max(nourut) +1 from tbp_news where dlt='0' limit 1");
                        oObject.nourut = clsGlobal.GetParseInt(strnourut);
                        if (oConn.Conn.State == ConnectionState.Closed)
                            oConn.Open();
                        oObject.Koneksi = oConn.Conn;
                        pstrnewsid = oObject.NewID();
                        oObject.newsid = pstrnewsid;
                        oObject.opadd = clsGlobal.strUserID;
                        oObject.pcadd = SystemInformation.ComputerName;
                        oObject.Insert();
                    }
                    else
                    {
                        oObject.opedit = clsGlobal.strUserID;
                        oObject.pcedit = SystemInformation.ComputerName;
                        oObject.Update();
                    }

                    setLoadDialog(false, "");
                    setModifiedState();
                    if (sender != null)
                    {
                        if (XtraMessageBox.Show("Berita sudah disimpan!\nApakah anda ingin menambah data baru", clsGlobal.pstrAppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            pstrnewsid = "";
                            loadData();
                        }
                        else
                        {
                            closebarButtonItem1_ItemClick(sender, e);
                        }
                    }


                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    oConn.Close();
                    setLoadDialog(false, "");
                }
            }
        }

        private void printPreviewItem1_ItemClick(object sender, ItemClickEventArgs e)
        {

        }



        bool iscontactAwardClick = false;
        private void richEditControl1_Click(object sender, EventArgs e)
        {

        }

        
        private void XtraRichEdit_Enter(object sender, EventArgs e)
        {
            Application.DoEvents();
            RichEditControl richEditControl = sender as RichEditControl;
            if (richEditControl != null)
            {
                RichEditControl richEditControlPrev = richEditBarController1.Control as RichEditControl;
                if (richEditControlPrev != null && richEditControl != richEditControlPrev)
                {
                    richEditControlPrev.DeselectAll();
                }
                richEditBarController1.Control = richEditControl;
                
            }
        }

        private void XtraRichEdit_InitializeDocument(object sender, EventArgs e)
        {
            try
            {
                RichEditControl xRichEdit = sender as RichEditControl;
                if (xRichEdit != null)
                {
                    xRichEdit.Document.DefaultCharacterProperties.FontName = "Myriad Web Pro";
                    xRichEdit.Document.DefaultCharacterProperties.FontSize = 11;
                    xRichEdit.Document.DefaultParagraphProperties.Alignment = DevExpress.XtraRichEdit.API.Native.ParagraphAlignment.Justify;
                }
            }
            catch
            {

            }

        }


        private void closebarButtonItem1_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (isModified())
            {
                if (XtraMessageBox.Show("Ada perubahan pada berita. Apakah anda ingin menyimpannya?", clsGlobal.pstrAppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    savebarButtonItem_ItemClick(null, null);
                }
            }
            this.Close();
        }
        private void setModifiedState()
        {
            try
            {
                foreach (RichEditControl rectl in xtraScrollableControl1.Controls.OfType<RichEditControl>())
                {
                    if (rectl != null)
                    {
                        if (rectl.Modified)
                        {
                            rectl.Modified = false;
                        }
                    }
                }
            }
            catch
            {
            }
        }
        private bool isModified()
        {
            bool bolModified = false;
            try
            {
                foreach (RichEditControl rectl in xtraScrollableControl1.Controls.OfType<RichEditControl>())
                {
                    if (rectl != null)
                    {
                        if (rectl.Modified)
                        {
                            bolModified = true;
                            break;
                        }
                    }
                }
            }
            catch
            {
            }
            return bolModified;
        }
        private void prinPreviewbarButtonItem1_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void PrintbarButtonItem1_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void frmCreateProject_Load(object sender, EventArgs e)
        {
            //setModifiedState();
        }
    }
}