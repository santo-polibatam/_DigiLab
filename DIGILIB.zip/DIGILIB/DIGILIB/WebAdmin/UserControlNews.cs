﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.Utils;
using Npgsql;
using DIGILIB.WebAdmin;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;

namespace DIGILIB.WebAdmin
{
    public partial class UserControlNews : UserControl
    {
        WaitDialogForm loadDialog;
        public frmMain formMain;
        
        public UserControlNews()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Processing...Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Processing...Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public void refreshAll()
        {
            loadData();
        }
        private void loadData()
        {
            clstbp_news oObject = new clstbp_news();
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    setLoadDialog(true, "Loading data...");
                    oConn.Open();
                    string strSql = @"SELECT *
                    FROM tbp_news                    
                    where dlt='0' order by nourut                    
                    ";
                    oObject.Koneksi = oConn.Conn;
                    xdt = oObject.GetData(strSql);
                    dgData.DataSource = xdt;

                    setLoadDialog(false, "");
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    oObject = null;
                    setLoadDialog(false, "");
                }
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                using (frmCreateNews frmPro=new frmCreateNews())
                {
                    frmCreateNews XtraForm = new frmCreateNews();
                    XtraForm.pstrnewsid = "";
                    XtraForm.WindowState = FormWindowState.Maximized;
                    XtraForm.refreshAll();
                    XtraForm.ShowDialog();
                    loadData();
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!btnEdit.Enabled) return;
                btnEdit.Enabled = false;
                int currentRow;
                currentRow = gridViewData.FocusedRowHandle;
                if (gridViewData.IsGroupRow(currentRow))
                {
                    currentRow = gridViewData.GetDataRowHandleByGroupRowHandle(currentRow);
                }
                if (Convert.ToString(gridViewData.GetRowCellValue(currentRow, newsid)) == "")
                {
                    XtraMessageBox.Show("No data selected...", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                using (frmCreateNews frmPro = new frmCreateNews())
                {
                    frmCreateNews XtraForm = new frmCreateNews();
                    XtraForm.pstrnewsid = Convert.ToString(gridViewData.GetRowCellValue(currentRow, newsid));
                    XtraForm.WindowState = FormWindowState.Maximized;
                    XtraForm.refreshAll();
                    XtraForm.ShowDialog();
                    loadData();
                    setMasterGridSelected(gridViewData, newsid.FieldName, XtraForm.pstrnewsid);
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                btnEdit.Enabled = true;
            }
        }
        private void setMasterGridSelected(GridView gridView, string fieldName, object val)
        {
            try
            {
                int idx = gridView.LocateByValue(fieldName, val);
                gridView.FocusedRowHandle = idx;
                gridView.SelectRow(idx);
                gridView.MakeRowVisible(idx, false);
            }
            catch 
            {
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    if (XtraMessageBox.Show("Apakah anda ingin menghapus data yang dipilih?", clsGlobal.pstrAppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        clstbp_news oObject = new clstbp_news();
                        string[] strConstraintTable = { "" };

                        int[] intSelectedRows = gridViewData.GetSelectedRows();
                        oConn.Open();
                        oObject.Koneksi = oConn.Conn;
                        for (int intindex = 0; intindex < intSelectedRows.Length; intindex++)
                        {
                            oObject.newsid = Convert.ToString(gridViewData.GetRowCellValue(intSelectedRows[intindex], newsid.FieldName));
                            if (clsGlobal.cekConstraint("newsid", oObject.newsid, strConstraintTable))
                            {
                                XtraMessageBox.Show("Berita ini tidak dapat dihapus, data ini sudah dipakai di proses lain", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                gridViewData.UnselectRow(intSelectedRows[intindex]);
                                continue;
                            }
                            else
                            {
                                oObject.SoftDelete();
                            }

                        }
                        gridViewData.DeleteSelectedRows();

                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                }
            }
        }
        DataTable xdt;
        private void btnPreview_Click(object sender, EventArgs e)
        {
            try
            {
                if (!btnPreview.Enabled) return;
                btnPreview.Enabled = false;

                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptJumlahAnggotaMahasiswa.repx";
                reportName = "rptNews";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    DataTable dtReport = null;

                    int rowHandle;
                    DataRow gridRow;
                    xdt.Rows.Clear();
                    for (int i = 0; i < gridViewData.RowCount; i++)
                    {
                        rowHandle = gridViewData.GetVisibleRowHandle(i);
                        if (!gridViewData.IsGroupRow(rowHandle))
                        {
                            gridRow = gridViewData.GetDataRow(rowHandle);
                            if (gridRow != null)
                                xdt.Rows.Add(gridRow.ItemArray);
                        }
                    }

                    dtReport = xdt.Copy();
                    dtReport.TableName = "tblReport";
                    mainReport.reportName = reportName;
                    mainReport.printReport(filename, dtReport);

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview.Enabled = true;
        }

        private void gridViewData_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(newsid)) == "")
            {
                btnEdit.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
            {
                btnEdit.Enabled = clsGlobal.bolEdit;
                btnDelete.Enabled = clsGlobal.bolDelete;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (formMain != null)
                formMain.closeUC();
        }
    }
}
