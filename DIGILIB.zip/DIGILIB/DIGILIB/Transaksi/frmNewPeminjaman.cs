﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Columns;
using Npgsql;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid;
using System.Collections;
using DIGILIB.MainReport;
using DIGILIB.MasterData;

using System.Globalization;
using System.Drawing.Printing;
using ReaderA;
using System.IO;
namespace DIGILIB.Transaksi
{
    public partial class frmNewPeminjaman : DevExpress.XtraEditors.XtraForm
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;
        private int intInitColumnCount;
        List<string> arrExistingDate = new List<string>();
        List<string> arrWorkpackId = new List<string>();

        public string pstrpeminjamanid = "";

        public string pstrsupervisorid = "";
        public string pstrforemanid = "";
        public bool bolLoading = false;
        public bool pEdit = false;

        public frmNewPeminjaman()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            intInitColumnCount = gridView1.Columns.Count;


            SelectICard();
            SetupReaderList();
            LoadApduList();
            comboReader_SelectedIndexChanged(null, null);

            setLoadDialog(false, "");
        }


        #region Smartcard
        delegate void SetValueLookUpEditDelegate(DevExpress.XtraEditors.LookUpEdit cbo, string editvalue);
        private GemCard.CardBase m_iCard = null;
        private GemCard.APDUPlayer m_apduPlayer = null;
        private GemCard.APDUParam m_apduParam = null;
        const string DefaultReader = "Gemplus USB Smart Card Reader 0";
        private TextBox txtboxATR;
        private Label label10;
        string reader = "ACS ACR122 0";
        const string ApduListFile = "ApduList.xml";


        public string GetScardErrMsg(string ReturnCode)
        {
            string strresult = ReturnCode;
            switch (ReturnCode)
            {
                case "9000":
                    strresult = "9000 : The operation completed succesfully.";
                    break;
                case "6300":
                    strresult = "6300 : The operation failed.";
                    break;
                case "6A81":
                    strresult = "6A81 : Function not supported.";
                    break;
            }
            return strresult;
        }

        private void SelectICard()
        {
            try
            {
                if (m_iCard != null)
                    m_iCard.Disconnect(GemCard.DISCONNECT.Unpower);

                m_iCard = new GemCard.CardNative();
                //statusBarPanel_Info.Text = "CardNative implementation used";              

                m_iCard.OnCardInserted += new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved += new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);

            }
            catch (Exception ex)
            {
                //btnConnect.Enabled = false;
                //btnDisconnect.Enabled = false;
                //btnTransmit.Enabled = false;

                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        /// <summary>
        /// CardRemovedEventHandler
        /// </summary>
        private void m_iCard_OnCardRemoved(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, false });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });

        }

        /// <summary>
        /// CardInsertedEventHandler
        /// </summary>
        private void m_iCard_OnCardInserted(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, true });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });
            //if (btnConnect.Enabled)
            //{
            try
            {
                m_iCard.Connect("ACS ACR122 0", GemCard.SHARE.Shared, GemCard.PROTOCOL.T0orT1);

                try
                {
                    // Get the ATR of the card
                    byte[] atrValue = m_iCard.GetAttribute(GemCard.SCARD_ATTR_VALUE.ATR_STRING);
                    //txtboxATR.Text = ByteArrayToString(atrValue);
                }
                catch (Exception)
                {
                    //txtboxATR.Text = "Cannot get ATR";
                }

                //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, btnConnect.Enabled });

                GemCard.APDUResponse apduResp = m_apduPlayer.ProcessCommand("Get UID", BuildParam());
                if (apduResp.Data != null)
                {
                    StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                    for (int nI = 0; nI < apduResp.Data.Length; nI++)
                        sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    if (apduResp.Data != null)
                    {
                        if (pEdit == false)
                        {
                            string editvalue = Convert.ToString(ByteArrayToString(apduResp.Data));
                            bool bolNotExist = false;
                            foreach (DataRow row in dtAnggota.Select("rfid='" + editvalue.Replace("'", "''") + "'"))
                            {
                                lookupEditAnggota.Invoke(new SetValueLookUpEditDelegate(SetValueLookUpEdit), new object[] { lookupEditAnggota, row["anggotaid"] });
                                bolNotExist = true;
                            }
                            if (bolNotExist == false)
                            {
                                XtraMessageBox.Show("RFI/Mahasiswa belum terdaftar!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            }
                        }
                        else
                        {
                            XtraMessageBox.Show("Fitur scan kartu hanya untuk mode peminjaman baru saja!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        //MessageBox.Show(ByteArrayToString(apduResp.Data));
                    }
                }


            }
            catch (Exception ex)
            {
                XtraMessageBox.Show(ex.Message + "\nKoneksi Card Reader bermasalah!!!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            //btnConnect_Click(btnConnect, null);
            //}
        }

        protected void SetValueLookUpEdit(DevExpress.XtraEditors.LookUpEdit lookupedit, object editValue)
        {
            lookupedit.EditValue = Convert.ToString(editValue);
        }
        protected void EnableButton(Button btn, bool enable)
        {
            btn.Enabled = enable;
        }

        static private string ByteArrayToString(byte[] data)
        {
            StringBuilder sDataOut;

            if (data != null)
            {
                sDataOut = new StringBuilder(data.Length * 2);
                for (int nI = 0; nI < data.Length; nI++)
                    sDataOut.AppendFormat("{0:X02}", data[nI]);
            }
            else
                sDataOut = new StringBuilder();

            return sDataOut.ToString();
        }
        string textClass = "";
        string textIns = "";
        string textP1 = "";
        string textP2 = "";
        string textLe = "";
        string textData = "";
        private GemCard.APDUParam BuildParam()
        {
            //byte bP1 = byte.Parse(textP1.Text, NumberStyles.AllowHexSpecifier);
            //byte bP2 = byte.Parse(textP2.Text, NumberStyles.AllowHexSpecifier);
            //byte bLe = byte.Parse(textLe.Text);

            byte bP1 = byte.Parse(textP1, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bP2 = byte.Parse(textP2, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bLe = byte.Parse(textLe);

            GemCard.APDUParam apduParam = new GemCard.APDUParam();
            apduParam.P1 = bP1;
            apduParam.P2 = bP2;
            apduParam.Le = bLe;

            // Update Current param
            m_apduParam = apduParam.Clone();

            return apduParam;
        }
        private void DisplayAPDUCommand(GemCard.APDUCommand apduCmd)
        {
            if (apduCmd != null)
            {
                textClass = string.Format("{0:X02}", apduCmd.Class);
                textIns = string.Format("{0:X02}", apduCmd.Ins);
                textP1 = string.Format("{0:X02}", apduCmd.P1);
                textP2 = string.Format("{0:X02}", apduCmd.P2);
                textLe = apduCmd.Le.ToString();

                if (apduCmd.Data != null)
                {
                    StringBuilder sData = new StringBuilder(apduCmd.Data.Length * 2);
                    for (int nI = 0; nI < apduCmd.Data.Length; nI++)
                        sData.AppendFormat("{0:X02}", apduCmd.Data[nI]);

                    textData = sData.ToString();
                }
                else
                    textData = "";

                m_apduParam = new GemCard.APDUParam();

                m_apduParam.P1 = apduCmd.P1;
                m_apduParam.P2 = apduCmd.P2;
                m_apduParam.Le = apduCmd.Le;
            }
        }

        private void SetupReaderList()
        {
            try
            {
                string[] sListReaders = m_iCard.ListReaders();
                //comboReader.Items.Clear();

                if (sListReaders != null)
                {
                    for (int nI = 0; nI < sListReaders.Length; nI++)
                    {
                        reader = Convert.ToString(sListReaders[nI]);
                        //    comboReader.Items.Add(sListReaders[nI]);
                    }
                    //comboReader.SelectedIndex = 0;

                    //btnConnect.Enabled = false;
                    //btnDisconnect.Enabled = false;
                    //btnTransmit.Enabled = false;

                    //// Start waiting for a card
                    //string reader = (string)comboReader.SelectedItem;
                    //m_iCard.StartCardEvents(reader);

                    //statusBarPanel_Info.Text = "Waiting for a card";
                }
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        /// <summary>
        /// Loads the APDU list
        /// </summary>
        private void LoadApduList()
        {
            try
            {
                // Create the APDU player
                m_apduPlayer = new GemCard.APDUPlayer(ApduListFile, m_iCard);

                // Get the list of APDUs and setup teh combo
                //comboApdu.Items.AddRange(m_apduPlayer.APDUNames);
                //comboApdu.SelectedIndex = 0;
                DisplayAPDUCommand(m_apduPlayer.APDUByName("Get UID"));
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        private void comboReader_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                m_iCard.StopCardEvents();

                // Get the current selection
                //int idx = comboReader.SelectedIndex;
                //if (idx != -1)
                //{
                // Start waiting for a card

                m_iCard.StartCardEvents(reader);

                //statusBarPanel_Info.Text = "Waiting for a card";
                //}
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        private void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //    m_iCard.Disconnect(DISCONNECT.Unpower);

                //    m_iCard.StopCardEvents();
                m_iCard.OnCardInserted -= new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved -= new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);
            }
            catch
            {
            }
        }
        #endregion


        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        private DateTime dateServer = DateTime.MinValue;
        public void refreshAll()
        {
            lblnamaanggota.Text = "";
            lblnimanggota.Text = "";
            labelControl10.Text = "";
            labelControl5.Text = "";
            dateServer = clsGlobal.getServerDate();
            loadRepository();
            loadKetentuanPeminjaman();
            loadDataBukuBelumKembali();
            datetgljatuhtempo.Focus();
            loadBuku();
            bolsave = true;

        }

        private DateTime getTglJatuhTempo(DateTime dateDari, int jmlHari)
        {
            DateTime dateReturn = dateDari;
            int jmlhari2 = 0;

            using (clsConnection oConn = new clsConnection())
            {
                DataView dvHolidays = new DataView(oConn.GetData("select holidayid, tgl::date as tgl, remarks from tbm_holiday where dlt='0' and tgl::date>'" + dateDari.ToString("yyyy-MM-dd") + "'::date order by tgl;"));
                oConn.Close();

            step1:
                jmlhari2++;
                dateReturn = dateReturn.AddDays(1);

            step2:
                if (dateReturn.ToString("ddd").ToLower() == "sat" || dateReturn.ToString("ddd").ToLower() == "sun")
                {
                    dateReturn = dateReturn.AddDays(1);
                    goto step2;
                }
                dvHolidays.RowFilter = "tgl='" + dateReturn.ToString("yyyy-MM-dd") + "'";
                if (dvHolidays.Count > 0)
                {
                    dateReturn = dateReturn.AddDays(1);
                    goto step2;
                }

                if (jmlhari2 < jmlHari)
                {
                    goto step1;
                }
            }
            return dateReturn;
        }

        public void CreateNewData()
        {
            pEdit = false;
            pstrpeminjamanid = "";
            txtjumlah.Text = "1";
            txtnopeminjaman.Text = clsGlobal.GetNewNumber("Nomor Peminjaman Buku");
            datetglpinjam.EditValue = clsGlobal.getServerDate();
            setKetentuanPeminjaman();
            if (!string.IsNullOrEmpty(txtlamapeminjaman.Text) && datetglpinjam.EditValue != null)
            {
                datetgljatuhtempo.EditValue = getTglJatuhTempo(clsGlobal.GetParseDate(datetglpinjam.EditValue), clsGlobal.GetParseInt(txtlamapeminjaman.Text));
            }
            lookupEditAnggota.EditValue = null;

            lblnamaanggota.Text = "";
            lblnimanggota.Text = "";
            labelControl10.Text = "";
            labelControl5.Text = "";
            pictureBox2.ImageLocation = ""; ;

            lookupEditAnggota.Focus();
            if (dtData != null)
            {
                dtData.Rows.Clear();
                dtData.AcceptChanges();
            }
            enableControl(true);
            txtnopeminjaman.Enabled = false;

            DataTable dtAnggota = lookupEditAnggota.Properties.DataSource as DataTable;
            if (dtAnggota != null)
            {
                dtAnggota.DefaultView.RowFilter = "statusaktif='Aktif'";
            }
        }
        private void setKetentuanPeminjaman()
        {
            if (dtKetentuanPeminjaman != null && dtKetentuanPeminjaman.Rows.Count > 0)
            {
                txtlamapeminjaman.Text = Convert.ToString(dtKetentuanPeminjaman.Rows[0]["lamapeminjaman"]);
                txtdendaperhari.Text = Convert.ToString(dtKetentuanPeminjaman.Rows[0]["dendaperhari"]);
                txtmaksbukudipinjam.Text = Convert.ToString(dtKetentuanPeminjaman.Rows[0]["maksbukudipinjam"]);
            }
        }
        public void loadData(bool bolcheck)
        {
            bolLoading = true;
            if (bolcheck)
            {
                //if (datetgljatuhtempo.EditValue == null)
                //{
                //    XtraMessageBox.Show("Tanggal tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    datetgljatuhtempo.Focus();
                //    return;
                //}
                //else if (Convert.ToString(cboProdi.EditValue) == "")
                //{
                //    XtraMessageBox.Show("Prodi tidak boleh kosong, silahkan pilih prodi!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    cboProdi.Focus();
                //    return;
                //}
                //else if (Convert.ToString(cboAnggota.EditValue) == "")
                //{
                //    XtraMessageBox.Show("Program tidak boleh kosong, silahkan pilih program!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    cboAnggota.Focus();
                //    return;
                //}
                //else if (Convert.ToString(cboNIB.EditValue) == "")
                //{
                //    XtraMessageBox.Show("Semester tidak boleh kosong, silahkan pilih semester!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    cboNIB.Focus();
                //    return;
                //}
            }
            setLoadDialog(true, "Loading data...");

            using (clsConnection oConn = new clsConnection())
            {

                try
                {
                    string strSQL = @"select inv.inventarisid, inv.nib, inv.rfid,
                    bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                    bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, 
                    ag.anggotaid, ag.rfid, ag.nim, ag.nama,
                    pj.peminjamanid, pj.anggotaid, pj.petugasid, pj.nopeminjaman, pj.tglpinjam, pj.tgljatuhtempo, pj.status, pj.maksbukudipinjam, pj.lamapeminjaman, pj.dendaperhari,
                    pjdet.peminjamandetailsid, pjdet.peminjamanid, pjdet.jumlah, pjdet.status, pjdet.keterangan,
                    pjdet.tglpinjam,  pjdet.tgljatuhtempo
                    from tblpeminjaman pj
                    inner join tblpeminjamandetails pjdet on pjdet.peminjamanid=pj.peminjamanid and pjdet.dlt='0'                    
                    inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                    inner join tbm_buku bk on bk.bukuid=inv.bukuid and bk.dlt='0'
                    inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                    where pj.dlt='0' and pj.peminjamanid='" + pstrpeminjamanid + @"'
                ";


                    oConn.Open();
                    clstblpeminjaman oObject = new clstblpeminjaman();
                    oObject.Koneksi = oConn.Conn;
                    dtData = oObject.GetData(strSQL);

                    dgData.DataSource = dtData;
                    dgData.Enabled = true;
                    oObject = null;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                    bolLoading = false;
                }
            }
        }

        public void loadDataBukuBelumKembali()
        {
            //bolLoading = true;            
            setLoadDialog(true, "Loading data...");

            using (clsConnection oConn = new clsConnection())
            {

                try
                {

                    string stranggotaid = Convert.ToString(lookupEditAnggota.EditValue);
                    string strSQL = @"select inv.inventarisid, inv.nib, inv.rfid, 
                    bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                    bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, 
                    ag.anggotaid, ag.rfid, ag.nim, ag.nama,
                    pj.peminjamanid, pj.anggotaid, pj.petugasid, pj.nopeminjaman, pj.tglpinjam, pj.tgljatuhtempo, pj.status, pj.maksbukudipinjam, pj.lamapeminjaman, pj.dendaperhari,
                    pjdet.peminjamandetailsid, pjdet.peminjamanid, pjdet.jumlah, pjdet.status, pjdet.keterangan, pjdet.tglpinjam,  pjdet.tgljatuhtempo

                    from tblpeminjaman pj
                    inner join tblpeminjamandetails pjdet on pjdet.peminjamanid=pj.peminjamanid and pjdet.dlt='0'
                    inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                    inner join tbm_buku bk on inv.bukuid=bk.bukuid and bk.dlt='0'
                    inner join tbm_anggota ag on ag.anggotaid=pj.anggotaid and ag.dlt='0'
                    left outer join 
                    (
                        select pb.pengembalianid, pb.regno, pb.petugasid, pb.nopengembalian,
                        pbdet.pengembaliandetailsid, pbdet.peminjamandetailsid, pbdet.tglkembali, pbdet.jumlah, pbdet.jumlahdenda, pbdet.keterangan, pbdet.dendadibayar, pbdet.status
                        from tblpengembalian pb
                        inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
                        where pb.dlt='0'
                    ) pbdet on pbdet.peminjamandetailsid=pjdet.peminjamandetailsid 

                    where pj.dlt='0' " + (string.IsNullOrEmpty(stranggotaid) ? "" : " and pj.anggotaid='" + stranggotaid + "'") + @"
                    and pbdet.pengembalianid is null
                    order by nopeminjaman, noinduk, judul
                    ";

                    oConn.Open();
                    clstblpeminjaman oObject = new clstblpeminjaman();
                    oObject.Koneksi = oConn.Conn;
                    DataTable dtBukuBelumKembali = oObject.GetData(strSQL);

                    gridControl1.DataSource = dtBukuBelumKembali;

                    oConn.Close();
                    oObject = null;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                    //bolLoading = false;
                }
            }
        }
        private void loadDataKaryawanTarif()
        {
            clsRepository oRepository = new clsRepository();
            dtKaryawan = oRepository.GetDataKaryawanAndTarif(Convert.ToString(lookupEditAnggota.EditValue), "", "tarif_dosenwali");
            LookUpEditEmp.DataSource = dtKaryawan;
            LookUpEditEmp.ValueMember = "karyawanid";
            LookUpEditEmp.DisplayMember = "namapetugas";
        }
        DataTable dtAnggota;
        DataTable dtBuku;
        private void loadBuku()
        {
            clsRepository oRepository = new clsRepository();

            DataTable dtBuku1 = oRepository.GetDataBuku_Tersedia();
            cboNIB.Properties.DataSource = dtBuku1;
            cboNIB.Properties.ValueMember = "inventarisid";
            cboNIB.Properties.DisplayMember = "judul";
            cboNIB.Properties.PopupFormMinSize = new System.Drawing.Size(600, 300);
            dtBuku = dtBuku1.Copy();

        }
        private void loadRepository()
        {
            clsRepository oRepository = new clsRepository();
            DataTable dtAnggota1 = oRepository.GetDataAnggota();
            lookupEditAnggota.Properties.DataSource = dtAnggota1;
            lookupEditAnggota.Properties.ValueMember = "anggotaid";
            lookupEditAnggota.Properties.DisplayMember = "rfid";
            lookupEditAnggota.Properties.PopupFormMinSize = new System.Drawing.Size(350, 400);

            lookUpEditNamaAnggota.Properties.DataSource = dtAnggota1;
            lookUpEditNamaAnggota.Properties.ValueMember = "anggotaid";
            lookUpEditNamaAnggota.Properties.DisplayMember = "nama";
            lookUpEditNamaAnggota.Properties.PopupFormMinSize = new System.Drawing.Size(400, 400);

            dtAnggota = dtAnggota1.Copy();

            DataTable dtKaryawan1 = oRepository.GetDataPetugas();
            lookupEditPetugas.Properties.DataSource = dtKaryawan1;
            lookupEditPetugas.Properties.ValueMember = "petugasid";
            lookupEditPetugas.Properties.DisplayMember = "rfid";
            lookupEditPetugas.EditValue = clsGlobal.strUserID;
            lookupEditPetugas.Properties.PopupFormMinSize = new System.Drawing.Size(350, 210);

            txtnamapetugas.Text = clsGlobal.strNamaPetugas;
        }

        private void loadKetentuanPeminjaman()
        {
            clsRepository oRepository = new clsRepository();
            dtKetentuanPeminjaman = oRepository.GetDataKetentuanPeminjaman();

        }
        private DataTable dtKetentuanPeminjaman;

        private DataTable dtData, dtKaryawan, dtProdi, dtMK;
        private DataView filteredDataView;
        private bool bolsave = true;

        private void gridView1_ShownEditor(object sender, EventArgs e)
        {
            GridView gridView = (GridView)sender;
            LookUpEdit lookup = gridView.ActiveEditor as LookUpEdit;
            if (gridView.FocusedColumn.FieldName == "karyawanid" && lookup != null && dtData != null)
            {
                List<string> keys = new List<string>();
                for (int i = 0; i < dtData.DefaultView.Count; i++)
                {

                    object key = dtData.DefaultView[i].Row["karyawanid"];
                    if (key != null && key != DBNull.Value)
                    {
                        if (key.ToString() != Convert.ToString(gridView.FocusedValue))
                            keys.Add(key.ToString());
                    }
                }
                filteredDataView = new DataView(dtKaryawan);
                lookup.Properties.DataSource = filteredDataView;

                if (keys.Count > 0)
                {
                    filteredDataView.RowFilter = string.Format("karyawanid NOT IN( {0} )", "'" + String.Join("','", keys.ToArray()) + "'");
                }


            }
        }
        private void gridView1_HiddenEditor(object sender, System.EventArgs e)
        {
            if (filteredDataView != null)
            {
                filteredDataView.Dispose();
                filteredDataView = null;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            SaveData(true);
            btnSave.Enabled = true;
        }
        private bool SaveData(bool showmsg)
        {
            bool bolResult = false;
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Saving data...");
                try
                {

                    //if (gridView1.RowCount <= 1)
                    //{
                    //    XtraMessageBox.Show("Tidak ada data yang mau disimpan", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    return;
                    //}
                    //else if (Convert.ToString(cboDisiapkanOleh.EditValue) == "" && Convert.ToString(cboDiperiksaOleh.EditValue) == "")
                    //{
                    //    XtraMessageBox.Show("Silahkan pilih [Disiapkan oleh]", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    cboDisiapkanOleh.Focus();
                    //    return;
                    //}

                    //else 
                    if (lookupEditAnggota.EditValue == null)
                    {
                        XtraMessageBox.Show("Silahkan pilih anggota!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        lookupEditAnggota.Focus();
                        return bolResult;
                    }
                    else if (datetglpinjam.EditValue == null)
                    {
                        XtraMessageBox.Show("Silahkan isi tanggal peminjaman!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        datetglpinjam.Focus();
                        return bolResult;
                    }
                    else if (string.IsNullOrEmpty(txtnopeminjaman.Text))
                    {
                        XtraMessageBox.Show("Silahkan isi nomor peminjaman!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        txtnopeminjaman.Focus();
                        return bolResult;
                    }
                    else if (datetglpinjam.EditValue == null)
                    {
                        XtraMessageBox.Show("Silahkan isi tanggal peminjaman!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        datetglpinjam.Focus();
                        return bolResult;
                    }

                    string strsql = "";
                    decimal decOut = 0;
                    string colActual_nt = "";
                    string colActual_ot = "";
                    DateTime myDate = Convert.ToDateTime(datetgljatuhtempo.EditValue);
                    clstblpeminjaman oMaster = new clstblpeminjaman();
                    if (string.IsNullOrEmpty(pstrpeminjamanid))
                    {
                        string strSQL = @"select 
                    pba.peminjamanid
                    from tblpeminjaman pba
                    where pba.dlt='0' and pba.nopeminjaman='" + Convert.ToString(txtnopeminjaman.Text) + @"' 
                    
                    ";
                        pstrpeminjamanid = clsGlobal.getData1Field(strSQL);

                        if (!string.IsNullOrEmpty(pstrpeminjamanid))
                        {
                            pstrpeminjamanid = "";
                            txtnopeminjaman.Text = clsGlobal.GetNewNumber("Nomor Peminjaman Buku");
                        }
                    }

                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oMaster.Koneksi = oConn.Conn;
                    oMaster.peminjamanid = Convert.ToString(pstrpeminjamanid);
                    if (!string.IsNullOrEmpty(oMaster.peminjamanid))
                    {
                        oMaster.GetByPrimaryKey(oMaster.peminjamanid);
                    }

                    oMaster.anggotaid = Convert.ToString(lookupEditAnggota.EditValue);
                    oMaster.petugasid = Convert.ToString(lookupEditPetugas.EditValue);
                    oMaster.nopeminjaman = Convert.ToString(txtnopeminjaman.Text);
                    try
                    {
                        oMaster.tglpinjam = Convert.ToDateTime(datetglpinjam.EditValue);
                    }
                    catch
                    {
                        oMaster.tglpinjam = clsGlobal.GetParseDate(datetglpinjam.EditValue);
                    }

                    oMaster.tgljatuhtempo = clsGlobal.GetParseDate(datetgljatuhtempo.EditValue);
                    oMaster.lamapeminjaman = clsGlobal.GetParseDecimal(txtlamapeminjaman.Text);
                    oMaster.dendaperhari = clsGlobal.GetParseDecimal(txtdendaperhari.Text);
                    oMaster.maksbukudipinjam = clsGlobal.GetParseDecimal(txtmaksbukudipinjam.Text);
                    //oMaster.status=Convert.ToString(cboStatus.EditValue);
                    //oMaster.keterangan=Convert.ToString(txtKeterangan.Text);
                    oMaster.dlt = false;

                    if (Convert.ToString(oMaster.peminjamanid) == "" || oMaster.peminjamanid == null)
                    {
                        oMaster.regno = clsGlobal.intNewNumber;
                        oMaster.opadd = clsGlobal.strUserName;
                        oMaster.pcadd = SystemInformation.ComputerName;
                        pstrpeminjamanid = oMaster.NewID();
                        oMaster.peminjamanid = pstrpeminjamanid;
                        oMaster.Insert();
                    }
                    else
                    {
                        oMaster.opedit = clsGlobal.strUserName;
                        oMaster.pcedit = SystemInformation.ComputerName;
                        oMaster.Update();
                    }

                    DataTable dtMdf = dgData.DataSource as DataTable;
                    if (dtMdf != null && dtMdf.GetChanges() != null)
                    {
                        clstblpeminjamandetails oObject;
                        NpgsqlCommand npcmd = new NpgsqlCommand();
                        //Modified
                        foreach (DataRow row in dtMdf.GetChanges().Rows)
                        {

                            oObject = new clstblpeminjamandetails();
                            if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                            oObject.Koneksi = oConn.Conn;

                            if (row.RowState == DataRowState.Deleted)
                            {
                                row.RejectChanges();
                                oObject.peminjamandetailsid = Convert.ToString(row[peminjamandetailsid.FieldName]);

                                oObject.SoftDelete();
                                row.Delete();
                                //row.AcceptChanges();
                            }
                            else
                            {

                                if (Convert.ToString(row[inventarisid.FieldName]) == "") continue;

                                oObject.peminjamandetailsid = Convert.ToString(row[peminjamandetailsid.FieldName]);
                                if (!string.IsNullOrEmpty(oObject.peminjamandetailsid))
                                {
                                    oObject.GetByPrimaryKey(oObject.peminjamandetailsid);
                                }
                                oObject.peminjamanid = Convert.ToString(oMaster.peminjamanid);

                                oObject.inventarisid = Convert.ToString(row[inventarisid.FieldName]);
                                oObject.keterangan = Convert.ToString(row[keterangan.FieldName]);
                                oObject.jumlah = clsGlobal.GetParseDecimal(row[jumlah.FieldName]);
                                oObject.status = Convert.ToString(row[status.FieldName]);
                                try
                                {
                                    oObject.tglpinjam = Convert.ToDateTime(row[tglpinjam.FieldName]);
                                }
                                catch
                                {
                                    oObject.tglpinjam = clsGlobal.GetParseDate(row[tglpinjam.FieldName]);
                                }

                                oObject.tgljatuhtempo = clsGlobal.GetParseDate(row[tgljatuhtempo.FieldName]);
                                if (Convert.ToString(oObject.peminjamandetailsid) == "" || oObject.peminjamandetailsid == null)
                                {

                                    oObject.opadd = clsGlobal.strUserName;
                                    oObject.pcadd = SystemInformation.ComputerName;
                                    oObject.peminjamandetailsid = oObject.NewID();
                                    row[peminjamandetailsid.FieldName] = oObject.peminjamandetailsid;
                                    oObject.Insert();
                                }
                                else
                                {

                                    oObject.opedit = clsGlobal.strUserName;
                                    oObject.pcedit = SystemInformation.ComputerName;
                                    oObject.Update();
                                }

                            }
                        }
                    }
                    if (dtMdf != null)
                    {
                        dtMdf.AcceptChanges();
                        dgData.RefreshDataSource();
                    }
                    bolResult = true;
                    bolsave = true;
                    setLoadDialog(false, "");
                    if (showmsg == false)
                    {
                        //    if (XtraMessageBox.Show("Data berhasil disimpan\n\nApakah anda ingin menambah data yang lain?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        //    {
                        //        arrExistingDate.Clear();                        
                        //        DateTime dateEdit = Convert.ToDateTime(datetglpinjam.EditValue);

                        //        pEdit = false;
                        //        pstrpeminjamanid = "";
                        //        enableControl(true);
                        //        loadData(false);
                        //        dgData.Enabled = false;
                        //        txtnopeminjaman.Focus();

                        //    }
                        //    else
                        //    {
                        //        btnClose_Click(null, null);
                        //    }
                    }
                    else
                    {
                        XtraMessageBox.Show("Data berhasil disimpan!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);


                    }
                    pEdit = true;
                    loadData(false);
                    loadBuku();
                    bolsave = true;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                }
            }
            return bolResult;
        }
        public void enableControl(bool isenabled)
        {
            txtnopeminjaman.Enabled = isenabled;
            lookupEditAnggota.Enabled = isenabled;
            lookUpEditNamaAnggota.Enabled = isenabled;
            //cboNIB.Enabled = isenabled;
            lblnamaanggota.Enabled = isenabled;
            datetglpinjam.Enabled = isenabled;
        }
        public void btnLoadData_Click(object sender, EventArgs e)
        {
            loadData(true);
        }
        private void gridView1_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            int currentRow = e.RowHandle;
            ColumnView view = sender as ColumnView;

            //if (view == null)
            //{
            //    XtraMessageBox.Show("Data source not found.., please click button [Load Data]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    return;
            //}
            //string suserid = Convert.ToString(view.GetRowCellValue(currentRow, peminjamanid)).ToLower();
            //if (suserid == "")
            //{
            //    string strMsg = "Nama Dosen tidak boleh kosong.\n";
            //    e.Valid = false;
            //    e.ErrorText = strMsg;
            //    view.FocusedColumn = peminjamanid;
            //    view.ShowEditor();
            //    return;
            //}

            bolsave = false;
        }

        private void gridView1_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            if (e.Column != peminjamanid && !e.Column.FieldName.Contains("subtotal"))
            {
                decimal decOut = 0;
                decimal.TryParse(Convert.ToString(e.CellValue), out decOut);
                if (decOut > 0)
                {
                    e.Appearance.Font = new Font(AppearanceObject.DefaultFont, FontStyle.Bold);
                    e.Appearance.ForeColor = Color.Black;

                }
                else
                {
                    e.Appearance.Font = new Font(AppearanceObject.DefaultFont, FontStyle.Regular);
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (bolsave == false)
            {
                if (XtraMessageBox.Show("Data sudah diubah. Apakah anda ingin menyimpan perubahan?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (!SaveData(true))
                    {
                        return;
                    }
                }
            }
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {

                    string strsql = "";
                    GridView detailView = gridView1 as GridView;
                    if (detailView == null)
                    {
                        XtraMessageBox.Show("No data selected, please select detail grid!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    if (XtraMessageBox.Show("Are you sure to delete selected record(s)?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        if (string.IsNullOrEmpty(pstrpeminjamanid))
                        {
                            gridView1.DeleteSelectedRows();
                        }
                        else
                        {
                            pBar.Visible = true;
                            pBar.Properties.Minimum = 0;
                            pBar.Properties.Maximum = gridView1.SelectedRowsCount;
                            pBar.EditValue = 0;

                            string[] strConstraintTable = { };
                            string strExistConstraint = "";
                            string colActual_nt = "";
                            string colActual_ot = "";
                            clstblpeminjamandetails oObject = new clstblpeminjamandetails();
                            oConn.Open();
                            oObject.Koneksi = oConn.Conn;

                            if (detailView != null)
                            {
                                if (detailView.SelectedRowsCount == 0)
                                {
                                    detailView.SelectRow(detailView.FocusedRowHandle);
                                    detailView.MakeRowVisible(detailView.FocusedRowHandle, false);
                                }
                                int[] arrSelectedRows = detailView.GetSelectedRows();

                                for (int i = 0; i < arrSelectedRows.Length; i++)
                                {
                                    pBar.Update();
                                    pBar.PerformStep();
                                    oObject.peminjamandetailsid = Convert.ToString(detailView.GetRowCellValue(arrSelectedRows[i], peminjamandetailsid));
                                    if (oObject.peminjamanid == "") continue;
                                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                                    oObject.Koneksi = oConn.Conn;


                                    if (clsGlobal.cekConstraint("peminjamandetailsid", oObject.peminjamandetailsid, strConstraintTable, ref strExistConstraint))
                                    {
                                        if (strExistConstraint == "") strExistConstraint = "prosees lain";
                                        //string sDesc = Convert.ToString(gridView1.GetRowCellValue(arrSelectedRows[i], areacode));
                                        //XtraMessageBox.Show("Area library [" + sDesc + "] can't be deleted, this record had been used by " + strExistConstraint, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                        //gridView1.UnselectRow(arrSelectedRows[i]);
                                        continue;
                                    }
                                    else
                                    {
                                        oObject.opedit = clsGlobal.strUserName;
                                        oObject.pcedit = SystemInformation.ComputerName;
                                        oObject.SoftDelete();

                                    }
                                }

                                Application.DoEvents();

                                if (arrSelectedRows.Length > 0)
                                {
                                    //gridView1.DeleteSelectedRows();
                                    loadData(false);
                                    XtraMessageBox.Show("Data has been deleted..", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }

                            }
                        }
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    pBar.Visible = false;
                }
            }
        }

        private void dateActual_DrawItem(object sender, DevExpress.XtraEditors.Calendar.CustomDrawDayNumberCellEventArgs e)
        {
            //if (e.Date.Month != 3)
            if (arrExistingDate.Contains(e.Date.ToString("yyyy-MM-dd")))
                e.Handled = true;
        }

        private void dateActual_QueryCloseUp(object sender, CancelEventArgs e)
        {
            DateEdit edit = sender as DateEdit;
            DevExpress.XtraEditors.Popup.PopupDateEditForm form = (sender as DevExpress.Utils.Win.IPopupControl).PopupWindow as DevExpress.XtraEditors.Popup.PopupDateEditForm;
            //if (form.Calendar.DateTime.Month != 3)
            if (arrExistingDate.Contains(form.Calendar.DateTime.Date.ToString("yyyy-MM-dd")))
            {
                e.Cancel = true;
                form.Calendar.DateTime = edit.DateTime == DateTime.MinValue ? clsGlobal.getServerDate() : edit.DateTime;
            }
        }

        private void cboTimecard_EditValueChanged(object sender, EventArgs e)
        {
            //dateBorang.EditValue = null;
            //arrExistingDate.Clear();
            //arrExistingDate.AddRange(getExistingDate(Convert.ToString(cboTimecard.EditValue)));
        }


        //public void LookUpEditEmp_EditValueChanged(object sender, EventArgs e)
        //{
        //    LookUpEdit cbolookup = sender as LookUpEdit;
        //    if (cbolookup != null)
        //    {
        //        gridView1.SetFocusedRowCellValue(bukuid, cbolookup.GetColumnValue("nik"));
        //        gridView1.SetFocusedRowCellValue(status, cbolookup.GetColumnValue("namapetugas"));
        //    }


        //}

        private void gridView1_SelectionChanged(object sender, DevExpress.Data.SelectionChangedEventArgs e)
        {
            if (!bolLoading)
                gridView1.SetMasterRowExpandedEx(gridView1.FocusedRowHandle, 0, true);
        }

        private void gridView1_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
        {
            //GridView view = sender as GridView;
            //if (e.IsGetData && e.Column.FieldName.Contains("subtotalnt"))
            //{
            //    DataRow row = ((view.DataSource as IList)[e.ListSourceRowIndex] as DataRowView).Row;
            //    e.Value = row.GetChildRows("subtotal_nt_dtl").Length; 
            //}
            //else if (e.IsGetData && e.Column.FieldName.Contains("subtotal_ot"))
            //{
            //    DataRow row = ((view.DataSource as IList)[e.ListSourceRowIndex] as DataRowView).Row;
            //    e.Value = row.GetChildRows("subtotal_ot_dtl").Length;
            //}

        }
        private void dgData_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        {
            try
            {
                if (e.View != null && e.View.ParentView != null)
                {
                    ColumnView view = e.View.ParentView as ColumnView;
                    view.FocusedRowHandle = e.View.SourceRowHandle;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }
        private void gridView1_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            //if (!bolLoading)
            //    gridView1.SetMasterRowExpandedEx(e.FocusedRowHandle, 0, true);
        }

        private void cbo_EditValueChanged(object sender, EventArgs e)
        {

            if (sender == datetglpinjam)
            {
                lblTglPinjam.Text = clsGlobal.GetParseDate(datetglpinjam.EditValue).ToString("dd-MMM-yyyy");
                lblJamPinjam.Text = clsGlobal.GetParseDate(datetglpinjam.EditValue).ToString("HH:mm:ss");

                if (!string.IsNullOrEmpty(txtlamapeminjaman.Text) && datetglpinjam.EditValue != null)
                {
                    datetgljatuhtempo.EditValue = getTglJatuhTempo(clsGlobal.GetParseDate(datetglpinjam.EditValue), clsGlobal.GetParseInt(txtlamapeminjaman.Text));
                }
            }
            if (!bolLoading)
                bolsave = false;
        }

        private void LookUpEditMhs_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
            try
            {
                //LookUpEdit cbolookup = sender as LookUpEdit;
                //if (cbolookup != null)
                //{
                //    gridView1.SetFocusedRowCellValue(mahasiswaid, cbolookup.GetColumnValue(mahasiswaid.FieldName));
                //    gridView1.SetFocusedRowCellValue(nim, cbolookup.GetColumnValue(nim.FieldName));
                //    gridView1.SetFocusedRowCellValue(namamahasiswa, cbolookup.GetColumnValue(namamahasiswa.FieldName));
                //}
            }
            catch
            {
            }
        }

        private void gridView1_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            try
            {
                //if (gridView1.FocusedColumn.FieldName == mahasiswaid.FieldName)
                //{
                //    LookUpEdit cbolookup = gridView1.ActiveEditor as LookUpEdit;
                //    if (cbolookup != null)
                //    {
                //        DataRowView drSelected = cbolookup.GetSelectedDataRow() as DataRowView;
                //        if (drSelected != null)
                //        {
                //            gridView1.SetFocusedRowCellValue(mahasiswaid, drSelected[mahasiswaid.FieldName]);
                //            gridView1.SetFocusedRowCellValue(nim, drSelected[nim.FieldName]);
                //            gridView1.SetFocusedRowCellValue(noinduk, drSelected[noinduk.FieldName]);

                //        }
                //    }
                //}
                //else if (gridView1.FocusedColumn.FieldName == peminjamanid.FieldName)
                //{
                //    LookUpEdit cbolookup = gridView1.ActiveEditor as LookUpEdit;
                //    if (cbolookup != null)
                //    {
                //        DataRowView drSelected = cbolookup.GetSelectedDataRow() as DataRowView;
                //        if (drSelected != null)
                //        {
                //            gridView1.SetFocusedRowCellValue(peminjamanid, drSelected[peminjamanid.FieldName]);
                //            gridView1.SetFocusedRowCellValue(tarif, drSelected[tarif.FieldName]);
                //            gridView1.SetFocusedRowCellValue(tarif_pajak, drSelected[tarif_pajak.FieldName]);
                //        }
                //    }
                //}
            }
            catch
            {
            }
        }

        private void cboProgram_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            try
            {
                if (e.Button.Kind == DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)
                {
                    frmAddNewRepositoryLib frmlib = new frmAddNewRepositoryLib();
                    frmlib.pkey = "programid";
                    frmlib.fieldname = "namaprogram";
                    frmlib.table_name = "tbp_program";
                    frmlib.ShowDialog();
                    loadRepository();
                }
            }
            catch
            {
            }
        }
        private void cboProgram_EditValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (pEdit) return; cbo_EditValueChanged(sender, e);
                if (lookupEditAnggota.Enabled && dgData.Enabled && gridView1.RowCount > 0)
                {
                    loadDataKaryawanTarif();
                }
            }
            catch
            {
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (datetglpinjam.EditValue == null)
            {
                XtraMessageBox.Show("Tanggal Peminjaman tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                datetglpinjam.Focus();
                return;
            }
            else if (datetgljatuhtempo.EditValue == null)
            {
                XtraMessageBox.Show("Tanggal Jatuh Tempo tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                datetgljatuhtempo.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtmaksbukudipinjam.Text))
            {
                XtraMessageBox.Show("Maks Buku dipinjam tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtmaksbukudipinjam.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtlamapeminjaman.Text))
            {
                XtraMessageBox.Show("Lama Peminjaman tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtlamapeminjaman.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(lookupEditAnggota.EditValue + ""))
            {
                XtraMessageBox.Show("Silahkan Scan Kartu Anggota terlebih dahulu!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                lookupEditAnggota.Focus();
                return;
            }
            DataRowView drSelected = cboNIB.GetSelectedDataRow() as DataRowView;
            if (drSelected != null)
            {
                DataTable dt = dgData.DataSource as DataTable;
                if (dt != null)
                {
                    bool bolBukuExist = false;
                    DataView dv = dt.DefaultView as DataView;
                    if (dv != null)
                    {
                        dv.RowFilter = "inventarisid='" + Convert.ToString(drSelected["inventarisid"]) + @"'";
                        if (dv.Count > 0)
                        {
                            bolBukuExist = true;
                            dv[0]["jumlah"] = clsGlobal.GetParseInt(dv[0]["jumlah"]) + clsGlobal.GetParseInt(txtjumlah.Text);
                        }
                        dv.RowFilter = "";
                    }
                    if (bolBukuExist == false)
                    {
                        DataRow dr = dt.NewRow();
                        dr["inventarisid"] = Convert.ToString(drSelected["inventarisid"]);
                        dr["pengadaanid"] = Convert.ToString(drSelected["pengadaanid"]);
                        dr["nib"] = Convert.ToString(drSelected["nib"]);
                        dr["kodepanggil"] = Convert.ToString(drSelected["kodepanggil"]);
                        dr["judul"] = Convert.ToString(drSelected["judul"]);
                        dr["pengarang"] = Convert.ToString(drSelected["pengarang"]);
                        dr["badankorporat"] = Convert.ToString(drSelected["badankorporat"]);
                        dr["edisi"] = Convert.ToString(drSelected["edisi"]);
                        dr["penerbit"] = Convert.ToString(drSelected["penerbit"]);
                        dr["tempatterbit"] = Convert.ToString(drSelected["tempatterbit"]);
                        dr["tahunterbit"] = Convert.ToString(drSelected["tahunterbit"]);
                        dr["isbn"] = Convert.ToString(drSelected["isbn"]);
                        dr["deskripsi"] = Convert.ToString(drSelected["deskripsi"]);
                        dr["supplemen"] = Convert.ToString(drSelected["supplemen"]);
                        dr["lokasikoleksi"] = Convert.ToString(drSelected["lokasikoleksi"]);
                        dr["jeniskoleksi"] = Convert.ToString(drSelected["jeniskoleksi"]);
                        dr["jumlah"] = clsGlobal.GetParseInt(txtjumlah.Text);
                        dr["tglpinjam"] = clsGlobal.GetParseDate(datetglpinjam.EditValue);
                        dr["tgljatuhtempo"] = clsGlobal.GetParseDate(datetgljatuhtempo.EditValue);

                        dt.Rows.Add(dr);
                    }
                }

            }
        }

        public void lookupEditAnggota_EditValueChanged(object sender, EventArgs e)
        {
            LookUpEdit cbolookup = sender as LookUpEdit;
            if (cbolookup != null)
            {
                DataRow drSelected = cbolookup.GetSelectedDataRow() as DataRow;
                if (drSelected == null)
                {
                    DataTable dtx = cbolookup.Properties.DataSource as DataTable;
                    foreach (DataRow dr in dtx.Select("anggotaid='" + Convert.ToString(cbolookup.EditValue) + "'"))
                    {
                        drSelected = dr;
                    }
                }
                if (drSelected != null)
                {

                    lblnamaanggota.Text = Convert.ToString(drSelected["nama"]);
                    lblnimanggota.Text = "NIM/NIK : " + Convert.ToString(drSelected["nim"]);
                    labelControl10.Text = Convert.ToString(drSelected["jenis"]);
                    labelControl5.Text = "Alamat : " + Convert.ToString(drSelected["alamat"]);

                    if (drSelected["photo"] != null && Convert.ToString(drSelected["photo"]) != "")
                    {
                        pictureBox2.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + drSelected["photo"];
                    }
                    else
                    {
                        pictureBox2.Image = pictureBox2.InitialImage;
                    }
                }
                lookUpEditNamaAnggota.EditValue = cbolookup.EditValue;
                if (!bolLoading)
                    bolsave = false;

                loadDataBukuBelumKembali();
            }
        }
        private void lookUpEditNamaAnggota_EditValueChanged(object sender, EventArgs e)
        {
            LookUpEdit cbolookup = sender as LookUpEdit;
            if (cbolookup != null)
            {
                DataRow drSelected = cbolookup.GetSelectedDataRow() as DataRow;
                if (drSelected == null)
                {
                    DataTable dtx = cbolookup.Properties.DataSource as DataTable;
                    foreach (DataRow dr in dtx.Select("anggotaid='" + Convert.ToString(cbolookup.EditValue) + "'"))
                    {
                        drSelected = dr;
                    }
                }
                if (drSelected != null)
                {
                    lblnamaanggota.Text = Convert.ToString(drSelected["nama"]);
                    lblnimanggota.Text = "NIM/NIK : " + Convert.ToString(drSelected["nim"]);
                    labelControl10.Text = Convert.ToString(drSelected["jenis"]);
                    labelControl5.Text = "Alamat : " + Convert.ToString(drSelected["alamat"]);

                    if (drSelected["photo"] != null && Convert.ToString(drSelected["photo"]) != "")
                    {
                        pictureBox2.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + drSelected["photo"];
                    }
                    else
                    {
                        pictureBox2.Image = pictureBox2.InitialImage;
                    }
                }
                lookupEditAnggota.EditValue = cbolookup.EditValue;
                if (!bolLoading)
                    bolsave = false;
            }
        }
        public void lookupEditPetugas_EditValueChanged(object sender, EventArgs e)
        {
            LookUpEdit cbolookup = sender as LookUpEdit;
            if (cbolookup != null)
            {
                DataRow drSelected = cbolookup.GetSelectedDataRow() as DataRow;

                if (drSelected == null)
                {
                    DataTable dtx = cbolookup.Properties.DataSource as DataTable;
                    foreach (DataRow dr in dtx.Select("petugasid='" + Convert.ToString(cbolookup.EditValue) + "'"))
                    {
                        drSelected = dr;
                    }
                }


                if (drSelected != null)
                {
                    txtnamapetugas.Text = Convert.ToString(drSelected["namapetugas"]);
                    if (drSelected["photo"] != null && Convert.ToString(drSelected["photo"]) != "")
                    {
                        pictureBox1.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + drSelected["photo"];
                    }
                    else
                    {
                        pictureBox1.Image = pictureBox1.InitialImage;
                    }
                }
                if (!bolLoading)
                    bolsave = false;
            }
        }

        private void btnKetentuanPeminjaman_Click(object sender, EventArgs e)
        {
            DIGILIB.Utility.Perpus.frmKetentuanPeminjaman fKetentuanPeminjaman = new Utility.Perpus.frmKetentuanPeminjaman();
            fKetentuanPeminjaman.ShowDialog();
            loadKetentuanPeminjaman();
            setKetentuanPeminjaman();
        }

        private void txtlamapeminjaman_Validated(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtlamapeminjaman.Text) && datetglpinjam.EditValue != null)
                {
                    datetgljatuhtempo.EditValue = getTglJatuhTempo(clsGlobal.GetParseDate(datetglpinjam.EditValue), clsGlobal.GetParseInt(txtlamapeminjaman.Text));
                }
            }
            catch
            {

            }
        }

        private void btnNotaPeminjamanBaru_Click(object sender, EventArgs e)
        {
            CreateNewData();
        }

        private void btnPengembalian_Click(object sender, EventArgs e)
        {
            try
            {
                frmNewPeminjaman_Leave(sender, e);
                DateTime myDate;
                frmNewPengembalian frm = new frmNewPengembalian();
                frm.pEdit = false;
                frm.pstrpengembalianid = "";
                //frm.refreshAll();
                //frm.CreateNewData(); ;
                //if (string.IsNullOrEmpty(frm.pstrpeminjamanid))
                //{

                //}
                frm.bolLoading = true;
                frm.refreshAll();

                frm.lookupEditAnggota.EditValue = lookupEditAnggota.EditValue;
                frm.lookUpEditNamaAnggota.EditValue = lookUpEditNamaAnggota.EditValue;
                frm.lblnamaanggota.Text = lblnamaanggota.Text;
                frm.lblnimanggota.Text = lblnimanggota.Text;
                frm.labelControl10.Text = labelControl10.Text;
                frm.labelControl5.Text = labelControl5.Text;
                frm.pictureBox2.ImageLocation = pictureBox2.ImageLocation;

                frm.txtnopengembalian.EditValue = txtnopeminjaman.EditValue;

                frm.lookupEditPetugas.EditValue = lookupEditPetugas.EditValue;
                frm.txtnamapetugas.Text = txtnamapetugas.Text;
                frm.pictureBox1.ImageLocation = pictureBox1.ImageLocation;

                DateTime.TryParse(Convert.ToString(datetglpinjam.EditValue), out myDate);
                if (myDate == DateTime.MinValue)
                    frm.datetglpinjam.EditValue = null;
                else
                    frm.datetglpinjam.EditValue = myDate;

                myDate = clsGlobal.GetParseDate(datetgljatuhtempo.EditValue);
                if (myDate == DateTime.MinValue)
                    frm.datetgljatuhtempo.EditValue = null;
                else
                    frm.datetgljatuhtempo.EditValue = myDate;

                frm.txtlamapeminjaman.Text = Convert.ToString(txtlamapeminjaman.Text);
                frm.txtdendaperhari.Text = Convert.ToString(txtdendaperhari.Text);
                frm.txtmaksbukudipinjam.Text = Convert.ToString(txtmaksbukudipinjam.Text);

                frm.loadData(true);
                frm.enableControl(true);
                frm.ShowDialog();

                frm.Close();
                frm.Dispose();
                frmNewPeminjaman_Load(sender, e);
                //loadDataBukuBelumKembali();
                refreshAll();

            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        private void btnPembayaranDenda_Click(object sender, EventArgs e)
        {

        }

        private void frmNewPeminjaman_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void frmNewPeminjaman_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F3)
            {
                btnNotaPeminjamanBaru_Click(null, null);
            }
            else if (e.KeyData == Keys.F4)
            {
                btnPengembalian_Click(null, null);
            }
            else if (e.KeyData == Keys.F10)
            {
                btnSave_Click(null, null);
            }
        }

        private void gridView2_RowStyle(object sender, RowStyleEventArgs e)
        {
            setLateAppearance(sender, e);
        }
        private void setLateAppearance(object sender, RowStyleEventArgs e)
        {
            try
            {
                GridView gridview = sender as GridView;
                if (dateServer > clsGlobal.GetParseDate(gridview.GetRowCellValue(e.RowHandle, tgljatuhtempo)))
                {
                    e.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
                    //e.Appearance.BackColor = Color.LightYellow;
                    //e.Appearance.BackColor2 = Color.Yellow;
                    e.Appearance.BackColor = Color.OrangeRed;
                    e.Appearance.BackColor2 = Color.Red;
                    e.Appearance.ForeColor = Color.Black;
                    //e.Appearance.Font = new System.Drawing.Font("Trebuchet MS", 8.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

                }
            }
            catch
            {
            }

        }

        private void btnUpdateAnggota_Click(object sender, EventArgs e)
        {

            try
            {
                DataRowView drSelected = lookupEditAnggota.GetSelectedDataRow() as DataRowView;
                if (drSelected != null)
                {
                    frmAnggota frm = new frmAnggota();
                    frm.strID = Convert.ToString(drSelected["anggotaid"]);
                    frm.strJenis = Convert.ToString(drSelected["jenis"]);

                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        clsRepository oRepository = new clsRepository();
                        DataTable dtAnggota = oRepository.GetDataAnggota();
                        lookupEditAnggota.Properties.DataSource = dtAnggota;
                        lookUpEditNamaAnggota.Properties.DataSource = dtAnggota;

                        drSelected = lookupEditAnggota.GetSelectedDataRow() as DataRowView;
                        if (drSelected != null)
                        {
                            lblnamaanggota.Text = Convert.ToString(drSelected["nama"]);
                            lblnimanggota.Text = "NIM/NIK : " + Convert.ToString(drSelected["nim"]);
                            labelControl10.Text = Convert.ToString(drSelected["jenis"]);
                            labelControl5.Text = "Alamat : " + Convert.ToString(drSelected["alamat"]);

                            if (drSelected["photo"] != null && Convert.ToString(drSelected["photo"]) != "")
                            {
                                pictureBox2.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + drSelected["photo"];
                            }
                            else
                            {
                                pictureBox2.Image = pictureBox2.InitialImage;
                            }
                        }
                    }
                    frm.Close();
                    frm.Dispose();
                    frm = null;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }


        }

        private void btnStatusPeminjaman_Click(object sender, EventArgs e)
        {

        }


        #region TAG BUKU
        private void timerScan_Tick(object sender, EventArgs e)
        {
            try
            {
                byte state = 0;
                byte AFI = 0;
                byte[] DSFIDAndUID = new byte[9];
                byte cardNumber = 0;
                string strDSFIDAndUID = "";

                byte[] cmdData;
                byte[] respData = new byte[256];
                byte[] option = new byte[4];
                clsGlobal.fCmdRet = 0x30;
                string temp = "004400000303a304";
                byte errorCode = 0;
                byte respLength = 0, feedBackDataLength = 0;

                option = clsGlobal.HexStringToByteArray(temp.Substring(0, 8));
                respLength = Convert.ToByte(temp.Substring(8, 2), 16);

                cmdData = clsGlobal.HexStringToByteArray(temp.Substring(10, temp.Length - 10));

                int fCmdRetW = StaticClassReaderA.TransparentWrite(ref clsGlobal.comAddr, option, respLength, (byte)cmdData.Length, cmdData,
                                                          ref feedBackDataLength, respData, ref errorCode, clsGlobal.portIndex);

                int fCmdRetInv = StaticClassReaderA.Inventory(ref clsGlobal.comAddr, ref state, ref AFI, DSFIDAndUID, ref cardNumber, clsGlobal.portIndex);
                if (fCmdRetInv == 0)
                {
                    strDSFIDAndUID = clsGlobal.ByteArrayToHexString(DSFIDAndUID).Replace(" ", "");
                    if (!string.IsNullOrEmpty(strDSFIDAndUID))
                    {
                        timerScan.Enabled = false;
                        if (datetglpinjam.EditValue == null)
                        {
                            XtraMessageBox.Show("Tanggal Peminjaman tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            datetglpinjam.Focus();
                            return;
                        }
                        else if (datetgljatuhtempo.EditValue == null)
                        {
                            XtraMessageBox.Show("Tanggal Jatuh Tempo tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            datetgljatuhtempo.Focus();
                            return;
                        }
                        else if (string.IsNullOrEmpty(txtmaksbukudipinjam.Text))
                        {
                            XtraMessageBox.Show("Maks Buku dipinjam tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtmaksbukudipinjam.Focus();
                            return;
                        }
                        else if (string.IsNullOrEmpty(txtlamapeminjaman.Text))
                        {
                            XtraMessageBox.Show("Lama Peminjaman tidak boleh kosong, silahkan mengisi tanggal!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtlamapeminjaman.Focus();
                            return;
                        }
                        else if (string.IsNullOrEmpty(lookupEditAnggota.EditValue + ""))
                        {
                            XtraMessageBox.Show("Silahkan Scan Kartu Anggota terlebih dahulu!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lookupEditAnggota.Focus();
                            return;
                        }

                        foreach (DataRow drSelected in dtBuku.Select("rfid='" + strDSFIDAndUID + "'"))
                        {
                            DataTable dt = dgData.DataSource as DataTable;
                            if (dt != null)
                            {
                                bool bolBukuExist = false;
                                DataView dv = dt.DefaultView as DataView;
                                if (dv != null)
                                {
                                    dv.RowFilter = "inventarisid='" + Convert.ToString(drSelected["inventarisid"]) + @"'";
                                    if (dv.Count > 0)
                                    {
                                        bolBukuExist = true;
                                        dv.RowFilter = "";
                                        XtraMessageBox.Show("Buku sudah di pinjam!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        break;
                                        //dv[0]["jumlah"] = clsGlobal.GetParseInt(dv[0]["jumlah"]) + clsGlobal.GetParseInt(txtjumlah.Text);
                                    }
                                    dv.RowFilter = "";
                                }
                                if (bolBukuExist == false)
                                {
                                    DataRow dr = dt.NewRow();
                                    dr["inventarisid"] = Convert.ToString(drSelected["inventarisid"]);
                                    dr["rfid"] = Convert.ToString(drSelected["rfid"]);
                                    dr["nib"] = Convert.ToString(drSelected["nib"]);
                                    dr["pengadaanid"] = Convert.ToString(drSelected["pengadaanid"]);

                                    dr["kodepanggil"] = Convert.ToString(drSelected["kodepanggil"]);
                                    dr["judul"] = Convert.ToString(drSelected["judul"]);
                                    dr["pengarang"] = Convert.ToString(drSelected["pengarang"]);
                                    dr["badankorporat"] = Convert.ToString(drSelected["badankorporat"]);
                                    dr["edisi"] = Convert.ToString(drSelected["edisi"]);
                                    dr["penerbit"] = Convert.ToString(drSelected["penerbit"]);
                                    dr["tempatterbit"] = Convert.ToString(drSelected["tempatterbit"]);
                                    dr["tahunterbit"] = Convert.ToString(drSelected["tahunterbit"]);
                                    dr["isbn"] = Convert.ToString(drSelected["isbn"]);
                                    dr["deskripsi"] = Convert.ToString(drSelected["deskripsi"]);
                                    dr["supplemen"] = Convert.ToString(drSelected["supplemen"]);
                                    dr["lokasikoleksi"] = Convert.ToString(drSelected["lokasikoleksi"]);
                                    dr["jeniskoleksi"] = Convert.ToString(drSelected["jeniskoleksi"]);
                                    dr["jumlah"] = clsGlobal.GetParseInt(txtjumlah.Text);
                                    dr["tglpinjam"] = clsGlobal.GetParseDate(datetglpinjam.EditValue);
                                    dr["tgljatuhtempo"] = clsGlobal.GetParseDate(datetgljatuhtempo.EditValue);

                                    dt.Rows.Add(dr);
                                }
                            }
                            SaveData(false);
                            break;
                        }

                    }

                }

            }
            catch (Exception)
            {

            }
            finally
            {
                timerScan.Enabled = true;
            }
        }

        private void openPort()
        {
            if (Convert.ToDecimal(clsGlobal.portIndex) == -1)
            {
                clsGlobal.fCmdRet = StaticClassReaderA.AutoOpenComPort(ref clsGlobal.portNumber, ref clsGlobal.comAddr, clsGlobal.baud, ref clsGlobal.portIndex);
            }
        }

        private void closePort()
        {
            if (Convert.ToDecimal(clsGlobal.portIndex) != -1)
            {
                clsGlobal.fCmdRet = StaticClassReaderA.CloseSpecComPort(clsGlobal.portIndex);
                clsGlobal.portIndex = -1;
            }
        }
        #endregion

        private void frmNewPeminjaman_Load(object sender, EventArgs e)
        {
            openPort();
            timerScan.Enabled = true;
        }

        private void frmNewPeminjaman_Leave(object sender, EventArgs e)
        {
            timerScan.Enabled = false;
            closePort();
        }


        #region print receive
        private Font printFont;
        private StreamReader streamToPrint;
        public Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        public void btnPreview_Click(object sender, EventArgs e)
        {

            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";
                if (bolsave == false)
                {
                    if (XtraMessageBox.Show("Data sudah diubah. Apakah anda ingin menyimpan perubahan?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        btnSave_Click(null, null);
                    }
                    else
                    {
                        loadData(false);
                    }
                }
                filename = Application.StartupPath + @"\reports\rptNotaPeminjaman.repx";
                reportName = "rptNotaPeminjaman";



                frmMainReport mainReport = new frmMainReport();
                try
                {
                    DataTable dtMaster = dgData.DataSource as DataTable;
                    if (dtMaster != null)
                    {
                        //dtReport.TableName = "dtReportSource";
                        mainReport.reportName = reportName;

                        mainReport.printReportToThermalPrinter(filename, dtMaster);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                        btnPreview.Enabled = true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }

        }

        // The PrintPage event is raised for each page to be printed.
        private void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            float linesPerPage = 0;
            float yPos = 0;
            int count = 0;
            float leftMargin = (float)0.1;//ev.MarginBounds.Left;
            float topMargin = (float)0.1;//ev.MarginBounds.Top;
            string line = null;

            // Calculate the number of lines per page.
            linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);

            // Print each line of the file.
            while (count < linesPerPage &&
               ((line = streamToPrint.ReadLine()) != null))
            {
                yPos = topMargin + (count * printFont.GetHeight(ev.Graphics));
                ev.Graphics.DrawString(line, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
                count++;
            }

            // If more lines exist, print another page.
            if (line != null)
                ev.HasMorePages = true;
            else
                ev.HasMorePages = false;
        }
        #endregion

    }
}