﻿namespace DIGILIB.Transaksi
{
    partial class ucBookStatus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucBookStatus));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnExportExcel = new DevExpress.XtraEditors.SimpleButton();
            this.panelTgl = new DevExpress.XtraEditors.PanelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnLoad = new DevExpress.XtraEditors.SimpleButton();
            this.dateTanggal2 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.dateTanggal1 = new DevExpress.XtraEditors.DateEdit();
            this.btnPreview2 = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.inventarisid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bukuid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rownum = new DevExpress.XtraGrid.Columns.GridColumn();
            this.noinduk = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nib = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.isbn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jeniskoleksi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.status = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nim = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nama = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopeminjaman = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglpinjam = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglkembali = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tgljatuhtempo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.ribbonImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelTgl)).BeginInit();
            this.panelTgl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.btnExportExcel);
            this.panelControl1.Controls.Add(this.panelTgl);
            this.panelControl1.Controls.Add(this.btnPreview2);
            this.panelControl1.Controls.Add(this.btnClose);
            this.panelControl1.Controls.Add(this.dgData);
            this.panelControl1.Controls.Add(this.label1);
            this.panelControl1.Controls.Add(this.lblTitle);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1598, 761);
            this.panelControl1.TabIndex = 0;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportExcel.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExportExcel.Appearance.Options.UseFont = true;
            this.btnExportExcel.Image = global::DIGILIB.Properties.Resources.export_excel_icon;
            this.btnExportExcel.Location = new System.Drawing.Point(1227, 701);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(4);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(214, 54);
            this.btnExportExcel.TabIndex = 88;
            this.btnExportExcel.Text = "Export Excel";
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // panelTgl
            // 
            this.panelTgl.Controls.Add(this.labelControl1);
            this.panelTgl.Controls.Add(this.btnLoad);
            this.panelTgl.Controls.Add(this.dateTanggal2);
            this.panelTgl.Controls.Add(this.labelControl14);
            this.panelTgl.Controls.Add(this.dateTanggal1);
            this.panelTgl.Location = new System.Drawing.Point(14, 45);
            this.panelTgl.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelTgl.Name = "panelTgl";
            this.panelTgl.Size = new System.Drawing.Size(737, 40);
            this.panelTgl.TabIndex = 87;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(285, 7);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(65, 21);
            this.labelControl1.TabIndex = 108;
            this.labelControl1.Text = "Sampai :";
            // 
            // btnLoad
            // 
            this.btnLoad.Image = ((System.Drawing.Image)(resources.GetObject("btnLoad.Image")));
            this.btnLoad.Location = new System.Drawing.Point(554, 4);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(136, 31);
            this.btnLoad.TabIndex = 107;
            this.btnLoad.Text = "&Load Data";
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // dateTanggal2
            // 
            this.dateTanggal2.EditValue = null;
            this.dateTanggal2.Location = new System.Drawing.Point(358, 5);
            this.dateTanggal2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTanggal2.Name = "dateTanggal2";
            this.dateTanggal2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTanggal2.Properties.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal2.Properties.EditFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal2.Properties.Mask.EditMask = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTanggal2.Size = new System.Drawing.Size(150, 26);
            this.dateTanggal2.TabIndex = 105;
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(8, 9);
            this.labelControl14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(50, 21);
            this.labelControl14.TabIndex = 103;
            this.labelControl14.Text = "Mulai :";
            // 
            // dateTanggal1
            // 
            this.dateTanggal1.EditValue = null;
            this.dateTanggal1.Location = new System.Drawing.Point(63, 5);
            this.dateTanggal1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTanggal1.Name = "dateTanggal1";
            this.dateTanggal1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTanggal1.Properties.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal1.Properties.EditFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal1.Properties.Mask.EditMask = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTanggal1.Size = new System.Drawing.Size(150, 26);
            this.dateTanggal1.TabIndex = 0;
            this.dateTanggal1.EditValueChanged += new System.EventHandler(this.dateTanggal1_EditValueChanged);
            // 
            // btnPreview2
            // 
            this.btnPreview2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview2.Appearance.Options.UseFont = true;
            this.btnPreview2.Image = global::DIGILIB.Properties.Resources.Actions_print_preview_icon32;
            this.btnPreview2.Location = new System.Drawing.Point(1275, 701);
            this.btnPreview2.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreview2.Name = "btnPreview2";
            this.btnPreview2.Size = new System.Drawing.Size(166, 54);
            this.btnPreview2.TabIndex = 86;
            this.btnPreview2.Text = "Preview";
            this.btnPreview2.Visible = false;
            this.btnPreview2.Click += new System.EventHandler(this.btnPreview2_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(1449, 701);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 54);
            this.btnClose.TabIndex = 70;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Location = new System.Drawing.Point(0, 94);
            this.dgData.MainView = this.gridView1;
            this.dgData.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1,
            this.repositoryItemMemoEdit1});
            this.dgData.Size = new System.Drawing.Size(1596, 599);
            this.dgData.TabIndex = 66;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.Row.Options.UseTextOptions = true;
            this.gridView1.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.inventarisid,
            this.bukuid,
            this.rfid,
            this.rownum,
            this.noinduk,
            this.nib,
            this.judul,
            this.isbn,
            this.jeniskoleksi,
            this.status,
            this.nim,
            this.nama,
            this.nopeminjaman,
            this.tglpinjam,
            this.tglkembali,
            this.tgljatuhtempo});
            this.gridView1.GridControl = this.dgData;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.RowAutoHeight = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // inventarisid
            // 
            this.inventarisid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.inventarisid.AppearanceHeader.Options.UseFont = true;
            this.inventarisid.AppearanceHeader.Options.UseTextOptions = true;
            this.inventarisid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.inventarisid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.inventarisid.Caption = "inventarisid";
            this.inventarisid.FieldName = "inventarisid";
            this.inventarisid.Name = "inventarisid";
            // 
            // bukuid
            // 
            this.bukuid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bukuid.AppearanceHeader.Options.UseFont = true;
            this.bukuid.AppearanceHeader.Options.UseTextOptions = true;
            this.bukuid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bukuid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bukuid.Caption = "bukuid";
            this.bukuid.FieldName = "bukuid";
            this.bukuid.Name = "bukuid";
            // 
            // rfid
            // 
            this.rfid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid.AppearanceHeader.Options.UseFont = true;
            this.rfid.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid.Caption = "rfid";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 120;
            this.rfid.Name = "rfid";
            this.rfid.Width = 130;
            // 
            // rownum
            // 
            this.rownum.Caption = "No";
            this.rownum.FieldName = "rownum";
            this.rownum.MinWidth = 60;
            this.rownum.Name = "rownum";
            this.rownum.Visible = true;
            this.rownum.VisibleIndex = 0;
            this.rownum.Width = 80;
            // 
            // noinduk
            // 
            this.noinduk.Caption = "Bibli";
            this.noinduk.FieldName = "noinduk";
            this.noinduk.MinWidth = 150;
            this.noinduk.Name = "noinduk";
            this.noinduk.Visible = true;
            this.noinduk.VisibleIndex = 1;
            this.noinduk.Width = 150;
            // 
            // nib
            // 
            this.nib.Caption = "NIB";
            this.nib.FieldName = "nib";
            this.nib.MinWidth = 150;
            this.nib.Name = "nib";
            this.nib.Visible = true;
            this.nib.VisibleIndex = 2;
            this.nib.Width = 150;
            // 
            // judul
            // 
            this.judul.Caption = "Judul";
            this.judul.ColumnEdit = this.repositoryItemMemoEdit1;
            this.judul.FieldName = "judul";
            this.judul.MinWidth = 300;
            this.judul.Name = "judul";
            this.judul.Visible = true;
            this.judul.VisibleIndex = 3;
            this.judul.Width = 300;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // isbn
            // 
            this.isbn.Caption = "ISBN";
            this.isbn.FieldName = "isbn";
            this.isbn.MinWidth = 150;
            this.isbn.Name = "isbn";
            this.isbn.Visible = true;
            this.isbn.VisibleIndex = 4;
            this.isbn.Width = 150;
            // 
            // jeniskoleksi
            // 
            this.jeniskoleksi.Caption = "Ket";
            this.jeniskoleksi.FieldName = "jeniskoleksi";
            this.jeniskoleksi.MinWidth = 150;
            this.jeniskoleksi.Name = "jeniskoleksi";
            this.jeniskoleksi.Visible = true;
            this.jeniskoleksi.VisibleIndex = 5;
            this.jeniskoleksi.Width = 150;
            // 
            // status
            // 
            this.status.Caption = "Status";
            this.status.FieldName = "status";
            this.status.MinWidth = 150;
            this.status.Name = "status";
            this.status.Visible = true;
            this.status.VisibleIndex = 6;
            this.status.Width = 150;
            // 
            // nim
            // 
            this.nim.Caption = "NIM/NIK";
            this.nim.FieldName = "nim";
            this.nim.MinWidth = 180;
            this.nim.Name = "nim";
            this.nim.Visible = true;
            this.nim.VisibleIndex = 7;
            this.nim.Width = 180;
            // 
            // nama
            // 
            this.nama.Caption = "Nama";
            this.nama.FieldName = "nama";
            this.nama.MinWidth = 200;
            this.nama.Name = "nama";
            this.nama.Visible = true;
            this.nama.VisibleIndex = 8;
            this.nama.Width = 200;
            // 
            // nopeminjaman
            // 
            this.nopeminjaman.Caption = "No Peminjaman";
            this.nopeminjaman.FieldName = "nopeminjaman";
            this.nopeminjaman.MinWidth = 180;
            this.nopeminjaman.Name = "nopeminjaman";
            this.nopeminjaman.Visible = true;
            this.nopeminjaman.VisibleIndex = 9;
            this.nopeminjaman.Width = 180;
            // 
            // tglpinjam
            // 
            this.tglpinjam.AppearanceCell.Options.UseTextOptions = true;
            this.tglpinjam.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam.Caption = "Tgl Peminjaman";
            this.tglpinjam.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.tglpinjam.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglpinjam.FieldName = "tglpinjam";
            this.tglpinjam.MinWidth = 150;
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.Visible = true;
            this.tglpinjam.VisibleIndex = 10;
            this.tglpinjam.Width = 150;
            // 
            // tglkembali
            // 
            this.tglkembali.AppearanceCell.Options.UseTextOptions = true;
            this.tglkembali.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglkembali.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglkembali.Caption = "Tgl Pengembalian";
            this.tglkembali.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.tglkembali.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglkembali.FieldName = "tglkembali";
            this.tglkembali.MinWidth = 150;
            this.tglkembali.Name = "tglkembali";
            this.tglkembali.Visible = true;
            this.tglkembali.VisibleIndex = 11;
            this.tglkembali.Width = 150;
            // 
            // tgljatuhtempo
            // 
            this.tgljatuhtempo.AppearanceCell.Options.UseTextOptions = true;
            this.tgljatuhtempo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo.Caption = "Tgl Jatuh Tempo";
            this.tgljatuhtempo.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.tgljatuhtempo.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tgljatuhtempo.FieldName = "tgljatuhtempo";
            this.tgljatuhtempo.MinWidth = 150;
            this.tgljatuhtempo.Name = "tgljatuhtempo";
            this.tgljatuhtempo.Visible = true;
            this.tgljatuhtempo.VisibleIndex = 12;
            this.tgljatuhtempo.Width = 150;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(10, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1575, 1);
            this.label1.TabIndex = 62;
            this.label1.Text = "label1";
            // 
            // lblTitle
            // 
            this.lblTitle.AllowHtmlString = true;
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Location = new System.Drawing.Point(2, 2);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(130, 24);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Status Buku";
            // 
            // ribbonImageCollection
            // 
            this.ribbonImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollection.ImageStream")));
            this.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_Save_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_SaveAs_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Info_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(3, "remove-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(4, "close-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(5, "Copy16.png");
            this.ribbonImageCollection.Images.SetKeyName(6, "Paste16.png");
            this.ribbonImageCollection.Images.SetKeyName(7, "New Edit16.png");
            this.ribbonImageCollection.Images.SetKeyName(8, "New Remove64.png");
            this.ribbonImageCollection.Images.SetKeyName(9, "Paste.png");
            this.ribbonImageCollection.Images.SetKeyName(10, "Paste_dis.png");
            // 
            // ucBookStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucBookStatus";
            this.Size = new System.Drawing.Size(1598, 761);
            this.Load += new System.EventHandler(this.userControlCTR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelTgl)).EndInit();
            this.panelTgl.ResumeLayout(false);
            this.panelTgl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private System.Windows.Forms.Label label1;
        private DevExpress.Utils.ImageCollection ribbonImageCollection;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraGrid.Columns.GridColumn inventarisid;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        public DevExpress.XtraEditors.SimpleButton btnPreview2;
        private DevExpress.XtraEditors.PanelControl panelTgl;
        private DevExpress.XtraEditors.DateEdit dateTanggal2;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.DateEdit dateTanggal1;
        private DevExpress.XtraEditors.SimpleButton btnLoad;
        public DevExpress.XtraEditors.SimpleButton btnExportExcel;
        private DevExpress.XtraGrid.Columns.GridColumn noinduk;
        private DevExpress.XtraGrid.Columns.GridColumn nib;
        private DevExpress.XtraGrid.Columns.GridColumn judul;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn isbn;
        private DevExpress.XtraGrid.Columns.GridColumn jeniskoleksi;
        private DevExpress.XtraGrid.Columns.GridColumn status;
        private DevExpress.XtraGrid.Columns.GridColumn nim;
        private DevExpress.XtraGrid.Columns.GridColumn nama;
        private DevExpress.XtraGrid.Columns.GridColumn nopeminjaman;
        private DevExpress.XtraGrid.Columns.GridColumn tglpinjam;
        private DevExpress.XtraGrid.Columns.GridColumn tgljatuhtempo;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.Columns.GridColumn rownum;
        private DevExpress.XtraGrid.Columns.GridColumn tglkembali; 
        
    }
}
