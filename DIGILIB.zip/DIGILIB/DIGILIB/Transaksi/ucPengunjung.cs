﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.XtraEditors;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Drawing;
using DevExpress.XtraEditors.DXErrorProvider;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

using DevExpress.Utils;

namespace DIGILIB.Transaksi
{
    public partial class ucPengunjung : XtraUserControl
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;

        public ucPengunjung()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
        public override void Refresh()
        {
            base.Refresh();
            loadData();
        }
        private void loadData()
        {
            btnLoad.Enabled = false;
            setLoadDialog(true, "Loading data...");
            try
            {
                using (clsConnection oconn = new clsConnection())
                {
                    string strWhere = "";
                    if (Convert.ToString(dateTanggal1.EditValue) != "")
                    {
                        strWhere = " and a.time_second2::date>='" + clsGlobal.GetParseDate(dateTanggal1.EditValue).ToString("yyyy-MM-dd") + "'";
                    }
                    if (Convert.ToString(dateTanggal2.EditValue) != "")
                    {
                        strWhere += " and a.time_second2::date<='" + clsGlobal.GetParseDate(dateTanggal2.EditValue).ToString("yyyy-MM-dd") + "'";
                    }
                    string strSql = @"select row_number() over (order by a.time_second2) as rownum, 
                                    a.pengunjungid, a.anggotaid, a.cardno, a.pin, a.verified, a.doorid, a.eventtype, a.inoutstate, a.time_second, a.time_second2,
                                    b.rfid, b.nim, b.nama, b.jeniskelamin, b.prodiid,
                                    c.prodicode, c.prodidesc
                                    from tbl_pengunjung a
                                    left outer join tbm_anggota b on a.anggotaid=b.anggotaid
                                    left outer join tbm_prodi c on b.prodiid=c.prodiid
                                    where a.dlt='0' " + strWhere + @"
                                    order by a.time_second2;";
                    DataTable dt = oconn.GetData(strSql);
                    dgData.DataSource = dt;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
            btnLoad.Enabled = true;
        }

        private void userControlCTR_Load(object sender, EventArgs e)
        {
            //refreshAll();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        DataTable xdt;
        private void btnPreview2_Click(object sender, EventArgs e)
        {
            btnPreview2.Enabled = false;
            try
            {
                btnPreview2.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptTransaksiPeminjaman.repx";
                reportName = "rptTransaksiPeminjaman";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    List<string> peminjamanid_list = new List<string>();
                    if (xdt.Rows.Count > gridView1.RowCount)
                    {
                        int rowHandle;
                        for (int i = 0; i < gridView1.RowCount; i++)
                        {
                            rowHandle = gridView1.GetVisibleRowHandle(i);
                            if (!gridView1.IsGroupRow(rowHandle))
                            {
                                object key = gridView1.GetRowCellValue(rowHandle, pengunjungid);
                                if (key != null && key != DBNull.Value)
                                {
                                    if (!peminjamanid_list.Contains(key.ToString()))
                                        peminjamanid_list.Add(key.ToString());
                                }
                            }
                        }
                    }
                    string strsql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Peminjaman' as header2,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status, 
                            sum(pjdet.jumlah) as jumlah
                            from tblpeminjaman pj
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamanid=pj.peminjamanid and pjdet.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on bk.bukuid=inv.bukuid and bk.dlt='0'
                            where pj.dlt='0' " + (peminjamanid_list.Count > 0 ? string.Format(" and pj.peminjamanid in ( {0} )", "'" + String.Join("','", peminjamanid_list.ToArray()) + "'") : "") + @"
                            group by inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status
                            order by nib, judul, jeniskoleksi
                    ";
                    using (clsConnection oConn = new clsConnection())
                    {
                        DataTable dtReport = oConn.GetData(strsql);
                        dtReport.TableName = "tblReport";
                        mainReport.reportName = reportName;
                        mainReport.printReport(filename, dtReport);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview2.Enabled = true;
        }

        IntPtr h = IntPtr.Zero;
        private void btnLoad_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show(this, "Anda yakin untuk memindahkan data pengunjung pada Gate ke Database DIGILIB?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int ret = 0;        // Error ID number
                int BUFFERSIZE = 1 * 1024 * 1024;
                byte[] buffer = new byte[BUFFERSIZE];

                setLoadDialog(true, "Moving Data, Please wait..");
                btnLoad.Enabled = false;

                DateTime dateGate = new DateTime(1987, 2, 6);
                DateTime dateReal = new DateTime(2016, 10, 15);
                TimeSpan tsDif = dateReal - dateGate;

                if (IntPtr.Zero == h)
                {
                    h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                    if (h != IntPtr.Zero)
                    {
                        ret = clsC3100.GetDeviceData(h, ref buffer[0], BUFFERSIZE, "transaction", "*", "", "");
                        if (ret >= 0)
                        {
                            using (clsConnection oConn = new clsConnection())
                            {
                                string strSql = @"select a.anggotaid, a.rfid, a.nim, a.nama, a.jeniskelamin, a.prodiid, b.prodicode, b.prodidesc, substring(rfid,1,6) as rfid6
                                            from tbm_anggota a
                                            left outer join tbm_prodi b on a.prodiid=b.prodiid
                                            where a.dlt='0' 
                                            and coalesce(a.rfid,'') not in ('','0','-');";
                                DataTable dtData = oConn.GetData(strSql);
                                oConn.Open();

                                string strData = Encoding.Default.GetString(buffer);
                                DataTable dtDataGate = clsC3100.strGateTrxtoDatatable(strData);

                                dtDataGate.Columns.Add("anggotaid", typeof(string));
                                dtDataGate.Columns.Add("rfid2", typeof(string));
                                dtDataGate.Columns.Add("nim", typeof(string));
                                dtDataGate.Columns.Add("nama", typeof(string));
                                dtDataGate.Columns.Add("jeniskelamin", typeof(string));
                                dtDataGate.Columns.Add("prodiid", typeof(string));
                                dtDataGate.Columns.Add("prodicode", typeof(string));
                                dtDataGate.Columns.Add("prodidesc", typeof(string));

                                int iCount = dtDataGate.Rows.Count;
                                int iIndex = 1;
                                setLoadDialog(true, "Moving Data " + iIndex.ToString("#,##0") + " of " + iCount.ToString("#,##0"));

                                foreach (DataRow dr in dtDataGate.Rows)
                                {
                                    setLoadDialog(true, "Moving Data " + iIndex.ToString("#,##0") + " of " + iCount.ToString("#,##0"));
                                    string strRFID = dr["rfid"] + "";
                                    dtData.DefaultView.RowFilter = "rfid6 = '" + strRFID + "'";
                                    if (dtData.DefaultView.Count > 0)
                                    {
                                        dr["anggotaid"] = dtData.DefaultView[0]["anggotaid"];
                                        dr["rfid2"] = dtData.DefaultView[0]["rfid"];
                                        dr["nim"] = dtData.DefaultView[0]["nim"];
                                        dr["nama"] = dtData.DefaultView[0]["nama"];
                                        dr["jeniskelamin"] = dtData.DefaultView[0]["jeniskelamin"];
                                        dr["prodiid"] = dtData.DefaultView[0]["prodiid"];
                                        dr["prodicode"] = dtData.DefaultView[0]["prodicode"];
                                        dr["prodidesc"] = dtData.DefaultView[0]["prodidesc"];
                                    }
                                    tbl_pengunjung oPengunjung = new tbl_pengunjung();
                                    oPengunjung.Koneksi = oConn.Conn;
                                    oPengunjung.pengunjungid = oPengunjung.NewID();
                                    oPengunjung.anggotaid = dr["anggotaid"] + "";
                                    oPengunjung.cardno = dr["cardno"] + "";
                                    oPengunjung.pin = dr["pin"] + "";
                                    oPengunjung.verified = dr["verified"] + "";
                                    oPengunjung.doorid = dr["doorid"] + "";
                                    oPengunjung.eventtype = dr["eventtype"] + "";
                                    oPengunjung.inoutstate = dr["inoutstate"] + "";
                                    oPengunjung.time_second = clsGlobal.GetParseDecimal(dr["timesecond"]);
                                    oPengunjung.time_second2 = clsGlobal.GetParseDate(dr["timesecond2"]);
                                    oPengunjung.time_second2 += tsDif;
                                    oPengunjung.opadd = clsGlobal.strUserName;
                                    oPengunjung.pcadd = SystemInformation.ComputerName;
                                    oPengunjung.Insert();
                                    oPengunjung = null;
                                    iIndex++;
                                }

                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                clsC3100.DeleteDeviceData(h, "transaction", "*", "");

                                oConn.Close();
                            }

                            clsC3100.Disconnect(h);
                            h = IntPtr.Zero;

                            setLoadDialog(false, "");

                        }
                    }
                }
                setLoadDialog(false, "");
                btnLoad.Enabled = true;
            }
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            string sFilePath = clsGlobal.pstrAppPath;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Title = "Save as Excel Workbook";
            saveFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";

            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.FileName = "Pegunjung.xlsx";
            string strSheetName = "Pegunjung";

            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                if (clsGlobal.isFileOpened(saveFileDialog1.FileName))
                {
                    XtraMessageBox.Show(this, "Download fail, this file [" + saveFileDialog1.FileName + "] is currenlty opened", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                sFilePath = saveFileDialog1.FileName;

                if (saveFileDialog1.FilterIndex == 2)
                    gridView1.ExportToXlsx(sFilePath, new DevExpress.XtraPrinting.XlsxExportOptions { SheetName = strSheetName });
                else
                    gridView1.ExportToXls(sFilePath, new DevExpress.XtraPrinting.XlsExportOptions { SheetName = strSheetName });

                System.Diagnostics.Process.Start(sFilePath);

            }
        }

        private void dateTanggal1_EditValueChanged_1(object sender, EventArgs e)
        {
            if (Convert.ToString(dateTanggal1.EditValue) == "")
            {
                dateTanggal2.Properties.MinValue = DateTime.MinValue;
            }
            else
            {
                dateTanggal2.Properties.MinValue = clsGlobal.GetParseDate(dateTanggal1.EditValue);
            }
        }

        private void btnLoad2_Click(object sender, EventArgs e)
        {
            loadData();
        }

    }
}
