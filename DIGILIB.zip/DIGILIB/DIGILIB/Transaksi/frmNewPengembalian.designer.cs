﻿namespace DIGILIB.Transaksi
{
    partial class frmNewPengembalian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewPengembalian));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            this.GridLookUpEditCTR = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.repositoryItemGridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.LookUpEditEmp = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.peminjamandetailsid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.peminjamanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bukuid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kembalikan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.nib = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kodepanggil = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengarang = new DevExpress.XtraGrid.Columns.GridColumn();
            this.edisi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.penerbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jumlah = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tgljatuhtempo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.tglkembali = new DevExpress.XtraGrid.Columns.GridColumn();
            this.terlambat = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jumlahdenda = new DevExpress.XtraGrid.Columns.GridColumn();
            this.status = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.keterangan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglpinjam = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dendaperhari = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengembalianid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dendadibayar = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengembaliandetailsid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.inventarisid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cboTipePembimbing = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.LookUpEditMhs = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.lblnimanggota = new DevExpress.XtraEditors.LabelControl();
            this.txtnopengembalian = new DevExpress.XtraEditors.TextEdit();
            this.datetglpinjam = new DevExpress.XtraEditors.DateEdit();
            this.datetgljatuhtempo = new DevExpress.XtraEditors.DateEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.lblnamaanggota = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.lookupEditAnggota = new DevExpress.XtraEditors.LookUpEdit();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.btnDelete = new DevExpress.XtraEditors.SimpleButton();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.pBar = new DevExpress.XtraEditors.ProgressBarControl();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lookupEditPetugas = new DevExpress.XtraEditors.LookUpEdit();
            this.txtnamapetugas = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureEdit2 = new DevExpress.XtraEditors.PictureEdit();
            this.panelControl6 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.btnAdd = new DevExpress.XtraEditors.SimpleButton();
            this.cboNIB = new DevExpress.XtraEditors.GridLookUpEdit();
            this.gridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.inventarisid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bukuid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nib1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kodepanggil1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengarang1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.edisi1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.penerbit1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isbn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopeminjaman2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditNamaAnggota = new DevExpress.XtraEditors.LookUpEdit();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.btnKetentuanPeminjaman = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.txtmaksbukudipinjam = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.txtdendaperhari = new DevExpress.XtraEditors.TextEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtlamapeminjaman = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.lblTglKembali = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.btnStatusPeminjaman = new DevExpress.XtraEditors.SimpleButton();
            this.btnUpdateAnggota = new DevExpress.XtraEditors.SimpleButton();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopeminjaman = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglpinjam2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tgljatuhtempo2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengembalianid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jumlahdenda1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglkembali1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.peminjamandetailsid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.anggotaid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengembaliandetailsid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.inventarisid3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemGridLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.btnNotaPeminjamanBaru = new DevExpress.XtraEditors.SimpleButton();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.btnPembayaranDenda = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.lblJamKembali = new DevExpress.XtraEditors.LabelControl();
            this.groupControl5 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.txtTotalDendaDibayar = new DevExpress.XtraEditors.TextEdit();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.txtTotalDenda = new DevExpress.XtraEditors.TextEdit();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.txtDendaBukuHilang = new DevExpress.XtraEditors.TextEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.txtBiayaKeterlambatan = new DevExpress.XtraEditors.TextEdit();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.timerScan = new System.Windows.Forms.Timer(this.components);
            this.deTglKembali = new DevExpress.XtraEditors.DateEdit();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.tglDendaDibayar = new DevExpress.XtraEditors.DateEdit();
            ((System.ComponentModel.ISupportInitialize)(this.GridLookUpEditCTR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LookUpEditEmp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboTipePembimbing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LookUpEditMhs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnopengembalian.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpinjam.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpinjam.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetgljatuhtempo.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetgljatuhtempo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookupEditAnggota.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBar.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookupEditPetugas.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamapetugas.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).BeginInit();
            this.panelControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboNIB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditNamaAnggota.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaksbukudipinjam.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdendaperhari.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtlamapeminjaman.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).BeginInit();
            this.groupControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalDendaDibayar.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalDenda.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDendaBukuHilang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBiayaKeterlambatan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deTglKembali.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deTglKembali.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglDendaDibayar.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglDendaDibayar.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // GridLookUpEditCTR
            // 
            this.GridLookUpEditCTR.AutoHeight = false;
            this.GridLookUpEditCTR.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.GridLookUpEditCTR.DisplayMember = "ctrview";
            this.GridLookUpEditCTR.ImmediatePopup = true;
            this.GridLookUpEditCTR.Name = "GridLookUpEditCTR";
            this.GridLookUpEditCTR.NullText = "";
            this.GridLookUpEditCTR.ValueMember = "ctrid";
            this.GridLookUpEditCTR.View = this.repositoryItemGridLookUpEdit1View;
            // 
            // repositoryItemGridLookUpEdit1View
            // 
            this.repositoryItemGridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemGridLookUpEdit1View.Name = "repositoryItemGridLookUpEdit1View";
            this.repositoryItemGridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemGridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // LookUpEditEmp
            // 
            this.LookUpEditEmp.AutoHeight = false;
            this.LookUpEditEmp.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.LookUpEditEmp.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LookUpEditEmp.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("karyawanid", "karyawanid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nik", 80, "NIK"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namakaryawan", 200, "Nama Dosen"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("karyawan", "Dosen", 200, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("unitid", "unitid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("unitkode", "unitkode", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("unitnama", 200, "Unit")});
            this.LookUpEditEmp.DropDownRows = 15;
            this.LookUpEditEmp.Name = "LookUpEditEmp";
            this.LookUpEditEmp.NullText = "";
            this.LookUpEditEmp.PopupWidth = 500;
            // 
            // dgData
            // 
            this.dgData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Location = new System.Drawing.Point(2, 2);
            this.dgData.MainView = this.gridView1;
            this.dgData.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.LookUpEditEmp,
            this.GridLookUpEditCTR,
            this.cboTipePembimbing,
            this.LookUpEditMhs,
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemComboBox2});
            this.dgData.Size = new System.Drawing.Size(1174, 7);
            this.dgData.TabIndex = 11;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.dgData.FocusedViewChanged += new DevExpress.XtraGrid.ViewFocusEventHandler(this.dgData_FocusedViewChanged);
            // 
            // gridView1
            // 
            this.gridView1.Appearance.EvenRow.BackColor = System.Drawing.Color.MintCream;
            this.gridView1.Appearance.EvenRow.BackColor2 = System.Drawing.Color.MintCream;
            this.gridView1.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridView1.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView1.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7.5F, System.Drawing.FontStyle.Bold);
            this.gridView1.Appearance.FooterPanel.Options.UseFont = true;
            this.gridView1.Appearance.FooterPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.FooterPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Appearance.FooterPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.peminjamandetailsid,
            this.peminjamanid,
            this.bukuid,
            this.kembalikan,
            this.nib,
            this.kodepanggil,
            this.judul,
            this.pengarang,
            this.edisi,
            this.penerbit,
            this.jumlah,
            this.tgljatuhtempo,
            this.tglkembali,
            this.terlambat,
            this.jumlahdenda,
            this.status,
            this.keterangan,
            this.tglpinjam,
            this.dendaperhari,
            this.pengembalianid,
            this.dendadibayar,
            this.pengembaliandetailsid,
            this.inventarisid,
            this.rfid});
            this.gridView1.GridControl = this.dgData;
            this.gridView1.Name = "gridView1";
            this.gridView1.NewItemRowText = "Click here to add new data";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView1.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridView1.OptionsDetail.AllowOnlyOneMasterRowExpanded = true;
            this.gridView1.OptionsDetail.ShowDetailTabs = false;
            this.gridView1.OptionsDetail.SmartDetailHeight = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.setLockedAppearance);
            this.gridView1.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.gridView1_ShowingEditor);
            this.gridView1.ShownEditor += new System.EventHandler(this.gridView1_ShownEditor);
            this.gridView1.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridView1_CellValueChanged);
            this.gridView1.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridView1_ValidateRow);
            this.gridView1.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridView1_ValidatingEditor);
            // 
            // peminjamandetailsid
            // 
            this.peminjamandetailsid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.peminjamandetailsid.AppearanceHeader.Options.UseFont = true;
            this.peminjamandetailsid.AppearanceHeader.Options.UseTextOptions = true;
            this.peminjamandetailsid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.peminjamandetailsid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.peminjamandetailsid.Caption = "peminjamandetailsid";
            this.peminjamandetailsid.FieldName = "peminjamandetailsid";
            this.peminjamandetailsid.Name = "peminjamandetailsid";
            this.peminjamandetailsid.OptionsColumn.AllowEdit = false;
            this.peminjamandetailsid.OptionsColumn.TabStop = false;
            // 
            // peminjamanid
            // 
            this.peminjamanid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.peminjamanid.AppearanceHeader.Options.UseFont = true;
            this.peminjamanid.AppearanceHeader.Options.UseTextOptions = true;
            this.peminjamanid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.peminjamanid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.peminjamanid.Caption = "peminjamanid";
            this.peminjamanid.FieldName = "peminjamanid";
            this.peminjamanid.Name = "peminjamanid";
            this.peminjamanid.OptionsColumn.AllowEdit = false;
            this.peminjamanid.OptionsColumn.TabStop = false;
            this.peminjamanid.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.peminjamanid.Width = 382;
            // 
            // bukuid
            // 
            this.bukuid.AppearanceCell.Options.UseTextOptions = true;
            this.bukuid.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bukuid.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bukuid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bukuid.AppearanceHeader.Options.UseFont = true;
            this.bukuid.AppearanceHeader.Options.UseTextOptions = true;
            this.bukuid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bukuid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bukuid.Caption = "bukuid";
            this.bukuid.FieldName = "bukuid";
            this.bukuid.Name = "bukuid";
            this.bukuid.OptionsColumn.AllowEdit = false;
            this.bukuid.OptionsColumn.TabStop = false;
            this.bukuid.Width = 109;
            // 
            // kembalikan
            // 
            this.kembalikan.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.kembalikan.AppearanceCell.Options.UseFont = true;
            this.kembalikan.AppearanceCell.Options.UseTextOptions = true;
            this.kembalikan.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.kembalikan.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.kembalikan.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.kembalikan.AppearanceHeader.Options.UseFont = true;
            this.kembalikan.AppearanceHeader.Options.UseTextOptions = true;
            this.kembalikan.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.kembalikan.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.kembalikan.Caption = "Kembalikan";
            this.kembalikan.ColumnEdit = this.repositoryItemCheckEdit1;
            this.kembalikan.FieldName = "kembalikan";
            this.kembalikan.MaxWidth = 90;
            this.kembalikan.MinWidth = 90;
            this.kembalikan.Name = "kembalikan";
            this.kembalikan.Visible = true;
            this.kembalikan.VisibleIndex = 0;
            this.kembalikan.Width = 90;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit1_CheckedChanged);
            // 
            // nib
            // 
            this.nib.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nib.AppearanceHeader.Options.UseFont = true;
            this.nib.AppearanceHeader.Options.UseTextOptions = true;
            this.nib.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nib.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nib.Caption = "NIB";
            this.nib.FieldName = "nib";
            this.nib.MaxWidth = 140;
            this.nib.MinWidth = 140;
            this.nib.Name = "nib";
            this.nib.OptionsColumn.AllowEdit = false;
            this.nib.OptionsColumn.TabStop = false;
            this.nib.Visible = true;
            this.nib.VisibleIndex = 2;
            this.nib.Width = 140;
            // 
            // kodepanggil
            // 
            this.kodepanggil.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.kodepanggil.AppearanceHeader.Options.UseFont = true;
            this.kodepanggil.AppearanceHeader.Options.UseTextOptions = true;
            this.kodepanggil.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.kodepanggil.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.kodepanggil.Caption = "Kode Panggil";
            this.kodepanggil.FieldName = "kodepanggil";
            this.kodepanggil.Name = "kodepanggil";
            this.kodepanggil.OptionsColumn.AllowEdit = false;
            this.kodepanggil.OptionsColumn.TabStop = false;
            this.kodepanggil.Width = 132;
            // 
            // judul
            // 
            this.judul.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.judul.AppearanceHeader.Options.UseFont = true;
            this.judul.AppearanceHeader.Options.UseTextOptions = true;
            this.judul.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.judul.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.judul.Caption = "Judul";
            this.judul.FieldName = "judul";
            this.judul.MinWidth = 150;
            this.judul.Name = "judul";
            this.judul.OptionsColumn.AllowEdit = false;
            this.judul.OptionsColumn.TabStop = false;
            this.judul.Visible = true;
            this.judul.VisibleIndex = 3;
            this.judul.Width = 150;
            // 
            // pengarang
            // 
            this.pengarang.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.pengarang.AppearanceHeader.Options.UseFont = true;
            this.pengarang.AppearanceHeader.Options.UseTextOptions = true;
            this.pengarang.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.pengarang.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.pengarang.Caption = "Pengarang";
            this.pengarang.FieldName = "pengarang";
            this.pengarang.Name = "pengarang";
            this.pengarang.OptionsColumn.AllowEdit = false;
            this.pengarang.OptionsColumn.TabStop = false;
            this.pengarang.Width = 102;
            // 
            // edisi
            // 
            this.edisi.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.edisi.AppearanceHeader.Options.UseFont = true;
            this.edisi.AppearanceHeader.Options.UseTextOptions = true;
            this.edisi.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.edisi.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.edisi.Caption = "Edisi";
            this.edisi.FieldName = "edisi";
            this.edisi.Name = "edisi";
            this.edisi.OptionsColumn.AllowEdit = false;
            this.edisi.OptionsColumn.TabStop = false;
            this.edisi.Width = 70;
            // 
            // penerbit
            // 
            this.penerbit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.penerbit.AppearanceHeader.Options.UseFont = true;
            this.penerbit.AppearanceHeader.Options.UseTextOptions = true;
            this.penerbit.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.penerbit.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.penerbit.Caption = "Penerbit";
            this.penerbit.FieldName = "penerbit";
            this.penerbit.Name = "penerbit";
            this.penerbit.OptionsColumn.AllowEdit = false;
            this.penerbit.OptionsColumn.TabStop = false;
            this.penerbit.Width = 134;
            // 
            // jumlah
            // 
            this.jumlah.AppearanceCell.Options.UseTextOptions = true;
            this.jumlah.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jumlah.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jumlah.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.jumlah.AppearanceHeader.Options.UseFont = true;
            this.jumlah.AppearanceHeader.Options.UseTextOptions = true;
            this.jumlah.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jumlah.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jumlah.Caption = "Jumlah";
            this.jumlah.DisplayFormat.FormatString = "#,##0;(#,##0);#";
            this.jumlah.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.jumlah.FieldName = "jumlah";
            this.jumlah.MaxWidth = 100;
            this.jumlah.MinWidth = 80;
            this.jumlah.Name = "jumlah";
            this.jumlah.OptionsColumn.AllowEdit = false;
            this.jumlah.OptionsColumn.TabStop = false;
            this.jumlah.Visible = true;
            this.jumlah.VisibleIndex = 4;
            this.jumlah.Width = 80;
            // 
            // tgljatuhtempo
            // 
            this.tgljatuhtempo.AppearanceCell.Options.UseTextOptions = true;
            this.tgljatuhtempo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tgljatuhtempo.AppearanceHeader.Options.UseFont = true;
            this.tgljatuhtempo.AppearanceHeader.Options.UseTextOptions = true;
            this.tgljatuhtempo.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo.Caption = "Tgl Jatuh Tempo";
            this.tgljatuhtempo.ColumnEdit = this.repositoryItemDateEdit1;
            this.tgljatuhtempo.FieldName = "tgljatuhtempo";
            this.tgljatuhtempo.MaxWidth = 120;
            this.tgljatuhtempo.MinWidth = 100;
            this.tgljatuhtempo.Name = "tgljatuhtempo";
            this.tgljatuhtempo.OptionsColumn.AllowEdit = false;
            this.tgljatuhtempo.OptionsColumn.TabStop = false;
            this.tgljatuhtempo.Visible = true;
            this.tgljatuhtempo.VisibleIndex = 5;
            this.tgljatuhtempo.Width = 100;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDateEdit1.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit1.Mask.UseMaskAsDisplayFormat = true;
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDateEdit1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemDateEdit1_ButtonClick);
            // 
            // tglkembali
            // 
            this.tglkembali.AppearanceCell.Options.UseTextOptions = true;
            this.tglkembali.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglkembali.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglkembali.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tglkembali.AppearanceHeader.Options.UseFont = true;
            this.tglkembali.AppearanceHeader.Options.UseTextOptions = true;
            this.tglkembali.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglkembali.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglkembali.Caption = "Tgl Kembali";
            this.tglkembali.ColumnEdit = this.repositoryItemDateEdit1;
            this.tglkembali.FieldName = "tglkembali";
            this.tglkembali.MaxWidth = 120;
            this.tglkembali.MinWidth = 90;
            this.tglkembali.Name = "tglkembali";
            this.tglkembali.Visible = true;
            this.tglkembali.VisibleIndex = 6;
            this.tglkembali.Width = 90;
            // 
            // terlambat
            // 
            this.terlambat.AppearanceCell.Options.UseTextOptions = true;
            this.terlambat.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.terlambat.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.terlambat.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.terlambat.AppearanceHeader.Options.UseFont = true;
            this.terlambat.AppearanceHeader.Options.UseTextOptions = true;
            this.terlambat.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.terlambat.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.terlambat.Caption = "Terlambat";
            this.terlambat.DisplayFormat.FormatString = "#,##0;(#,##0);#";
            this.terlambat.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.terlambat.FieldName = "terlambat";
            this.terlambat.MaxWidth = 100;
            this.terlambat.MinWidth = 80;
            this.terlambat.Name = "terlambat";
            this.terlambat.OptionsColumn.AllowEdit = false;
            this.terlambat.OptionsColumn.TabStop = false;
            this.terlambat.Visible = true;
            this.terlambat.VisibleIndex = 7;
            this.terlambat.Width = 80;
            // 
            // jumlahdenda
            // 
            this.jumlahdenda.AppearanceCell.Options.UseTextOptions = true;
            this.jumlahdenda.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.jumlahdenda.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jumlahdenda.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.jumlahdenda.AppearanceHeader.Options.UseFont = true;
            this.jumlahdenda.AppearanceHeader.Options.UseTextOptions = true;
            this.jumlahdenda.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jumlahdenda.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jumlahdenda.Caption = "Denda";
            this.jumlahdenda.DisplayFormat.FormatString = "#,##0.##;(#,##0.##);#";
            this.jumlahdenda.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.jumlahdenda.FieldName = "jumlahdenda";
            this.jumlahdenda.MaxWidth = 100;
            this.jumlahdenda.MinWidth = 80;
            this.jumlahdenda.Name = "jumlahdenda";
            this.jumlahdenda.Visible = true;
            this.jumlahdenda.VisibleIndex = 8;
            this.jumlahdenda.Width = 80;
            // 
            // status
            // 
            this.status.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.status.AppearanceHeader.Options.UseFont = true;
            this.status.AppearanceHeader.Options.UseTextOptions = true;
            this.status.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.status.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.status.Caption = "Status";
            this.status.ColumnEdit = this.repositoryItemComboBox2;
            this.status.FieldName = "status";
            this.status.MaxWidth = 100;
            this.status.MinWidth = 80;
            this.status.Name = "status";
            this.status.Visible = true;
            this.status.VisibleIndex = 10;
            this.status.Width = 80;
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "",
            "Buku Hilang"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // keterangan
            // 
            this.keterangan.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.keterangan.AppearanceHeader.Options.UseFont = true;
            this.keterangan.AppearanceHeader.Options.UseTextOptions = true;
            this.keterangan.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.keterangan.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.keterangan.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.keterangan.Caption = "Keterangan";
            this.keterangan.FieldName = "keterangan";
            this.keterangan.MinWidth = 80;
            this.keterangan.Name = "keterangan";
            this.keterangan.Visible = true;
            this.keterangan.VisibleIndex = 9;
            this.keterangan.Width = 80;
            // 
            // tglpinjam
            // 
            this.tglpinjam.AppearanceCell.Options.UseTextOptions = true;
            this.tglpinjam.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tglpinjam.AppearanceHeader.Options.UseFont = true;
            this.tglpinjam.AppearanceHeader.Options.UseTextOptions = true;
            this.tglpinjam.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam.Caption = "Tgl Pinjam";
            this.tglpinjam.ColumnEdit = this.repositoryItemDateEdit1;
            this.tglpinjam.FieldName = "tglpinjam";
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.OptionsColumn.AllowEdit = false;
            this.tglpinjam.OptionsColumn.TabStop = false;
            // 
            // dendaperhari
            // 
            this.dendaperhari.Caption = "dendaperhari";
            this.dendaperhari.FieldName = "dendaperhari";
            this.dendaperhari.Name = "dendaperhari";
            // 
            // pengembalianid
            // 
            this.pengembalianid.Caption = "pengembalianid";
            this.pengembalianid.FieldName = "pengembalianid";
            this.pengembalianid.Name = "pengembalianid";
            // 
            // dendadibayar
            // 
            this.dendadibayar.Caption = "dendadibayar";
            this.dendadibayar.FieldName = "dendadibayar";
            this.dendadibayar.Name = "dendadibayar";
            // 
            // pengembaliandetailsid
            // 
            this.pengembaliandetailsid.Caption = "pengembaliandetailsid";
            this.pengembaliandetailsid.FieldName = "pengembaliandetailsid";
            this.pengembaliandetailsid.Name = "pengembaliandetailsid";
            // 
            // inventarisid
            // 
            this.inventarisid.Caption = "inventarisid";
            this.inventarisid.FieldName = "inventarisid";
            this.inventarisid.Name = "inventarisid";
            // 
            // rfid
            // 
            this.rfid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid.AppearanceHeader.Options.UseFont = true;
            this.rfid.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid.Caption = "RFID";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 120;
            this.rfid.Name = "rfid";
            this.rfid.Visible = true;
            this.rfid.VisibleIndex = 1;
            this.rfid.Width = 120;
            // 
            // cboTipePembimbing
            // 
            this.cboTipePembimbing.AutoHeight = false;
            this.cboTipePembimbing.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboTipePembimbing.Items.AddRange(new object[] {
            "",
            "Pembimbing Utama",
            "Pendamping"});
            this.cboTipePembimbing.Name = "cboTipePembimbing";
            this.cboTipePembimbing.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // LookUpEditMhs
            // 
            this.LookUpEditMhs.AutoHeight = false;
            this.LookUpEditMhs.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.LookUpEditMhs.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LookUpEditMhs.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("mahasiswaid", "mahasiswaid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nim", 100, "NIM"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namalengkap", 200, "Nama Lengkap")});
            this.LookUpEditMhs.Name = "LookUpEditMhs";
            this.LookUpEditMhs.NullText = "";
            this.LookUpEditMhs.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.LookUpEditMhs_EditValueChanging);
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(15, 35);
            this.labelControl12.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(114, 21);
            this.labelControl12.TabIndex = 94;
            this.labelControl12.Text = "Tanggal Pinjam";
            // 
            // lblnimanggota
            // 
            this.lblnimanggota.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnimanggota.Appearance.ForeColor = System.Drawing.Color.OliveDrab;
            this.lblnimanggota.Location = new System.Drawing.Point(158, 63);
            this.lblnimanggota.Margin = new System.Windows.Forms.Padding(4);
            this.lblnimanggota.Name = "lblnimanggota";
            this.lblnimanggota.Size = new System.Drawing.Size(6, 21);
            this.lblnimanggota.TabIndex = 92;
            this.lblnimanggota.Text = "-";
            // 
            // txtnopengembalian
            // 
            this.txtnopengembalian.EditValue = "0452";
            this.txtnopengembalian.Location = new System.Drawing.Point(3, 76);
            this.txtnopengembalian.Margin = new System.Windows.Forms.Padding(4);
            this.txtnopengembalian.Name = "txtnopengembalian";
            this.txtnopengembalian.Properties.Appearance.BackColor = System.Drawing.Color.Lavender;
            this.txtnopengembalian.Properties.Appearance.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.txtnopengembalian.Properties.Appearance.ForeColor = System.Drawing.Color.DarkGreen;
            this.txtnopengembalian.Properties.Appearance.Options.UseBackColor = true;
            this.txtnopengembalian.Properties.Appearance.Options.UseFont = true;
            this.txtnopengembalian.Properties.Appearance.Options.UseForeColor = true;
            this.txtnopengembalian.Properties.Appearance.Options.UseTextOptions = true;
            this.txtnopengembalian.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtnopengembalian.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtnopengembalian.Properties.AutoHeight = false;
            this.txtnopengembalian.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.txtnopengembalian.Size = new System.Drawing.Size(168, 37);
            this.txtnopengembalian.TabIndex = 3;
            // 
            // datetglpinjam
            // 
            this.datetglpinjam.EditValue = null;
            this.datetglpinjam.Location = new System.Drawing.Point(201, 35);
            this.datetglpinjam.Margin = new System.Windows.Forms.Padding(4);
            this.datetglpinjam.Name = "datetglpinjam";
            this.datetglpinjam.Properties.AllowMouseWheel = false;
            this.datetglpinjam.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datetglpinjam.Properties.DisplayFormat.FormatString = "dd MMM yyyy";
            this.datetglpinjam.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.datetglpinjam.Properties.EditFormat.FormatString = "dd MMM yyyy";
            this.datetglpinjam.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.datetglpinjam.Properties.Mask.EditMask = "dd MMM yyyy";
            this.datetglpinjam.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.datetglpinjam.Size = new System.Drawing.Size(174, 26);
            this.datetglpinjam.TabIndex = 4;
            this.datetglpinjam.EditValueChanged += new System.EventHandler(this.cbo_EditValueChanged);
            // 
            // datetgljatuhtempo
            // 
            this.datetgljatuhtempo.EditValue = null;
            this.datetgljatuhtempo.Location = new System.Drawing.Point(201, 102);
            this.datetgljatuhtempo.Margin = new System.Windows.Forms.Padding(4);
            this.datetgljatuhtempo.Name = "datetgljatuhtempo";
            this.datetgljatuhtempo.Properties.AllowMouseWheel = false;
            this.datetgljatuhtempo.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datetgljatuhtempo.Properties.DisplayFormat.FormatString = "dd MMM yyyy";
            this.datetgljatuhtempo.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.datetgljatuhtempo.Properties.EditFormat.FormatString = "dd MMM yyyy";
            this.datetgljatuhtempo.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.datetgljatuhtempo.Properties.Mask.EditMask = "dd MMM yyyy";
            this.datetgljatuhtempo.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.datetgljatuhtempo.Size = new System.Drawing.Size(174, 26);
            this.datetgljatuhtempo.TabIndex = 5;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(15, 75);
            this.labelControl6.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(95, 21);
            this.labelControl6.TabIndex = 95;
            this.labelControl6.Text = "Lama Pinjam";
            // 
            // lblnamaanggota
            // 
            this.lblnamaanggota.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnamaanggota.Appearance.ForeColor = System.Drawing.Color.OliveDrab;
            this.lblnamaanggota.Location = new System.Drawing.Point(158, 38);
            this.lblnamaanggota.Margin = new System.Windows.Forms.Padding(4);
            this.lblnamaanggota.Name = "lblnamaanggota";
            this.lblnamaanggota.Size = new System.Drawing.Size(7, 22);
            this.lblnamaanggota.TabIndex = 85;
            this.lblnamaanggota.Text = "-";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.BackColor = System.Drawing.Color.LightGreen;
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.Green;
            this.labelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl2.Location = new System.Drawing.Point(9, 145);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.labelControl2.Size = new System.Drawing.Size(212, 38);
            this.labelControl2.TabIndex = 12;
            this.labelControl2.Text = "RFID/TAG :";
            // 
            // lookupEditAnggota
            // 
            this.lookupEditAnggota.Location = new System.Drawing.Point(8, 189);
            this.lookupEditAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.lookupEditAnggota.Name = "lookupEditAnggota";
            this.lookupEditAnggota.Properties.Appearance.BackColor = System.Drawing.Color.Lavender;
            this.lookupEditAnggota.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11.5F);
            this.lookupEditAnggota.Properties.Appearance.ForeColor = System.Drawing.Color.DarkGreen;
            this.lookupEditAnggota.Properties.Appearance.Options.UseBackColor = true;
            this.lookupEditAnggota.Properties.Appearance.Options.UseFont = true;
            this.lookupEditAnggota.Properties.Appearance.Options.UseForeColor = true;
            this.lookupEditAnggota.Properties.AutoHeight = false;
            this.lookupEditAnggota.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus, "", -1, true, false, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject3, "", null, null, true)});
            this.lookupEditAnggota.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("anggotaid", "anggotaid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("rfid", 200, "RFID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nim", 100, "NIM/NIK"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nama", 200, "Nama")});
            this.lookupEditAnggota.Properties.ImmediatePopup = true;
            this.lookupEditAnggota.Properties.NullText = "";
            this.lookupEditAnggota.Properties.PopupSizeable = false;
            this.lookupEditAnggota.Size = new System.Drawing.Size(168, 28);
            this.lookupEditAnggota.TabIndex = 0;
            this.lookupEditAnggota.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.cboProgram_ButtonClick);
            this.lookupEditAnggota.EditValueChanged += new System.EventHandler(this.lookupEditAnggota_EditValueChanged);
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureEdit1.EditValue = ((object)(resources.GetObject("pictureEdit1.EditValue")));
            this.pictureEdit1.Location = new System.Drawing.Point(701, 0);
            this.pictureEdit1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit1.Size = new System.Drawing.Size(472, 58);
            this.pictureEdit1.TabIndex = 89;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(4, 85);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(170, 21);
            this.labelControl1.TabIndex = 11;
            this.labelControl1.Text = "Pengurus/Pustakawan:";
            // 
            // panelControl2
            // 
            this.panelControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl2.Controls.Add(this.dgData);
            this.panelControl2.Location = new System.Drawing.Point(0, 506);
            this.panelControl2.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(1178, 11);
            this.panelControl2.TabIndex = 1;
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Appearance.Options.UseFont = true;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(495, 582);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(144, 37);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "Hapus";
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSave.Appearance.Options.UseFont = true;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(153, 519);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(332, 37);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Simpan Pengembalian (F10)";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pBar
            // 
            this.pBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pBar.Location = new System.Drawing.Point(881, 12);
            this.pBar.Margin = new System.Windows.Forms.Padding(4);
            this.pBar.Name = "pBar";
            this.pBar.Properties.ShowTitle = true;
            this.pBar.Properties.Step = 1;
            this.pBar.Size = new System.Drawing.Size(290, 26);
            this.pBar.TabIndex = 83;
            this.pBar.Visible = false;
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPreview.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Appearance.Options.UseFont = true;
            this.btnPreview.Image = ((System.Drawing.Image)(resources.GetObject("btnPreview.Image")));
            this.btnPreview.Location = new System.Drawing.Point(495, 621);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(144, 37);
            this.btnPreview.TabIndex = 15;
            this.btnPreview.Text = "Cetak Struk";
            this.btnPreview.Visible = false;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // panelControl3
            // 
            this.panelControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl3.Controls.Add(this.pictureBox1);
            this.panelControl3.Controls.Add(this.lookupEditPetugas);
            this.panelControl3.Controls.Add(this.txtnamapetugas);
            this.panelControl3.Controls.Add(this.labelControl3);
            this.panelControl3.Controls.Add(this.labelControl1);
            this.panelControl3.Location = new System.Drawing.Point(800, 519);
            this.panelControl3.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(373, 176);
            this.panelControl3.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::DIGILIB.Properties.Resources.imgunavail;
            this.pictureBox1.InitialImage = global::DIGILIB.Properties.Resources.imgunavail;
            this.pictureBox1.Location = new System.Drawing.Point(265, 22);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 119);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 100;
            this.pictureBox1.TabStop = false;
            // 
            // lookupEditPetugas
            // 
            this.lookupEditPetugas.Location = new System.Drawing.Point(4, 45);
            this.lookupEditPetugas.Margin = new System.Windows.Forms.Padding(4);
            this.lookupEditPetugas.Name = "lookupEditPetugas";
            this.lookupEditPetugas.Properties.AllowMouseWheel = false;
            this.lookupEditPetugas.Properties.Appearance.BackColor = System.Drawing.Color.Lavender;
            this.lookupEditPetugas.Properties.Appearance.Options.UseBackColor = true;
            this.lookupEditPetugas.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookupEditPetugas.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("petugasid", "petugasid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("rfid", 100, "RFID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nik", 100, "NIK"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namapetugas", 200, "Nama")});
            this.lookupEditPetugas.Properties.NullText = "";
            this.lookupEditPetugas.Size = new System.Drawing.Size(253, 26);
            this.lookupEditPetugas.TabIndex = 99;
            this.lookupEditPetugas.EditValueChanged += new System.EventHandler(this.lookupEditPetugas_EditValueChanged);
            // 
            // txtnamapetugas
            // 
            this.txtnamapetugas.Location = new System.Drawing.Point(4, 112);
            this.txtnamapetugas.Margin = new System.Windows.Forms.Padding(4);
            this.txtnamapetugas.Name = "txtnamapetugas";
            this.txtnamapetugas.Properties.Appearance.BackColor = System.Drawing.Color.Lavender;
            this.txtnamapetugas.Properties.Appearance.Options.UseBackColor = true;
            this.txtnamapetugas.Size = new System.Drawing.Size(253, 26);
            this.txtnamapetugas.TabIndex = 7;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Location = new System.Drawing.Point(8, 19);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(88, 21);
            this.labelControl3.TabIndex = 12;
            this.labelControl3.Text = "ID Petugas:";
            // 
            // panelControl4
            // 
            this.panelControl4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl4.Controls.Add(this.label1);
            this.panelControl4.Controls.Add(this.pictureEdit2);
            this.panelControl4.Controls.Add(this.pictureEdit1);
            this.panelControl4.Location = new System.Drawing.Point(0, 0);
            this.panelControl4.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(1178, 67);
            this.panelControl4.TabIndex = 95;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16F);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(100, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(560, 36);
            this.label1.TabIndex = 92;
            this.label1.Text = "Modul Sirkulasi -> Pengembalian Buku";
            // 
            // pictureEdit2
            // 
            this.pictureEdit2.EditValue = ((object)(resources.GetObject("pictureEdit2.EditValue")));
            this.pictureEdit2.Location = new System.Drawing.Point(0, 0);
            this.pictureEdit2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureEdit2.Name = "pictureEdit2";
            this.pictureEdit2.Properties.PictureAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.pictureEdit2.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit2.Size = new System.Drawing.Size(92, 67);
            this.pictureEdit2.TabIndex = 91;
            // 
            // panelControl6
            // 
            this.panelControl6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl6.Controls.Add(this.labelControl4);
            this.panelControl6.Controls.Add(this.btnAdd);
            this.panelControl6.Controls.Add(this.cboNIB);
            this.panelControl6.Controls.Add(this.pBar);
            this.panelControl6.Location = new System.Drawing.Point(0, 444);
            this.panelControl6.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl6.Name = "panelControl6";
            this.panelControl6.Size = new System.Drawing.Size(1178, 48);
            this.panelControl6.TabIndex = 3;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.BackColor = System.Drawing.Color.LightGreen;
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.Green;
            this.labelControl4.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl4.Location = new System.Drawing.Point(9, 7);
            this.labelControl4.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.labelControl4.Size = new System.Drawing.Size(110, 37);
            this.labelControl4.TabIndex = 13;
            this.labelControl4.Text = "NIB :";
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdd.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Appearance.Options.UseFont = true;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(646, 7);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(128, 37);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Tambah";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cboNIB
            // 
            this.cboNIB.Location = new System.Drawing.Point(128, 7);
            this.cboNIB.Margin = new System.Windows.Forms.Padding(4);
            this.cboNIB.Name = "cboNIB";
            this.cboNIB.Properties.AutoHeight = false;
            this.cboNIB.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboNIB.Properties.ImmediatePopup = true;
            this.cboNIB.Properties.NullText = "";
            this.cboNIB.Properties.PopupSizeable = false;
            this.cboNIB.Properties.View = this.gridLookUpEdit1View;
            this.cboNIB.Size = new System.Drawing.Size(507, 25);
            this.cboNIB.TabIndex = 8;
            this.cboNIB.EditValueChanged += new System.EventHandler(this.cbo_EditValueChanged);
            // 
            // gridLookUpEdit1View
            // 
            this.gridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.inventarisid1,
            this.bukuid1,
            this.nib1,
            this.rfid3,
            this.kodepanggil1,
            this.judul1,
            this.pengarang1,
            this.edisi1,
            this.penerbit1,
            this.isbn1,
            this.nopeminjaman2});
            this.gridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridLookUpEdit1View.GroupCount = 1;
            this.gridLookUpEdit1View.Name = "gridLookUpEdit1View";
            this.gridLookUpEdit1View.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.gridLookUpEdit1View.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.nopeminjaman2, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // inventarisid1
            // 
            this.inventarisid1.Caption = "inventarisid";
            this.inventarisid1.FieldName = "inventarisid";
            this.inventarisid1.Name = "inventarisid1";
            this.inventarisid1.Width = 42;
            // 
            // bukuid1
            // 
            this.bukuid1.Caption = "bukuid";
            this.bukuid1.FieldName = "bukuid";
            this.bukuid1.Name = "bukuid1";
            // 
            // nib1
            // 
            this.nib1.Caption = "No Induk";
            this.nib1.FieldName = "nib";
            this.nib1.Name = "nib1";
            this.nib1.Visible = true;
            this.nib1.VisibleIndex = 0;
            this.nib1.Width = 42;
            // 
            // rfid3
            // 
            this.rfid3.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid3.AppearanceHeader.Options.UseFont = true;
            this.rfid3.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid3.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid3.Caption = "RFID";
            this.rfid3.FieldName = "rfid";
            this.rfid3.MinWidth = 140;
            this.rfid3.Name = "rfid3";
            this.rfid3.Visible = true;
            this.rfid3.VisibleIndex = 7;
            this.rfid3.Width = 140;
            // 
            // kodepanggil1
            // 
            this.kodepanggil1.Caption = "Kode Panggil";
            this.kodepanggil1.FieldName = "kodepanggil";
            this.kodepanggil1.Name = "kodepanggil1";
            this.kodepanggil1.Visible = true;
            this.kodepanggil1.VisibleIndex = 1;
            this.kodepanggil1.Width = 42;
            // 
            // judul1
            // 
            this.judul1.Caption = "Judul";
            this.judul1.FieldName = "judul";
            this.judul1.Name = "judul1";
            this.judul1.Visible = true;
            this.judul1.VisibleIndex = 2;
            this.judul1.Width = 42;
            // 
            // pengarang1
            // 
            this.pengarang1.Caption = "Pengarang";
            this.pengarang1.FieldName = "pengarang";
            this.pengarang1.Name = "pengarang1";
            this.pengarang1.Visible = true;
            this.pengarang1.VisibleIndex = 3;
            this.pengarang1.Width = 42;
            // 
            // edisi1
            // 
            this.edisi1.Caption = "Edisi";
            this.edisi1.FieldName = "edisi";
            this.edisi1.Name = "edisi1";
            this.edisi1.Visible = true;
            this.edisi1.VisibleIndex = 4;
            this.edisi1.Width = 42;
            // 
            // penerbit1
            // 
            this.penerbit1.Caption = "Penerbit";
            this.penerbit1.FieldName = "penerbit";
            this.penerbit1.Name = "penerbit1";
            this.penerbit1.Visible = true;
            this.penerbit1.VisibleIndex = 5;
            this.penerbit1.Width = 42;
            // 
            // isbn1
            // 
            this.isbn1.Caption = "ISBN";
            this.isbn1.FieldName = "isbn";
            this.isbn1.Name = "isbn1";
            this.isbn1.Visible = true;
            this.isbn1.VisibleIndex = 6;
            this.isbn1.Width = 42;
            // 
            // nopeminjaman2
            // 
            this.nopeminjaman2.Caption = "No Peminjaman";
            this.nopeminjaman2.FieldName = "nopeminjaman";
            this.nopeminjaman2.Name = "nopeminjaman2";
            this.nopeminjaman2.Visible = true;
            this.nopeminjaman2.VisibleIndex = 7;
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.ForeColor = System.Drawing.Color.Maroon;
            this.groupControl1.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl1.Controls.Add(this.pictureBox2);
            this.groupControl1.Controls.Add(this.labelControl10);
            this.groupControl1.Controls.Add(this.labelControl5);
            this.groupControl1.Controls.Add(this.lblnamaanggota);
            this.groupControl1.Controls.Add(this.lblnimanggota);
            this.groupControl1.Location = new System.Drawing.Point(0, 234);
            this.groupControl1.Margin = new System.Windows.Forms.Padding(4);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(609, 170);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Informasi Peminjam / Anggota";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = global::DIGILIB.Properties.Resources.imgunavail;
            this.pictureBox2.InitialImage = global::DIGILIB.Properties.Resources.imgunavail;
            this.pictureBox2.Location = new System.Drawing.Point(9, 35);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(122, 131);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 98;
            this.pictureBox2.TabStop = false;
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.OliveDrab;
            this.labelControl10.Location = new System.Drawing.Point(158, 89);
            this.labelControl10.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(6, 21);
            this.labelControl10.TabIndex = 95;
            this.labelControl10.Text = "-";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.OliveDrab;
            this.labelControl5.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.labelControl5.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.labelControl5.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl5.Location = new System.Drawing.Point(158, 115);
            this.labelControl5.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(444, 51);
            this.labelControl5.TabIndex = 94;
            this.labelControl5.Text = "-";
            // 
            // lookUpEditNamaAnggota
            // 
            this.lookUpEditNamaAnggota.Location = new System.Drawing.Point(206, 189);
            this.lookUpEditNamaAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.lookUpEditNamaAnggota.Name = "lookUpEditNamaAnggota";
            this.lookUpEditNamaAnggota.Properties.Appearance.BackColor = System.Drawing.Color.Lavender;
            this.lookUpEditNamaAnggota.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11.5F);
            this.lookUpEditNamaAnggota.Properties.Appearance.ForeColor = System.Drawing.Color.DarkGreen;
            this.lookUpEditNamaAnggota.Properties.Appearance.Options.UseBackColor = true;
            this.lookUpEditNamaAnggota.Properties.Appearance.Options.UseFont = true;
            this.lookUpEditNamaAnggota.Properties.Appearance.Options.UseForeColor = true;
            this.lookUpEditNamaAnggota.Properties.AutoHeight = false;
            this.lookUpEditNamaAnggota.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus, "", -1, true, false, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.lookUpEditNamaAnggota.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("anggotaid", "anggotaid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("rfid", 200, "RFID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nim", 100, "NIM/NIK"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nama", 200, "Nama")});
            this.lookUpEditNamaAnggota.Properties.ImmediatePopup = true;
            this.lookUpEditNamaAnggota.Properties.NullText = "";
            this.lookUpEditNamaAnggota.Properties.PopupSizeable = false;
            this.lookUpEditNamaAnggota.Size = new System.Drawing.Size(404, 28);
            this.lookUpEditNamaAnggota.TabIndex = 96;
            this.lookUpEditNamaAnggota.EditValueChanged += new System.EventHandler(this.lookUpEditNamaAnggota_EditValueChanged);
            // 
            // groupControl2
            // 
            this.groupControl2.AppearanceCaption.ForeColor = System.Drawing.Color.Maroon;
            this.groupControl2.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl2.Controls.Add(this.btnKetentuanPeminjaman);
            this.groupControl2.Controls.Add(this.labelControl22);
            this.groupControl2.Controls.Add(this.txtmaksbukudipinjam);
            this.groupControl2.Controls.Add(this.labelControl21);
            this.groupControl2.Controls.Add(this.labelControl20);
            this.groupControl2.Controls.Add(this.labelControl18);
            this.groupControl2.Controls.Add(this.labelControl19);
            this.groupControl2.Controls.Add(this.txtdendaperhari);
            this.groupControl2.Controls.Add(this.labelControl17);
            this.groupControl2.Controls.Add(this.labelControl16);
            this.groupControl2.Controls.Add(this.labelControl15);
            this.groupControl2.Controls.Add(this.labelControl14);
            this.groupControl2.Controls.Add(this.labelControl13);
            this.groupControl2.Controls.Add(this.txtlamapeminjaman);
            this.groupControl2.Controls.Add(this.labelControl11);
            this.groupControl2.Controls.Add(this.labelControl12);
            this.groupControl2.Controls.Add(this.datetglpinjam);
            this.groupControl2.Controls.Add(this.datetgljatuhtempo);
            this.groupControl2.Controls.Add(this.labelControl6);
            this.groupControl2.Location = new System.Drawing.Point(614, 86);
            this.groupControl2.Margin = new System.Windows.Forms.Padding(4);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(448, 317);
            this.groupControl2.TabIndex = 97;
            this.groupControl2.Text = "Ketentuan Peminjaman Buku";
            // 
            // btnKetentuanPeminjaman
            // 
            this.btnKetentuanPeminjaman.Location = new System.Drawing.Point(14, 219);
            this.btnKetentuanPeminjaman.Margin = new System.Windows.Forms.Padding(4);
            this.btnKetentuanPeminjaman.Name = "btnKetentuanPeminjaman";
            this.btnKetentuanPeminjaman.Size = new System.Drawing.Size(264, 35);
            this.btnKetentuanPeminjaman.TabIndex = 110;
            this.btnKetentuanPeminjaman.Text = "Update Ketentuan Peminjaman";
            this.btnKetentuanPeminjaman.Click += new System.EventHandler(this.btnKetentuanPeminjaman_Click);
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl22.Location = new System.Drawing.Point(386, 175);
            this.labelControl22.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(38, 21);
            this.labelControl22.TabIndex = 109;
            this.labelControl22.Text = "Buku";
            // 
            // txtmaksbukudipinjam
            // 
            this.txtmaksbukudipinjam.Location = new System.Drawing.Point(201, 171);
            this.txtmaksbukudipinjam.Margin = new System.Windows.Forms.Padding(4);
            this.txtmaksbukudipinjam.Name = "txtmaksbukudipinjam";
            this.txtmaksbukudipinjam.Size = new System.Drawing.Size(174, 26);
            this.txtmaksbukudipinjam.TabIndex = 108;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl21.Location = new System.Drawing.Point(186, 175);
            this.labelControl21.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(6, 21);
            this.labelControl21.TabIndex = 107;
            this.labelControl21.Text = ":";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl20.Location = new System.Drawing.Point(14, 175);
            this.labelControl20.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(152, 21);
            this.labelControl20.TabIndex = 106;
            this.labelControl20.Text = "Maks. Buku dipinjam";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl18.Location = new System.Drawing.Point(186, 140);
            this.labelControl18.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(6, 21);
            this.labelControl18.TabIndex = 105;
            this.labelControl18.Text = ":";
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl19.Location = new System.Drawing.Point(382, 140);
            this.labelControl19.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(45, 21);
            this.labelControl19.TabIndex = 104;
            this.labelControl19.Text = "/ Hari";
            // 
            // txtdendaperhari
            // 
            this.txtdendaperhari.Location = new System.Drawing.Point(201, 136);
            this.txtdendaperhari.Margin = new System.Windows.Forms.Padding(4);
            this.txtdendaperhari.Name = "txtdendaperhari";
            this.txtdendaperhari.Size = new System.Drawing.Size(174, 26);
            this.txtdendaperhari.TabIndex = 103;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl17.Location = new System.Drawing.Point(14, 140);
            this.labelControl17.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(48, 21);
            this.labelControl17.TabIndex = 102;
            this.labelControl17.Text = "Denda";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Location = new System.Drawing.Point(186, 73);
            this.labelControl16.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(6, 21);
            this.labelControl16.TabIndex = 101;
            this.labelControl16.Text = ":";
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl15.Location = new System.Drawing.Point(186, 105);
            this.labelControl15.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(6, 21);
            this.labelControl15.TabIndex = 100;
            this.labelControl15.Text = ":";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(15, 105);
            this.labelControl14.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(171, 21);
            this.labelControl14.TabIndex = 99;
            this.labelControl14.Text = "Tanggal Harus Kembali";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(388, 73);
            this.labelControl13.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(33, 21);
            this.labelControl13.TabIndex = 98;
            this.labelControl13.Text = "Hari";
            // 
            // txtlamapeminjaman
            // 
            this.txtlamapeminjaman.Location = new System.Drawing.Point(201, 69);
            this.txtlamapeminjaman.Margin = new System.Windows.Forms.Padding(4);
            this.txtlamapeminjaman.Name = "txtlamapeminjaman";
            this.txtlamapeminjaman.Size = new System.Drawing.Size(174, 26);
            this.txtlamapeminjaman.TabIndex = 97;
            this.txtlamapeminjaman.Validated += new System.EventHandler(this.txtlamapeminjaman_Validated);
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(186, 39);
            this.labelControl11.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(6, 21);
            this.labelControl11.TabIndex = 96;
            this.labelControl11.Text = ":";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.OliveDrab;
            this.labelControl7.Location = new System.Drawing.Point(206, 73);
            this.labelControl7.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(234, 21);
            this.labelControl7.TabIndex = 98;
            this.labelControl7.Text = "Tanggal dan Jam Pengembalian";
            // 
            // lblTglKembali
            // 
            this.lblTglKembali.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTglKembali.Appearance.ForeColor = System.Drawing.Color.OliveDrab;
            this.lblTglKembali.Location = new System.Drawing.Point(206, 96);
            this.lblTglKembali.Margin = new System.Windows.Forms.Padding(4);
            this.lblTglKembali.Name = "lblTglKembali";
            this.lblTglKembali.Size = new System.Drawing.Size(150, 22);
            this.lblTglKembali.TabIndex = 99;
            this.lblTglKembali.Text = "Tanggal Kembali";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.BackColor = System.Drawing.Color.LightGreen;
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.Green;
            this.labelControl8.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl8.Location = new System.Drawing.Point(204, 145);
            this.labelControl8.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelControl8.Size = new System.Drawing.Size(405, 38);
            this.labelControl8.TabIndex = 100;
            this.labelControl8.Text = "Nama :";
            // 
            // btnStatusPeminjaman
            // 
            this.btnStatusPeminjaman.Location = new System.Drawing.Point(8, 408);
            this.btnStatusPeminjaman.Margin = new System.Windows.Forms.Padding(4);
            this.btnStatusPeminjaman.Name = "btnStatusPeminjaman";
            this.btnStatusPeminjaman.Size = new System.Drawing.Size(195, 29);
            this.btnStatusPeminjaman.TabIndex = 101;
            this.btnStatusPeminjaman.Text = "Status Peminjaman";
            // 
            // btnUpdateAnggota
            // 
            this.btnUpdateAnggota.Location = new System.Drawing.Point(210, 408);
            this.btnUpdateAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateAnggota.Name = "btnUpdateAnggota";
            this.btnUpdateAnggota.Size = new System.Drawing.Size(207, 29);
            this.btnUpdateAnggota.TabIndex = 102;
            this.btnUpdateAnggota.Text = "Update Data Anggota";
            this.btnUpdateAnggota.Click += new System.EventHandler(this.btnUpdateAnggota_Click);
            // 
            // groupControl3
            // 
            this.groupControl3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControl3.AppearanceCaption.ForeColor = System.Drawing.Color.Maroon;
            this.groupControl3.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl3.Controls.Add(this.gridControl1);
            this.groupControl3.Location = new System.Drawing.Point(1074, 86);
            this.groupControl3.Margin = new System.Windows.Forms.Padding(4);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(101, 317);
            this.groupControl3.TabIndex = 103;
            this.groupControl3.Text = "Daftar Buku dipinjam / Belum Kembali";
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.gridControl1.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gridControl1.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gridControl1.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gridControl1.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.gridControl1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl1.Location = new System.Drawing.Point(2, 27);
            this.gridControl1.MainView = this.gridView2;
            this.gridControl1.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit1,
            this.repositoryItemGridLookUpEdit1,
            this.repositoryItemComboBox1,
            this.repositoryItemLookUpEdit2,
            this.repositoryItemDateEdit2});
            this.gridControl1.Size = new System.Drawing.Size(97, 288);
            this.gridControl1.TabIndex = 12;
            this.gridControl1.UseEmbeddedNavigator = true;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.Appearance.EvenRow.BackColor = System.Drawing.Color.MintCream;
            this.gridView2.Appearance.EvenRow.BackColor2 = System.Drawing.Color.MintCream;
            this.gridView2.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridView2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView2.Appearance.FooterPanel.Font = new System.Drawing.Font("Verdana", 7.5F, System.Drawing.FontStyle.Bold);
            this.gridView2.Appearance.FooterPanel.Options.UseFont = true;
            this.gridView2.Appearance.FooterPanel.Options.UseTextOptions = true;
            this.gridView2.Appearance.FooterPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView2.Appearance.FooterPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.nopeminjaman,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn9,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.tglpinjam2,
            this.tgljatuhtempo2,
            this.pengembalianid1,
            this.jumlahdenda1,
            this.tglkembali1,
            this.peminjamandetailsid1,
            this.anggotaid1,
            this.pengembaliandetailsid1,
            this.inventarisid3,
            this.rfid2});
            this.gridView2.GridControl = this.gridControl1;
            this.gridView2.Name = "gridView2";
            this.gridView2.NewItemRowText = "Click here to add new data";
            this.gridView2.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView2.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView2.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView2.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridView2.OptionsDetail.AllowOnlyOneMasterRowExpanded = true;
            this.gridView2.OptionsDetail.ShowDetailTabs = false;
            this.gridView2.OptionsDetail.SmartDetailHeight = true;
            this.gridView2.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.gridView2.OptionsSelection.MultiSelect = true;
            this.gridView2.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            this.gridView2.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridView2_RowCellStyle);
            this.gridView2.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.setLateAppearance);
            this.gridView2.DoubleClick += new System.EventHandler(this.gridView2_DoubleClick);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn1.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn1.Caption = "peminjamandetailsid";
            this.gridColumn1.FieldName = "peminjamandetailsid";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.TabStop = false;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn2.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn2.Caption = "peminjamanid";
            this.gridColumn2.FieldName = "peminjamanid";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.TabStop = false;
            this.gridColumn2.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.gridColumn2.Width = 382;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn3.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn3.Caption = "bukuid";
            this.gridColumn3.FieldName = "bukuid";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsColumn.TabStop = false;
            this.gridColumn3.Width = 109;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn4.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn4.Caption = "Kode Panggil";
            this.gridColumn4.FieldName = "kodepanggil";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsColumn.TabStop = false;
            this.gridColumn4.Width = 132;
            // 
            // nopeminjaman
            // 
            this.nopeminjaman.AppearanceHeader.Options.UseTextOptions = true;
            this.nopeminjaman.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nopeminjaman.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nopeminjaman.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.nopeminjaman.Caption = "No Peminjaman";
            this.nopeminjaman.FieldName = "nopeminjaman";
            this.nopeminjaman.MinWidth = 90;
            this.nopeminjaman.Name = "nopeminjaman";
            this.nopeminjaman.OptionsColumn.AllowEdit = false;
            this.nopeminjaman.OptionsColumn.TabStop = false;
            this.nopeminjaman.Visible = true;
            this.nopeminjaman.VisibleIndex = 0;
            this.nopeminjaman.Width = 90;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn5.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn5.Caption = "NIB";
            this.gridColumn5.FieldName = "nib";
            this.gridColumn5.MinWidth = 120;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.TabStop = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 1;
            this.gridColumn5.Width = 120;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn6.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn6.Caption = "Judul";
            this.gridColumn6.FieldName = "judul";
            this.gridColumn6.MinWidth = 150;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.TabStop = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 3;
            this.gridColumn6.Width = 150;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn7.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn7.Caption = "Pengarang";
            this.gridColumn7.FieldName = "pengarang";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.TabStop = false;
            this.gridColumn7.Width = 102;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn9.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn9.Caption = "Penerbit";
            this.gridColumn9.FieldName = "penerbit";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.OptionsColumn.TabStop = false;
            this.gridColumn9.Width = 134;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn10.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn10.Caption = "Status";
            this.gridColumn10.FieldName = "status";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsColumn.TabStop = false;
            this.gridColumn10.Width = 83;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn11.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn11.Caption = "Jumlah";
            this.gridColumn11.FieldName = "jumlah";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowEdit = false;
            this.gridColumn11.OptionsColumn.TabStop = false;
            this.gridColumn11.Width = 44;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn12.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn12.Caption = "Keterangan";
            this.gridColumn12.FieldName = "keterangan";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.OptionsColumn.TabStop = false;
            this.gridColumn12.Width = 97;
            // 
            // tglpinjam2
            // 
            this.tglpinjam2.AppearanceCell.Options.UseTextOptions = true;
            this.tglpinjam2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam2.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam2.AppearanceHeader.Options.UseTextOptions = true;
            this.tglpinjam2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam2.Caption = "Tgl Pinjam";
            this.tglpinjam2.FieldName = "tglpinjam";
            this.tglpinjam2.MinWidth = 90;
            this.tglpinjam2.Name = "tglpinjam2";
            this.tglpinjam2.Visible = true;
            this.tglpinjam2.VisibleIndex = 4;
            this.tglpinjam2.Width = 90;
            // 
            // tgljatuhtempo2
            // 
            this.tgljatuhtempo2.AppearanceCell.Options.UseTextOptions = true;
            this.tgljatuhtempo2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo2.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo2.AppearanceHeader.Options.UseTextOptions = true;
            this.tgljatuhtempo2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo2.Caption = "Tgl Jatuh Tempo";
            this.tgljatuhtempo2.FieldName = "tgljatuhtempo";
            this.tgljatuhtempo2.MinWidth = 90;
            this.tgljatuhtempo2.Name = "tgljatuhtempo2";
            this.tgljatuhtempo2.Visible = true;
            this.tgljatuhtempo2.VisibleIndex = 5;
            this.tgljatuhtempo2.Width = 90;
            // 
            // pengembalianid1
            // 
            this.pengembalianid1.Caption = "pengembalianid";
            this.pengembalianid1.FieldName = "pengembalianid";
            this.pengembalianid1.Name = "pengembalianid1";
            // 
            // jumlahdenda1
            // 
            this.jumlahdenda1.Caption = "jumlahdenda";
            this.jumlahdenda1.FieldName = "jumlahdenda";
            this.jumlahdenda1.Name = "jumlahdenda1";
            // 
            // tglkembali1
            // 
            this.tglkembali1.Caption = "tglkembali";
            this.tglkembali1.FieldName = "tglkembali";
            this.tglkembali1.Name = "tglkembali1";
            // 
            // peminjamandetailsid1
            // 
            this.peminjamandetailsid1.Caption = "peminjamandetailsid";
            this.peminjamandetailsid1.FieldName = "peminjamandetailsid";
            this.peminjamandetailsid1.Name = "peminjamandetailsid1";
            // 
            // anggotaid1
            // 
            this.anggotaid1.Caption = "anggotaid";
            this.anggotaid1.FieldName = "anggotaid";
            this.anggotaid1.Name = "anggotaid1";
            // 
            // pengembaliandetailsid1
            // 
            this.pengembaliandetailsid1.Caption = "pengembaliandetailsid";
            this.pengembaliandetailsid1.FieldName = "pengembaliandetailsid";
            this.pengembaliandetailsid1.Name = "pengembaliandetailsid1";
            // 
            // inventarisid3
            // 
            this.inventarisid3.Caption = "inventarisid";
            this.inventarisid3.FieldName = "inventarisid";
            this.inventarisid3.Name = "inventarisid3";
            // 
            // rfid2
            // 
            this.rfid2.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid2.AppearanceHeader.Options.UseFont = true;
            this.rfid2.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid2.Caption = "RFID";
            this.rfid2.FieldName = "rfid";
            this.rfid2.MinWidth = 140;
            this.rfid2.Name = "rfid2";
            this.rfid2.Visible = true;
            this.rfid2.VisibleIndex = 2;
            this.rfid2.Width = 140;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("karyawanid", "karyawanid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nik", 80, "NIK"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namakaryawan", 200, "Nama Dosen"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("karyawan", "Dosen", 200, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("unitid", "unitid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("unitkode", "unitkode", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("unitnama", 200, "Unit")});
            this.repositoryItemLookUpEdit1.DropDownRows = 15;
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.NullText = "";
            this.repositoryItemLookUpEdit1.PopupWidth = 500;
            // 
            // repositoryItemGridLookUpEdit1
            // 
            this.repositoryItemGridLookUpEdit1.AutoHeight = false;
            this.repositoryItemGridLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemGridLookUpEdit1.DisplayMember = "ctrview";
            this.repositoryItemGridLookUpEdit1.ImmediatePopup = true;
            this.repositoryItemGridLookUpEdit1.Name = "repositoryItemGridLookUpEdit1";
            this.repositoryItemGridLookUpEdit1.NullText = "";
            this.repositoryItemGridLookUpEdit1.ValueMember = "ctrid";
            this.repositoryItemGridLookUpEdit1.View = this.gridView4;
            // 
            // gridView4
            // 
            this.gridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView4.Name = "gridView4";
            this.gridView4.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView4.OptionsView.ShowGroupPanel = false;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "",
            "Pembimbing Utama",
            "Pendamping"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            this.repositoryItemComboBox1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("mahasiswaid", "mahasiswaid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nim", 100, "NIM"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("namalengkap", 200, "Nama Lengkap")});
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            this.repositoryItemLookUpEdit2.NullText = "";
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit2.Mask.UseMaskAsDisplayFormat = true;
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            this.repositoryItemDateEdit2.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // btnNotaPeminjamanBaru
            // 
            this.btnNotaPeminjamanBaru.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNotaPeminjamanBaru.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnNotaPeminjamanBaru.Appearance.ForeColor = System.Drawing.Color.Navy;
            this.btnNotaPeminjamanBaru.Appearance.Options.UseFont = true;
            this.btnNotaPeminjamanBaru.Appearance.Options.UseForeColor = true;
            this.btnNotaPeminjamanBaru.Location = new System.Drawing.Point(153, 558);
            this.btnNotaPeminjamanBaru.Margin = new System.Windows.Forms.Padding(4);
            this.btnNotaPeminjamanBaru.Name = "btnNotaPeminjamanBaru";
            this.btnNotaPeminjamanBaru.Size = new System.Drawing.Size(332, 37);
            this.btnNotaPeminjamanBaru.TabIndex = 104;
            this.btnNotaPeminjamanBaru.Text = "NOTA / PENGEMBALIAN BARU (F3)";
            this.btnNotaPeminjamanBaru.Click += new System.EventHandler(this.btnNotaPeminjamanBaru_Click);
            // 
            // groupControl4
            // 
            this.groupControl4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupControl4.AppearanceCaption.ForeColor = System.Drawing.Color.Maroon;
            this.groupControl4.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl4.Controls.Add(this.labelControl24);
            this.groupControl4.Controls.Add(this.btnPembayaranDenda);
            this.groupControl4.Controls.Add(this.labelControl25);
            this.groupControl4.Controls.Add(this.labelControl26);
            this.groupControl4.Location = new System.Drawing.Point(8, 606);
            this.groupControl4.Margin = new System.Windows.Forms.Padding(4);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.ShowCaption = false;
            this.groupControl4.Size = new System.Drawing.Size(630, 88);
            this.groupControl4.TabIndex = 106;
            this.groupControl4.Text = "Informasi Peminjam / Anggota";
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl24.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.labelControl24.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.labelControl24.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl24.Location = new System.Drawing.Point(158, 115);
            this.labelControl24.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(476, 51);
            this.labelControl24.TabIndex = 94;
            this.labelControl24.Text = "Alamat : Batam Cente";
            // 
            // btnPembayaranDenda
            // 
            this.btnPembayaranDenda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPembayaranDenda.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPembayaranDenda.Appearance.ForeColor = System.Drawing.Color.Green;
            this.btnPembayaranDenda.Appearance.Options.UseFont = true;
            this.btnPembayaranDenda.Appearance.Options.UseForeColor = true;
            this.btnPembayaranDenda.Location = new System.Drawing.Point(380, 3);
            this.btnPembayaranDenda.Margin = new System.Windows.Forms.Padding(4);
            this.btnPembayaranDenda.Name = "btnPembayaranDenda";
            this.btnPembayaranDenda.Size = new System.Drawing.Size(248, 35);
            this.btnPembayaranDenda.TabIndex = 109;
            this.btnPembayaranDenda.Text = "PEMBAYARAN DENDA (F7)";
            this.btnPembayaranDenda.Visible = false;
            this.btnPembayaranDenda.Click += new System.EventHandler(this.btnPembayaranDenda_Click);
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl25.Location = new System.Drawing.Point(8, 7);
            this.labelControl25.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(135, 21);
            this.labelControl25.TabIndex = 85;
            this.labelControl25.Text = "Teknis Pengisian :";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl26.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.labelControl26.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl26.Location = new System.Drawing.Point(8, 31);
            this.labelControl26.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(615, 57);
            this.labelControl26.TabIndex = 92;
            this.labelControl26.Text = "Isi/scan RFID/TAG (atau ketik/cari nama anggota pada column NAMA ANGGOTA) kemudia" +
    "n dilanjutkan dengan mengisi/scan NIB dan kolom jumlah buku...";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(8, 519);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 75);
            this.btnClose.TabIndex = 107;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblJamKembali
            // 
            this.lblJamKembali.Appearance.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJamKembali.Appearance.ForeColor = System.Drawing.Color.Olive;
            this.lblJamKembali.Location = new System.Drawing.Point(206, 121);
            this.lblJamKembali.Margin = new System.Windows.Forms.Padding(4);
            this.lblJamKembali.Name = "lblJamKembali";
            this.lblJamKembali.Size = new System.Drawing.Size(98, 17);
            this.lblJamKembali.TabIndex = 108;
            this.lblJamKembali.Text = "Tanggal Kembali";
            this.lblJamKembali.Visible = false;
            // 
            // groupControl5
            // 
            this.groupControl5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControl5.AppearanceCaption.ForeColor = System.Drawing.Color.Maroon;
            this.groupControl5.AppearanceCaption.Options.UseForeColor = true;
            this.groupControl5.Controls.Add(this.tglDendaDibayar);
            this.groupControl5.Controls.Add(this.labelControl27);
            this.groupControl5.Controls.Add(this.txtTotalDendaDibayar);
            this.groupControl5.Controls.Add(this.labelControl31);
            this.groupControl5.Controls.Add(this.labelControl30);
            this.groupControl5.Controls.Add(this.labelControl29);
            this.groupControl5.Controls.Add(this.txtTotalDenda);
            this.groupControl5.Controls.Add(this.labelControl32);
            this.groupControl5.Controls.Add(this.labelControl23);
            this.groupControl5.Controls.Add(this.txtDendaBukuHilang);
            this.groupControl5.Controls.Add(this.labelControl28);
            this.groupControl5.Controls.Add(this.labelControl9);
            this.groupControl5.Controls.Add(this.txtBiayaKeterlambatan);
            this.groupControl5.Controls.Add(this.labelControl37);
            this.groupControl5.Location = new System.Drawing.Point(258, 519);
            this.groupControl5.Margin = new System.Windows.Forms.Padding(4);
            this.groupControl5.Name = "groupControl5";
            this.groupControl5.ShowCaption = false;
            this.groupControl5.Size = new System.Drawing.Size(534, 176);
            this.groupControl5.TabIndex = 110;
            this.groupControl5.Text = "Biaya Denda";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl27.Location = new System.Drawing.Point(220, 114);
            this.labelControl27.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(36, 21);
            this.labelControl27.TabIndex = 122;
            this.labelControl27.Text = "Rp. :";
            // 
            // txtTotalDendaDibayar
            // 
            this.txtTotalDendaDibayar.EditValue = "";
            this.txtTotalDendaDibayar.Location = new System.Drawing.Point(262, 110);
            this.txtTotalDendaDibayar.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalDendaDibayar.Name = "txtTotalDendaDibayar";
            this.txtTotalDendaDibayar.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTotalDendaDibayar.Properties.Appearance.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalDendaDibayar.Properties.Appearance.Options.UseBackColor = true;
            this.txtTotalDendaDibayar.Properties.Appearance.Options.UseFont = true;
            this.txtTotalDendaDibayar.Properties.Appearance.Options.UseTextOptions = true;
            this.txtTotalDendaDibayar.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtTotalDendaDibayar.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtTotalDendaDibayar.Properties.Mask.EditMask = "n0";
            this.txtTotalDendaDibayar.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtTotalDendaDibayar.Properties.Mask.ShowPlaceHolders = false;
            this.txtTotalDendaDibayar.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTotalDendaDibayar.Size = new System.Drawing.Size(254, 28);
            this.txtTotalDendaDibayar.TabIndex = 121;
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl30.Location = new System.Drawing.Point(16, 114);
            this.labelControl30.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(174, 21);
            this.labelControl30.TabIndex = 120;
            this.labelControl30.Text = "Total Denda Dibayar";
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl29.Location = new System.Drawing.Point(220, 80);
            this.labelControl29.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(36, 21);
            this.labelControl29.TabIndex = 119;
            this.labelControl29.Text = "Rp. :";
            // 
            // txtTotalDenda
            // 
            this.txtTotalDenda.EditValue = "";
            this.txtTotalDenda.Location = new System.Drawing.Point(262, 76);
            this.txtTotalDenda.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalDenda.Name = "txtTotalDenda";
            this.txtTotalDenda.Properties.Appearance.BackColor = System.Drawing.Color.Gold;
            this.txtTotalDenda.Properties.Appearance.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalDenda.Properties.Appearance.Options.UseBackColor = true;
            this.txtTotalDenda.Properties.Appearance.Options.UseFont = true;
            this.txtTotalDenda.Properties.Appearance.Options.UseTextOptions = true;
            this.txtTotalDenda.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtTotalDenda.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtTotalDenda.Properties.Mask.EditMask = "n0";
            this.txtTotalDenda.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtTotalDenda.Properties.Mask.ShowPlaceHolders = false;
            this.txtTotalDenda.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtTotalDenda.Properties.ReadOnly = true;
            this.txtTotalDenda.Size = new System.Drawing.Size(254, 28);
            this.txtTotalDenda.TabIndex = 117;
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl32.Location = new System.Drawing.Point(16, 80);
            this.labelControl32.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(103, 21);
            this.labelControl32.TabIndex = 116;
            this.labelControl32.Text = "Total Denda";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl23.Location = new System.Drawing.Point(220, 45);
            this.labelControl23.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(36, 21);
            this.labelControl23.TabIndex = 115;
            this.labelControl23.Text = "Rp. :";
            // 
            // txtDendaBukuHilang
            // 
            this.txtDendaBukuHilang.EditValue = "";
            this.txtDendaBukuHilang.Location = new System.Drawing.Point(262, 41);
            this.txtDendaBukuHilang.Margin = new System.Windows.Forms.Padding(4);
            this.txtDendaBukuHilang.Name = "txtDendaBukuHilang";
            this.txtDendaBukuHilang.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtDendaBukuHilang.Properties.Appearance.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDendaBukuHilang.Properties.Appearance.Options.UseBackColor = true;
            this.txtDendaBukuHilang.Properties.Appearance.Options.UseFont = true;
            this.txtDendaBukuHilang.Properties.Appearance.Options.UseTextOptions = true;
            this.txtDendaBukuHilang.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtDendaBukuHilang.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtDendaBukuHilang.Properties.Mask.EditMask = "n0";
            this.txtDendaBukuHilang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtDendaBukuHilang.Properties.Mask.ShowPlaceHolders = false;
            this.txtDendaBukuHilang.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtDendaBukuHilang.Properties.ReadOnly = true;
            this.txtDendaBukuHilang.Size = new System.Drawing.Size(254, 28);
            this.txtDendaBukuHilang.TabIndex = 113;
            this.txtDendaBukuHilang.TextChanged += new System.EventHandler(this.txtBiayaKeterlambatan_TextChanged);
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl28.Location = new System.Drawing.Point(16, 45);
            this.labelControl28.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(183, 21);
            this.labelControl28.TabIndex = 112;
            this.labelControl28.Text = "Total Denda Buku Hilang";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(220, 10);
            this.labelControl9.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(36, 21);
            this.labelControl9.TabIndex = 111;
            this.labelControl9.Text = "Rp. :";
            // 
            // txtBiayaKeterlambatan
            // 
            this.txtBiayaKeterlambatan.EditValue = "";
            this.txtBiayaKeterlambatan.Location = new System.Drawing.Point(262, 6);
            this.txtBiayaKeterlambatan.Margin = new System.Windows.Forms.Padding(4);
            this.txtBiayaKeterlambatan.Name = "txtBiayaKeterlambatan";
            this.txtBiayaKeterlambatan.Properties.Appearance.BackColor = System.Drawing.Color.Beige;
            this.txtBiayaKeterlambatan.Properties.Appearance.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBiayaKeterlambatan.Properties.Appearance.Options.UseBackColor = true;
            this.txtBiayaKeterlambatan.Properties.Appearance.Options.UseFont = true;
            this.txtBiayaKeterlambatan.Properties.Appearance.Options.UseTextOptions = true;
            this.txtBiayaKeterlambatan.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtBiayaKeterlambatan.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtBiayaKeterlambatan.Properties.Mask.EditMask = "n0";
            this.txtBiayaKeterlambatan.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBiayaKeterlambatan.Properties.Mask.ShowPlaceHolders = false;
            this.txtBiayaKeterlambatan.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtBiayaKeterlambatan.Size = new System.Drawing.Size(254, 28);
            this.txtBiayaKeterlambatan.TabIndex = 97;
            this.txtBiayaKeterlambatan.EditValueChanged += new System.EventHandler(this.txtBiayaKeterlambatan_EditValueChanged);
            this.txtBiayaKeterlambatan.TextChanged += new System.EventHandler(this.txtBiayaKeterlambatan_TextChanged);
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl37.Location = new System.Drawing.Point(15, 10);
            this.labelControl37.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(197, 21);
            this.labelControl37.TabIndex = 95;
            this.labelControl37.Text = "Total Biaya Keterlambatan";
            // 
            // timerScan
            // 
            this.timerScan.Interval = 1000;
            this.timerScan.Tick += new System.EventHandler(this.timerScan_Tick);
            // 
            // deTglKembali
            // 
            this.deTglKembali.EditValue = null;
            this.deTglKembali.Location = new System.Drawing.Point(206, 98);
            this.deTglKembali.Margin = new System.Windows.Forms.Padding(4);
            this.deTglKembali.Name = "deTglKembali";
            this.deTglKembali.Properties.AllowMouseWheel = false;
            this.deTglKembali.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deTglKembali.Properties.DisplayFormat.FormatString = "dd MMM yyyy  HH:mm:ss";
            this.deTglKembali.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.deTglKembali.Properties.EditFormat.FormatString = "dd MMM yyyy  HH:mm:ss";
            this.deTglKembali.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.deTglKembali.Properties.Mask.EditMask = "dd MMM yyyy  HH:mm:ss";
            this.deTglKembali.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deTglKembali.Size = new System.Drawing.Size(400, 26);
            this.deTglKembali.TabIndex = 111;
            this.deTglKembali.EditValueChanged += new System.EventHandler(this.deTglKembali_EditValueChanged);
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl31.Location = new System.Drawing.Point(16, 147);
            this.labelControl31.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(157, 21);
            this.labelControl31.TabIndex = 120;
            this.labelControl31.Text = "Tgl Denda Dibayar";
            // 
            // tglDendaDibayar
            // 
            this.tglDendaDibayar.EditValue = null;
            this.tglDendaDibayar.Location = new System.Drawing.Point(262, 144);
            this.tglDendaDibayar.Margin = new System.Windows.Forms.Padding(4);
            this.tglDendaDibayar.Name = "tglDendaDibayar";
            this.tglDendaDibayar.Properties.AllowMouseWheel = false;
            this.tglDendaDibayar.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.tglDendaDibayar.Properties.DisplayFormat.FormatString = "dd MMM yyyy";
            this.tglDendaDibayar.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglDendaDibayar.Properties.EditFormat.FormatString = "dd MMM yyyy";
            this.tglDendaDibayar.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglDendaDibayar.Properties.Mask.EditMask = "dd MMM yyyy";
            this.tglDendaDibayar.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.tglDendaDibayar.Size = new System.Drawing.Size(254, 26);
            this.tglDendaDibayar.TabIndex = 123;
            // 
            // frmNewPengembalian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 712);
            this.Controls.Add(this.deTglKembali);
            this.Controls.Add(this.groupControl5);
            this.Controls.Add(this.lblJamKembali);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupControl4);
            this.Controls.Add(this.btnNotaPeminjamanBaru);
            this.Controls.Add(this.groupControl3);
            this.Controls.Add(this.btnUpdateAnggota);
            this.Controls.Add(this.btnStatusPeminjaman);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.lblTglKembali);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.txtnopengembalian);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.lookUpEditNamaAnggota);
            this.Controls.Add(this.lookupEditAnggota);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.panelControl4);
            this.Controls.Add(this.panelControl6);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.panelControl3);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.panelControl2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmNewPengembalian";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pengembalian Buku";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frm_FormClosed);
            this.Load += new System.EventHandler(this.frmNewPengembalian_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmNewPengembalian_KeyDown);
            this.Leave += new System.EventHandler(this.frmNewPengembalian_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.GridLookUpEditCTR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LookUpEditEmp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboTipePembimbing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LookUpEditMhs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnopengembalian.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpinjam.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpinjam.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetgljatuhtempo.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetgljatuhtempo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookupEditAnggota.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBar.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookupEditPetugas.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamapetugas.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            this.panelControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).EndInit();
            this.panelControl6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cboNIB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditNamaAnggota.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaksbukudipinjam.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdendaperhari.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtlamapeminjaman.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemGridLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            this.groupControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).EndInit();
            this.groupControl5.ResumeLayout(false);
            this.groupControl5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalDendaDibayar.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalDenda.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDendaBukuHilang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBiayaKeterlambatan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deTglKembali.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deTglKembali.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglDendaDibayar.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglDendaDibayar.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit LookUpEditEmp;
        public DevExpress.XtraEditors.SimpleButton btnDelete;
        public DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraEditors.ProgressBarControl pBar;
        public DevExpress.XtraEditors.DateEdit datetglpinjam;
        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit GridLookUpEditCTR;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemGridLookUpEdit1View;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamandetailsid;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamanid;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid;
        private DevExpress.XtraGrid.Columns.GridColumn status;
        private DevExpress.XtraGrid.Columns.GridColumn keterangan;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        public DevExpress.XtraEditors.TextEdit txtnopengembalian;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PictureEdit pictureEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox cboTipePembimbing;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit LookUpEditMhs;
        private DevExpress.XtraGrid.Columns.GridColumn nib;
        private DevExpress.XtraGrid.Columns.GridColumn kodepanggil;
        private DevExpress.XtraGrid.Columns.GridColumn jumlah;
        public DevExpress.XtraEditors.LookUpEdit lookupEditAnggota;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        public DevExpress.XtraEditors.DateEdit datetgljatuhtempo;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.PanelControl panelControl6;
        private DevExpress.XtraEditors.GridLookUpEdit cboNIB;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn judul;
        private DevExpress.XtraGrid.Columns.GridColumn pengarang;
        private DevExpress.XtraGrid.Columns.GridColumn edisi;
        private DevExpress.XtraGrid.Columns.GridColumn penerbit;
        public DevExpress.XtraEditors.TextEdit txtnamapetugas;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.Label label1;
        public DevExpress.XtraEditors.SimpleButton btnAdd;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid1;
        private DevExpress.XtraGrid.Columns.GridColumn nib1;
        private DevExpress.XtraGrid.Columns.GridColumn kodepanggil1;
        private DevExpress.XtraGrid.Columns.GridColumn judul1;
        private DevExpress.XtraGrid.Columns.GridColumn pengarang1;
        private DevExpress.XtraGrid.Columns.GridColumn edisi1;
        private DevExpress.XtraGrid.Columns.GridColumn penerbit1;
        private DevExpress.XtraGrid.Columns.GridColumn isbn1;
        public DevExpress.XtraEditors.LookUpEdit lookUpEditNamaAnggota;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        public DevExpress.XtraEditors.SimpleButton btnStatusPeminjaman;
        public DevExpress.XtraEditors.SimpleButton btnUpdateAnggota;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        public DevExpress.XtraEditors.TextEdit txtlamapeminjaman;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn nopeminjaman;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemGridLookUpEdit repositoryItemGridLookUpEdit1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        public DevExpress.XtraEditors.TextEdit txtdendaperhari;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        public DevExpress.XtraEditors.TextEdit txtmaksbukudipinjam;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        public DevExpress.XtraEditors.SimpleButton btnKetentuanPeminjaman;
        public DevExpress.XtraEditors.LabelControl labelControl5;
        public DevExpress.XtraEditors.LabelControl labelControl10;
        public DevExpress.XtraEditors.LabelControl lblnamaanggota;
        public DevExpress.XtraEditors.LabelControl lblnimanggota;
        public DevExpress.XtraEditors.SimpleButton btnNotaPeminjamanBaru;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        public DevExpress.XtraEditors.LabelControl labelControl24;
        public DevExpress.XtraEditors.LabelControl labelControl25;
        public DevExpress.XtraEditors.LabelControl labelControl26;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        public DevExpress.XtraEditors.SimpleButton btnPembayaranDenda;
        private DevExpress.XtraGrid.Columns.GridColumn tglpinjam;
        private DevExpress.XtraGrid.Columns.GridColumn tgljatuhtempo;
        private DevExpress.XtraGrid.Columns.GridColumn tglpinjam2;
        private DevExpress.XtraGrid.Columns.GridColumn tgljatuhtempo2;
        private DevExpress.XtraGrid.Columns.GridColumn tglkembali;
        private DevExpress.XtraGrid.Columns.GridColumn jumlahdenda;
        private DevExpress.XtraGrid.Columns.GridColumn terlambat;
        private DevExpress.XtraGrid.Columns.GridColumn dendaperhari;
        private DevExpress.XtraGrid.Columns.GridColumn pengembalianid;
        private DevExpress.XtraGrid.Columns.GridColumn pengembalianid1;
        private DevExpress.XtraGrid.Columns.GridColumn jumlahdenda1;
        private DevExpress.XtraGrid.Columns.GridColumn tglkembali1;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamandetailsid1;
        private DevExpress.XtraGrid.Columns.GridColumn anggotaid1;
        private DevExpress.XtraGrid.Columns.GridColumn kembalikan;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn nopeminjaman2;
        private DevExpress.XtraEditors.GroupControl groupControl5;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        public DevExpress.XtraEditors.TextEdit txtTotalDenda;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        public DevExpress.XtraEditors.TextEdit txtDendaBukuHilang;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        public DevExpress.XtraEditors.TextEdit txtBiayaKeterlambatan;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        public DevExpress.XtraEditors.TextEdit txtTotalDendaDibayar;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraGrid.Columns.GridColumn dendadibayar;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraGrid.Columns.GridColumn pengembaliandetailsid1;
        private DevExpress.XtraGrid.Columns.GridColumn pengembaliandetailsid;
        public DevExpress.XtraEditors.LabelControl lblTglKembali;
        public DevExpress.XtraEditors.LabelControl lblJamKembali;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.PictureBox pictureBox1;
        public DevExpress.XtraEditors.LookUpEdit lookupEditPetugas;
        private System.Windows.Forms.Timer timerScan;
        private DevExpress.XtraGrid.Columns.GridColumn inventarisid;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        private DevExpress.XtraGrid.Columns.GridColumn inventarisid1;
        private DevExpress.XtraGrid.Columns.GridColumn rfid3;
        private DevExpress.XtraGrid.Columns.GridColumn inventarisid3;
        private DevExpress.XtraGrid.Columns.GridColumn rfid2;
        public DevExpress.XtraEditors.DateEdit deTglKembali;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        public DevExpress.XtraEditors.DateEdit tglDendaDibayar;
    }
}