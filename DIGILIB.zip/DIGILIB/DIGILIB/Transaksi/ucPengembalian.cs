﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.XtraEditors;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Drawing;
using DevExpress.XtraEditors.DXErrorProvider;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

using DevExpress.Utils;

namespace DIGILIB.Transaksi
{
    public partial class ucPengembalian : UserControl
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;

        List<String> workpackid_CopyList = new List<String>();
        int idxpaste = 0;
        public ucPengembalian()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
        public void refreshAll()
        {
            loadData();
        }
        private void loadData()
        {
            setLoadDialog(true, "Loading data...");
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    clstblpengembalian oObject = new clstblpengembalian();
                    oConn.Open();
                    oObject.Koneksi = oConn.Conn;

                    string strFilter = "";
                    if (Convert.ToString(rgFilter.EditValue).ToLower() == "transaksi hari ini saja")
                    {
                        strFilter = " and to_char(pb.tglkembali,'yyyy-mm-dd')=to_char(now(),'yyyy-mm-dd')";
                    }
                    else if (Convert.ToString(rgFilter.EditValue).ToLower() == "transaksi 3 bulan terbaru")
                    {
                        strFilter = " and (pb.tglkembali::date<=now()::date and pb.tglkembali::date>=(now() - interval '3 month')::date)";
                    }
                    else if (Convert.ToString(rgFilter.EditValue).ToLower() == "transaksi 1 tahun terbaru")
                    {
                        strFilter = " and (pb.tglkembali::date<=now()::date and pb.tglkembali::date>=(now() - interval '1 year')::date)";
                    }

                    DataTable dt = oObject.GetData("", strFilter);
                    dgData.DataSource = dt;
                    xdt = dt.Copy();
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                }
            }
        }

        private void userControlCTR_Load(object sender, EventArgs e)
        {
            //refreshAll();
        }

        private void dgData_EmbeddedNavigator_ButtonClick(object sender, NavigatorButtonClickEventArgs e)
        {
            try
            {
                if (e.Button.ButtonType == NavigatorButtonType.Append)
                {

                }
                else if (e.Button.ButtonType == NavigatorButtonType.EndEdit)
                {

                }
                else if (e.Button.ButtonType == NavigatorButtonType.Remove)
                {
                    e.Handled = true;
                    deleteRow();
                    //string strMsg = "Are you sure to delete selected record?";
                    //if (gridView2.GetSelectedRows().Length > 1)
                    //{
                    //    strMsg = "Are you sure to delete selected records?";
                    //}
                    //if (XtraMessageBox.Show(strMsg, clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    //{
                    //    deleteRow();
                    //}
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }


        #region "Create New Data"
        private bool bolAdd_click;
        private void btnCreateNew_Click(object sender, EventArgs e)
        {
            try
            {
                frmNewPengembalian frm = new frmNewPengembalian();
                frm.pEdit = false;
                frm.pstrpengembalianid = "";
                frm.refreshAll();
                frm.CreateNewData();
                if (string.IsNullOrEmpty(frm.pstrpengembalianid))
                {

                }
                frm.loadData(true);
                frm.ShowDialog(this);

                loadData();
                if (!string.IsNullOrEmpty(frm.pstrpengembalianid))
                {
                    setGridMasterSelected(pengembalianid.FieldName, frm.pstrpengembalianid);
                }
                frm.Close();
                frm.Dispose();
                frm = null;
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }

        }


        #endregion


        private void btnDelete_Click(object sender, EventArgs e)
        {
            deleteRow();
        }


        private void deleteRow()
        {

            frmMain oMain = formMain as frmMain;
            using (clsConnection oConn = new clsConnection())
            {
                if (gridView1.IsGroupRow(gridView1.FocusedRowHandle))
                {
                    XtraMessageBox.Show("Penghapusan gagal, tidak ada data yang dipilih", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;

                }
                try
                {
                    oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
                    oMain.repositoryItemProgressBar1.Minimum = 0;
                    oMain.pbarMain.EditValue = 0;
                    oMain.repositoryItemProgressBar1.BeginUpdate();
                    string strSQL = "";
                    //GridView gridView1 = this.gridView1.GetgridView1(this.gridView1.FocusedRowHandle, 0) as GridView;

                    if (XtraMessageBox.Show("Apakah anda ingin menghapus record yang dipilih?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {

                        string strExistConstraint = "";


                        string[] strConstraintTable = { };
                        clstblpengembalian oObject = new clstblpengembalian();
                        if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                        oObject.Koneksi = oConn.Conn;
                        if (gridView1.SelectedRowsCount == 0)
                        {
                            gridView1.SelectRow(gridView1.FocusedRowHandle);
                            gridView1.MakeRowVisible(gridView1.FocusedRowHandle, false);
                        }
                        int[] arrSelectedRows = gridView1.GetSelectedRows();

                        oMain.repositoryItemProgressBar1.Maximum = arrSelectedRows.Length;
                        oMain.pbarMain.Caption = "Deleting selected row(s)...please wait";

                        for (int i = 0; i < arrSelectedRows.Length; i++)
                        {

                            oMain.pbarMain.EditValue = (int)oMain.pbarMain.EditValue + 1;

                            oObject.pengembalianid = Convert.ToString(gridView1.GetRowCellValue(arrSelectedRows[i], pengembalianid));
                            if (clsGlobal.cekConstraint("pengembalianid", oObject.pengembalianid, strConstraintTable, ref strExistConstraint))
                            {
                                string sDesc = Convert.ToString(gridView1.GetRowCellValue(arrSelectedRows[i], nopeminjaman)); ;
                                if (strExistConstraint == "") strExistConstraint = "another table(s)";
                                XtraMessageBox.Show("No Peminjaman [" + sDesc + "] tidak dapat dihapus, data ini di gunakan diproses lain" + strExistConstraint, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                gridView1.UnselectRow(arrSelectedRows[i]);
                                continue;
                            }
                            else
                            {
                                oObject.opedit = clsGlobal.strUserName;
                                oObject.pcedit = SystemInformation.ComputerName;
                                oObject.SoftDelete();
                            }


                        }
                        if (arrSelectedRows.Length > 0)
                        {
                            gridView1.DeleteSelectedRows();
                            XtraMessageBox.Show("Data Peminjaman sukses dihapus", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }


                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    oMain.repositoryItemProgressBar1.EndUpdate();
                    oMain.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (gridView1.IsGroupRow(gridView1.FocusedRowHandle))
            {
                XtraMessageBox.Show("Silahkan pilih salah satu record!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (gridView1.RowCount <= 0)
            {
                XtraMessageBox.Show("Tidak ada record yang dipilih", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataRow row = gridView1.GetDataRow(gridView1.FocusedRowHandle);
            DateTime myDate;

            frmNewPengembalian frm = new frmNewPengembalian();
            frm.pEdit = true;

            ////frm.txtnoborang.Enabled = false;
            //frm.cboTA.Enabled = false;
            //frm.cboProdi.Enabled = false;
            //frm.cboProgram.Enabled = false;
            //frm.cboSemester.Enabled = false;
            ////frm.txtlampiran.Enabled = false;
            //frm.dateBorang.Enabled = false;

            frm.bolLoading = true;
            frm.refreshAll();

            frm.pstrpengembalianid = Convert.ToString(row["pengembalianid"]);
            frm.lookupEditAnggota.EditValue = Convert.ToString(row["anggotaid"]);
            frm.lookUpEditNamaAnggota.EditValue = Convert.ToString(row["anggotaid"]);
            frm.lblnamaanggota.Text = Convert.ToString(row["namaanggota"]);
            frm.lblnimanggota.Text = "NIM/NIK : " + Convert.ToString(row["nimanggota"]);
            frm.labelControl10.Text = Convert.ToString(row["jenis"]);
            frm.labelControl5.Text = "Alamat : " + Convert.ToString(row["alamat"]);
            if (row["photo"] != null && Convert.ToString(row["photo"]) != "")
            {
                frm.pictureBox2.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + row["photo"];
            }
            frm.txtnopengembalian.EditValue = Convert.ToString(row["nopengembalian"]);

            frm.lookupEditPetugas.EditValue = Convert.ToString(row["petugasid"]);
            frm.txtnamapetugas.Text = Convert.ToString(row["namapetugas"]);
            if (row["photopetugas"] != null && Convert.ToString(row["photopetugas"]) != "")
            {
                frm.pictureBox1.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + row["photopetugas"];
            }

            DateTime.TryParse(Convert.ToString(row["tglpinjam"]), out myDate);
            if (myDate == DateTime.MinValue)
                frm.datetglpinjam.EditValue = null;
            else
                frm.datetglpinjam.EditValue = myDate;

            myDate = clsGlobal.GetParseDate(row["tgljatuhtempo"]);
            if (myDate == DateTime.MinValue)
                frm.datetgljatuhtempo.EditValue = null;
            else
                frm.datetgljatuhtempo.EditValue = myDate;

            frm.txtlamapeminjaman.Text = Convert.ToString(row["lamapeminjaman"]);
            frm.txtdendaperhari.Text = Convert.ToString(row["dendaperhari"]);
            frm.txtmaksbukudipinjam.Text = Convert.ToString(row["maksbukudipinjam"]);
            try
            {
                myDate = Convert.ToDateTime(row["tglkembalimaster"]);
            }
            catch
            {

            }

            if (myDate == DateTime.MinValue)
            {
                frm.lblTglKembali.Text = clsGlobal.getServerDate().ToString("dd-MMM-yyyy");
                frm.lblJamKembali.Text = clsGlobal.getServerDate().ToString("HH:mm:ss");
            }
            else
            {
                frm.lblTglKembali.Text = myDate.ToString("dd-MMM-yyyy");
                frm.lblJamKembali.Text = myDate.ToString("HH:mm:ss");
            }
            frm.deTglKembali.EditValue = myDate;

            if (clsGlobal.GetParseDate(row["tgldendadibayar"]) != DateTime.MinValue)
            {
                frm.tglDendaDibayar.EditValue = clsGlobal.GetParseDate(row["tgldendadibayar"]);
            }

            frm.loadData(true);
            frm.enableControl(true);
            frm.ShowDialog(this);

            loadData();

            if (!string.IsNullOrEmpty(frm.pstrpengembalianid))
            {
                setGridMasterSelected(peminjamanid.FieldName, frm.pstrpengembalianid);
            }
            frm.Close();
            frm.Dispose();
            frm = null;
        }

        private void setGridMasterSelected(string colname, string findValue)
        {
            try
            {
                int i = gridView1.LocateByValue(colname, findValue);
                gridView1.ClearSelection();
                gridView1.FocusedRowHandle = i;
                gridView1.SelectRow(i);
                gridView1.MakeRowVisible(i, false);
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }


        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            if (Convert.ToString(gridView1.GetFocusedRowCellValue(pengembalianid)) != "")
            {
                btnEdit_Click(sender, e);
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {

            try
            {
                if (gridView1.IsGroupRow(gridView1.FocusedRowHandle))
                {
                    XtraMessageBox.Show("Silahkan pilih salah satu record!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else if (gridView1.RowCount <= 0)
                {
                    XtraMessageBox.Show("Tidak ada record yang dipilih", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DataRow row = gridView1.GetDataRow(gridView1.FocusedRowHandle);
                DateTime myDate;
                DateTime.TryParse(Convert.ToString(row["tglpinjam"]), out myDate);
                frmNewPengembalian frm = new frmNewPengembalian();
                frm.pEdit = true;

                ////frm.txtnoborang.Enabled = false;
                //frm.cboTA.Enabled = false;
                //frm.cboProdi.Enabled = false;
                //frm.cboProgram.Enabled = false;
                //frm.cboSemester.Enabled = false;
                ////frm.txtlampiran.Enabled = false;
                //frm.dateBorang.Enabled = false;

                frm.bolLoading = true;
                frm.pstrpengembalianid = Convert.ToString(row["pengembalianid"]);
                //frm.pstrsupervisorid = Convert.ToString(row["diperiksaolehid"]);
                //frm.pdateactualdate = Convert.ToDateTime(row["tanggalborang"]);
                //frm.txtnoborang.EditValue = Convert.ToString(row["noborang"]);
                //frm.cboTA.EditValue = Convert.ToString(row["tahunajaranid"]);
                //frm.cboProdi.EditValue = Convert.ToString(row["prodiid"]);
                //frm.cboProgram.EditValue = Convert.ToString(row["program"]);
                //frm.cboSemester.EditValue = Convert.ToString(row["semester"]); 
                //frm.txtlampiran.EditValue = Convert.ToString(row["lampiran"]);

                if (myDate == DateTime.MinValue)
                    frm.datetglpinjam.EditValue = null;
                else
                    frm.datetglpinjam.EditValue = myDate;

                myDate = clsGlobal.GetParseDate(row["tgljatuhtempo"]);
                if (myDate == DateTime.MinValue)
                    frm.datetgljatuhtempo.EditValue = null;
                else
                    frm.datetgljatuhtempo.EditValue = myDate;
                frm.refreshAll();

                //frm.cboDisiapkanOleh.EditValue = Convert.ToString(row["disiapkanolehid"]);
                //frm.cboDiperiksaOleh.EditValue = Convert.ToString(row["diperiksaolehid"]);
                //frm.cboMengetahui.EditValue = Convert.ToString(row["diketahuiolehid"]);

                //frm.optShift.EditValue = Convert.ToString(row["shift"]);
                frm.loadData(true);
                frm.Show();
                frm.btnPreview_Click(sender, e);
                frm.Close();
                frm.Dispose();
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                btnPreview.Enabled = true;
            }
        }

        public void ExtendLastColumn()
        {
            try
            {
                GridView detailView = gridView1 as GridView;
                if (detailView != null)
                {
                    DevExpress.XtraGrid.Views.Grid.ViewInfo.GridViewRects rects =
                        ((DevExpress.XtraGrid.Views.Grid.ViewInfo.GridViewInfo)detailView.GetViewInfo()).ViewRects;

                    if (detailView.VisibleColumns.Count > 0 && rects.ColumnTotalWidth < rects.ColumnPanelWidth)
                    {
                        detailView.VisibleColumns[detailView.VisibleColumns.Count - 1].Width += (rects.ColumnPanelWidth - rects.ColumnTotalWidth) - 20;
                    }

                    else if (detailView.VisibleColumns.Count > 0)
                    {
                        int total = detailView.VisibleColumns[detailView.VisibleColumns.Count - 1].Width - (rects.ColumnTotalWidth - rects.ColumnPanelWidth) + 20;
                        if (total > detailView.VisibleColumns[detailView.VisibleColumns.Count - 1].MinWidth)
                            detailView.VisibleColumns[detailView.VisibleColumns.Count - 1].Width -= (rects.ColumnTotalWidth - rects.ColumnPanelWidth) + 20;
                        else
                            detailView.VisibleColumns[detailView.VisibleColumns.Count - 1].Width = total;
                    }
                }
            }

            catch
            {
                //log the error
            }
        }

        private void dgData_Resize(object sender, EventArgs e)
        {
            ExtendLastColumn();
        }

        private void gridView1_Layout(object sender, EventArgs e)
        {
            ExtendLastColumn();
        }

        DataTable xdt;
        private void btnPreview2_Click(object sender, EventArgs e)
        {
            btnPreview2.Enabled = false;
            try
            {
                btnPreview2.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptTransaksiPengembalian.repx";
                reportName = "rptTransaksiPengembalian";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    List<string> pengembalianid_list = new List<string>();
                    if (xdt.Rows.Count > gridView1.RowCount)
                    {
                        int rowHandle;
                        for (int i = 0; i < gridView1.RowCount; i++)
                        {
                            rowHandle = gridView1.GetVisibleRowHandle(i);
                            if (!gridView1.IsGroupRow(rowHandle))
                            {
                                object key = gridView1.GetRowCellValue(rowHandle, peminjamanid);
                                if (key != null && key != DBNull.Value)
                                {
                                    if (!pengembalianid_list.Contains(key.ToString()))
                                        pengembalianid_list.Add(key.ToString());
                                }
                            }
                        }
                    }
                    string strsql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Pengembalian' as header2,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status, 
                            sum(pbdet.jumlah) as jumlah
                            from tblpengembalian pb
                            inner join tblpengembaliandetails pbdet on pbdet.pengembalianid=pb.pengembalianid and pbdet.dlt='0'
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamandetailsid=pbdet.peminjamandetailsid and pjdet.dlt='0'
                            inner join tblpeminjaman pj on pj.peminjamanid=pjdet.peminjamanid and pj.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on inv.bukuid=bk.bukuid and bk.dlt='0'
                            where pb.dlt='0' " + (pengembalianid_list.Count > 0 ? string.Format(" and pb.pengembalianid in ( {0} )", "'" + String.Join("','", pengembalianid_list.ToArray()) + "'") : "") + @"
                            group by inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status
                            order by nib, judul, jeniskoleksi

                    ";
                    using (clsConnection oConn = new clsConnection())
                    {
                        DataTable dtReport = oConn.GetData(strsql);
                        dtReport.TableName = "tblReport";
                        mainReport.reportName = reportName;
                        mainReport.printReport(filename, dtReport);
                    }

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview2.Enabled = true;
        }

        private void btnBookHistory_Click(object sender, EventArgs e)
        {
            btnBookHistory.Enabled = false;
            Utility.frmBookHistory oForm = new Utility.frmBookHistory();
            oForm.ShowDialog(this);
            oForm = null;
            btnBookHistory.Enabled = true;
        }

        private void rgFIlter_EditValueChanged(object sender, EventArgs e)
        {
            loadData();
        }

    }
}
