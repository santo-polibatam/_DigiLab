﻿namespace DIGILIB.Transaksi
{
    partial class ucPeminjaman
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPeminjaman));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnBookHistory = new DevExpress.XtraEditors.SimpleButton();
            this.btnPreview2 = new DevExpress.XtraEditors.SimpleButton();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            this.btnAdd = new DevExpress.XtraEditors.SimpleButton();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.btnDelete = new DevExpress.XtraEditors.SimpleButton();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.peminjamanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.anggotaid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.petugasid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopeminjaman = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglpinjam = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tgljatuhtempo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.status = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.namaanggota = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nimanggota = new DevExpress.XtraGrid.Columns.GridColumn();
            this.keterangan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.namapetugas = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.ribbonImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            this.rgFilter = new DevExpress.XtraEditors.RadioGroup();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgFilter.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.rgFilter);
            this.panelControl1.Controls.Add(this.btnBookHistory);
            this.panelControl1.Controls.Add(this.btnPreview2);
            this.panelControl1.Controls.Add(this.btnPreview);
            this.panelControl1.Controls.Add(this.btnAdd);
            this.panelControl1.Controls.Add(this.btnEdit);
            this.panelControl1.Controls.Add(this.btnClose);
            this.panelControl1.Controls.Add(this.btnDelete);
            this.panelControl1.Controls.Add(this.dgData);
            this.panelControl1.Controls.Add(this.label1);
            this.panelControl1.Controls.Add(this.lblTitle);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1598, 802);
            this.panelControl1.TabIndex = 0;
            // 
            // btnBookHistory
            // 
            this.btnBookHistory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBookHistory.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnBookHistory.Appearance.Options.UseFont = true;
            this.btnBookHistory.Image = ((System.Drawing.Image)(resources.GetObject("btnBookHistory.Image")));
            this.btnBookHistory.Location = new System.Drawing.Point(918, 725);
            this.btnBookHistory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBookHistory.Name = "btnBookHistory";
            this.btnBookHistory.Size = new System.Drawing.Size(198, 57);
            this.btnBookHistory.TabIndex = 95;
            this.btnBookHistory.Text = "Book &History";
            this.btnBookHistory.Click += new System.EventHandler(this.btnBookHistory_Click);
            // 
            // btnPreview2
            // 
            this.btnPreview2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview2.Appearance.Options.UseFont = true;
            this.btnPreview2.Image = global::DIGILIB.Properties.Resources.Actions_print_preview_icon32;
            this.btnPreview2.Location = new System.Drawing.Point(1419, 725);
            this.btnPreview2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPreview2.Name = "btnPreview2";
            this.btnPreview2.Size = new System.Drawing.Size(166, 57);
            this.btnPreview2.TabIndex = 86;
            this.btnPreview2.Text = "Preview";
            this.btnPreview2.Click += new System.EventHandler(this.btnPreview2_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Appearance.Options.UseFont = true;
            this.btnPreview.Image = global::DIGILIB.Properties.Resources.Action_Printing_Print_32x32;
            this.btnPreview.Location = new System.Drawing.Point(1125, 725);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(285, 57);
            this.btnPreview.TabIndex = 85;
            this.btnPreview.Text = "Cetak Struk Peminjaman";
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdd.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Appearance.Options.UseFont = true;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(14, 725);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(168, 57);
            this.btnAdd.TabIndex = 68;
            this.btnAdd.Text = "&Tambah";
            this.btnAdd.Click += new System.EventHandler(this.btnCreateNew_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnEdit.Appearance.Options.UseFont = true;
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(190, 725);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(136, 57);
            this.btnEdit.TabIndex = 69;
            this.btnEdit.Text = "&Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(482, 725);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 57);
            this.btnClose.TabIndex = 70;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Appearance.Options.UseFont = true;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(336, 725);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 57);
            this.btnDelete.TabIndex = 67;
            this.btnDelete.Text = "&Hapus";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgData.EmbeddedNavigator.ButtonClick += new DevExpress.XtraEditors.NavigatorButtonClickEventHandler(this.dgData_EmbeddedNavigator_ButtonClick);
            this.dgData.Location = new System.Drawing.Point(0, 37);
            this.dgData.MainView = this.gridView1;
            this.dgData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1});
            this.dgData.Size = new System.Drawing.Size(1596, 678);
            this.dgData.TabIndex = 66;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.dgData.Resize += new System.EventHandler(this.dgData_Resize);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.peminjamanid,
            this.anggotaid,
            this.petugasid,
            this.nopeminjaman,
            this.tglpinjam,
            this.tgljatuhtempo,
            this.status,
            this.rfid,
            this.namaanggota,
            this.nimanggota,
            this.keterangan,
            this.namapetugas});
            this.gridView1.GridControl = this.dgData;
            this.gridView1.GroupCount = 1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.RowAutoHeight = true;
            this.gridView1.OptionsView.ShowAutoFilterRow = true;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.tglpinjam, DevExpress.Data.ColumnSortOrder.Descending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.nopeminjaman, DevExpress.Data.ColumnSortOrder.Descending)});
            this.gridView1.DoubleClick += new System.EventHandler(this.gridView1_DoubleClick);
            this.gridView1.Layout += new System.EventHandler(this.gridView1_Layout);
            // 
            // peminjamanid
            // 
            this.peminjamanid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.peminjamanid.AppearanceHeader.Options.UseFont = true;
            this.peminjamanid.AppearanceHeader.Options.UseTextOptions = true;
            this.peminjamanid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.peminjamanid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.peminjamanid.Caption = "peminjamanid";
            this.peminjamanid.FieldName = "peminjamanid";
            this.peminjamanid.Name = "peminjamanid";
            // 
            // anggotaid
            // 
            this.anggotaid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.anggotaid.AppearanceHeader.Options.UseFont = true;
            this.anggotaid.AppearanceHeader.Options.UseTextOptions = true;
            this.anggotaid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.anggotaid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.anggotaid.Caption = "anggotaid";
            this.anggotaid.FieldName = "anggotaid";
            this.anggotaid.Name = "anggotaid";
            // 
            // petugasid
            // 
            this.petugasid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.petugasid.AppearanceHeader.Options.UseFont = true;
            this.petugasid.AppearanceHeader.Options.UseTextOptions = true;
            this.petugasid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.petugasid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.petugasid.Caption = "petugasid";
            this.petugasid.FieldName = "petugasid";
            this.petugasid.MinWidth = 120;
            this.petugasid.Name = "petugasid";
            this.petugasid.Width = 130;
            // 
            // nopeminjaman
            // 
            this.nopeminjaman.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nopeminjaman.AppearanceHeader.Options.UseFont = true;
            this.nopeminjaman.AppearanceHeader.Options.UseTextOptions = true;
            this.nopeminjaman.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nopeminjaman.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nopeminjaman.Caption = "No Peminjaman";
            this.nopeminjaman.FieldName = "nopeminjaman";
            this.nopeminjaman.MinWidth = 180;
            this.nopeminjaman.Name = "nopeminjaman";
            this.nopeminjaman.Visible = true;
            this.nopeminjaman.VisibleIndex = 0;
            this.nopeminjaman.Width = 201;
            // 
            // tglpinjam
            // 
            this.tglpinjam.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tglpinjam.AppearanceHeader.Options.UseFont = true;
            this.tglpinjam.AppearanceHeader.Options.UseTextOptions = true;
            this.tglpinjam.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam.Caption = "Tgl Pinjam";
            this.tglpinjam.FieldName = "tglpinjam";
            this.tglpinjam.MinWidth = 150;
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.Visible = true;
            this.tglpinjam.VisibleIndex = 1;
            this.tglpinjam.Width = 171;
            // 
            // tgljatuhtempo
            // 
            this.tgljatuhtempo.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.tgljatuhtempo.AppearanceHeader.Options.UseFont = true;
            this.tgljatuhtempo.AppearanceHeader.Options.UseTextOptions = true;
            this.tgljatuhtempo.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo.Caption = "Tgl Jatuh Tempo";
            this.tgljatuhtempo.FieldName = "tgljatuhtempo";
            this.tgljatuhtempo.MinWidth = 130;
            this.tgljatuhtempo.Name = "tgljatuhtempo";
            this.tgljatuhtempo.Visible = true;
            this.tgljatuhtempo.VisibleIndex = 1;
            this.tgljatuhtempo.Width = 130;
            // 
            // status
            // 
            this.status.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.status.AppearanceHeader.Options.UseFont = true;
            this.status.AppearanceHeader.Options.UseTextOptions = true;
            this.status.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.status.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.status.Caption = "Status";
            this.status.FieldName = "status";
            this.status.MinWidth = 120;
            this.status.Name = "status";
            this.status.Visible = true;
            this.status.VisibleIndex = 2;
            this.status.Width = 120;
            // 
            // rfid
            // 
            this.rfid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid.AppearanceHeader.Options.UseFont = true;
            this.rfid.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid.Caption = "RFID";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 150;
            this.rfid.Name = "rfid";
            this.rfid.Visible = true;
            this.rfid.VisibleIndex = 3;
            this.rfid.Width = 150;
            // 
            // namaanggota
            // 
            this.namaanggota.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.namaanggota.AppearanceHeader.Options.UseFont = true;
            this.namaanggota.AppearanceHeader.Options.UseTextOptions = true;
            this.namaanggota.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.namaanggota.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.namaanggota.Caption = "Nama Anggota";
            this.namaanggota.FieldName = "namaanggota";
            this.namaanggota.MinWidth = 180;
            this.namaanggota.Name = "namaanggota";
            this.namaanggota.Visible = true;
            this.namaanggota.VisibleIndex = 4;
            this.namaanggota.Width = 180;
            // 
            // nimanggota
            // 
            this.nimanggota.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.nimanggota.AppearanceHeader.Options.UseFont = true;
            this.nimanggota.AppearanceHeader.Options.UseTextOptions = true;
            this.nimanggota.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nimanggota.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.nimanggota.Caption = "NIM/NIK";
            this.nimanggota.FieldName = "nimanggota";
            this.nimanggota.MinWidth = 180;
            this.nimanggota.Name = "nimanggota";
            this.nimanggota.Visible = true;
            this.nimanggota.VisibleIndex = 5;
            this.nimanggota.Width = 180;
            // 
            // keterangan
            // 
            this.keterangan.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.keterangan.AppearanceHeader.Options.UseFont = true;
            this.keterangan.AppearanceHeader.Options.UseTextOptions = true;
            this.keterangan.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.keterangan.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.keterangan.Caption = "Keterangan";
            this.keterangan.FieldName = "keterangan";
            this.keterangan.MinWidth = 200;
            this.keterangan.Name = "keterangan";
            this.keterangan.Visible = true;
            this.keterangan.VisibleIndex = 6;
            this.keterangan.Width = 200;
            // 
            // namapetugas
            // 
            this.namapetugas.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.namapetugas.AppearanceHeader.Options.UseFont = true;
            this.namapetugas.AppearanceHeader.Options.UseTextOptions = true;
            this.namapetugas.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.namapetugas.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.namapetugas.Caption = "Nama Petugas";
            this.namapetugas.FieldName = "namapetugas";
            this.namapetugas.MinWidth = 180;
            this.namapetugas.Name = "namapetugas";
            this.namapetugas.Visible = true;
            this.namapetugas.VisibleIndex = 7;
            this.namapetugas.Width = 180;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(10, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1575, 2);
            this.label1.TabIndex = 62;
            this.label1.Text = "label1";
            // 
            // lblTitle
            // 
            this.lblTitle.AllowHtmlString = true;
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Location = new System.Drawing.Point(2, 2);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(384, 24);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Modul Sirkulasi -> Peminjaman Buku";
            // 
            // ribbonImageCollection
            // 
            this.ribbonImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollection.ImageStream")));
            this.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_Save_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_SaveAs_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Info_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(3, "remove-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(4, "close-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(5, "Copy16.png");
            this.ribbonImageCollection.Images.SetKeyName(6, "Paste16.png");
            this.ribbonImageCollection.Images.SetKeyName(7, "New Edit16.png");
            this.ribbonImageCollection.Images.SetKeyName(8, "New Remove64.png");
            this.ribbonImageCollection.Images.SetKeyName(9, "Paste.png");
            this.ribbonImageCollection.Images.SetKeyName(10, "Paste_dis.png");
            // 
            // rgFilter
            // 
            this.rgFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rgFilter.EditValue = "Transaksi Hari Ini Saja";
            this.rgFilter.Location = new System.Drawing.Point(1030, 45);
            this.rgFilter.Margin = new System.Windows.Forms.Padding(4);
            this.rgFilter.Name = "rgFilter";
            this.rgFilter.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Transaksi Hari Ini Saja", "Transaksi Hari Ini Saja"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Transaksi 3 Bulan Terbaru", "Transaksi 3 Bulan Terbaru"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Transaksi 1 Tahun Terbaru", "Transaksi 1 Tahun Terbaru"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Semua", "Tampil Semua")});
            this.rgFilter.Size = new System.Drawing.Size(529, 63);
            this.rgFilter.TabIndex = 98;
            this.rgFilter.EditValueChanged += new System.EventHandler(this.rgFilter_EditValueChanged);
            // 
            // ucPeminjaman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ucPeminjaman";
            this.Size = new System.Drawing.Size(1598, 802);
            this.Load += new System.EventHandler(this.userControlCTR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgFilter.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private System.Windows.Forms.Label label1;
        private DevExpress.Utils.ImageCollection ribbonImageCollection;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn anggotaid;
        private DevExpress.XtraGrid.Columns.GridColumn nopeminjaman;
        private DevExpress.XtraGrid.Columns.GridColumn tgljatuhtempo;
        private DevExpress.XtraGrid.Columns.GridColumn status;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        public DevExpress.XtraEditors.SimpleButton btnAdd;
        public DevExpress.XtraEditors.SimpleButton btnEdit;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        public DevExpress.XtraEditors.SimpleButton btnDelete;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamanid;
        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraGrid.Columns.GridColumn petugasid;
        private DevExpress.XtraGrid.Columns.GridColumn tglpinjam;
        private DevExpress.XtraGrid.Columns.GridColumn keterangan;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        private DevExpress.XtraGrid.Columns.GridColumn namaanggota;
        private DevExpress.XtraGrid.Columns.GridColumn nimanggota;
        private DevExpress.XtraGrid.Columns.GridColumn namapetugas;
        public DevExpress.XtraEditors.SimpleButton btnPreview2;
        public DevExpress.XtraEditors.SimpleButton btnBookHistory;
        private DevExpress.XtraEditors.RadioGroup rgFilter; 
        
    }
}
