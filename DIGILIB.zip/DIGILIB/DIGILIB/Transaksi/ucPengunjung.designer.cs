﻿namespace DIGILIB.Transaksi
{
    partial class ucPengunjung
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPengunjung));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.panelTgl = new DevExpress.XtraEditors.PanelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnLoad2 = new DevExpress.XtraEditors.SimpleButton();
            this.dateTanggal2 = new DevExpress.XtraEditors.DateEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.dateTanggal1 = new DevExpress.XtraEditors.DateEdit();
            this.btnExportExcel = new DevExpress.XtraEditors.SimpleButton();
            this.btnLoad = new DevExpress.XtraEditors.SimpleButton();
            this.btnPreview2 = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.pengunjungid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.anggotaid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cardno = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pin = new DevExpress.XtraGrid.Columns.GridColumn();
            this.verified = new DevExpress.XtraGrid.Columns.GridColumn();
            this.doorid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.eventtype = new DevExpress.XtraGrid.Columns.GridColumn();
            this.inoutstate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.time_second = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodiid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rownum = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nim = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nama = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jeniskelamin = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodicode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodidesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.time_second2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.ribbonImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelTgl)).BeginInit();
            this.panelTgl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.panelTgl);
            this.panelControl1.Controls.Add(this.btnExportExcel);
            this.panelControl1.Controls.Add(this.btnLoad);
            this.panelControl1.Controls.Add(this.btnPreview2);
            this.panelControl1.Controls.Add(this.btnClose);
            this.panelControl1.Controls.Add(this.dgData);
            this.panelControl1.Controls.Add(this.label1);
            this.panelControl1.Controls.Add(this.lblTitle);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1244, 761);
            this.panelControl1.TabIndex = 0;
            // 
            // panelTgl
            // 
            this.panelTgl.Controls.Add(this.labelControl1);
            this.panelTgl.Controls.Add(this.btnLoad2);
            this.panelTgl.Controls.Add(this.dateTanggal2);
            this.panelTgl.Controls.Add(this.labelControl14);
            this.panelTgl.Controls.Add(this.dateTanggal1);
            this.panelTgl.Location = new System.Drawing.Point(14, 105);
            this.panelTgl.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panelTgl.Name = "panelTgl";
            this.panelTgl.Size = new System.Drawing.Size(737, 40);
            this.panelTgl.TabIndex = 108;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(285, 7);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(65, 21);
            this.labelControl1.TabIndex = 108;
            this.labelControl1.Text = "Sampai :";
            // 
            // btnLoad2
            // 
            this.btnLoad2.Image = ((System.Drawing.Image)(resources.GetObject("btnLoad2.Image")));
            this.btnLoad2.Location = new System.Drawing.Point(554, 4);
            this.btnLoad2.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad2.Name = "btnLoad2";
            this.btnLoad2.Size = new System.Drawing.Size(136, 31);
            this.btnLoad2.TabIndex = 107;
            this.btnLoad2.Text = "&Load Data";
            this.btnLoad2.Click += new System.EventHandler(this.btnLoad2_Click);
            // 
            // dateTanggal2
            // 
            this.dateTanggal2.EditValue = null;
            this.dateTanggal2.Location = new System.Drawing.Point(358, 5);
            this.dateTanggal2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTanggal2.Name = "dateTanggal2";
            this.dateTanggal2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTanggal2.Properties.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal2.Properties.EditFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal2.Properties.Mask.EditMask = "dd-MMM-yyyy";
            this.dateTanggal2.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTanggal2.Size = new System.Drawing.Size(150, 26);
            this.dateTanggal2.TabIndex = 105;
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(8, 9);
            this.labelControl14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(50, 21);
            this.labelControl14.TabIndex = 103;
            this.labelControl14.Text = "Mulai :";
            // 
            // dateTanggal1
            // 
            this.dateTanggal1.EditValue = null;
            this.dateTanggal1.Location = new System.Drawing.Point(63, 5);
            this.dateTanggal1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTanggal1.Name = "dateTanggal1";
            this.dateTanggal1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateTanggal1.Properties.DisplayFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal1.Properties.EditFormat.FormatString = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.dateTanggal1.Properties.Mask.EditMask = "dd-MMM-yyyy";
            this.dateTanggal1.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateTanggal1.Size = new System.Drawing.Size(150, 26);
            this.dateTanggal1.TabIndex = 0;
            this.dateTanggal1.EditValueChanged += new System.EventHandler(this.dateTanggal1_EditValueChanged_1);
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportExcel.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExportExcel.Appearance.Options.UseFont = true;
            this.btnExportExcel.Image = global::DIGILIB.Properties.Resources.export_excel_icon;
            this.btnExportExcel.Location = new System.Drawing.Point(873, 701);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(4);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(214, 54);
            this.btnExportExcel.TabIndex = 88;
            this.btnExportExcel.Text = "Export Excel";
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Image = ((System.Drawing.Image)(resources.GetObject("btnLoad.Image")));
            this.btnLoad.Location = new System.Drawing.Point(14, 50);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(254, 46);
            this.btnLoad.TabIndex = 107;
            this.btnLoad.Text = "&Get Data From Gate";
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnPreview2
            // 
            this.btnPreview2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview2.Appearance.Options.UseFont = true;
            this.btnPreview2.Image = global::DIGILIB.Properties.Resources.Actions_print_preview_icon32;
            this.btnPreview2.Location = new System.Drawing.Point(921, 701);
            this.btnPreview2.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreview2.Name = "btnPreview2";
            this.btnPreview2.Size = new System.Drawing.Size(166, 54);
            this.btnPreview2.TabIndex = 86;
            this.btnPreview2.Text = "Preview";
            this.btnPreview2.Visible = false;
            this.btnPreview2.Click += new System.EventHandler(this.btnPreview2_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(1095, 701);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 54);
            this.btnClose.TabIndex = 70;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Location = new System.Drawing.Point(0, 154);
            this.dgData.MainView = this.gridView1;
            this.dgData.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1,
            this.repositoryItemMemoEdit1});
            this.dgData.Size = new System.Drawing.Size(1242, 539);
            this.dgData.TabIndex = 66;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.Row.Options.UseTextOptions = true;
            this.gridView1.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.pengunjungid,
            this.anggotaid,
            this.rfid,
            this.cardno,
            this.pin,
            this.verified,
            this.doorid,
            this.eventtype,
            this.inoutstate,
            this.time_second,
            this.prodiid,
            this.rownum,
            this.nim,
            this.nama,
            this.jeniskelamin,
            this.prodicode,
            this.prodidesc,
            this.time_second2});
            this.gridView1.GridControl = this.dgData;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.RowAutoHeight = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // pengunjungid
            // 
            this.pengunjungid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.pengunjungid.AppearanceHeader.Options.UseFont = true;
            this.pengunjungid.AppearanceHeader.Options.UseTextOptions = true;
            this.pengunjungid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.pengunjungid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.pengunjungid.Caption = "pengunjungid";
            this.pengunjungid.FieldName = "pengunjungid";
            this.pengunjungid.Name = "pengunjungid";
            // 
            // anggotaid
            // 
            this.anggotaid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.anggotaid.AppearanceHeader.Options.UseFont = true;
            this.anggotaid.AppearanceHeader.Options.UseTextOptions = true;
            this.anggotaid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.anggotaid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.anggotaid.Caption = "anggotaid";
            this.anggotaid.FieldName = "anggotaid";
            this.anggotaid.Name = "anggotaid";
            // 
            // rfid
            // 
            this.rfid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.rfid.AppearanceHeader.Options.UseFont = true;
            this.rfid.AppearanceHeader.Options.UseTextOptions = true;
            this.rfid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.rfid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.rfid.Caption = "rfid";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 120;
            this.rfid.Name = "rfid";
            this.rfid.Width = 130;
            // 
            // cardno
            // 
            this.cardno.Caption = "cardno";
            this.cardno.FieldName = "cardno";
            this.cardno.MinWidth = 150;
            this.cardno.Name = "cardno";
            this.cardno.Width = 150;
            // 
            // pin
            // 
            this.pin.Caption = "pin";
            this.pin.FieldName = "pin";
            this.pin.MinWidth = 150;
            this.pin.Name = "pin";
            this.pin.Width = 150;
            // 
            // verified
            // 
            this.verified.Caption = "verified";
            this.verified.FieldName = "verified";
            this.verified.Name = "verified";
            // 
            // doorid
            // 
            this.doorid.Caption = "doorid";
            this.doorid.FieldName = "doorid";
            this.doorid.Name = "doorid";
            // 
            // eventtype
            // 
            this.eventtype.Caption = "eventtype";
            this.eventtype.FieldName = "eventtype";
            this.eventtype.Name = "eventtype";
            // 
            // inoutstate
            // 
            this.inoutstate.Caption = "inoutstate";
            this.inoutstate.FieldName = "inoutstate";
            this.inoutstate.Name = "inoutstate";
            // 
            // time_second
            // 
            this.time_second.Caption = "time_second";
            this.time_second.FieldName = "time_second";
            this.time_second.Name = "time_second";
            // 
            // prodiid
            // 
            this.prodiid.Caption = "prodiid";
            this.prodiid.FieldName = "prodiid";
            this.prodiid.Name = "prodiid";
            // 
            // rownum
            // 
            this.rownum.Caption = "No";
            this.rownum.FieldName = "rownum";
            this.rownum.MinWidth = 100;
            this.rownum.Name = "rownum";
            this.rownum.Visible = true;
            this.rownum.VisibleIndex = 0;
            this.rownum.Width = 100;
            // 
            // nim
            // 
            this.nim.Caption = "NIM/NIK";
            this.nim.FieldName = "nim";
            this.nim.MinWidth = 180;
            this.nim.Name = "nim";
            this.nim.Visible = true;
            this.nim.VisibleIndex = 1;
            this.nim.Width = 180;
            // 
            // nama
            // 
            this.nama.Caption = "Nama";
            this.nama.FieldName = "nama";
            this.nama.MinWidth = 250;
            this.nama.Name = "nama";
            this.nama.Visible = true;
            this.nama.VisibleIndex = 2;
            this.nama.Width = 250;
            // 
            // jeniskelamin
            // 
            this.jeniskelamin.Caption = "Jenis Kelamin";
            this.jeniskelamin.FieldName = "jeniskelamin";
            this.jeniskelamin.MinWidth = 100;
            this.jeniskelamin.Name = "jeniskelamin";
            this.jeniskelamin.Visible = true;
            this.jeniskelamin.VisibleIndex = 3;
            this.jeniskelamin.Width = 300;
            // 
            // prodicode
            // 
            this.prodicode.Caption = "Kode Prodi";
            this.prodicode.FieldName = "prodicode";
            this.prodicode.MinWidth = 100;
            this.prodicode.Name = "prodicode";
            this.prodicode.Visible = true;
            this.prodicode.VisibleIndex = 4;
            this.prodicode.Width = 100;
            // 
            // prodidesc
            // 
            this.prodidesc.Caption = "Nama Prodi";
            this.prodidesc.FieldName = "prodidesc";
            this.prodidesc.MinWidth = 250;
            this.prodidesc.Name = "prodidesc";
            this.prodidesc.Visible = true;
            this.prodidesc.VisibleIndex = 5;
            this.prodidesc.Width = 250;
            // 
            // time_second2
            // 
            this.time_second2.AppearanceCell.Options.UseTextOptions = true;
            this.time_second2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.time_second2.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.time_second2.Caption = "Tgl dan Jam";
            this.time_second2.DisplayFormat.FormatString = "dd-MMM-yyyy HH:mm:ss";
            this.time_second2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.time_second2.FieldName = "time_second2";
            this.time_second2.MinWidth = 180;
            this.time_second2.Name = "time_second2";
            this.time_second2.Visible = true;
            this.time_second2.VisibleIndex = 6;
            this.time_second2.Width = 180;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(10, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1221, 1);
            this.label1.TabIndex = 62;
            this.label1.Text = "label1";
            // 
            // lblTitle
            // 
            this.lblTitle.AllowHtmlString = true;
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Location = new System.Drawing.Point(2, 2);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(131, 24);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Pengunjung";
            // 
            // ribbonImageCollection
            // 
            this.ribbonImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollection.ImageStream")));
            this.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_Save_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_SaveAs_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Info_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(3, "remove-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(4, "close-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(5, "Copy16.png");
            this.ribbonImageCollection.Images.SetKeyName(6, "Paste16.png");
            this.ribbonImageCollection.Images.SetKeyName(7, "New Edit16.png");
            this.ribbonImageCollection.Images.SetKeyName(8, "New Remove64.png");
            this.ribbonImageCollection.Images.SetKeyName(9, "Paste.png");
            this.ribbonImageCollection.Images.SetKeyName(10, "Paste_dis.png");
            // 
            // ucPengunjung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucPengunjung";
            this.Size = new System.Drawing.Size(1244, 761);
            this.Load += new System.EventHandler(this.userControlCTR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelTgl)).EndInit();
            this.panelTgl.ResumeLayout(false);
            this.panelTgl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTanggal1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private System.Windows.Forms.Label label1;
        private DevExpress.Utils.ImageCollection ribbonImageCollection;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn anggotaid;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraGrid.Columns.GridColumn pengunjungid;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        public DevExpress.XtraEditors.SimpleButton btnPreview2;
        private DevExpress.XtraEditors.SimpleButton btnLoad;
        public DevExpress.XtraEditors.SimpleButton btnExportExcel;
        private DevExpress.XtraGrid.Columns.GridColumn cardno;
        private DevExpress.XtraGrid.Columns.GridColumn pin;
        private DevExpress.XtraGrid.Columns.GridColumn jeniskelamin;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn nim;
        private DevExpress.XtraGrid.Columns.GridColumn nama;
        private DevExpress.XtraGrid.Columns.GridColumn time_second2;
        private DevExpress.XtraGrid.Columns.GridColumn rownum;
        private DevExpress.XtraEditors.PanelControl panelTgl;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton btnLoad2;
        private DevExpress.XtraEditors.DateEdit dateTanggal2;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.DateEdit dateTanggal1;
        private DevExpress.XtraGrid.Columns.GridColumn verified;
        private DevExpress.XtraGrid.Columns.GridColumn doorid;
        private DevExpress.XtraGrid.Columns.GridColumn eventtype;
        private DevExpress.XtraGrid.Columns.GridColumn inoutstate;
        private DevExpress.XtraGrid.Columns.GridColumn time_second;
        private DevExpress.XtraGrid.Columns.GridColumn prodiid;
        private DevExpress.XtraGrid.Columns.GridColumn prodicode;
        private DevExpress.XtraGrid.Columns.GridColumn prodidesc; 
        
    }
}
