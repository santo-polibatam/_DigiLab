﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.XtraEditors;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Drawing;
using DevExpress.XtraEditors.DXErrorProvider;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

using DevExpress.Utils;

namespace DIGILIB.Transaksi
{
    public partial class ucReminderJatuhTempo : XtraUserControl
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;

        public ucReminderJatuhTempo()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
        public override void Refresh()
        {
            base.Refresh();
            loadData();
        }
        private void loadData()
        {
            setLoadDialog(true, "Loading data...");
            try
            {
                using (clsConnection oconn = new clsConnection())
                {
                    string strSql = @"select a.peminjamanid, a.anggotaid, a.nopeminjaman, a.tglpinjam, a.tgljatuhtempo,
                                    b.peminjamandetailsid, b.inventarisid, d.nib, d.bukuid, e.kodepanggil, e.judul,
                                    c.nim, c.nama, g.prodicode, g.prodidesc, c.jenis
                                    from tblpeminjaman a
                                    inner join tblpeminjamandetails b on a.peminjamanid=b.peminjamanid and b.dlt='0'
                                    inner join tbm_anggota c on a.anggotaid=c.anggotaid and c.dlt='0'
                                    inner join tbm_inventaris d on b.inventarisid=d.inventarisid and d.dlt='0'
                                    inner join tbm_buku e on d.bukuid=e.bukuid and e.dlt='0'
                                    left outer join
                                    (
	                                    select a.pengembalianid, a.tglkembali, b.pengembaliandetailsid, b.peminjamandetailsid
	                                    from tblpengembalian a
	                                    inner join tblpengembaliandetails b on a.pengembalianid=b.pengembalianid and b.dlt='0'
	                                    where a.dlt='0'
                                    ) f on b.peminjamandetailsid=f.peminjamandetailsid
                                    left outer join tbm_prodi g on c.prodiid=g.prodiid
                                    where a.dlt='0' and f.pengembaliandetailsid is null and a.tgljatuhtempo<=(now()+interval '2 days')
                                    order by a.tgljatuhtempo desc;";
                    DataTable dt = oconn.GetData(strSql);
                    dgData.DataSource = dt;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
        }

        private void userControlCTR_Load(object sender, EventArgs e)
        {
            //refreshAll();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        DataTable xdt;
        
        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            string sFilePath = clsGlobal.pstrAppPath;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Title = "Save as Excel Workbook";
            saveFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";

            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.FileName = "Reminder Mendekati Jatuh Tempo.xlsx";
            string strSheetName = "Reminder Mendekati Jatuh Tempo";

            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                if (clsGlobal.isFileOpened(saveFileDialog1.FileName))
                {
                    XtraMessageBox.Show(this, "Download fail, this file [" + saveFileDialog1.FileName + "] is currenlty opened", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                sFilePath = saveFileDialog1.FileName;

                if (saveFileDialog1.FilterIndex == 2)
                    gridView1.ExportToXlsx(sFilePath, new DevExpress.XtraPrinting.XlsxExportOptions { SheetName = strSheetName });
                else
                    gridView1.ExportToXls(sFilePath, new DevExpress.XtraPrinting.XlsExportOptions { SheetName = strSheetName });

                System.Diagnostics.Process.Start(sFilePath);

            }
        }
        
    }
}
