﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Library;
using DevExpress.XtraEditors;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Drawing;
using DevExpress.XtraEditors.DXErrorProvider;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

using DevExpress.Utils;

namespace DIGILIB.Transaksi
{
    public partial class ucBookStatus : XtraUserControl
    {
        public frmMain formMain;
        WaitDialogForm loadDialog;

        public ucBookStatus()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }
        public override void Refresh()
        {
            base.Refresh();
            loadData();
        }
        private void loadData()
        {
            btnLoad.Enabled = false;
            setLoadDialog(true, "Loading data...");
            try
            {
                using (clsConnection oconn = new clsConnection())
                {
                    string strWhere = "";
                    if (Convert.ToString(dateTanggal1.EditValue) != "")
                    {
                        strWhere = " and aa.tglpinjam::date>='" + clsGlobal.GetParseDate(dateTanggal1.EditValue).ToString("yyyy-MM-dd") + "'";
                    }
                    if (Convert.ToString(dateTanggal2.EditValue) != "")
                    {
                        strWhere += " and aa.tglpinjam::date<='" + clsGlobal.GetParseDate(dateTanggal2.EditValue).ToString("yyyy-MM-dd") + "'";
                    }
                    string strSql = @"select row_number() over (order by a.noinduk, a.nib, a.judul) as rownum, a.*, 
                                    b.nopeminjaman, b.tglpinjam, b.tgljatuhtempo, 
                                    b.pengembaliandetailsid, b.nopengembalian, b.tglkembali,
                                    b.anggotaid, b.nim, b.nama,
                                    case when b.peminjamandetailsid is not null and b.pengembaliandetailsid is null then 'Dipinjam' 
                                    when b.pengembaliandetailsid is not null then 'Tersedia' 
                                    else 'Tersedia' end as status
                                    from
                                    (
	                                    select a.inventarisid, a.bukuid, a.rfid, b.noinduk, a.nib, b.judul, b.isbn, b.jeniskoleksi, b.jenis_barang,
	                                    (
		                                    select bb.peminjamandetailsid
		                                    from tblpeminjaman aa
		                                    inner join tblpeminjamandetails bb on aa.peminjamanid=bb.peminjamanid and bb.dlt='0'
		                                    where aa.dlt='0' and bb.inventarisid=a.inventarisid " + strWhere + @"
		                                    order by aa.tglpinjam desc limit 1
	                                    ) as peminjamandetailsid
	                                    from tbm_inventaris a
	                                    inner join tbm_buku b on a.bukuid=b.bukuid and b.dlt='0'
	                                    where a.dlt='0'
                                    ) a
                                    left outer join
                                    (
	                                    select b.peminjamandetailsid, c.inventarisid, d.bukuid, a.nopeminjaman, a.tglpinjam, a.tgljatuhtempo,
	                                    f.anggotaid, f.nim, f.nama, e.pengembaliandetailsid, e.nopengembalian, e.tglkembali
	                                    from tblpeminjaman a
	                                    inner join tblpeminjamandetails b on a.peminjamanid=b.peminjamanid and b.dlt='0'
	                                    inner join tbm_inventaris c on b.inventarisid=c.inventarisid and c.dlt='0'
	                                    inner join tbm_buku d on c.bukuid=d.bukuid and d.dlt='0'
	                                    left outer JOIN
	                                    (
		                                    select b.peminjamandetailsid, b.pengembaliandetailsid, a.nopengembalian, a.tglkembali
		                                    from tblpengembalian a
		                                    inner join tblpengembaliandetails b on a.pengembalianid=b.pengembalianid and b.dlt='0'
		                                    where a.dlt='0'
	                                    ) e on b.peminjamandetailsid=e.peminjamandetailsid
	                                    left outer join tbm_anggota f on a.anggotaid=f.anggotaid and f.dlt='0'
	                                    where a.dlt='0'
                                    ) b on a.peminjamandetailsid=b.peminjamandetailsid
                                    order by a.noinduk, a.nib, a.judul;";
                    DataTable dt = oconn.GetData(strSql);
                    dgData.DataSource = dt;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            finally
            {
                setLoadDialog(false, "");
            }
            btnLoad.Enabled = true;
        }

        private void userControlCTR_Load(object sender, EventArgs e)
        {
            //refreshAll();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        DataTable xdt;
        private void btnPreview2_Click(object sender, EventArgs e)
        {
            btnPreview2.Enabled = false;
            try
            {
                btnPreview2.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptTransaksiPeminjaman.repx";
                reportName = "rptTransaksiPeminjaman";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    List<string> peminjamanid_list = new List<string>();
                    if (xdt.Rows.Count > gridView1.RowCount)
                    {
                        int rowHandle;
                        for (int i = 0; i < gridView1.RowCount; i++)
                        {
                            rowHandle = gridView1.GetVisibleRowHandle(i);
                            if (!gridView1.IsGroupRow(rowHandle))
                            {
                                object key = gridView1.GetRowCellValue(rowHandle, inventarisid);
                                if (key != null && key != DBNull.Value)
                                {
                                    if (!peminjamanid_list.Contains(key.ToString()))
                                        peminjamanid_list.Add(key.ToString());
                                }
                            }
                        }
                    }
                    string strsql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Laporan Transaksi Peminjaman' as header2,
                            inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status, 
                            sum(pjdet.jumlah) as jumlah
                            from tblpeminjaman pj
                            inner join tblpeminjamandetails pjdet on pjdet.peminjamanid=pj.peminjamanid and pjdet.dlt='0'                    
                            inner join tbm_inventaris inv on inv.inventarisid=pjdet.inventarisid and inv.dlt='0'
                            inner join tbm_buku bk on bk.bukuid=inv.bukuid and bk.dlt='0'
                            where pj.dlt='0' " + (peminjamanid_list.Count > 0 ? string.Format(" and pj.peminjamanid in ( {0} )", "'" + String.Join("','", peminjamanid_list.ToArray()) + "'") : "") + @"
                            group by inv.inventarisid, inv.nib, inv.rfid,
                            bk.bukuid, bk.pengadaanid, bk.noinduk, bk.kodepanggil, bk.judul, bk.pengarang, bk.badankorporat, bk.edisi, bk.penerbit, 
                            bk.tempatterbit, bk.tahunterbit, bk.isbn, bk.deskripsi, bk.supplemen, bk.lokasikoleksi, bk.jeniskoleksi, inv.status
                            order by nib, judul, jeniskoleksi
                    ";
                    using (clsConnection oConn = new clsConnection())
                    {
                        DataTable dtReport = oConn.GetData(strsql);
                        dtReport.TableName = "tblReport";
                        mainReport.reportName = reportName;
                        mainReport.printReport(filename, dtReport);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview2.Enabled = true;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            string sFilePath = clsGlobal.pstrAppPath;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Title = "Save as Excel Workbook";
            saveFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";

            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.FileName = "Status Buku.xlsx";
            string strSheetName = "Status Buku";

            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                if (clsGlobal.isFileOpened(saveFileDialog1.FileName))
                {
                    XtraMessageBox.Show(this, "Download fail, this file [" + saveFileDialog1.FileName + "] is currenlty opened", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                sFilePath = saveFileDialog1.FileName;

                if (saveFileDialog1.FilterIndex == 2)
                    gridView1.ExportToXlsx(sFilePath, new DevExpress.XtraPrinting.XlsxExportOptions { SheetName = strSheetName });
                else
                    gridView1.ExportToXls(sFilePath, new DevExpress.XtraPrinting.XlsExportOptions { SheetName = strSheetName });

                System.Diagnostics.Process.Start(sFilePath);

            }
        }

        private void dateTanggal1_EditValueChanged(object sender, EventArgs e)
        {
            if (Convert.ToString(dateTanggal1.EditValue) == "")
            {
                dateTanggal2.Properties.MinValue = DateTime.MinValue;
            }
            else
            {
                dateTanggal2.Properties.MinValue = clsGlobal.GetParseDate(dateTanggal1.EditValue);
            }
        }

    }
}
