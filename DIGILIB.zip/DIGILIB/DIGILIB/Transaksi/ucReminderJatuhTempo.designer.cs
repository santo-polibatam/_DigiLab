﻿namespace DIGILIB.Transaksi
{
    partial class ucReminderJatuhTempo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucReminderJatuhTempo));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnExportExcel = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.peminjamanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.anggotaid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.peminjamandetailsid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.inventarisid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bukuid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodidesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopeminjaman = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglpinjam = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tgljatuhtempo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nim = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nama = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kodepanggil = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.jenis = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.ribbonImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            this.nib = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.btnExportExcel);
            this.panelControl1.Controls.Add(this.btnClose);
            this.panelControl1.Controls.Add(this.dgData);
            this.panelControl1.Controls.Add(this.label1);
            this.panelControl1.Controls.Add(this.lblTitle);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1598, 761);
            this.panelControl1.TabIndex = 0;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportExcel.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnExportExcel.Appearance.Options.UseFont = true;
            this.btnExportExcel.Image = global::DIGILIB.Properties.Resources.export_excel_icon;
            this.btnExportExcel.Location = new System.Drawing.Point(1227, 701);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(4);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(214, 54);
            this.btnExportExcel.TabIndex = 88;
            this.btnExportExcel.Text = "Export Excel";
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(1449, 701);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 54);
            this.btnClose.TabIndex = 70;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Location = new System.Drawing.Point(0, 40);
            this.dgData.MainView = this.gridView1;
            this.dgData.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1,
            this.repositoryItemMemoEdit1});
            this.dgData.Size = new System.Drawing.Size(1596, 653);
            this.dgData.TabIndex = 66;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.Row.Options.UseTextOptions = true;
            this.gridView1.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView1.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.peminjamanid,
            this.anggotaid,
            this.peminjamandetailsid,
            this.inventarisid,
            this.bukuid,
            this.prodidesc,
            this.nopeminjaman,
            this.tglpinjam,
            this.tgljatuhtempo,
            this.nim,
            this.nama,
            this.nib,
            this.kodepanggil,
            this.judul,
            this.jenis});
            this.gridView1.GridControl = this.dgData;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.FocusLeaveOnTab = true;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.RowAutoHeight = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // peminjamanid
            // 
            this.peminjamanid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.peminjamanid.AppearanceHeader.Options.UseFont = true;
            this.peminjamanid.AppearanceHeader.Options.UseTextOptions = true;
            this.peminjamanid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.peminjamanid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.peminjamanid.Caption = "peminjamanid";
            this.peminjamanid.FieldName = "peminjamanid";
            this.peminjamanid.Name = "peminjamanid";
            // 
            // anggotaid
            // 
            this.anggotaid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.anggotaid.AppearanceHeader.Options.UseFont = true;
            this.anggotaid.AppearanceHeader.Options.UseTextOptions = true;
            this.anggotaid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.anggotaid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.anggotaid.Caption = "anggotaid";
            this.anggotaid.FieldName = "anggotaid";
            this.anggotaid.Name = "anggotaid";
            // 
            // peminjamandetailsid
            // 
            this.peminjamandetailsid.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.peminjamandetailsid.AppearanceHeader.Options.UseFont = true;
            this.peminjamandetailsid.AppearanceHeader.Options.UseTextOptions = true;
            this.peminjamandetailsid.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.peminjamandetailsid.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.peminjamandetailsid.Caption = "peminjamandetailsid";
            this.peminjamandetailsid.FieldName = "peminjamandetailsid";
            this.peminjamandetailsid.MinWidth = 120;
            this.peminjamandetailsid.Name = "peminjamandetailsid";
            this.peminjamandetailsid.Width = 130;
            // 
            // inventarisid
            // 
            this.inventarisid.Caption = "inventarisid";
            this.inventarisid.FieldName = "inventarisid";
            this.inventarisid.Name = "inventarisid";
            // 
            // bukuid
            // 
            this.bukuid.Caption = "bukuid";
            this.bukuid.FieldName = "bukuid";
            this.bukuid.Name = "bukuid";
            // 
            // prodidesc
            // 
            this.prodidesc.Caption = "Prodi";
            this.prodidesc.FieldName = "prodidesc";
            this.prodidesc.MinWidth = 180;
            this.prodidesc.Name = "prodidesc";
            this.prodidesc.Visible = true;
            this.prodidesc.VisibleIndex = 0;
            this.prodidesc.Width = 190;
            // 
            // nopeminjaman
            // 
            this.nopeminjaman.AppearanceCell.Options.UseTextOptions = true;
            this.nopeminjaman.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.nopeminjaman.Caption = "No Peminjaman";
            this.nopeminjaman.FieldName = "nopeminjaman";
            this.nopeminjaman.MinWidth = 100;
            this.nopeminjaman.Name = "nopeminjaman";
            this.nopeminjaman.Visible = true;
            this.nopeminjaman.VisibleIndex = 1;
            this.nopeminjaman.Width = 100;
            // 
            // tglpinjam
            // 
            this.tglpinjam.AppearanceCell.Options.UseTextOptions = true;
            this.tglpinjam.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglpinjam.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tglpinjam.Caption = "Tgl Peminjaman";
            this.tglpinjam.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.tglpinjam.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglpinjam.FieldName = "tglpinjam";
            this.tglpinjam.MinWidth = 150;
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.Visible = true;
            this.tglpinjam.VisibleIndex = 2;
            this.tglpinjam.Width = 169;
            // 
            // tgljatuhtempo
            // 
            this.tgljatuhtempo.AppearanceCell.BackColor = System.Drawing.Color.Red;
            this.tgljatuhtempo.AppearanceCell.ForeColor = System.Drawing.Color.White;
            this.tgljatuhtempo.AppearanceCell.Options.UseBackColor = true;
            this.tgljatuhtempo.AppearanceCell.Options.UseForeColor = true;
            this.tgljatuhtempo.AppearanceCell.Options.UseTextOptions = true;
            this.tgljatuhtempo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tgljatuhtempo.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tgljatuhtempo.Caption = "Tgl Jatuh Tempo";
            this.tgljatuhtempo.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.tgljatuhtempo.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tgljatuhtempo.FieldName = "tgljatuhtempo";
            this.tgljatuhtempo.MinWidth = 150;
            this.tgljatuhtempo.Name = "tgljatuhtempo";
            this.tgljatuhtempo.Visible = true;
            this.tgljatuhtempo.VisibleIndex = 3;
            this.tgljatuhtempo.Width = 169;
            // 
            // nim
            // 
            this.nim.Caption = "NIM/NIK";
            this.nim.FieldName = "nim";
            this.nim.MinWidth = 180;
            this.nim.Name = "nim";
            this.nim.Visible = true;
            this.nim.VisibleIndex = 4;
            this.nim.Width = 204;
            // 
            // nama
            // 
            this.nama.Caption = "Nama";
            this.nama.FieldName = "nama";
            this.nama.MinWidth = 200;
            this.nama.Name = "nama";
            this.nama.Visible = true;
            this.nama.VisibleIndex = 5;
            this.nama.Width = 226;
            // 
            // kodepanggil
            // 
            this.kodepanggil.Caption = "Kode Panggil";
            this.kodepanggil.FieldName = "kodepanggil";
            this.kodepanggil.MinWidth = 120;
            this.kodepanggil.Name = "kodepanggil";
            this.kodepanggil.Visible = true;
            this.kodepanggil.VisibleIndex = 7;
            this.kodepanggil.Width = 169;
            // 
            // judul
            // 
            this.judul.Caption = "Judul";
            this.judul.ColumnEdit = this.repositoryItemMemoEdit1;
            this.judul.FieldName = "judul";
            this.judul.MinWidth = 300;
            this.judul.Name = "judul";
            this.judul.Visible = true;
            this.judul.VisibleIndex = 9;
            this.judul.Width = 351;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // jenis
            // 
            this.jenis.Caption = "Jenis";
            this.jenis.FieldName = "jenis";
            this.jenis.MinWidth = 100;
            this.jenis.Name = "jenis";
            this.jenis.Visible = true;
            this.jenis.VisibleIndex = 8;
            this.jenis.Width = 100;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.DisplayFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd MMM yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd MMM yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(10, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1575, 1);
            this.label1.TabIndex = 62;
            this.label1.Text = "label1";
            // 
            // lblTitle
            // 
            this.lblTitle.AllowHtmlString = true;
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Location = new System.Drawing.Point(2, 2);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(355, 24);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Reminder Mendekati Jatuh Tempo";
            // 
            // ribbonImageCollection
            // 
            this.ribbonImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollection.ImageStream")));
            this.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_Save_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_SaveAs_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Info_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(3, "remove-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(4, "close-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(5, "Copy16.png");
            this.ribbonImageCollection.Images.SetKeyName(6, "Paste16.png");
            this.ribbonImageCollection.Images.SetKeyName(7, "New Edit16.png");
            this.ribbonImageCollection.Images.SetKeyName(8, "New Remove64.png");
            this.ribbonImageCollection.Images.SetKeyName(9, "Paste.png");
            this.ribbonImageCollection.Images.SetKeyName(10, "Paste_dis.png");
            // 
            // nib
            // 
            this.nib.Caption = "NIB";
            this.nib.FieldName = "nib";
            this.nib.MinWidth = 120;
            this.nib.Name = "nib";
            this.nib.Visible = true;
            this.nib.VisibleIndex = 6;
            this.nib.Width = 120;
            // 
            // ucReminderJatuhTempo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucReminderJatuhTempo";
            this.Size = new System.Drawing.Size(1598, 761);
            this.Load += new System.EventHandler(this.userControlCTR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private System.Windows.Forms.Label label1;
        private DevExpress.Utils.ImageCollection ribbonImageCollection;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn anggotaid;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamanid;
        private DevExpress.XtraGrid.Columns.GridColumn peminjamandetailsid;
        public DevExpress.XtraEditors.SimpleButton btnExportExcel;
        private DevExpress.XtraGrid.Columns.GridColumn kodepanggil;
        private DevExpress.XtraGrid.Columns.GridColumn judul;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn nim;
        private DevExpress.XtraGrid.Columns.GridColumn nama;
        private DevExpress.XtraGrid.Columns.GridColumn nopeminjaman;
        private DevExpress.XtraGrid.Columns.GridColumn tglpinjam;
        private DevExpress.XtraGrid.Columns.GridColumn tgljatuhtempo;
        private DevExpress.XtraGrid.Columns.GridColumn inventarisid;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid;
        private DevExpress.XtraGrid.Columns.GridColumn prodidesc;
        private DevExpress.XtraGrid.Columns.GridColumn jenis;
        private DevExpress.XtraGrid.Columns.GridColumn nib;
    }
}
