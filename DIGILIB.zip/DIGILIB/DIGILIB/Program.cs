using System;
using System.Collections.Generic;
using System.Windows.Forms;
using DevExpress.LookAndFeel;

namespace DIGILIB
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            DevExpress.Skins.SkinManager.EnableFormSkins();
            DevExpress.UserSkins.OfficeSkins.Register();
            DevExpress.UserSkins.BonusSkins.Register();
            Library.clsGlobal.DefaultSkinName = "Money Twins";//"London Liquid Sky";
            UserLookAndFeel.Default.SetSkinStyle(Library.clsGlobal.DefaultSkinName);

            Application.Run(new frmMain());
        }
    }
}