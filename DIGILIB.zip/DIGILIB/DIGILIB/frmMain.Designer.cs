namespace DIGILIB
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.ribbonControl = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.ribbonImageCollection = new DevExpress.Utils.ImageCollection(this.components);
            this.bciClose = new DevExpress.XtraBars.BarCheckItem();
            this.bciExit = new DevExpress.XtraBars.BarCheckItem();
            this.bciUtility = new DevExpress.XtraBars.BarCheckItem();
            this.bsiTahun = new DevExpress.XtraBars.BarStaticItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.barStaticItem3 = new DevExpress.XtraBars.BarStaticItem();
            this.bsiUsername = new DevExpress.XtraBars.BarStaticItem();
            this.bsiServer = new DevExpress.XtraBars.BarStaticItem();
            this.bsiDatabase = new DevExpress.XtraBars.BarStaticItem();
            this.bciManagementUser = new DevExpress.XtraBars.BarCheckItem();
            this.bciCheckUpdate = new DevExpress.XtraBars.BarCheckItem();
            this.bciSettingJadwalBeasiswa = new DevExpress.XtraBars.BarCheckItem();
            this.bciDaftarBeasiswa = new DevExpress.XtraBars.BarCheckItem();
            this.bciSettingFinish = new DevExpress.XtraBars.BarCheckItem();
            this.bciSettingGolongan = new DevExpress.XtraBars.BarCheckItem();
            this.bciSettingTarif = new DevExpress.XtraBars.BarCheckItem();
            this.bciRekapDosenWali = new DevExpress.XtraBars.BarCheckItem();
            this.pbarMain = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemProgressBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
            this.bciSkinGallery = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.bciSettingTunjanganPendidik = new DevExpress.XtraBars.BarCheckItem();
            this.bciSettingTunjanganKependidikan = new DevExpress.XtraBars.BarCheckItem();
            this.bciTarifHonor = new DevExpress.XtraBars.BarCheckItem();
            this.bciReports = new DevExpress.XtraBars.BarCheckItem();
            this.bciPeminjaman = new DevExpress.XtraBars.BarCheckItem();
            this.bciPengembalian = new DevExpress.XtraBars.BarCheckItem();
            this.bciAnggota = new DevExpress.XtraBars.BarCheckItem();
            this.bciPengadaan = new DevExpress.XtraBars.BarCheckItem();
            this.barDefaultSkin = new DevExpress.XtraBars.BarButtonItem();
            this.bciBuku = new DevExpress.XtraBars.BarCheckItem();
            this.bciMultimedia = new DevExpress.XtraBars.BarCheckItem();
            this.bciStockOpname = new DevExpress.XtraBars.BarCheckItem();
            this.bciPrefixNumber = new DevExpress.XtraBars.BarCheckItem();
            this.bciNews = new DevExpress.XtraBars.BarCheckItem();
            this.bciAgenda = new DevExpress.XtraBars.BarCheckItem();
            this.bciSettingTanggalMerah = new DevExpress.XtraBars.BarCheckItem();
            this.bciStatusBuku = new DevExpress.XtraBars.BarCheckItem();
            this.bciPengunjung = new DevExpress.XtraBars.BarCheckItem();
            this.ribbonImageCollectionLarge = new DevExpress.Utils.ImageCollection(this.components);
            this.rpMaster = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgMaster = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpPengolahan = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgPegawai = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpReports = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgReport = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpWebAdmin = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgWebAdmin = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpUtility = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgUtility = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgSkin = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.mainPanel = new DevExpress.XtraEditors.PanelControl();
            this.popupMenu1 = new DevExpress.XtraBars.PopupMenu(this.components);
            this.bciReminderMendekatiJatuhTempo = new DevExpress.XtraBars.BarCheckItem();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollectionLarge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl
            // 
            this.ribbonControl.ApplicationButtonText = null;
            this.ribbonControl.ExpandCollapseItem.Id = 0;
            this.ribbonControl.Images = this.ribbonImageCollection;
            this.ribbonControl.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl.ExpandCollapseItem,
            this.bciClose,
            this.bciExit,
            this.bciUtility,
            this.bsiTahun,
            this.barStaticItem2,
            this.barStaticItem3,
            this.bsiUsername,
            this.bsiServer,
            this.bsiDatabase,
            this.bciManagementUser,
            this.bciCheckUpdate,
            this.bciSettingJadwalBeasiswa,
            this.bciDaftarBeasiswa,
            this.bciSettingFinish,
            this.bciSettingGolongan,
            this.bciSettingTarif,
            this.bciRekapDosenWali,
            this.pbarMain,
            this.bciSkinGallery,
            this.bciSettingTunjanganPendidik,
            this.bciSettingTunjanganKependidikan,
            this.bciTarifHonor,
            this.bciReports,
            this.bciPeminjaman,
            this.bciPengembalian,
            this.bciAnggota,
            this.bciPengadaan,
            this.barDefaultSkin,
            this.bciBuku,
            this.bciMultimedia,
            this.bciStockOpname,
            this.bciPrefixNumber,
            this.bciNews,
            this.bciAgenda,
            this.bciSettingTanggalMerah,
            this.bciStatusBuku,
            this.bciPengunjung,
            this.bciReminderMendekatiJatuhTempo});
            this.ribbonControl.LargeImages = this.ribbonImageCollectionLarge;
            this.ribbonControl.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl.Margin = new System.Windows.Forms.Padding(4);
            this.ribbonControl.MaxItemId = 149;
            this.ribbonControl.Name = "ribbonControl";
            this.ribbonControl.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.rpMaster,
            this.rpPengolahan,
            this.rpReports,
            this.rpWebAdmin,
            this.rpUtility});
            this.ribbonControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemProgressBar1});
            this.ribbonControl.Size = new System.Drawing.Size(1497, 140);
            this.ribbonControl.StatusBar = this.ribbonStatusBar;
            this.ribbonControl.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // ribbonImageCollection
            // 
            this.ribbonImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollection.ImageStream")));
            this.ribbonImageCollection.Images.SetKeyName(0, "Ribbon_New_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(1, "Ribbon_Open_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(2, "Ribbon_Close_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(3, "Ribbon_Find_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(4, "Ribbon_Save_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(5, "Ribbon_SaveAs_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(6, "Ribbon_Exit_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(7, "Ribbon_Content_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(8, "Ribbon_Info_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(9, "Ribbon_Bold_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(10, "Ribbon_Italic_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(11, "Ribbon_Underline_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(12, "Ribbon_AlignLeft_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(13, "Ribbon_AlignCenter_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(14, "Ribbon_AlignRight_16x16.png");
            this.ribbonImageCollection.Images.SetKeyName(15, "documentcontrol16.png");
            this.ribbonImageCollection.Images.SetKeyName(16, "folder utilities16.png");
            this.ribbonImageCollection.Images.SetKeyName(17, "20110627050157769_easyicon_cn_16.png");
            this.ribbonImageCollection.Images.SetKeyName(18, "check-user-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(19, "Software_Update_icon24.png");
            this.ribbonImageCollection.Images.SetKeyName(20, "dosen48.png");
            this.ribbonImageCollection.Images.SetKeyName(21, "daftarbeasiswa64.png");
            this.ribbonImageCollection.Images.SetKeyName(22, "acc.png");
            this.ribbonImageCollection.Images.SetKeyName(23, "gol32.png");
            this.ribbonImageCollection.Images.SetKeyName(24, "Bookmark-icon_3.png");
            this.ribbonImageCollection.Images.SetKeyName(25, "notepad-icon_4.png");
            this.ribbonImageCollection.Images.SetKeyName(26, "folder-icon_3.png");
            this.ribbonImageCollection.Images.SetKeyName(27, "Action-view-icon-icon24.png");
            this.ribbonImageCollection.Images.SetKeyName(28, "calendar-selection-week-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(29, "applications-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(30, "notebook-icon.png");
            this.ribbonImageCollection.Images.SetKeyName(31, "Apps-preferences-system-time-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(32, "tunjangan32.png");
            this.ribbonImageCollection.Images.SetKeyName(33, "user_root(2).png");
            this.ribbonImageCollection.Images.SetKeyName(34, "user(4).png");
            this.ribbonImageCollection.Images.SetKeyName(35, "personal(1).png");
            this.ribbonImageCollection.Images.SetKeyName(36, "vault.png");
            this.ribbonImageCollection.Images.SetKeyName(37, "emp_kependidikan32.png");
            this.ribbonImageCollection.Images.SetKeyName(38, "emp_pendidik32.png");
            this.ribbonImageCollection.Images.SetKeyName(39, "documents_folder(2).png");
            this.ribbonImageCollection.Images.SetKeyName(40, "khexedit(2).png");
            this.ribbonImageCollection.Images.SetKeyName(41, "folder_temporary(1).png");
            this.ribbonImageCollection.Images.SetKeyName(42, "files_text(2).png");
            this.ribbonImageCollection.Images.SetKeyName(43, "documents(6).png");
            this.ribbonImageCollection.Images.SetKeyName(44, "folder_blue.png");
            this.ribbonImageCollection.Images.SetKeyName(45, "files_edit.png");
            this.ribbonImageCollection.Images.SetKeyName(46, "folder_documents(1).png");
            this.ribbonImageCollection.Images.SetKeyName(47, "doc_f2.png");
            this.ribbonImageCollection.Images.SetKeyName(48, "doc_f(1).png");
            this.ribbonImageCollection.Images.SetKeyName(49, "folder_users.png");
            this.ribbonImageCollection.Images.SetKeyName(50, "contacts(3).png");
            this.ribbonImageCollection.Images.SetKeyName(51, "anggota32.png");
            this.ribbonImageCollection.Images.SetKeyName(52, "buku32.png");
            this.ribbonImageCollection.Images.SetKeyName(53, "multimedia32.png");
            this.ribbonImageCollection.Images.SetKeyName(54, "pengadaan32.png");
            this.ribbonImageCollection.Images.SetKeyName(55, "stockopname32.png");
            this.ribbonImageCollection.Images.SetKeyName(56, "prefix32.png");
            this.ribbonImageCollection.Images.SetKeyName(57, "Mes-documents-icon16.png");
            this.ribbonImageCollection.Images.SetKeyName(58, "Autocomplete16.png");
            this.ribbonImageCollection.Images.SetKeyName(59, "newspaper-add-icon.png");
            this.ribbonImageCollection.Images.SetKeyName(60, "agenda.png");
            this.ribbonImageCollection.Images.SetKeyName(61, "agenda16.png");
            this.ribbonImageCollection.Images.SetKeyName(62, "bookstatus.png");
            this.ribbonImageCollection.Images.SetKeyName(63, "pengunjung.png");
            this.ribbonImageCollection.Images.SetKeyName(64, "reminder1.png");
            this.ribbonImageCollection.Images.SetKeyName(65, "reminder2.png");
            // 
            // bciClose
            // 
            this.bciClose.Caption = "Close";
            this.bciClose.Enabled = false;
            this.bciClose.Id = 67;
            this.bciClose.ImageIndex = 23;
            this.bciClose.LargeImageIndex = 9;
            this.bciClose.LargeWidth = 80;
            this.bciClose.Name = "bciClose";
            this.bciClose.Tag = "Close";
            this.bciClose.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.bciClose_CheckedChanged);
            // 
            // bciExit
            // 
            this.bciExit.Caption = "Exit";
            this.bciExit.Id = 68;
            this.bciExit.ImageIndex = 6;
            this.bciExit.LargeImageIndex = 6;
            this.bciExit.LargeWidth = 80;
            this.bciExit.Name = "bciExit";
            this.bciExit.Tag = "Exit";
            this.bciExit.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.bciExit_CheckedChanged);
            // 
            // bciUtility
            // 
            this.bciUtility.Caption = "Utility";
            this.bciUtility.Id = 81;
            this.bciUtility.LargeImageIndex = 14;
            this.bciUtility.LargeWidth = 90;
            this.bciUtility.Name = "bciUtility";
            this.bciUtility.Tag = "Utility";
            this.bciUtility.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bciUtility.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciUtility_ItemClick);
            // 
            // bsiTahun
            // 
            this.bsiTahun.Caption = "Tahun Ajaran : ";
            this.bsiTahun.Id = 90;
            this.bsiTahun.Name = "bsiTahun";
            this.bsiTahun.TextAlignment = System.Drawing.StringAlignment.Near;
            this.bsiTahun.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "barStaticItem2";
            this.barStaticItem2.Id = 95;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barStaticItem3
            // 
            this.barStaticItem3.Caption = "barStaticItem3";
            this.barStaticItem3.Id = 96;
            this.barStaticItem3.Name = "barStaticItem3";
            this.barStaticItem3.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // bsiUsername
            // 
            this.bsiUsername.Caption = "Username : ";
            this.bsiUsername.Id = 97;
            this.bsiUsername.Name = "bsiUsername";
            this.bsiUsername.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // bsiServer
            // 
            this.bsiServer.Caption = "Server : ";
            this.bsiServer.Id = 98;
            this.bsiServer.Name = "bsiServer";
            this.bsiServer.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // bsiDatabase
            // 
            this.bsiDatabase.Caption = "Database : ";
            this.bsiDatabase.Id = 99;
            this.bsiDatabase.Name = "bsiDatabase";
            this.bsiDatabase.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // bciManagementUser
            // 
            this.bciManagementUser.Caption = "Management User";
            this.bciManagementUser.Id = 104;
            this.bciManagementUser.ImageIndex = 24;
            this.bciManagementUser.LargeImageIndex = 10;
            this.bciManagementUser.LargeWidth = 90;
            this.bciManagementUser.Name = "bciManagementUser";
            this.bciManagementUser.Tag = "(Utility) Management User";
            this.bciManagementUser.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciManagementUser_ItemClick);
            // 
            // bciCheckUpdate
            // 
            this.bciCheckUpdate.Caption = "Check Update";
            this.bciCheckUpdate.Id = 105;
            this.bciCheckUpdate.ImageIndex = 19;
            this.bciCheckUpdate.LargeImageIndex = 18;
            this.bciCheckUpdate.LargeWidth = 90;
            this.bciCheckUpdate.Name = "bciCheckUpdate";
            this.bciCheckUpdate.Tag = "Check Update";
            this.bciCheckUpdate.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciCheckUpdate_ItemClick);
            // 
            // bciSettingJadwalBeasiswa
            // 
            this.bciSettingJadwalBeasiswa.Caption = "Setting Jadwal";
            this.bciSettingJadwalBeasiswa.Id = 106;
            this.bciSettingJadwalBeasiswa.ImageIndex = 26;
            this.bciSettingJadwalBeasiswa.LargeImageIndex = 37;
            this.bciSettingJadwalBeasiswa.LargeWidth = 90;
            this.bciSettingJadwalBeasiswa.Name = "bciSettingJadwalBeasiswa";
            this.bciSettingJadwalBeasiswa.Tag = "(Beasiswa) Setting Jadwal";
            // 
            // bciDaftarBeasiswa
            // 
            this.bciDaftarBeasiswa.Caption = "Daftar Pengajuan Beasiswa";
            this.bciDaftarBeasiswa.Id = 110;
            this.bciDaftarBeasiswa.ImageIndex = 30;
            this.bciDaftarBeasiswa.LargeImageIndex = 41;
            this.bciDaftarBeasiswa.Name = "bciDaftarBeasiswa";
            this.bciDaftarBeasiswa.Tag = "(Beasiswa) Daftar Pengajuan Beasiswa";
            // 
            // bciSettingFinish
            // 
            this.bciSettingFinish.Caption = "Setting Finish Jadwal";
            this.bciSettingFinish.Id = 111;
            this.bciSettingFinish.ImageIndex = 31;
            this.bciSettingFinish.LargeImageIndex = 42;
            this.bciSettingFinish.LargeWidth = 90;
            this.bciSettingFinish.Name = "bciSettingFinish";
            this.bciSettingFinish.Tag = "(Beasiswa) Setting Finish Jadwal";
            // 
            // bciSettingGolongan
            // 
            this.bciSettingGolongan.Caption = "Setting Golongan dan Gaji Pokok";
            this.bciSettingGolongan.Id = 112;
            this.bciSettingGolongan.ImageIndex = 32;
            this.bciSettingGolongan.LargeImageIndex = 43;
            this.bciSettingGolongan.Name = "bciSettingGolongan";
            this.bciSettingGolongan.Tag = "(Utility) Setting Golongan dan Gaji Pokok";
            // 
            // bciSettingTarif
            // 
            this.bciSettingTarif.Caption = "Setting Tarif Gaji Pokok";
            this.bciSettingTarif.Id = 113;
            this.bciSettingTarif.ImageIndex = 33;
            this.bciSettingTarif.LargeImageIndex = 44;
            this.bciSettingTarif.LargeWidth = 90;
            this.bciSettingTarif.Name = "bciSettingTarif";
            this.bciSettingTarif.Tag = "(Utility) Setting Tarif Gaji Pokok";
            // 
            // bciRekapDosenWali
            // 
            this.bciRekapDosenWali.Caption = "Rekap Dosen Wali";
            this.bciRekapDosenWali.Id = 123;
            this.bciRekapDosenWali.ImageIndex = 17;
            this.bciRekapDosenWali.LargeImageIndex = 29;
            this.bciRekapDosenWali.LargeWidth = 90;
            this.bciRekapDosenWali.Name = "bciRekapDosenWali";
            this.bciRekapDosenWali.Tag = "(Honor) Rekap Dosen Wali";
            // 
            // pbarMain
            // 
            this.pbarMain.Caption = "Progress";
            this.pbarMain.Edit = this.repositoryItemProgressBar1;
            this.pbarMain.Id = 126;
            this.pbarMain.Name = "pbarMain";
            this.pbarMain.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.pbarMain.Width = 180;
            // 
            // repositoryItemProgressBar1
            // 
            this.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1";
            this.repositoryItemProgressBar1.Step = 1;
            // 
            // bciSkinGallery
            // 
            this.bciSkinGallery.Caption = "Skin Gallery";
            this.bciSkinGallery.Id = 127;
            this.bciSkinGallery.Name = "bciSkinGallery";
            this.bciSkinGallery.Tag = "Skin";
            this.bciSkinGallery.GalleryItemClick += new DevExpress.XtraBars.Ribbon.GalleryItemClickEventHandler(this.bciSkinGallery_Gallery_ItemClick);
            // 
            // bciSettingTunjanganPendidik
            // 
            this.bciSettingTunjanganPendidik.Caption = "Setting Tunjangan Pendidik";
            this.bciSettingTunjanganPendidik.Id = 128;
            this.bciSettingTunjanganPendidik.ImageIndex = 44;
            this.bciSettingTunjanganPendidik.LargeImageIndex = 56;
            this.bciSettingTunjanganPendidik.Name = "bciSettingTunjanganPendidik";
            this.bciSettingTunjanganPendidik.Tag = "(Utility) Setting Tunjangan Pendidik";
            // 
            // bciSettingTunjanganKependidikan
            // 
            this.bciSettingTunjanganKependidikan.Caption = "Setting Tunjangan Kependidikan";
            this.bciSettingTunjanganKependidikan.Id = 129;
            this.bciSettingTunjanganKependidikan.ImageIndex = 44;
            this.bciSettingTunjanganKependidikan.LargeImageIndex = 56;
            this.bciSettingTunjanganKependidikan.Name = "bciSettingTunjanganKependidikan";
            this.bciSettingTunjanganKependidikan.Tag = "(Utility) Setting Tunjangan Kependidikan";
            // 
            // bciTarifHonor
            // 
            this.bciTarifHonor.Caption = "Tarif Honor";
            this.bciTarifHonor.Id = 130;
            this.bciTarifHonor.ImageIndex = 48;
            this.bciTarifHonor.LargeImageIndex = 60;
            this.bciTarifHonor.LargeWidth = 90;
            this.bciTarifHonor.Name = "bciTarifHonor";
            this.bciTarifHonor.Tag = "(Utility) Tarif Honor";
            // 
            // bciReports
            // 
            this.bciReports.Caption = "Laporan";
            this.bciReports.Id = 131;
            this.bciReports.ImageIndex = 58;
            this.bciReports.LargeImageIndex = 68;
            this.bciReports.LargeWidth = 90;
            this.bciReports.Name = "bciReports";
            this.bciReports.Tag = "(Reports) Laporan";
            this.bciReports.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciReports_ItemClick);
            // 
            // bciPeminjaman
            // 
            this.bciPeminjaman.Caption = "Peminjaman";
            this.bciPeminjaman.Id = 132;
            this.bciPeminjaman.ImageIndex = 50;
            this.bciPeminjaman.LargeImageIndex = 62;
            this.bciPeminjaman.LargeWidth = 90;
            this.bciPeminjaman.Name = "bciPeminjaman";
            this.bciPeminjaman.Tag = "(Pengolahan) Peminjaman";
            this.bciPeminjaman.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciPeminjaman_ItemClick);
            // 
            // bciPengembalian
            // 
            this.bciPengembalian.Caption = "Pengembalian";
            this.bciPengembalian.Id = 133;
            this.bciPengembalian.ImageIndex = 49;
            this.bciPengembalian.LargeImageIndex = 61;
            this.bciPengembalian.LargeWidth = 90;
            this.bciPengembalian.Name = "bciPengembalian";
            this.bciPengembalian.Tag = "(Pengolahan) Pengembalian";
            this.bciPengembalian.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciPengembalian_ItemClick);
            // 
            // bciAnggota
            // 
            this.bciAnggota.Caption = "Anggota";
            this.bciAnggota.Id = 134;
            this.bciAnggota.ImageIndex = 51;
            this.bciAnggota.LargeImageIndex = 61;
            this.bciAnggota.LargeWidth = 90;
            this.bciAnggota.Name = "bciAnggota";
            this.bciAnggota.Tag = "(Master Data) Anggota";
            this.bciAnggota.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciAnggota_ItemClick);
            // 
            // bciPengadaan
            // 
            this.bciPengadaan.Caption = "Pengadaan";
            this.bciPengadaan.Id = 135;
            this.bciPengadaan.ImageIndex = 54;
            this.bciPengadaan.LargeImageIndex = 64;
            this.bciPengadaan.LargeWidth = 90;
            this.bciPengadaan.Name = "bciPengadaan";
            this.bciPengadaan.Tag = "(Master Data) Pengadaan";
            this.bciPengadaan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciDaftarGaji_ItemClick);
            // 
            // barDefaultSkin
            // 
            this.barDefaultSkin.Caption = "Default Skin";
            this.barDefaultSkin.Id = 136;
            this.barDefaultSkin.Name = "barDefaultSkin";
            this.barDefaultSkin.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barDefaultSkin_ItemClick);
            // 
            // bciBuku
            // 
            this.bciBuku.Caption = "Buku";
            this.bciBuku.Id = 138;
            this.bciBuku.ImageIndex = 52;
            this.bciBuku.LargeImageIndex = 62;
            this.bciBuku.LargeWidth = 90;
            this.bciBuku.Name = "bciBuku";
            this.bciBuku.Tag = "(Master Data) Buku";
            this.bciBuku.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciBuku_ItemClick);
            // 
            // bciMultimedia
            // 
            this.bciMultimedia.Caption = "Multimedia";
            this.bciMultimedia.Id = 139;
            this.bciMultimedia.ImageIndex = 53;
            this.bciMultimedia.LargeImageIndex = 63;
            this.bciMultimedia.LargeWidth = 90;
            this.bciMultimedia.Name = "bciMultimedia";
            this.bciMultimedia.Tag = "(Master Data) Multimedia";
            this.bciMultimedia.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciMultimedia_ItemClick);
            // 
            // bciStockOpname
            // 
            this.bciStockOpname.Caption = "Stock Opname";
            this.bciStockOpname.Id = 140;
            this.bciStockOpname.ImageIndex = 55;
            this.bciStockOpname.LargeImageIndex = 65;
            this.bciStockOpname.LargeWidth = 90;
            this.bciStockOpname.Name = "bciStockOpname";
            this.bciStockOpname.Tag = "(Master Data) Stock Opname";
            this.bciStockOpname.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // bciPrefixNumber
            // 
            this.bciPrefixNumber.Caption = "Prefix Number";
            this.bciPrefixNumber.Id = 141;
            this.bciPrefixNumber.ImageIndex = 56;
            this.bciPrefixNumber.LargeImageIndex = 66;
            this.bciPrefixNumber.LargeWidth = 90;
            this.bciPrefixNumber.Name = "bciPrefixNumber";
            this.bciPrefixNumber.Tag = "(Utility) Prefix Number";
            this.bciPrefixNumber.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciPrefixNumber_ItemClick);
            // 
            // bciNews
            // 
            this.bciNews.Caption = "Halaman Berita";
            this.bciNews.Id = 142;
            this.bciNews.ImageIndex = 59;
            this.bciNews.LargeImageIndex = 69;
            this.bciNews.LargeWidth = 90;
            this.bciNews.Name = "bciNews";
            this.bciNews.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.bciNews.Tag = "Halaman Berita";
            this.bciNews.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciNews_ItemClick);
            // 
            // bciAgenda
            // 
            this.bciAgenda.Caption = "Agenda";
            this.bciAgenda.Id = 143;
            this.bciAgenda.ImageIndex = 61;
            this.bciAgenda.LargeImageIndex = 71;
            this.bciAgenda.LargeWidth = 90;
            this.bciAgenda.Name = "bciAgenda";
            this.bciAgenda.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.bciAgenda.Tag = "Agenda";
            this.bciAgenda.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciAgenda_ItemClick);
            // 
            // bciSettingTanggalMerah
            // 
            this.bciSettingTanggalMerah.Caption = "Setting Tanggal Merah/Libur";
            this.bciSettingTanggalMerah.Id = 144;
            this.bciSettingTanggalMerah.ImageIndex = 31;
            this.bciSettingTanggalMerah.LargeImageIndex = 60;
            this.bciSettingTanggalMerah.LargeWidth = 90;
            this.bciSettingTanggalMerah.Name = "bciSettingTanggalMerah";
            this.bciSettingTanggalMerah.Tag = "Setting Tanggal Merah/Libur";
            this.bciSettingTanggalMerah.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciSettingTanggalMerah_ItemClick);
            // 
            // bciStatusBuku
            // 
            this.bciStatusBuku.Caption = "Status Buku";
            this.bciStatusBuku.Id = 145;
            this.bciStatusBuku.ImageIndex = 62;
            this.bciStatusBuku.LargeImageIndex = 72;
            this.bciStatusBuku.LargeWidth = 90;
            this.bciStatusBuku.Name = "bciStatusBuku";
            this.bciStatusBuku.Tag = "(Pengolahan) Status Buku";
            this.bciStatusBuku.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciStatusBuku_ItemClick);
            // 
            // bciPengunjung
            // 
            this.bciPengunjung.Caption = "Pengunjung";
            this.bciPengunjung.Id = 146;
            this.bciPengunjung.ImageIndex = 63;
            this.bciPengunjung.LargeImageIndex = 73;
            this.bciPengunjung.LargeWidth = 90;
            this.bciPengunjung.Name = "bciPengunjung";
            this.bciPengunjung.Tag = "(Pengolahan) Pengunjung";
            this.bciPengunjung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciPengunjung_ItemClick);
            // 
            // ribbonImageCollectionLarge
            // 
            this.ribbonImageCollectionLarge.ImageSize = new System.Drawing.Size(32, 32);
            this.ribbonImageCollectionLarge.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("ribbonImageCollectionLarge.ImageStream")));
            this.ribbonImageCollectionLarge.Images.SetKeyName(0, "Ribbon_New_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(1, "Ribbon_Open_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(2, "Ribbon_Close_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(3, "Ribbon_Find_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(4, "Ribbon_Save_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(5, "Ribbon_SaveAs_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(6, "Ribbon_Exit_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(7, "Ribbon_Content_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(8, "Ribbon_Info_32x32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(9, "close-icon32_2.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(10, "2011062709460991_easyicon_cn_32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(11, "report32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(12, "check-user-icon32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(13, "calendar_date32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(14, "ReportingSetup_32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(15, "documentcontrol32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(16, "folder utilities32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(17, "check-user-icon32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(18, "Software_Update_icon32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(19, "jadwalBeasiswa32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(20, "mahasiswa32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(21, "sms48.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(22, "dosen48.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(23, "daftarbeasiswa64.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(24, "acc.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(25, "gol32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(26, "tarifGaji32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(27, "Calendar-icon_3.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(28, "document-2-icon_3.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(29, "Book-phones-icon_2.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(30, "Books-icon_2.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(31, "Bookmark-icon_2.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(32, "folder-icon (2).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(33, "Action-view-icon-icon32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(34, "notebook-icon.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(35, "Document-scheduled-tasks-icon32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(36, "files(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(37, "my_documents(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(38, "tunjangan32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(39, "user_root(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(40, "user (2).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(41, "personal.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(42, "vault(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(43, "emp_kependidikan32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(44, "emp_pendidik32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(45, "documents_folder(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(46, "khexedit(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(47, "folder_temporary.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(48, "files_text.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(49, "documents(5).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(50, "folder_blue(2).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(51, "files_edit(2).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(52, "folder_documents.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(53, "doc_f2(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(54, "doc_f.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(55, "folder_desktop_alt.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(56, "folder_docs_alt.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(57, "folder_users(2).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(58, "contacts(1).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(59, "calendar (2).png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(60, "schedule.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(61, "anggota32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(62, "buku32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(63, "multimedia32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(64, "pengadaan32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(65, "stockopname32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(66, "prefix32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(67, "Mes-documents-icon.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(68, "Autocomplete32.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(69, "newspaper-add-icon.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(70, "agenda.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(71, "agenda48.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(72, "bookstatus.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(73, "pengunjung.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(74, "reminder1.png");
            this.ribbonImageCollectionLarge.Images.SetKeyName(75, "reminder2.png");
            // 
            // rpMaster
            // 
            this.rpMaster.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgMaster,
            this.ribbonPageGroup6});
            this.rpMaster.Name = "rpMaster";
            this.rpMaster.Text = "Master Data";
            // 
            // rpgMaster
            // 
            this.rpgMaster.ItemLinks.Add(this.bciAnggota);
            this.rpgMaster.ItemLinks.Add(this.bciPengadaan);
            this.rpgMaster.ItemLinks.Add(this.bciBuku);
            this.rpgMaster.ItemLinks.Add(this.bciMultimedia);
            this.rpgMaster.ItemLinks.Add(this.bciStockOpname);
            this.rpgMaster.Name = "rpgMaster";
            this.rpgMaster.Text = "Master Data";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.bciClose);
            this.ribbonPageGroup6.ItemLinks.Add(this.bciExit);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "Exit";
            // 
            // rpPengolahan
            // 
            this.rpPengolahan.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgPegawai,
            this.ribbonPageGroup5});
            this.rpPengolahan.Name = "rpPengolahan";
            this.rpPengolahan.Text = "Pengolahan";
            // 
            // rpgPegawai
            // 
            this.rpgPegawai.ItemLinks.Add(this.bciPeminjaman);
            this.rpgPegawai.ItemLinks.Add(this.bciPengembalian);
            this.rpgPegawai.ItemLinks.Add(this.bciStatusBuku);
            this.rpgPegawai.ItemLinks.Add(this.bciPengunjung);
            this.rpgPegawai.ItemLinks.Add(this.bciReminderMendekatiJatuhTempo);
            this.rpgPegawai.Name = "rpgPegawai";
            this.rpgPegawai.Text = "Buku";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.bciClose);
            this.ribbonPageGroup5.ItemLinks.Add(this.bciExit);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Exit";
            // 
            // rpReports
            // 
            this.rpReports.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgReport,
            this.ribbonPageGroup3});
            this.rpReports.Name = "rpReports";
            this.rpReports.Text = "Reports";
            // 
            // rpgReport
            // 
            this.rpgReport.ItemLinks.Add(this.bciReports);
            this.rpgReport.Name = "rpgReport";
            this.rpgReport.Text = "Reports";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.bciClose);
            this.ribbonPageGroup3.ItemLinks.Add(this.bciExit);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Exit";
            // 
            // rpWebAdmin
            // 
            this.rpWebAdmin.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgWebAdmin,
            this.ribbonPageGroup2});
            this.rpWebAdmin.Name = "rpWebAdmin";
            this.rpWebAdmin.Text = "Web Admin";
            // 
            // rpgWebAdmin
            // 
            this.rpgWebAdmin.ItemLinks.Add(this.bciNews);
            this.rpgWebAdmin.ItemLinks.Add(this.bciAgenda);
            this.rpgWebAdmin.Name = "rpgWebAdmin";
            this.rpgWebAdmin.Text = "Web Admin";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.bciClose);
            this.ribbonPageGroup2.ItemLinks.Add(this.bciExit);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Exit";
            // 
            // rpUtility
            // 
            this.rpUtility.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgUtility,
            this.rpgSkin,
            this.ribbonPageGroup1});
            this.rpUtility.Name = "rpUtility";
            this.rpUtility.Text = "Utility";
            // 
            // rpgUtility
            // 
            this.rpgUtility.ItemLinks.Add(this.bciManagementUser);
            this.rpgUtility.ItemLinks.Add(this.bciPrefixNumber);
            this.rpgUtility.ItemLinks.Add(this.bciUtility);
            this.rpgUtility.ItemLinks.Add(this.bciCheckUpdate);
            this.rpgUtility.ItemLinks.Add(this.bciSettingTanggalMerah);
            this.rpgUtility.Name = "rpgUtility";
            this.rpgUtility.Tag = "Utility";
            this.rpgUtility.Text = "Utility";
            // 
            // rpgSkin
            // 
            this.rpgSkin.ItemLinks.Add(this.bciSkinGallery);
            this.rpgSkin.Name = "rpgSkin";
            this.rpgSkin.Text = "Skin";
            this.rpgSkin.CaptionButtonClick += new DevExpress.XtraBars.Ribbon.RibbonPageGroupEventHandler(this.skinGrp_CaptionButtonClick);
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.bciClose);
            this.ribbonPageGroup1.ItemLinks.Add(this.bciExit);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Exit";
            // 
            // ribbonStatusBar
            // 
            this.ribbonStatusBar.ItemLinks.Add(this.bsiTahun);
            this.ribbonStatusBar.ItemLinks.Add(this.bsiUsername, true);
            this.ribbonStatusBar.ItemLinks.Add(this.bsiServer, true);
            this.ribbonStatusBar.ItemLinks.Add(this.bsiDatabase, true);
            this.ribbonStatusBar.ItemLinks.Add(this.pbarMain);
            this.ribbonStatusBar.Location = new System.Drawing.Point(0, 773);
            this.ribbonStatusBar.Margin = new System.Windows.Forms.Padding(4);
            this.ribbonStatusBar.Name = "ribbonStatusBar";
            this.ribbonStatusBar.Ribbon = this.ribbonControl;
            this.ribbonStatusBar.Size = new System.Drawing.Size(1497, 31);
            // 
            // mainPanel
            // 
            this.mainPanel.ContentImage = global::DIGILIB.Properties.Resources.bgblue2;
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(0, 140);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(4);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(1497, 633);
            this.mainPanel.TabIndex = 2;
            this.mainPanel.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.mainPanel_ControlAdded);
            this.mainPanel.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.mainPanel_ControlRemoved);
            // 
            // popupMenu1
            // 
            this.popupMenu1.ItemLinks.Add(this.barDefaultSkin);
            this.popupMenu1.Name = "popupMenu1";
            this.popupMenu1.Ribbon = this.ribbonControl;
            // 
            // bciReminderMendekatiJatuhTempo
            // 
            this.bciReminderMendekatiJatuhTempo.Caption = "Reminder Mendekati Jatuh Tempo";
            this.bciReminderMendekatiJatuhTempo.Id = 147;
            this.bciReminderMendekatiJatuhTempo.ImageIndex = 64;
            this.bciReminderMendekatiJatuhTempo.LargeImageIndex = 74;
            this.bciReminderMendekatiJatuhTempo.Name = "bciReminderMendekatiJatuhTempo";
            this.bciReminderMendekatiJatuhTempo.Tag = "(Pengolahan) Reminder Mendekati Jatuh Tempo";
            this.bciReminderMendekatiJatuhTempo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bciReminderMendekatiJatuhTempo_ItemClick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1497, 804);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.ribbonControl);
            this.Controls.Add(this.ribbonStatusBar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Digital Library Politeknik Negeri Batam";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonImageCollectionLarge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
        private DevExpress.Utils.ImageCollection ribbonImageCollection;
        private DevExpress.Utils.ImageCollection ribbonImageCollectionLarge;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpUtility;
        private DevExpress.XtraBars.BarCheckItem bciClose;
        private DevExpress.XtraBars.BarCheckItem bciExit;
        private DevExpress.XtraEditors.PanelControl mainPanel;
        private DevExpress.XtraBars.BarCheckItem bciUtility;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgUtility;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraBars.BarStaticItem barStaticItem3;
        public DevExpress.XtraBars.BarStaticItem bsiTahun;
        public DevExpress.XtraBars.BarStaticItem bsiUsername;
        public DevExpress.XtraBars.BarStaticItem bsiServer;
        public DevExpress.XtraBars.BarStaticItem bsiDatabase;
        private DevExpress.XtraBars.BarCheckItem bciManagementUser;
        private DevExpress.XtraBars.BarCheckItem bciCheckUpdate;
        private DevExpress.XtraBars.BarCheckItem bciSettingJadwalBeasiswa;
        private DevExpress.XtraBars.BarCheckItem bciDaftarBeasiswa;
        private DevExpress.XtraBars.BarCheckItem bciSettingFinish;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpMaster;
        private DevExpress.XtraBars.BarCheckItem bciSettingGolongan;
        private DevExpress.XtraBars.BarCheckItem bciSettingTarif;
        private DevExpress.XtraBars.BarCheckItem bciRekapDosenWali;
        public DevExpress.XtraBars.BarEditItem pbarMain;
        public DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemProgressBar1;
        private DevExpress.XtraBars.RibbonGalleryBarItem bciSkinGallery;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgSkin;
        private DevExpress.XtraBars.BarCheckItem bciSettingTunjanganPendidik;
        private DevExpress.XtraBars.BarCheckItem bciSettingTunjanganKependidikan;
        private DevExpress.XtraBars.BarCheckItem bciTarifHonor;
        private DevExpress.XtraBars.BarCheckItem bciReports;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpReports;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgReport;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.BarCheckItem bciPeminjaman;
        private DevExpress.XtraBars.BarCheckItem bciPengembalian;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpPengolahan;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgPegawai;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.BarCheckItem bciAnggota;
        private DevExpress.XtraBars.BarCheckItem bciPengadaan;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgMaster;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.BarButtonItem barDefaultSkin;
        private DevExpress.XtraBars.PopupMenu popupMenu1;
        private DevExpress.XtraBars.BarCheckItem bciBuku;
        private DevExpress.XtraBars.BarCheckItem bciMultimedia;
        private DevExpress.XtraBars.BarCheckItem bciStockOpname;
        private DevExpress.XtraBars.BarCheckItem bciPrefixNumber;
        private DevExpress.XtraBars.BarCheckItem bciNews;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpWebAdmin;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgWebAdmin;
        private DevExpress.XtraBars.BarCheckItem bciAgenda;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.BarCheckItem bciSettingTanggalMerah;
        private DevExpress.XtraBars.BarCheckItem bciStatusBuku;
        private DevExpress.XtraBars.BarCheckItem bciPengunjung;
        private DevExpress.XtraBars.BarCheckItem bciReminderMendekatiJatuhTempo;
    }
}
