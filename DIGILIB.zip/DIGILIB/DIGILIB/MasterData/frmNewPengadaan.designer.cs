﻿namespace DIGILIB.MasterData
{
    partial class frmNewPengadaan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewPengadaan));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtnopengadaan = new DevExpress.XtraEditors.TextEdit();
            this.datetglpengadaan = new DevExpress.XtraEditors.DateEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.cboPetugas = new DevExpress.XtraEditors.LookUpEdit();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridViewData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.pengadaanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengadaandetailsid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nopo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.pengarang = new DevExpress.XtraGrid.Columns.GridColumn();
            this.edisi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.penerbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tempatterbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tahunterbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isbn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.supplemen = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengusul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jumlah = new DevExpress.XtraGrid.Columns.GridColumn();
            this.status = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.harga = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nourut = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryLUJenjang = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryLUJurusan = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.pBar = new DevExpress.XtraEditors.ProgressBarControl();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.txtnamapetugas = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelControl6 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.btnAddNew = new DevExpress.XtraEditors.SimpleButton();
            this.btnAdd = new DevExpress.XtraEditors.SimpleButton();
            this.txtjumlah = new DevExpress.XtraEditors.TextEdit();
            this.cboNIB = new DevExpress.XtraEditors.GridLookUpEdit();
            this.gridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.bukuid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kodepanggil1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.noinduk1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengarang1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.edisi1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.penerbit1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isbn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtnopengadaan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpengadaan.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpengadaan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPetugas.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJenjang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJurusan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBar.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamapetugas.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).BeginInit();
            this.panelControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtjumlah.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboNIB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.labelControl12);
            this.panelControl1.Controls.Add(this.labelControl11);
            this.panelControl1.Controls.Add(this.txtnopengadaan);
            this.panelControl1.Controls.Add(this.datetglpengadaan);
            this.panelControl1.Location = new System.Drawing.Point(0, 68);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(502, 60);
            this.panelControl1.TabIndex = 0;
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(7, 29);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(145, 13);
            this.labelControl12.TabIndex = 94;
            this.labelControl12.Text = "TGL PENGADAAN / DITERIMA:";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(7, 6);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(106, 13);
            this.labelControl11.TabIndex = 92;
            this.labelControl11.Text = "NOMOR PENGADAAN:";
            // 
            // txtnopengadaan
            // 
            this.txtnopengadaan.Location = new System.Drawing.Point(167, 3);
            this.txtnopengadaan.Name = "txtnopengadaan";
            this.txtnopengadaan.Size = new System.Drawing.Size(221, 20);
            this.txtnopengadaan.TabIndex = 0;
            // 
            // datetglpengadaan
            // 
            this.datetglpengadaan.EditValue = null;
            this.datetglpengadaan.Location = new System.Drawing.Point(167, 26);
            this.datetglpengadaan.Name = "datetglpengadaan";
            this.datetglpengadaan.Properties.AllowMouseWheel = false;
            this.datetglpengadaan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datetglpengadaan.Properties.DisplayFormat.FormatString = "dd MMM yyyy";
            this.datetglpengadaan.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.datetglpengadaan.Properties.EditFormat.FormatString = "dd MMM yyyy";
            this.datetglpengadaan.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.datetglpengadaan.Properties.Mask.EditMask = "dd MMM yyyy";
            this.datetglpengadaan.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.datetglpengadaan.Size = new System.Drawing.Size(155, 20);
            this.datetglpengadaan.TabIndex = 1;
            this.datetglpengadaan.EditValueChanged += new System.EventHandler(this.cbo_EditValueChanged);
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(10, 8);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(94, 13);
            this.labelControl4.TabIndex = 83;
            this.labelControl4.Text = "Nomor Induk Buku :";
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureEdit1.EditValue = ((object)(resources.GetObject("pictureEdit1.EditValue")));
            this.pictureEdit1.Location = new System.Drawing.Point(592, 3);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit1.Size = new System.Drawing.Size(335, 52);
            this.pictureEdit1.TabIndex = 89;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(5, 32);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(73, 13);
            this.labelControl1.TabIndex = 11;
            this.labelControl1.Text = "Nama Petugas:";
            // 
            // cboPetugas
            // 
            this.cboPetugas.Location = new System.Drawing.Point(103, 6);
            this.cboPetugas.Name = "cboPetugas";
            this.cboPetugas.Properties.AllowMouseWheel = false;
            this.cboPetugas.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboPetugas.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("anggotaid", "anggotaid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nim", 100, "NIK"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("nama", 200, "Nama"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("rfid", "rfid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.cboPetugas.Properties.DisplayMember = "nim";
            this.cboPetugas.Properties.DropDownRows = 15;
            this.cboPetugas.Properties.NullText = "";
            this.cboPetugas.Properties.PopupWidth = 650;
            this.cboPetugas.Properties.ValueMember = "anggotaid";
            this.cboPetugas.Size = new System.Drawing.Size(275, 20);
            this.cboPetugas.TabIndex = 8;
            this.cboPetugas.EditValueChanged += new System.EventHandler(this.cbo_EditValueChanged);
            // 
            // panelControl2
            // 
            this.panelControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl2.Controls.Add(this.dgData);
            this.panelControl2.Location = new System.Drawing.Point(0, 173);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(929, 375);
            this.panelControl2.TabIndex = 1;
            // 
            // dgData
            // 
            this.dgData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgData.Location = new System.Drawing.Point(2, 2);
            this.dgData.MainView = this.gridViewData;
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryLUJenjang,
            this.repositoryLUJurusan,
            this.repositoryItemComboBox1,
            this.repositoryItemMemoEdit1});
            this.dgData.Size = new System.Drawing.Size(925, 371);
            this.dgData.TabIndex = 1;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewData});
            // 
            // gridViewData
            // 
            this.gridViewData.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridViewData.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewData.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewData.Appearance.Row.Options.UseTextOptions = true;
            this.gridViewData.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewData.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewData.ColumnPanelRowHeight = 35;
            this.gridViewData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.pengadaanid,
            this.pengadaandetailsid,
            this.nopo,
            this.judul,
            this.pengarang,
            this.edisi,
            this.penerbit,
            this.tempatterbit,
            this.tahunterbit,
            this.isbn,
            this.supplemen,
            this.pengusul,
            this.jumlah,
            this.status,
            this.harga,
            this.nourut});
            this.gridViewData.GridControl = this.dgData;
            this.gridViewData.Name = "gridViewData";
            this.gridViewData.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewData.OptionsView.ShowGroupPanel = false;
            // 
            // pengadaanid
            // 
            this.pengadaanid.Caption = "pengadaanid";
            this.pengadaanid.FieldName = "pengadaanid";
            this.pengadaanid.Name = "pengadaanid";
            // 
            // pengadaandetailsid
            // 
            this.pengadaandetailsid.Caption = "pengadaandetailsid";
            this.pengadaandetailsid.FieldName = "pengadaandetailsid";
            this.pengadaandetailsid.Name = "pengadaandetailsid";
            // 
            // nopo
            // 
            this.nopo.Caption = "No PO";
            this.nopo.FieldName = "nopo";
            this.nopo.MinWidth = 100;
            this.nopo.Name = "nopo";
            this.nopo.Visible = true;
            this.nopo.VisibleIndex = 0;
            this.nopo.Width = 100;
            // 
            // judul
            // 
            this.judul.Caption = "Judul";
            this.judul.ColumnEdit = this.repositoryItemMemoEdit1;
            this.judul.FieldName = "judul";
            this.judul.MinWidth = 200;
            this.judul.Name = "judul";
            this.judul.Visible = true;
            this.judul.VisibleIndex = 1;
            this.judul.Width = 200;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // pengarang
            // 
            this.pengarang.Caption = "Pengarang";
            this.pengarang.FieldName = "pengarang";
            this.pengarang.MinWidth = 150;
            this.pengarang.Name = "pengarang";
            this.pengarang.Visible = true;
            this.pengarang.VisibleIndex = 2;
            this.pengarang.Width = 150;
            // 
            // edisi
            // 
            this.edisi.Caption = "Edisi";
            this.edisi.FieldName = "edisi";
            this.edisi.MinWidth = 100;
            this.edisi.Name = "edisi";
            this.edisi.Visible = true;
            this.edisi.VisibleIndex = 3;
            this.edisi.Width = 100;
            // 
            // penerbit
            // 
            this.penerbit.Caption = "Penerbit";
            this.penerbit.FieldName = "penerbit";
            this.penerbit.MinWidth = 150;
            this.penerbit.Name = "penerbit";
            this.penerbit.Visible = true;
            this.penerbit.VisibleIndex = 4;
            this.penerbit.Width = 150;
            // 
            // tempatterbit
            // 
            this.tempatterbit.Caption = "Tempat Terbit";
            this.tempatterbit.FieldName = "tempatterbit";
            this.tempatterbit.MinWidth = 150;
            this.tempatterbit.Name = "tempatterbit";
            this.tempatterbit.Visible = true;
            this.tempatterbit.VisibleIndex = 5;
            this.tempatterbit.Width = 150;
            // 
            // tahunterbit
            // 
            this.tahunterbit.Caption = "Tahun Terbit";
            this.tahunterbit.FieldName = "tahunterbit";
            this.tahunterbit.MinWidth = 100;
            this.tahunterbit.Name = "tahunterbit";
            this.tahunterbit.Visible = true;
            this.tahunterbit.VisibleIndex = 6;
            this.tahunterbit.Width = 100;
            // 
            // isbn
            // 
            this.isbn.Caption = "ISBN";
            this.isbn.FieldName = "isbn";
            this.isbn.MinWidth = 150;
            this.isbn.Name = "isbn";
            this.isbn.Visible = true;
            this.isbn.VisibleIndex = 7;
            this.isbn.Width = 150;
            // 
            // supplemen
            // 
            this.supplemen.Caption = "Supplemen";
            this.supplemen.FieldName = "supplemen";
            this.supplemen.MinWidth = 100;
            this.supplemen.Name = "supplemen";
            this.supplemen.Visible = true;
            this.supplemen.VisibleIndex = 8;
            this.supplemen.Width = 100;
            // 
            // pengusul
            // 
            this.pengusul.Caption = "Pengusul";
            this.pengusul.FieldName = "pengusul";
            this.pengusul.MinWidth = 150;
            this.pengusul.Name = "pengusul";
            this.pengusul.Visible = true;
            this.pengusul.VisibleIndex = 9;
            this.pengusul.Width = 150;
            // 
            // jumlah
            // 
            this.jumlah.Caption = "Jumlah";
            this.jumlah.DisplayFormat.FormatString = "#,##0";
            this.jumlah.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.jumlah.FieldName = "jumlah";
            this.jumlah.MinWidth = 100;
            this.jumlah.Name = "jumlah";
            this.jumlah.Visible = true;
            this.jumlah.VisibleIndex = 10;
            this.jumlah.Width = 100;
            // 
            // status
            // 
            this.status.Caption = "Status";
            this.status.ColumnEdit = this.repositoryItemComboBox1;
            this.status.FieldName = "status";
            this.status.MinWidth = 100;
            this.status.Name = "status";
            this.status.Visible = true;
            this.status.VisibleIndex = 11;
            this.status.Width = 100;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "Teks",
            "Tandon",
            "Referensi",
            "Restricted"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // harga
            // 
            this.harga.Caption = "Harga";
            this.harga.DisplayFormat.FormatString = "#,##0";
            this.harga.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.harga.FieldName = "harga";
            this.harga.MinWidth = 100;
            this.harga.Name = "harga";
            this.harga.Visible = true;
            this.harga.VisibleIndex = 12;
            this.harga.Width = 100;
            // 
            // nourut
            // 
            this.nourut.Caption = "nourut";
            this.nourut.FieldName = "nourut";
            this.nourut.Name = "nourut";
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryLUJenjang
            // 
            this.repositoryLUJenjang.AutoHeight = false;
            this.repositoryLUJenjang.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUJenjang.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjangakademikid", "jenjangakademikid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjang", "jenjang")});
            this.repositoryLUJenjang.DisplayMember = "jenjang";
            this.repositoryLUJenjang.DropDownRows = 15;
            this.repositoryLUJenjang.Name = "repositoryLUJenjang";
            this.repositoryLUJenjang.NullText = "";
            this.repositoryLUJenjang.ShowHeader = false;
            this.repositoryLUJenjang.ValueMember = "jenjangakademikid";
            // 
            // repositoryLUJurusan
            // 
            this.repositoryLUJurusan.AutoHeight = false;
            this.repositoryLUJurusan.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUJurusan.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusanid", "jurusanid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusancode", "Kode Jurusan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusandesc", 50, "Nama Jurusan")});
            this.repositoryLUJurusan.DisplayMember = "jurusandesc";
            this.repositoryLUJurusan.DropDownRows = 15;
            this.repositoryLUJurusan.Name = "repositoryLUJurusan";
            this.repositoryLUJurusan.NullText = "";
            this.repositoryLUJurusan.ValueMember = "jurusanid";
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(103, 554);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(91, 24);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSave.Appearance.Options.UseFont = true;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(12, 554);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 24);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Simpan";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pBar
            // 
            this.pBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pBar.Location = new System.Drawing.Point(370, 554);
            this.pBar.Name = "pBar";
            this.pBar.Properties.ShowTitle = true;
            this.pBar.Properties.Step = 1;
            this.pBar.Size = new System.Drawing.Size(418, 18);
            this.pBar.TabIndex = 83;
            this.pBar.Visible = false;
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Appearance.Options.UseFont = true;
            this.btnPreview.Image = ((System.Drawing.Image)(resources.GetObject("btnPreview.Image")));
            this.btnPreview.Location = new System.Drawing.Point(826, 554);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(91, 24);
            this.btnPreview.TabIndex = 14;
            this.btnPreview.Text = "Preview";
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // panelControl3
            // 
            this.panelControl3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl3.Controls.Add(this.txtnamapetugas);
            this.panelControl3.Controls.Add(this.labelControl3);
            this.panelControl3.Controls.Add(this.labelControl1);
            this.panelControl3.Controls.Add(this.cboPetugas);
            this.panelControl3.Location = new System.Drawing.Point(508, 68);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(419, 60);
            this.panelControl3.TabIndex = 85;
            // 
            // txtnamapetugas
            // 
            this.txtnamapetugas.Location = new System.Drawing.Point(103, 32);
            this.txtnamapetugas.Name = "txtnamapetugas";
            this.txtnamapetugas.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtnamapetugas.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtnamapetugas.Properties.ReadOnly = true;
            this.txtnamapetugas.Size = new System.Drawing.Size(275, 20);
            this.txtnamapetugas.TabIndex = 13;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Location = new System.Drawing.Point(5, 7);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(57, 13);
            this.labelControl3.TabIndex = 12;
            this.labelControl3.Text = "ID Petugas:";
            // 
            // panelControl4
            // 
            this.panelControl4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl4.Controls.Add(this.pictureBox1);
            this.panelControl4.Controls.Add(this.label1);
            this.panelControl4.Controls.Add(this.pictureEdit1);
            this.panelControl4.Location = new System.Drawing.Point(0, 0);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(929, 63);
            this.panelControl4.TabIndex = 95;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(5, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 61);
            this.pictureBox1.TabIndex = 93;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16F);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(71, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 25);
            this.label1.TabIndex = 92;
            this.label1.Text = "Master Data -> Pengadaan Buku";
            // 
            // panelControl6
            // 
            this.panelControl6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl6.Controls.Add(this.labelControl2);
            this.panelControl6.Controls.Add(this.btnAddNew);
            this.panelControl6.Controls.Add(this.btnAdd);
            this.panelControl6.Controls.Add(this.txtjumlah);
            this.panelControl6.Controls.Add(this.labelControl4);
            this.panelControl6.Controls.Add(this.cboNIB);
            this.panelControl6.Location = new System.Drawing.Point(0, 134);
            this.panelControl6.Name = "panelControl6";
            this.panelControl6.Size = new System.Drawing.Size(929, 33);
            this.panelControl6.TabIndex = 97;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Location = new System.Drawing.Point(451, 8);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(40, 13);
            this.labelControl2.TabIndex = 87;
            this.labelControl2.Text = "Jumlah :";
            // 
            // btnAddNew
            // 
            this.btnAddNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAddNew.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAddNew.Appearance.Options.UseFont = true;
            this.btnAddNew.Image = ((System.Drawing.Image)(resources.GetObject("btnAddNew.Image")));
            this.btnAddNew.Location = new System.Drawing.Point(729, 4);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(157, 24);
            this.btnAddNew.TabIndex = 86;
            this.btnAddNew.Text = "Tambah Buku Baru";
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdd.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Appearance.Options.UseFont = true;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(576, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(85, 24);
            this.btnAdd.TabIndex = 85;
            this.btnAdd.Text = "Tambah";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtjumlah
            // 
            this.txtjumlah.Location = new System.Drawing.Point(497, 5);
            this.txtjumlah.Name = "txtjumlah";
            this.txtjumlah.Size = new System.Drawing.Size(73, 20);
            this.txtjumlah.TabIndex = 84;
            // 
            // cboNIB
            // 
            this.cboNIB.Location = new System.Drawing.Point(126, 5);
            this.cboNIB.Name = "cboNIB";
            this.cboNIB.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboNIB.Properties.DisplayMember = "noinduk";
            this.cboNIB.Properties.ImmediatePopup = true;
            this.cboNIB.Properties.NullText = "";
            this.cboNIB.Properties.PopupFormMinSize = new System.Drawing.Size(800, 400);
            this.cboNIB.Properties.ValueMember = "bukuid";
            this.cboNIB.Properties.View = this.gridLookUpEdit1View;
            this.cboNIB.Size = new System.Drawing.Size(297, 20);
            this.cboNIB.TabIndex = 5;
            this.cboNIB.EditValueChanged += new System.EventHandler(this.cbo_EditValueChanged);
            // 
            // gridLookUpEdit1View
            // 
            this.gridLookUpEdit1View.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridLookUpEdit1View.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridLookUpEdit1View.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridLookUpEdit1View.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridLookUpEdit1View.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.bukuid1,
            this.kodepanggil1,
            this.noinduk1,
            this.judul1,
            this.pengarang1,
            this.edisi1,
            this.penerbit1,
            this.isbn1});
            this.gridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridLookUpEdit1View.Name = "gridLookUpEdit1View";
            this.gridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // bukuid1
            // 
            this.bukuid1.Caption = "bukuid";
            this.bukuid1.FieldName = "bukuid";
            this.bukuid1.Name = "bukuid1";
            // 
            // kodepanggil1
            // 
            this.kodepanggil1.Caption = "Kode Panggil";
            this.kodepanggil1.FieldName = "kodepanggil";
            this.kodepanggil1.MinWidth = 150;
            this.kodepanggil1.Name = "kodepanggil1";
            this.kodepanggil1.Visible = true;
            this.kodepanggil1.VisibleIndex = 1;
            this.kodepanggil1.Width = 150;
            // 
            // noinduk1
            // 
            this.noinduk1.Caption = "No Induk";
            this.noinduk1.FieldName = "noinduk";
            this.noinduk1.MinWidth = 150;
            this.noinduk1.Name = "noinduk1";
            this.noinduk1.Visible = true;
            this.noinduk1.VisibleIndex = 0;
            this.noinduk1.Width = 150;
            // 
            // judul1
            // 
            this.judul1.Caption = "Judul";
            this.judul1.FieldName = "judul";
            this.judul1.MinWidth = 200;
            this.judul1.Name = "judul1";
            this.judul1.Visible = true;
            this.judul1.VisibleIndex = 2;
            this.judul1.Width = 200;
            // 
            // pengarang1
            // 
            this.pengarang1.Caption = "Pengarang";
            this.pengarang1.FieldName = "pengarang";
            this.pengarang1.MinWidth = 150;
            this.pengarang1.Name = "pengarang1";
            this.pengarang1.Visible = true;
            this.pengarang1.VisibleIndex = 3;
            this.pengarang1.Width = 150;
            // 
            // edisi1
            // 
            this.edisi1.Caption = "Edisi";
            this.edisi1.FieldName = "edisi";
            this.edisi1.MinWidth = 100;
            this.edisi1.Name = "edisi1";
            this.edisi1.Visible = true;
            this.edisi1.VisibleIndex = 4;
            this.edisi1.Width = 100;
            // 
            // penerbit1
            // 
            this.penerbit1.Caption = "Penerbit";
            this.penerbit1.FieldName = "penerbit";
            this.penerbit1.MinWidth = 150;
            this.penerbit1.Name = "penerbit1";
            this.penerbit1.Visible = true;
            this.penerbit1.VisibleIndex = 5;
            this.penerbit1.Width = 150;
            // 
            // isbn1
            // 
            this.isbn1.Caption = "ISBN";
            this.isbn1.FieldName = "isbn";
            this.isbn1.MinWidth = 150;
            this.isbn1.Name = "isbn1";
            this.isbn1.Visible = true;
            this.isbn1.VisibleIndex = 6;
            this.isbn1.Width = 150;
            // 
            // frmNewPengadaan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 584);
            this.Controls.Add(this.panelControl4);
            this.Controls.Add(this.panelControl6);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.panelControl3);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.pBar);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.panelControl2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmNewPengadaan";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form Pengadaan";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmNewPengadaan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtnopengadaan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpengadaan.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datetglpengadaan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPetugas.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJenjang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJurusan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBar.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamapetugas.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            this.panelControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).EndInit();
            this.panelControl6.ResumeLayout(false);
            this.panelControl6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtjumlah.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboNIB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        public DevExpress.XtraEditors.LookUpEdit cboPetugas;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        public DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraEditors.ProgressBarControl pBar;
        public DevExpress.XtraEditors.DateEdit datetglpengadaan;
        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        public DevExpress.XtraEditors.TextEdit txtnopengadaan;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl6;
        private DevExpress.XtraEditors.GridLookUpEdit cboNIB;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        public DevExpress.XtraEditors.TextEdit txtnamapetugas;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private System.Windows.Forms.Label label1;
        public DevExpress.XtraEditors.TextEdit txtjumlah;
        public DevExpress.XtraEditors.SimpleButton btnAdd;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid1;
        private DevExpress.XtraGrid.Columns.GridColumn noinduk1;
        private DevExpress.XtraGrid.Columns.GridColumn kodepanggil1;
        private DevExpress.XtraGrid.Columns.GridColumn judul1;
        private DevExpress.XtraGrid.Columns.GridColumn pengarang1;
        private DevExpress.XtraGrid.Columns.GridColumn edisi1;
        private DevExpress.XtraGrid.Columns.GridColumn penerbit1;
        private DevExpress.XtraGrid.Columns.GridColumn isbn1;
        private System.Windows.Forms.PictureBox pictureBox1;
        public DevExpress.XtraEditors.SimpleButton btnAddNew;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewData;
        private DevExpress.XtraGrid.Columns.GridColumn pengadaanid;
        private DevExpress.XtraGrid.Columns.GridColumn nopo;
        private DevExpress.XtraGrid.Columns.GridColumn judul;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn pengarang;
        private DevExpress.XtraGrid.Columns.GridColumn edisi;
        private DevExpress.XtraGrid.Columns.GridColumn penerbit;
        private DevExpress.XtraGrid.Columns.GridColumn tempatterbit;
        private DevExpress.XtraGrid.Columns.GridColumn tahunterbit;
        private DevExpress.XtraGrid.Columns.GridColumn isbn;
        private DevExpress.XtraGrid.Columns.GridColumn supplemen;
        private DevExpress.XtraGrid.Columns.GridColumn pengusul;
        private DevExpress.XtraGrid.Columns.GridColumn jumlah;
        private DevExpress.XtraGrid.Columns.GridColumn status;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraGrid.Columns.GridColumn harga;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUJenjang;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUJurusan;
        private DevExpress.XtraGrid.Columns.GridColumn pengadaandetailsid;
        private DevExpress.XtraGrid.Columns.GridColumn nourut;
        private DevExpress.XtraEditors.LabelControl labelControl2;
    }
}