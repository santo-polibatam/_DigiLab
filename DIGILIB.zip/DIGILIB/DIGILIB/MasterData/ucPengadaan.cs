﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Views.Grid;
using Npgsql;

namespace DIGILIB.MasterData
{
    public partial class ucPengadaan : DevExpress.XtraEditors.XtraUserControl
    {
        public ucPengadaan()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        public frmMain formMain;
        WaitDialogForm loadDialog;

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null || loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public string strID = "";

        public void loadData()
        {
            setLoadDialog(true, "Loading data...");
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                string strSql = @"select a.*, b.nim, b.nama
                            from tbm_pengadaan a
                            left outer join tbm_anggota b on a.anggotaid=b.anggotaid and b.dlt='0'
                            where a.dlt='0'
                            order by a.nourut desc";
                DataTable dt = oConn.GetData(strSql);
                dgData.DataSource = dt;
                xdt = dt.Copy();
                btnAdd.Enabled = clsGlobal.bolAdd;
                btnEdit.Enabled = clsGlobal.bolEdit;
                btnDelete.Enabled = clsGlobal.bolDelete;
                setLoadDialog(false, "");
                if (dt.Rows.Count == 0)
                {
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                }
                else
                {
                    btnEdit.Enabled = clsGlobal.bolEdit;
                    btnDelete.Enabled = clsGlobal.bolDelete;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void ucProdi_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        private void ucProdi_Load(object sender, EventArgs e)
        {
            //loadDataJurusan();
            //loadData();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            //if (Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid)) != "")
            //{
            //    if (XtraMessageBox.Show("Anda yakin menghapus data ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            //    {
            //        clsConnection oConn = new clsConnection();
            //        tbp_pegawai_jenjang oObject = new tbp_pegawai_jenjang();
            //        oConn.Open();
            //        oObject.Koneksi = oConn.Conn;
            //        oObject.pegawai_jenjangid = Convert.ToString(Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid)));
            //        oObject.op_edit = clsGlobal.strUserName;
            //        oObject.pc_edit = SystemInformation.ComputerName;
            //        oObject.SoftDelete();
            //        oConn.Close();
            //        oObject = null; oConn = null;
            //        gridViewData.DeleteSelectedRows();
            //    }
            //}
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmNewPengadaan frm = new frmNewPengadaan();
            try
            {
                frm.pEdit = false;
                frm.datetglpengadaan.EditValue = clsGlobal.getServerDate();
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    loadData();
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }

            frm.Close();
            frm.Dispose();
            frm = null;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmNewPengadaan frm = new frmNewPengadaan();
            try
            {
                frm.strID = Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid));
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    loadData();
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }

            frm.Close();
            frm.Dispose();
            frm = null;
        }

        private void gridViewData_DoubleClick(object sender, EventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid)) != "")
            {
                btnEdit_Click(sender, e);
            }
        }

        private void gridViewData_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid)) != "")
            {
                btnEdit.Enabled = clsGlobal.bolEdit;
                btnDelete.Enabled = clsGlobal.bolDelete;
            }
            else
            {
                btnEdit.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        DataTable xdt;
        private void btnPreview_Click(object sender, EventArgs e)
        {
            btnPreview.Enabled = false;
            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptDaftarPengadaan.repx";
                reportName = "rptDaftarPengadaan";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    List<string> pengadaanid_list = new List<string>();
                    if (xdt.Rows.Count > gridViewData.RowCount)
                    {
                        int rowHandle;
                        for (int i = 0; i < gridViewData.RowCount; i++)
                        {
                            rowHandle = gridViewData.GetVisibleRowHandle(i);
                            if (!gridViewData.IsGroupRow(rowHandle))
                            {
                                object key = gridViewData.GetRowCellValue(rowHandle, pengadaanid);
                                if (key != null && key != DBNull.Value)
                                {
                                    if (!pengadaanid_list.Contains(key.ToString()))
                                        pengadaanid_list.Add(key.ToString());
                                }
                            }
                        }
                    }
                    string strsql = @"select distinct 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Daftar Pengadaan Buku' as header2, 
                                b.*, a.*, c.bukuid
                                from tbm_pengadaandetails a
                                inner join tbm_pengadaan b on a.pengadaanid=b.pengadaanid and b.dlt='0'
                                left outer join tbm_inventaris c on c.pengadaandetailsid=a.pengadaandetailsid and c.dlt='0'
                                where a.dlt='0' " + (pengadaanid_list.Count > 0 ? string.Format(" and a.pengadaanid in ( {0} )", "'" + String.Join("','", pengadaanid_list.ToArray()) + "'") : "") + @"
                                order by a.nourut";
                    using (clsConnection oConn = new clsConnection())
                    {
                        DataTable dtReport = oConn.GetData(strsql);
                        dtReport.TableName = "tblReport";
                        mainReport.reportName = reportName;
                        mainReport.printReport(filename, dtReport);
                    }

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview.Enabled = true;
        }


    }
}
