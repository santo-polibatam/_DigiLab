﻿namespace DIGILIB.MasterData
{
    partial class ucProdi
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucProdi));
            this.gridViewDetail = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.jurusanid2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodiid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodicode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.inisial = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodidesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridViewData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.jurusanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jurusancode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jurusandesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnEndEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnDel = new DevExpress.XtraEditors.SimpleButton();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewDetail
            // 
            this.gridViewDetail.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.jurusanid2,
            this.prodiid,
            this.prodicode,
            this.inisial,
            this.prodidesc});
            this.gridViewDetail.GridControl = this.dgData;
            this.gridViewDetail.Name = "gridViewDetail";
            this.gridViewDetail.OptionsView.ShowGroupPanel = false;
            this.gridViewDetail.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewDetail_ValidateRow);
            // 
            // jurusanid2
            // 
            this.jurusanid2.Caption = "jurusanid";
            this.jurusanid2.FieldName = "jurusanid";
            this.jurusanid2.Name = "jurusanid2";
            // 
            // prodiid
            // 
            this.prodiid.Caption = "prodiid";
            this.prodiid.FieldName = "prodiid";
            this.prodiid.Name = "prodiid";
            // 
            // prodicode
            // 
            this.prodicode.AppearanceCell.Options.UseTextOptions = true;
            this.prodicode.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.prodicode.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.prodicode.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.prodicode.AppearanceHeader.Options.UseFont = true;
            this.prodicode.AppearanceHeader.Options.UseTextOptions = true;
            this.prodicode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.prodicode.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.prodicode.Caption = "Kode Prodi";
            this.prodicode.FieldName = "prodicode";
            this.prodicode.MaxWidth = 200;
            this.prodicode.MinWidth = 150;
            this.prodicode.Name = "prodicode";
            this.prodicode.Visible = true;
            this.prodicode.VisibleIndex = 0;
            this.prodicode.Width = 150;
            // 
            // inisial
            // 
            this.inisial.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.inisial.AppearanceHeader.Options.UseFont = true;
            this.inisial.AppearanceHeader.Options.UseTextOptions = true;
            this.inisial.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.inisial.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.inisial.Caption = "Inisial";
            this.inisial.FieldName = "inisial";
            this.inisial.MaxWidth = 200;
            this.inisial.MinWidth = 150;
            this.inisial.Name = "inisial";
            this.inisial.Visible = true;
            this.inisial.VisibleIndex = 1;
            this.inisial.Width = 150;
            // 
            // prodidesc
            // 
            this.prodidesc.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.prodidesc.AppearanceHeader.Options.UseFont = true;
            this.prodidesc.AppearanceHeader.Options.UseTextOptions = true;
            this.prodidesc.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.prodidesc.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.prodidesc.Caption = "Nama Prodi";
            this.prodidesc.FieldName = "prodidesc";
            this.prodidesc.Name = "prodidesc";
            this.prodidesc.Visible = true;
            this.prodidesc.VisibleIndex = 2;
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            gridLevelNode1.LevelTemplate = this.gridViewDetail;
            gridLevelNode1.RelationName = "Level1";
            this.dgData.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.dgData.Location = new System.Drawing.Point(3, 3);
            this.dgData.MainView = this.gridViewData;
            this.dgData.Name = "dgData";
            this.dgData.Size = new System.Drawing.Size(808, 327);
            this.dgData.TabIndex = 0;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewData,
            this.gridViewDetail});
            this.dgData.FocusedViewChanged += new DevExpress.XtraGrid.ViewFocusEventHandler(this.dgData_FocusedViewChanged);
            // 
            // gridViewData
            // 
            this.gridViewData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.jurusanid,
            this.jurusancode,
            this.jurusandesc});
            this.gridViewData.GridControl = this.dgData;
            this.gridViewData.Name = "gridViewData";
            this.gridViewData.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewData.OptionsBehavior.Editable = false;
            this.gridViewData.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridViewData.OptionsDetail.ShowDetailTabs = false;
            this.gridViewData.OptionsView.ShowGroupPanel = false;
            this.gridViewData.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewData_ValidateRow);
            // 
            // jurusanid
            // 
            this.jurusanid.Caption = "jurusanid";
            this.jurusanid.FieldName = "jurusanid";
            this.jurusanid.Name = "jurusanid";
            // 
            // jurusancode
            // 
            this.jurusancode.AppearanceCell.Options.UseTextOptions = true;
            this.jurusancode.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jurusancode.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jurusancode.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.jurusancode.AppearanceHeader.Options.UseFont = true;
            this.jurusancode.AppearanceHeader.Options.UseTextOptions = true;
            this.jurusancode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jurusancode.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jurusancode.Caption = "Kode Jurusan";
            this.jurusancode.FieldName = "jurusancode";
            this.jurusancode.MaxWidth = 200;
            this.jurusancode.MinWidth = 150;
            this.jurusancode.Name = "jurusancode";
            this.jurusancode.Visible = true;
            this.jurusancode.VisibleIndex = 0;
            this.jurusancode.Width = 200;
            // 
            // jurusandesc
            // 
            this.jurusandesc.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.jurusandesc.AppearanceHeader.Options.UseFont = true;
            this.jurusandesc.AppearanceHeader.Options.UseTextOptions = true;
            this.jurusandesc.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.jurusandesc.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.jurusandesc.Caption = "Nama Jurusan";
            this.jurusandesc.FieldName = "jurusandesc";
            this.jurusandesc.Name = "jurusandesc";
            this.jurusandesc.Visible = true;
            this.jurusandesc.VisibleIndex = 1;
            // 
            // btnEndEdit
            // 
            this.btnEndEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEndEdit.Enabled = false;
            this.btnEndEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEndEdit.Image")));
            this.btnEndEdit.Location = new System.Drawing.Point(168, 336);
            this.btnEndEdit.Name = "btnEndEdit";
            this.btnEndEdit.Size = new System.Drawing.Size(80, 23);
            this.btnEndEdit.TabIndex = 83;
            this.btnEndEdit.Text = "&End Edit";
            this.btnEndEdit.Click += new System.EventHandler(this.btnEndEdit_Click);
            // 
            // btnDel
            // 
            this.btnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDel.Image = ((System.Drawing.Image)(resources.GetObject("btnDel.Image")));
            this.btnDel.Location = new System.Drawing.Point(89, 336);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(73, 23);
            this.btnDel.TabIndex = 82;
            this.btnDel.Text = "Hapus";
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(7, 336);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(76, 23);
            this.btnEdit.TabIndex = 81;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(731, 333);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 26);
            this.btnClose.TabIndex = 84;
            this.btnClose.Text = "&Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // ucProdi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnEndEdit);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.dgData);
            this.Name = "ucProdi";
            this.Size = new System.Drawing.Size(814, 364);
            this.Load += new System.EventHandler(this.ucProdi_Load);
            this.Leave += new System.EventHandler(this.ucProdi_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewData;
        public DevExpress.XtraEditors.SimpleButton btnEndEdit;
        public DevExpress.XtraEditors.SimpleButton btnDel;
        public DevExpress.XtraEditors.SimpleButton btnEdit;
        private DevExpress.XtraGrid.Columns.GridColumn jurusanid;
        private DevExpress.XtraGrid.Columns.GridColumn jurusancode;
        private DevExpress.XtraGrid.Columns.GridColumn jurusandesc;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewDetail;
        private DevExpress.XtraGrid.Columns.GridColumn jurusanid2;
        private DevExpress.XtraGrid.Columns.GridColumn prodiid;
        private DevExpress.XtraGrid.Columns.GridColumn prodicode;
        private DevExpress.XtraGrid.Columns.GridColumn prodidesc;
        private DevExpress.XtraGrid.Columns.GridColumn inisial;
    }
}
