﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Views.Grid;
using Npgsql;
using DevExpress.XtraGrid.Views.Base;
using ReaderA;
using System.IO;

namespace DIGILIB.MasterData
{
    public partial class ucMultimedia : DevExpress.XtraEditors.XtraUserControl
    {
        public ucMultimedia()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        public frmMain formMain;
        WaitDialogForm loadDialog;

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null || loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public string strID = "";
        public string strJenisTenaga = "Tenaga Pendidik";

        public void loadData()
        {
            setLoadDialog(true, "Loading data...");
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();

                string strSQL = @"select distinct 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Daftar Multimedia' as header2, 
                            a.*, b.*
                            from tbm_inventaris a
                            inner join tbm_buku b on a.bukuid=b.bukuid and b.dlt='0' and lower(b.jenis_barang)='multimedia'
                            where a.dlt='0' 
                            order by a.tglditerima, a.nib";
                NpgsqlCommand cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataSet ds = new DataSet();
                DataTable dt = ds.Tables.Add("tbldetail");
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tbldetail");
                xdt = dt.Copy();

                strSQL = @"select a.*
                        from tbm_buku a
                        where a.dlt='0' and lower(a.jenis_barang)='multimedia'
                        order by noinduk, judul";
                cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataTable dt1 = ds.Tables.Add("tblmaster");
                da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tblmaster");
                ds.Relations.Add(new DataRelation("detailData", dt1.Columns["bukuid"], dt.Columns["bukuid"]));
                dgData.DataSource = dt1;
                xdtMaster = dt1.Copy();
                dgData.LevelTree.Nodes.Add("detailData", gridViewInventaris);
                //for (int i = 0; i < gridViewData.RowCount; i++)
                //{
                //    gridViewData.SetMasterRowExpandedEx(i, 0, true);
                //}

                gridViewData.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
                gridViewData.OptionsBehavior.Editable = false;
                gridViewInventaris.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
                gridViewInventaris.OptionsBehavior.Editable = false;
                btnEdit.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                btnDel.Enabled = clsGlobal.bolDelete;
                btnEndEdit.Enabled = false;
                setLoadDialog(false, "");
                if (dt.Rows.Count == 0)
                {
                    btnDel.Enabled = false;
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            gridViewData.OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            gridViewData.OptionsBehavior.Editable = true;
            gridViewInventaris.OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            gridViewInventaris.OptionsBehavior.Editable = true;
            btnEndEdit.Enabled = true;
            btnEdit.Enabled = false;
            btnActive.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void ucProdi_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        private void btnEndEdit_Click(object sender, EventArgs e)
        {
            gridViewData.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
            gridViewData.OptionsBehavior.Editable = false;
            gridViewInventaris.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
            gridViewInventaris.OptionsBehavior.Editable = false;
            btnEndEdit.Enabled = false;
            btnEdit.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
            if (btnStop.Enabled)
            {
                btnStop_Click(sender, e);
            }
        }

        private void ucProdi_Load(object sender, EventArgs e)
        {
            //loadDataJurusan();
            //loadData();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dgData.FocusedView.Name == gridViewData.Name)
            {
                if (Convert.ToString(gridViewData.GetFocusedRowCellValue(bukuid)) != "")
                {
                    if (XtraMessageBox.Show("Anda yakin menghapus data buku ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (clsConnection oConn = new clsConnection())
                        {
                            tbm_buku oObject = new tbm_buku();
                            oConn.Open();
                            oObject.Koneksi = oConn.Conn;
                            oObject.bukuid = Convert.ToString(Convert.ToString(gridViewData.GetFocusedRowCellValue(bukuid)));
                            oObject.opedit = clsGlobal.strUserName;
                            oObject.pcedit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                            oObject = null;
                            gridViewData.DeleteSelectedRows();
                        }
                    }
                }
            }
            else if (dgData.FocusedView.Name == gridViewInventaris.Name)
            {
                GridView gridDetail = gridViewData.GetDetailView(gridViewData.FocusedRowHandle, 0) as GridView;
                if (gridDetail == null)
                {
                    return;
                }
                if (Convert.ToString(gridDetail.GetFocusedRowCellValue(inventarisid)) != "")
                {
                    if (XtraMessageBox.Show("Anda yakin menghapus data inventaris ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (clsConnection oConn = new clsConnection())
                        {
                            tbm_inventaris oObject = new tbm_inventaris();
                            oConn.Open();
                            oObject.Koneksi = oConn.Conn;
                            oObject.inventarisid = Convert.ToString(Convert.ToString(gridDetail.GetFocusedRowCellValue(inventarisid)));
                            oObject.opedit = clsGlobal.strUserName;
                            oObject.pcedit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                            oObject = null;
                            gridDetail.DeleteSelectedRows();
                        }
                    }
                }
            }
        }

        private void gridViewData_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            string strID = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, bukuid));

            using (clsConnection oConn = new clsConnection())
            {
                tbm_buku oObject = new tbm_buku();

                oConn.Open();
                oObject.Koneksi = oConn.Conn;
                oObject.GetByPrimaryKey(strID);
                oObject.bukuid = strID;
                oObject.noinduk = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, noinduk));
                oObject.kodepanggil = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, kodepanggil));
                oObject.judul = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, judul));
                oObject.pengarang = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, pengarang));
                oObject.badankorporat = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, badankorporat));
                oObject.edisi = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, edisi));
                oObject.penerbit = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, penerbit));
                oObject.tempatterbit = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, tempatterbit));
                oObject.tahunterbit = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, tahunterbit));
                oObject.isbn = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, isbn));
                oObject.deskripsi = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, deskripsi));
                oObject.supplemen = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, supplemen));
                oObject.lokasikoleksi = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, lokasikoleksi));
                oObject.jeniskoleksi = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, jeniskoleksi));
                oObject.keterangan = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, keterangan));
                oObject.judul = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, judul));
                oObject.jenis_barang = "Multimedia";

                string strPDFFolder = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, pdffolder));
                string strPdfFileName = "";
                string strFullPDFFileName = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, pdffilename)), strMsg = "";
                if (!string.IsNullOrEmpty(strFullPDFFileName))
                {
                    FileInfo fl = new FileInfo(strFullPDFFileName);
                    strPdfFileName = fl.Name;
                }

                string strImgFolder = "";
                string strImgFileName = "";
                string strFullImgFileName = Convert.ToString(gridViewData.GetRowCellValue(e.RowHandle, coverbuku));
                if (!string.IsNullOrEmpty(strFullImgFileName))
                {
                    FileInfo fl = new FileInfo(strFullImgFileName);
                    strImgFileName = fl.Name;
                }

                if (strID == "")
                {
                    if (!string.IsNullOrEmpty(strFullPDFFileName))
                    {
                        try
                        {
                            if (clsGlobal.Upload(clsGlobal.strFTP_host + "/" + clsGlobal.strftppdfpath, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, ref strFullPDFFileName, strPdfFileName, strPDFFolder, false, ref strMsg))
                            {
                                //oObject.pdflfolder = strFolder;
                                oObject.pdffilename = Path.GetFileName(strFullPDFFileName);
                            }
                        }
                        catch (Exception ee)
                        {
                            XtraMessageBox.Show(ee.Message, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    if (!string.IsNullOrEmpty(strFullImgFileName))
                    {
                        try
                        {
                            string strFullImgFolder_thumbnail = Path.GetDirectoryName(strFullImgFileName) + "\\thumbnail";
                            string strImgfile_thumbnail = Path.GetFileName(strFullImgFileName);
                            string strFullImgFileName_thumbnail = Path.Combine(strFullImgFolder_thumbnail, strImgfile_thumbnail);

                            if (clsGlobal.Upload(clsGlobal.strFTP_host + "/" + clsGlobal.strftpcoverpath, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, ref strFullImgFileName, strImgFileName, strImgFolder, false, ref strMsg))
                            {
                                oObject.coverbuku = Path.GetFileName(strFullImgFileName);
                                gridViewData.SetRowCellValue(e.RowHandle, coverbuku, oObject.coverbuku);
                            }
                            //thumbnail
                            clsGlobal.Upload(clsGlobal.strFTP_host + "/" + clsGlobal.strftpcoverpath + "/thumbnail", clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, ref strFullImgFileName_thumbnail, strImgFileName, strImgFolder, false, ref strMsg);
                        }
                        catch (Exception ee)
                        {
                            XtraMessageBox.Show(ee.Message, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }

                    oObject.opadd = clsGlobal.strUserName;
                    oObject.pcadd = SystemInformation.ComputerName;
                    oObject.bukuid = oObject.NewID();
                    oObject.nourut = clsGlobal.intNewNumber;
                    oObject.Insert();
                    gridViewData.SetRowCellValue(e.RowHandle, bukuid, oObject.bukuid);
                }
                else
                {
                    if (oObject.pdffilename != strFullPDFFileName && !string.IsNullOrEmpty(strFullPDFFileName))
                    {
                        try
                        {
                            //clsGlobal.Upload(clsGlobal.strFTP_host, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, clsGlobal.strftppdfpath, strFullName, strPdfFileName );
                            if (clsGlobal.Upload(clsGlobal.strFTP_host + "/" + clsGlobal.strftppdfpath, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, ref strFullPDFFileName, strPdfFileName, strPDFFolder, false, ref strMsg))
                            {
                                //oObject.pdflfolder = strFolder;
                                oObject.pdffilename = Path.GetFileName(strFullPDFFileName);
                                gridViewData.SetRowCellValue(e.RowHandle, pdffilename, oObject.pdffilename);
                            }
                        }
                        catch (Exception ee)
                        {
                            XtraMessageBox.Show(ee.Message, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else if (string.IsNullOrEmpty(strFullPDFFileName))
                    {
                        oObject.pdffilename = strFullPDFFileName;
                    }
                    if (oObject.coverbuku != strFullImgFileName && !string.IsNullOrEmpty(strFullImgFileName))
                    {
                        try
                        {
                            string strFullImgFolder_thumbnail = Path.GetDirectoryName(strFullImgFileName) + "\\thumbnail";
                            string strImgfile_thumbnail = Path.GetFileName(strFullImgFileName);
                            string strFullImgFileName_thumbnail = Path.Combine(strFullImgFolder_thumbnail, strImgfile_thumbnail);

                            if (clsGlobal.Upload(clsGlobal.strFTP_host + "/" + clsGlobal.strftpcoverpath, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, ref strFullImgFileName, strImgFileName, strImgFolder, false, ref strMsg))
                            {
                                oObject.coverbuku = Path.GetFileName(strFullImgFileName);
                                gridViewData.SetRowCellValue(e.RowHandle, coverbuku, oObject.coverbuku);
                            }
                            //thumbnail
                            clsGlobal.Upload(clsGlobal.strFTP_host + "/" + clsGlobal.strftpcoverpath + "/thumbnail", clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, ref strFullImgFileName_thumbnail, strImgFileName, strImgFolder, false, ref strMsg);

                        }
                        catch (Exception ee)
                        {
                            XtraMessageBox.Show(ee.Message, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                    else if (string.IsNullOrEmpty(strFullImgFileName))
                    {
                        oObject.coverbuku = strFullImgFileName;
                    }
                    oObject.opedit = clsGlobal.strUserName;
                    oObject.pcedit = SystemInformation.ComputerName;
                    oObject.Update();
                }
                oObject = null;
            }
            e.Valid = true;
        }

        private void gridViewData_InitNewRow(object sender, InitNewRowEventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(noinduk)) == "")
            {
                gridViewData.SetFocusedRowCellValue(noinduk, clsGlobal.GetNewNumber("Nomor Induk Multimedia"));
            }
        }

        private void dgData_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        {
            if (e.View != null && e.View.ParentView != null)
            {
                ColumnView view = e.View.ParentView as ColumnView;
                view.FocusedRowHandle = e.View.SourceRowHandle;
            }
        }

        private void gridViewInventaris_ValidateRow(object sender, ValidateRowEventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                ColumnView view = sender as ColumnView;
                tbm_inventaris oObject = new tbm_inventaris();
                oConn.Open();
                oObject.Koneksi = oConn.Conn;
                oObject.inventarisid = Convert.ToString(view.GetFocusedRowCellValue(inventarisid));
                oObject.GetByPrimaryKey(oObject.inventarisid);

                DateTime dtOut = DateTime.MinValue;
                DateTime.TryParse(Convert.ToString(view.GetFocusedRowCellValue(tglditerima)), out dtOut);
                oObject.tglditerima = dtOut;
                oObject.bukuid = Convert.ToString(gridViewData.GetFocusedRowCellValue(bukuid));
                oObject.rfid = Convert.ToString(view.GetFocusedRowCellValue(rfid));
                oObject.nib = Convert.ToString(view.GetFocusedRowCellValue(nib));
                oObject.status = Convert.ToString(view.GetFocusedRowCellValue(status));
                oObject.ket_koleksi = Convert.ToString(view.GetFocusedRowCellValue(ket_koleksi));
                oObject.kode_makul = Convert.ToString(view.GetFocusedRowCellValue(kode_makul));

                if (oObject.inventarisid == "" || oObject.inventarisid == null)
                {
                    oObject.opadd = clsGlobal.strUserName;
                    oObject.pcadd = SystemInformation.ComputerName;
                    oObject.nourut = clsGlobal.intNewNumber;
                    oObject.inventarisid = oObject.NewID();
                    if (oObject.Insert() == false)
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                    view.SetFocusedRowCellValue(inventarisid, oObject.inventarisid);
                }
                else
                {
                    oObject.opedit = clsGlobal.strUserName;
                    oObject.pcedit = SystemInformation.ComputerName;
                    if (oObject.Update() == false)
                    {
                        e.ErrorText = "Data Tidak Dapat Disimpan...";
                        e.Valid = false;
                    }
                }
                oObject = null;
            }
            return;
        }

        private void gridViewInventaris_InitNewRow(object sender, InitNewRowEventArgs e)
        {
            ColumnView view = sender as ColumnView;
            if (Convert.ToString(view.GetFocusedRowCellValue(nib)) == "")
            {
                view.SetFocusedRowCellValue(nib, clsGlobal.GetNewNumber("Nomor Inventaris Multimedia"));
            }
        }

        private void btnActive_Click(object sender, EventArgs e)
        {
            btnStop.Enabled = true;
            btnActive.Enabled = false;
            try
            {
                openPort();
                timerScan.Enabled = true;
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timerScan.Enabled = false;
            btnStop.Enabled = false;
            closePort();
            if (clsGlobal.bolAdd || clsGlobal.bolEdit)
            {
                btnActive.Enabled = !btnEdit.Enabled;
            }
            else
            {
                btnActive.Enabled = false;
            }
        }

        private void timerScan_Tick(object sender, EventArgs e)
        {
            try
            {
                byte state = 0;
                byte AFI = 0;
                byte[] DSFIDAndUID = new byte[9];
                byte cardNumber = 0;
                string strDSFIDAndUID = "";

                byte[] cmdData;
                byte[] respData = new byte[256];
                byte[] option = new byte[4];
                clsGlobal.fCmdRet = 0x30;
                string temp = "004400000303A204";
                byte errorCode = 0;
                byte respLength = 0, feedBackDataLength = 0;

                option = clsGlobal.HexStringToByteArray(temp.Substring(0, 8));
                respLength = Convert.ToByte(temp.Substring(8, 2), 16);

                cmdData = clsGlobal.HexStringToByteArray(temp.Substring(10, temp.Length - 10));

                int fCmdRetW = StaticClassReaderA.TransparentWrite(ref clsGlobal.comAddr, option, respLength, (byte)cmdData.Length, cmdData,
                                                          ref feedBackDataLength, respData, ref errorCode, clsGlobal.portIndex);

                int fCmdRetInv = StaticClassReaderA.Inventory(ref clsGlobal.comAddr, ref state, ref AFI, DSFIDAndUID, ref cardNumber, clsGlobal.portIndex);

                if (fCmdRetInv == 0)
                {
                    timerScan.Enabled = false;
                    //clsGlobal.fCmdRet = StaticClassReaderA.SetGeneralOutput(ref clsGlobal.comAddr, ref clsGlobal.activeOutput, clsGlobal.portIndex);
                    strDSFIDAndUID = clsGlobal.ByteArrayToHexString(DSFIDAndUID).Replace(" ", "");
                    setRFIDTogrid(strDSFIDAndUID);
                    //clsGlobal.fCmdRet = StaticClassReaderA.SetGeneralOutput(ref clsGlobal.comAddr, ref clsGlobal.inActiveOutput, clsGlobal.portIndex);
                    timerScan.Enabled = true;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        private void setRFIDTogrid(string strRFID)
        {
            if (dgData.FocusedView.Name == gridViewInventaris.Name)
            {
                GridView view = dgData.FocusedView as GridView;
                if (view.FocusedColumn.FieldName == rfid.FieldName)
                {
                    string strCount = clsGlobal.getData1Field("select count(*) from tbm_inventaris where dlt='0' and rfid='" + strRFID + "' and inventarisid<>'" + view.GetFocusedRowCellValue(inventarisid) + "'");
                    if (Convert.ToInt32(strCount) == 0)
                    {
                        view.SetFocusedRowCellValue(rfid, strRFID);
                    }
                    else
                    {
                        XtraMessageBox.Show("RFID [" + strRFID + "] ini sudah pernah ada di database!\nSilahkan scan RFID yg lainnya!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void openPort()
        {
            if (Convert.ToDecimal(clsGlobal.portIndex) == -1)
            {
                clsGlobal.fCmdRet = StaticClassReaderA.AutoOpenComPort(ref clsGlobal.portNumber, ref clsGlobal.comAddr, clsGlobal.baud, ref clsGlobal.portIndex);
            }
        }

        private void closePort()
        {
            if (Convert.ToDecimal(clsGlobal.portIndex) != -1)
            {
                clsGlobal.fCmdRet = StaticClassReaderA.CloseSpecComPort(clsGlobal.portIndex);
                clsGlobal.portIndex = -1;
            }
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string sFilePath = clsGlobal.pstrAppPath;

                    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    saveFileDialog1.Title = "Save as Excel Workbook";
                    saveFileDialog1.Filter = "Excel 97-2003 Workbook(*.xls)|*.xls|Excel Workbook (*.xlsx)|*.xlsx";

                    saveFileDialog1.FilterIndex = 2;
                    saveFileDialog1.FileName = "Multimedia.xlsx";


                    string strSql = "";
                    strSql = @" select inv.tglditerima as ""Tanggal diterima"",
                    coalesce(bk.noinduk,'') as ""Bibli"",
                    coalesce(inv.nib,'') as ""No Inventaris Buku (NIB)"",
                    coalesce(bk.kodepanggil,'') as ""Kode Panggil/ Kode DDC"",
                    coalesce(bk.judul,'') as ""Judul"",
                    coalesce(bk.pengarang,'') as ""Pengarang"",
                    coalesce(bk.badankorporat,'') as ""Badan Korporat"",
                    coalesce(bk.edisi,'') as ""Edisi"",
                    coalesce(bk.penerbit,'') as ""Penerbit"",
                    coalesce(bk.tempatterbit,'') as ""Tempat Terbit"",
                    coalesce(bk.tahunterbit,'') as ""Tahun Terbit"",
                    coalesce(bk.isbn,'') as ""ISBN"",
                    coalesce(bk.deskripsi,'') as ""Deskripsi Fisik"",
                    coalesce(bk.supplemen,'') as ""Suplemen"",
                    coalesce(inv.status,'') as ""Keterangan"",
                    coalesce(inv.kode_makul,'') as ""Mata Kuliah"",
                    coalesce(bk.lokasikoleksi,'') as ""No Rak"",
                    --coalesce(bk.jeniskoleksi,'') as ""Keterangan"",
                    coalesce(bk.keterangan,'') as ""KET STOCK""
                    --coalesce(bk.jenis_barang,'') as ""jenis_barang"",
                    --coalesce(bk.pdffilename,'') as ""pdffilename"",
                    --coalesce(inv.ket_koleksi,'') as ""ket_koleksi""
                    from tbm_buku bk 
                    inner join tbm_inventaris inv on inv.bukuid=bk.bukuid and inv.dlt='0' 
                    where bk.dlt='0' and lower(bk.jenis_barang)='multimedia'
                    order by ""Tanggal diterima"", ""No Inventaris Buku (NIB)""
                    ";

                    DataTable dtReport = oConn.GetData(strSql);
                    if (dtReport == null) return;

                    DevExpress.XtraGrid.GridControl gcRuntime = new DevExpress.XtraGrid.GridControl();
                    gcRuntime.BindingContext = new BindingContext();
                    GridView gridviewRuntime = new GridView();
                    gcRuntime.MainView = gridviewRuntime;
                    gridviewRuntime.GridControl = gcRuntime;


                    gcRuntime.DataSource = dtReport;
                    gridviewRuntime.OptionsPrint.AutoWidth = false;
                    gridviewRuntime.Columns["Tanggal diterima"].Width = 140;
                    gridviewRuntime.Columns["Bibli"].Width = 140;
                    gridviewRuntime.Columns["No Inventaris Buku (NIB)"].Width = 140;
                    gridviewRuntime.Columns["Kode Panggil/ Kode DDC"].Width = 140;
                    gridviewRuntime.Columns["Judul"].Width = 140;
                    gridviewRuntime.Columns["Pengarang"].Width = 140;
                    gridviewRuntime.Columns["Badan Korporat"].Width = 140;
                    gridviewRuntime.Columns["Edisi"].Width = 140;
                    gridviewRuntime.Columns["Penerbit"].Width = 140;
                    gridviewRuntime.Columns["Tempat Terbit"].Width = 140;
                    gridviewRuntime.Columns["Tahun Terbit"].Width = 140;
                    gridviewRuntime.Columns["ISBN"].Width = 140;
                    gridviewRuntime.Columns["Deskripsi Fisik"].Width = 140;
                    gridviewRuntime.Columns["Suplemen"].Width = 140;
                    gridviewRuntime.Columns["Keterangan"].Width = 140;
                    gridviewRuntime.Columns["Mata Kuliah"].Width = 140;
                    gridviewRuntime.Columns["No Rak"].Width = 140;
                    gridviewRuntime.Columns["KET STOCK"].Width = 140;

                    string strSheetName = "Multimedia";


                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        if (clsGlobal.isFileOpened(saveFileDialog1.FileName))
                        {
                            XtraMessageBox.Show("Download fail, this file [" + saveFileDialog1.FileName + "] is currenlty opened", clsGlobal.pstrAppName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }
                        sFilePath = saveFileDialog1.FileName;

                        if (saveFileDialog1.FilterIndex == 2)
                            gridviewRuntime.ExportToXlsx(sFilePath, new DevExpress.XtraPrinting.XlsxExportOptions { SheetName = strSheetName });
                        else
                            gridviewRuntime.ExportToXls(sFilePath, new DevExpress.XtraPrinting.XlsExportOptions { SheetName = strSheetName });

                        System.Diagnostics.Process.Start(sFilePath);

                    }

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {

            frmImportExcel fImportExcel = new frmImportExcel("Multimedia");
            fImportExcel.fMain = formMain;
            fImportExcel.splitContainerControl1.PanelVisibility = SplitPanelVisibility.Panel1;
            fImportExcel.ShowDialog();


            loadData();
        }

        DataTable xdt;
        DataTable xdtMaster;
        private void btnPreview_Click(object sender, EventArgs e)
        {
            btnPreview.Enabled = false;
            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptDaftarBuku.repx";
                reportName = "rptDaftarBuku";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    DataView dvReport = xdt.Copy().DefaultView;
                    List<string> bukuid_list = new List<string>();
                    int rowHandle;
                    if (xdtMaster.Rows.Count > gridViewData.RowCount)
                    {
                        for (int i = 0; i < gridViewData.RowCount; i++)
                        {
                            rowHandle = gridViewData.GetVisibleRowHandle(i);
                            if (!gridViewData.IsGroupRow(rowHandle))
                            {
                                object key = gridViewData.GetRowCellValue(rowHandle, bukuid);
                                if (key != null && key != DBNull.Value)
                                {
                                    if (!bukuid_list.Contains(key.ToString()))
                                        bukuid_list.Add(key.ToString());
                                }
                            }
                        }
                        if (dvReport == null) return;
                        if (bukuid_list.Count > 0)
                        {
                            dvReport.RowFilter = string.Format(" bukuid in ( {0} )", "'" + String.Join("','", bukuid_list.ToArray()) + "'");
                        }
                    }
                    DataTable dtReport = dvReport.ToTable();
                    dtReport.TableName = "tblReport";
                    mainReport.reportName = reportName;
                    mainReport.printReport(filename, dtReport);

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview.Enabled = true;
        }

        private void repositoryItemHyperLinkEdit1_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            if (e.Button.Index == 0)
            {
                OpenFileDialog fdlg = new OpenFileDialog();
                fdlg.Title = "Browse Document File...";
                //fdlg.Filter = "Pdf files (*.Pdf)|*.Pdf";
                fdlg.Filter = "Pdf files (*.*)|*.*";
                if (fdlg.ShowDialog() == DialogResult.OK)
                {
                    gridViewData.SetFocusedRowCellValue(pdffilename, fdlg.FileName);
                }
                fdlg = null;
            }
            else
            {
                gridViewData.SetFocusedRowCellValue(pdffilename, "");
            }
        }

        private void repositoryItemHyperLinkEdit1_OpenLink(object sender, DevExpress.XtraEditors.Controls.OpenLinkEventArgs e)
        {
            HyperLinkEdit hl = sender as HyperLinkEdit;
            if (Convert.ToString(e.EditValue) != "")
            {

                SaveFileDialog dlgSave = new SaveFileDialog();
                dlgSave.FileName = Convert.ToString(e.EditValue);
                dlgSave.Filter = "All files (*.*)|*.*";
                if (dlgSave.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    if (clsGlobal.isFileOpened(dlgSave.FileName))
                    {
                        XtraMessageBox.Show("Download fail, this file [" + dlgSave.FileName + "] is currenlty opened", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                    try
                    {
                        setLoadDialog(true, "Download Document.");
                        string sFolder = Convert.ToString(gridViewData.GetFocusedRowCellValue(pdffolder));
                        string strMsg = "";
                        if (clsGlobal.Download(clsGlobal.strFTP_host + "/" + clsGlobal.strftppdfpath, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, dlgSave.FileName, Convert.ToString(e.EditValue), sFolder, ref strMsg))
                        {
                            setLoadDialog(false, "");
                            if (XtraMessageBox.Show("Download complete.\nDo you want to open file?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                                System.Diagnostics.Process.Start(dlgSave.FileName);
                        }
                        else
                        {
                            setLoadDialog(false, "");
                            XtraMessageBox.Show("An error occurred while downloading", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    finally
                    {
                        setLoadDialog(false, "");
                    }

                }
                dlgSave = null;
            }
        }

        private void gridViewData_CustomRowCellEdit(object sender, CustomRowCellEditEventArgs e)
        {
            if (e.Column.FieldName == pdffilename.FieldName && Convert.ToString(e.CellValue) != "")
            {

                if (Convert.ToString(e.CellValue).ToLower().Contains(".pdf"))
                {
                    e.RepositoryItem = repositoryLinkPDF;
                    //gridViewData.SetRowCellValue(e.RowHandle, e.Column.FieldName, e.CellValue);
                }
                //else if (Convert.ToString(e.CellValue).ToLower().Contains(".doc") || Convert.ToString(e.CellValue).ToLower().Contains(".docx"))
                //{
                //    e.RepositoryItem = repositoryLinkWord;
                //}
                //else if (Convert.ToString(e.CellValue).ToLower().Contains(".xls") || Convert.ToString(e.CellValue).ToLower().Contains(".xlsx"))
                //{
                //    e.RepositoryItem = repositoryLinkExcel;
                //}

                //else if (Convert.ToString(e.CellValue).ToLower().Contains(".png") || Convert.ToString(e.CellValue).ToLower().Contains(".jpg") || Convert.ToString(e.CellValue).ToLower().Contains(".gif") || Convert.ToString(e.CellValue).ToLower().Contains(".bmp"))
                //{
                //    e.RepositoryItem = repositoryLinkImages;
                //}
                //else if (Convert.ToString(e.CellValue).ToLower().Contains(".rar") || Convert.ToString(e.CellValue).ToLower().Contains(".zip"))
                //{
                //    e.RepositoryItem = repositoryLinkRAR;
                //}
                //else
                //{
                //    e.RepositoryItem = repositoryLinkFile;
                //}
            }
            else if (e.Column.FieldName == coverbuku.FieldName && Convert.ToString(e.CellValue) != "")
            {

                if (Convert.ToString(e.CellValue).ToLower().Contains(".png") || Convert.ToString(e.CellValue).ToLower().Contains(".jpg") || Convert.ToString(e.CellValue).ToLower().Contains(".gif") || Convert.ToString(e.CellValue).ToLower().Contains(".bmp"))
                {
                    e.RepositoryItem = repositoryLinkImages;
                    //gridViewData.SetRowCellValue(e.RowHandle, e.Column.FieldName, e.CellValue);
                }
            }
        }

        private void gridViewData_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {

        }

        #region Cover Buku
        private void repositoryItemHyperLinkEdit2_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            try
            {
                if (e.Button.Index == 0)
                {
                    OpenFileDialog fdlg = new OpenFileDialog();
                    fdlg.Title = "Browse Photo...";
                    fdlg.Filter = "JPEG (*.jpg)|*.jpg|PNG (*.png)|*.png|GIF (*.gif)|*.gif";
                    if (fdlg.ShowDialog() == DialogResult.OK)
                    {
                        string strYM = clsGlobal.getData1Field("select to_char(now(),'yyyymmddHH24MISS');");
                        string path = Application.StartupPath + "\\cover\\";
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }
                        string path_thumbnail = Application.StartupPath + "\\cover\\thumbnail\\";
                        if (!Directory.Exists(path_thumbnail))
                        {
                            Directory.CreateDirectory(path_thumbnail);
                        }
                        string strTempPath = strYM + Path.GetExtension(fdlg.FileName);
                        //Image img1 = ScaleImage(Image.FromFile(fdlg.FileName), 114, 152); //3cm x 4cm
                        Image img1 = Image.FromFile(fdlg.FileName);
                        //img1.Save(path + strTempPath);

                        Bitmap resizedImage = new Bitmap(500, 668);
                        using (Graphics g = Graphics.FromImage(resizedImage))
                            g.DrawImage(img1, 0, 0, 500, 668);

                        //Image resizedImage = img1.GetThumbnailImage(500, 668, null, IntPtr.Zero);//(114 * img1.Height) / img1.Width
                        resizedImage.Save(path + strTempPath);
                        gridViewData.SetFocusedRowCellValue(coverbuku, path + strTempPath);

                        Bitmap resizedImage_thumb = new Bitmap(113, 151);
                        using (Graphics g = Graphics.FromImage(resizedImage_thumb))
                            g.DrawImage(img1, 0, 0, 113, 151);
                        //Image resizedImage_thumb = img1.GetThumbnailImage(114, 152, null, IntPtr.Zero);//(114 * img1.Height) / img1.Width
                        resizedImage_thumb.Save(path_thumbnail + strTempPath);
                    }
                    fdlg = null;
                }
                else
                {
                    gridViewData.SetFocusedRowCellValue(coverbuku, "");
                }
            }
            catch
            {
            }
        }

        private Image ScaleImage(Image image, int p, int p_2)
        {
            throw new NotImplementedException();
        }

        private void repositoryItemHyperLinkEdit2_OpenLink(object sender, DevExpress.XtraEditors.Controls.OpenLinkEventArgs e)
        {
            HyperLinkEdit hl = sender as HyperLinkEdit;
            if (Convert.ToString(e.EditValue) != "")
            {

                SaveFileDialog dlgSave = new SaveFileDialog();
                dlgSave.FileName = Convert.ToString(e.EditValue);
                dlgSave.Filter = "All files (*.*)|*.*";
                if (dlgSave.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    if (clsGlobal.isFileOpened(dlgSave.FileName))
                    {
                        XtraMessageBox.Show("Download fail, this file [" + dlgSave.FileName + "] is currenlty opened", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                    try
                    {
                        setLoadDialog(true, "Download Cover..");
                        string sFolder = "";
                        string strMsg = "";

                        if (clsGlobal.Download(clsGlobal.strFTP_host + "/" + clsGlobal.strftpcoverpath, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, dlgSave.FileName, Convert.ToString(e.EditValue), sFolder, ref strMsg))
                        {
                            setLoadDialog(false, "");
                            if (XtraMessageBox.Show("Download complete.\nDo you want to open file?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                                System.Diagnostics.Process.Start(dlgSave.FileName);
                        }
                        else
                        {
                            setLoadDialog(false, "");
                            XtraMessageBox.Show("An error occurred while downloading", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    catch (Exception)
                    {
                    }
                    finally
                    {
                        setLoadDialog(false, "");
                    }

                }
                dlgSave = null;
            }
        }
        #endregion
    }
}
