﻿namespace DIGILIB.MasterData
{
    partial class ucMultimedia
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem2 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem3 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem4 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem5 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem6 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem7 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SuperToolTip superToolTip8 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem8 = new DevExpress.Utils.ToolTipItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucMultimedia));
            this.gridViewInventaris = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.inventarisid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bukuid2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pengadaanid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tglditerima = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nib = new DevExpress.XtraGrid.Columns.GridColumn();
            this.status = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.ket_koleksi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.kode_makul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridViewData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.bukuid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.noinduk = new DevExpress.XtraGrid.Columns.GridColumn();
            this.kodepanggil = new DevExpress.XtraGrid.Columns.GridColumn();
            this.judul = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.pengarang = new DevExpress.XtraGrid.Columns.GridColumn();
            this.badankorporat = new DevExpress.XtraGrid.Columns.GridColumn();
            this.edisi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.penerbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tempatterbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tahunterbit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.isbn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.deskripsi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.supplemen = new DevExpress.XtraGrid.Columns.GridColumn();
            this.lokasikoleksi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jeniskoleksi = new DevExpress.XtraGrid.Columns.GridColumn();
            this.keterangan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pdffilename = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemHyperLinkEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.pdffolder = new DevExpress.XtraGrid.Columns.GridColumn();
            this.coverbuku = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemHyperLinkEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryLUJenjang = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryLUJurusan = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryLinkPDF = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.repositoryLinkImages = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.btnEndEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnDel = new DevExpress.XtraEditors.SimpleButton();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnActive = new DevExpress.XtraEditors.SimpleButton();
            this.btnStop = new DevExpress.XtraEditors.SimpleButton();
            this.timerScan = new System.Windows.Forms.Timer(this.components);
            this.btnDownload = new DevExpress.XtraEditors.SimpleButton();
            this.btnUpload = new DevExpress.XtraEditors.SimpleButton();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewInventaris)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJenjang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJurusan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLinkPDF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLinkImages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewInventaris
            // 
            this.gridViewInventaris.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridViewInventaris.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewInventaris.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridViewInventaris.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridViewInventaris.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewInventaris.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewInventaris.Appearance.Row.Options.UseTextOptions = true;
            this.gridViewInventaris.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewInventaris.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewInventaris.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.inventarisid,
            this.bukuid2,
            this.pengadaanid,
            this.rfid,
            this.tglditerima,
            this.nib,
            this.status,
            this.ket_koleksi,
            this.kode_makul});
            this.gridViewInventaris.GridControl = this.dgData;
            this.gridViewInventaris.Name = "gridViewInventaris";
            this.gridViewInventaris.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewInventaris.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridViewInventaris.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridViewInventaris.OptionsView.ShowGroupPanel = false;
            this.gridViewInventaris.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridViewInventaris_InitNewRow);
            this.gridViewInventaris.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewInventaris_ValidateRow);
            // 
            // inventarisid
            // 
            this.inventarisid.Caption = "inventarisid";
            this.inventarisid.FieldName = "inventarisid";
            this.inventarisid.Name = "inventarisid";
            // 
            // bukuid2
            // 
            this.bukuid2.Caption = "bukuid";
            this.bukuid2.FieldName = "bukuid";
            this.bukuid2.Name = "bukuid2";
            // 
            // pengadaanid
            // 
            this.pengadaanid.Caption = "pengadaanid";
            this.pengadaanid.FieldName = "pengadaanid";
            this.pengadaanid.Name = "pengadaanid";
            // 
            // rfid
            // 
            this.rfid.Caption = "RFID";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 180;
            this.rfid.Name = "rfid";
            this.rfid.Visible = true;
            this.rfid.VisibleIndex = 1;
            this.rfid.Width = 180;
            // 
            // tglditerima
            // 
            this.tglditerima.AppearanceCell.Options.UseTextOptions = true;
            this.tglditerima.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tglditerima.Caption = "Tanggal Diterima";
            this.tglditerima.DisplayFormat.FormatString = "dd-MM-yyyy";
            this.tglditerima.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.tglditerima.FieldName = "tglditerima";
            this.tglditerima.MaxWidth = 150;
            this.tglditerima.MinWidth = 150;
            this.tglditerima.Name = "tglditerima";
            this.tglditerima.Visible = true;
            this.tglditerima.VisibleIndex = 0;
            this.tglditerima.Width = 150;
            // 
            // nib
            // 
            this.nib.Caption = "NIB";
            this.nib.FieldName = "nib";
            this.nib.MinWidth = 150;
            this.nib.Name = "nib";
            this.nib.Visible = true;
            this.nib.VisibleIndex = 2;
            this.nib.Width = 150;
            // 
            // status
            // 
            this.status.Caption = "Status";
            this.status.ColumnEdit = this.repositoryItemComboBox2;
            this.status.FieldName = "status";
            this.status.MinWidth = 100;
            this.status.Name = "status";
            this.status.Visible = true;
            this.status.VisibleIndex = 3;
            this.status.Width = 100;
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "Tandon",
            "Teks",
            "Referensi",
            "Restricted"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // ket_koleksi
            // 
            this.ket_koleksi.Caption = "Keterangan Koleksi";
            this.ket_koleksi.ColumnEdit = this.repositoryItemComboBox3;
            this.ket_koleksi.FieldName = "ket_koleksi";
            this.ket_koleksi.MinWidth = 100;
            this.ket_koleksi.Name = "ket_koleksi";
            this.ket_koleksi.Visible = true;
            this.ket_koleksi.VisibleIndex = 4;
            this.ket_koleksi.Width = 100;
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Items.AddRange(new object[] {
            "Ada",
            "Rusak",
            "Hilang",
            "Pemutihan"});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            // 
            // kode_makul
            // 
            this.kode_makul.Caption = "Kode Makul";
            this.kode_makul.FieldName = "kode_makul";
            this.kode_makul.MinWidth = 150;
            this.kode_makul.Name = "kode_makul";
            this.kode_makul.Visible = true;
            this.kode_makul.VisibleIndex = 5;
            this.kode_makul.Width = 150;
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            gridLevelNode1.LevelTemplate = this.gridViewInventaris;
            gridLevelNode1.RelationName = "Level1";
            this.dgData.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.dgData.Location = new System.Drawing.Point(3, 73);
            this.dgData.MainView = this.gridViewData;
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryLUJenjang,
            this.repositoryLUJurusan,
            this.repositoryItemComboBox1,
            this.repositoryItemMemoEdit1,
            this.repositoryItemComboBox2,
            this.repositoryItemComboBox3,
            this.repositoryItemHyperLinkEdit1,
            this.repositoryLinkPDF,
            this.repositoryItemHyperLinkEdit2,
            this.repositoryLinkImages});
            this.dgData.Size = new System.Drawing.Size(942, 395);
            this.dgData.TabIndex = 95;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewData,
            this.gridViewInventaris});
            this.dgData.FocusedViewChanged += new DevExpress.XtraGrid.ViewFocusEventHandler(this.dgData_FocusedViewChanged);
            // 
            // gridViewData
            // 
            this.gridViewData.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridViewData.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewData.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewData.Appearance.Row.Options.UseTextOptions = true;
            this.gridViewData.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewData.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewData.ColumnPanelRowHeight = 35;
            this.gridViewData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.bukuid,
            this.noinduk,
            this.kodepanggil,
            this.judul,
            this.pengarang,
            this.badankorporat,
            this.edisi,
            this.penerbit,
            this.tempatterbit,
            this.tahunterbit,
            this.isbn,
            this.deskripsi,
            this.supplemen,
            this.lokasikoleksi,
            this.jeniskoleksi,
            this.keterangan,
            this.pdffilename,
            this.pdffolder,
            this.coverbuku});
            this.gridViewData.GridControl = this.dgData;
            this.gridViewData.Name = "gridViewData";
            this.gridViewData.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewData.OptionsBehavior.Editable = false;
            this.gridViewData.OptionsDetail.AllowExpandEmptyDetails = true;
            this.gridViewData.OptionsDetail.ShowDetailTabs = false;
            this.gridViewData.OptionsFind.AlwaysVisible = true;
            this.gridViewData.OptionsView.AutoCalcPreviewLineCount = true;
            this.gridViewData.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewData.OptionsView.RowAutoHeight = true;
            this.gridViewData.OptionsView.ShowGroupPanel = false;
            this.gridViewData.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridViewData_RowCellStyle);
            this.gridViewData.CustomRowCellEdit += new DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(this.gridViewData_CustomRowCellEdit);
            this.gridViewData.InitNewRow += new DevExpress.XtraGrid.Views.Grid.InitNewRowEventHandler(this.gridViewData_InitNewRow);
            this.gridViewData.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridViewData_ValidateRow);
            // 
            // bukuid
            // 
            this.bukuid.Caption = "bukuid";
            this.bukuid.FieldName = "bukuid";
            this.bukuid.Name = "bukuid";
            // 
            // noinduk
            // 
            this.noinduk.Caption = "Bibli / No Induk Buku";
            this.noinduk.FieldName = "noinduk";
            this.noinduk.MinWidth = 100;
            this.noinduk.Name = "noinduk";
            this.noinduk.Visible = true;
            this.noinduk.VisibleIndex = 0;
            this.noinduk.Width = 100;
            // 
            // kodepanggil
            // 
            this.kodepanggil.Caption = "Kode Panggil";
            this.kodepanggil.FieldName = "kodepanggil";
            this.kodepanggil.MinWidth = 150;
            this.kodepanggil.Name = "kodepanggil";
            this.kodepanggil.Visible = true;
            this.kodepanggil.VisibleIndex = 1;
            this.kodepanggil.Width = 150;
            // 
            // judul
            // 
            this.judul.Caption = "Judul";
            this.judul.ColumnEdit = this.repositoryItemMemoEdit1;
            this.judul.FieldName = "judul";
            this.judul.MinWidth = 200;
            this.judul.Name = "judul";
            this.judul.Visible = true;
            this.judul.VisibleIndex = 2;
            this.judul.Width = 200;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // pengarang
            // 
            this.pengarang.Caption = "Pengarang";
            this.pengarang.FieldName = "pengarang";
            this.pengarang.MinWidth = 150;
            this.pengarang.Name = "pengarang";
            this.pengarang.Visible = true;
            this.pengarang.VisibleIndex = 3;
            this.pengarang.Width = 150;
            // 
            // badankorporat
            // 
            this.badankorporat.Caption = "Badan Korporat";
            this.badankorporat.FieldName = "badankorporat";
            this.badankorporat.MinWidth = 150;
            this.badankorporat.Name = "badankorporat";
            this.badankorporat.Visible = true;
            this.badankorporat.VisibleIndex = 4;
            this.badankorporat.Width = 150;
            // 
            // edisi
            // 
            this.edisi.Caption = "Edisi";
            this.edisi.FieldName = "edisi";
            this.edisi.MinWidth = 100;
            this.edisi.Name = "edisi";
            this.edisi.Visible = true;
            this.edisi.VisibleIndex = 5;
            this.edisi.Width = 100;
            // 
            // penerbit
            // 
            this.penerbit.Caption = "Penerbit";
            this.penerbit.FieldName = "penerbit";
            this.penerbit.MinWidth = 150;
            this.penerbit.Name = "penerbit";
            this.penerbit.Visible = true;
            this.penerbit.VisibleIndex = 6;
            this.penerbit.Width = 150;
            // 
            // tempatterbit
            // 
            this.tempatterbit.Caption = "Tempat Terbit";
            this.tempatterbit.FieldName = "tempatterbit";
            this.tempatterbit.MinWidth = 150;
            this.tempatterbit.Name = "tempatterbit";
            this.tempatterbit.Visible = true;
            this.tempatterbit.VisibleIndex = 7;
            this.tempatterbit.Width = 150;
            // 
            // tahunterbit
            // 
            this.tahunterbit.Caption = "Tahun Terbit";
            this.tahunterbit.FieldName = "tahunterbit";
            this.tahunterbit.MinWidth = 100;
            this.tahunterbit.Name = "tahunterbit";
            this.tahunterbit.Visible = true;
            this.tahunterbit.VisibleIndex = 8;
            this.tahunterbit.Width = 100;
            // 
            // isbn
            // 
            this.isbn.Caption = "ISBN";
            this.isbn.FieldName = "isbn";
            this.isbn.MinWidth = 150;
            this.isbn.Name = "isbn";
            this.isbn.Visible = true;
            this.isbn.VisibleIndex = 9;
            this.isbn.Width = 150;
            // 
            // deskripsi
            // 
            this.deskripsi.Caption = "Deskripsi Fisik";
            this.deskripsi.FieldName = "deskripsi";
            this.deskripsi.MinWidth = 200;
            this.deskripsi.Name = "deskripsi";
            this.deskripsi.Visible = true;
            this.deskripsi.VisibleIndex = 10;
            this.deskripsi.Width = 200;
            // 
            // supplemen
            // 
            this.supplemen.Caption = "Supplemen";
            this.supplemen.FieldName = "supplemen";
            this.supplemen.MinWidth = 100;
            this.supplemen.Name = "supplemen";
            this.supplemen.Visible = true;
            this.supplemen.VisibleIndex = 11;
            this.supplemen.Width = 100;
            // 
            // lokasikoleksi
            // 
            this.lokasikoleksi.Caption = "Lokasi Koleksi";
            this.lokasikoleksi.FieldName = "lokasikoleksi";
            this.lokasikoleksi.MinWidth = 150;
            this.lokasikoleksi.Name = "lokasikoleksi";
            this.lokasikoleksi.Visible = true;
            this.lokasikoleksi.VisibleIndex = 12;
            this.lokasikoleksi.Width = 150;
            // 
            // jeniskoleksi
            // 
            this.jeniskoleksi.Caption = "Jenis Koleksi";
            this.jeniskoleksi.FieldName = "jeniskoleksi";
            this.jeniskoleksi.MinWidth = 100;
            this.jeniskoleksi.Name = "jeniskoleksi";
            this.jeniskoleksi.Visible = true;
            this.jeniskoleksi.VisibleIndex = 13;
            this.jeniskoleksi.Width = 100;
            // 
            // keterangan
            // 
            this.keterangan.Caption = "Keterangan";
            this.keterangan.ColumnEdit = this.repositoryItemMemoEdit1;
            this.keterangan.FieldName = "keterangan";
            this.keterangan.MinWidth = 200;
            this.keterangan.Name = "keterangan";
            this.keterangan.Visible = true;
            this.keterangan.VisibleIndex = 14;
            this.keterangan.Width = 200;
            // 
            // pdffilename
            // 
            this.pdffilename.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.pdffilename.AppearanceHeader.Options.UseFont = true;
            this.pdffilename.AppearanceHeader.Options.UseTextOptions = true;
            this.pdffilename.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.pdffilename.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.pdffilename.Caption = "Pdf File";
            this.pdffilename.ColumnEdit = this.repositoryItemHyperLinkEdit1;
            this.pdffilename.FieldName = "pdffilename";
            this.pdffilename.MinWidth = 200;
            this.pdffilename.Name = "pdffilename";
            this.pdffilename.Visible = true;
            this.pdffilename.VisibleIndex = 15;
            this.pdffilename.Width = 220;
            // 
            // repositoryItemHyperLinkEdit1
            // 
            this.repositoryItemHyperLinkEdit1.AutoHeight = false;
            toolTipTitleItem1.Text = "Browse File..";
            toolTipItem1.LeftIndent = 6;
            toolTipItem1.Text = "Upload Pdf File ke server..";
            superToolTip1.Items.Add(toolTipTitleItem1);
            superToolTip1.Items.Add(toolTipItem1);
            toolTipTitleItem2.Text = "Hapus File";
            toolTipItem2.LeftIndent = 6;
            toolTipItem2.Text = "Hapus Pdf file dari server";
            superToolTip2.Items.Add(toolTipTitleItem2);
            superToolTip2.Items.Add(toolTipItem2);
            this.repositoryItemHyperLinkEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "...", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, superToolTip1, true),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, superToolTip2, true)});
            this.repositoryItemHyperLinkEdit1.Name = "repositoryItemHyperLinkEdit1";
            this.repositoryItemHyperLinkEdit1.OpenLink += new DevExpress.XtraEditors.Controls.OpenLinkEventHandler(this.repositoryItemHyperLinkEdit1_OpenLink);
            this.repositoryItemHyperLinkEdit1.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemHyperLinkEdit1_ButtonClick);
            // 
            // pdffolder
            // 
            this.pdffolder.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.pdffolder.AppearanceHeader.Options.UseFont = true;
            this.pdffolder.AppearanceHeader.Options.UseTextOptions = true;
            this.pdffolder.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.pdffolder.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.pdffolder.Caption = "pdffolder";
            this.pdffolder.FieldName = "pdffolder";
            this.pdffolder.MinWidth = 120;
            this.pdffolder.Name = "pdffolder";
            this.pdffolder.Width = 120;
            // 
            // coverbuku
            // 
            this.coverbuku.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.coverbuku.AppearanceHeader.Options.UseFont = true;
            this.coverbuku.AppearanceHeader.Options.UseTextOptions = true;
            this.coverbuku.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.coverbuku.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.coverbuku.Caption = "Cover";
            this.coverbuku.ColumnEdit = this.repositoryItemHyperLinkEdit2;
            this.coverbuku.FieldName = "coverbuku";
            this.coverbuku.MinWidth = 120;
            this.coverbuku.Name = "coverbuku";
            this.coverbuku.Visible = true;
            this.coverbuku.VisibleIndex = 16;
            this.coverbuku.Width = 120;
            // 
            // repositoryItemHyperLinkEdit2
            // 
            this.repositoryItemHyperLinkEdit2.AutoHeight = false;
            toolTipItem3.Text = "Browse File../Upload Cover ke server..";
            superToolTip3.Items.Add(toolTipItem3);
            toolTipItem4.Text = "Hapus File/Hapus Cover file dari server";
            superToolTip4.Items.Add(toolTipItem4);
            this.repositoryItemHyperLinkEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject3, "", null, superToolTip3, true),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject4, "", null, superToolTip4, true)});
            this.repositoryItemHyperLinkEdit2.Name = "repositoryItemHyperLinkEdit2";
            this.repositoryItemHyperLinkEdit2.OpenLink += new DevExpress.XtraEditors.Controls.OpenLinkEventHandler(this.repositoryItemHyperLinkEdit2_OpenLink);
            this.repositoryItemHyperLinkEdit2.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemHyperLinkEdit2_ButtonClick);
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryLUJenjang
            // 
            this.repositoryLUJenjang.AutoHeight = false;
            this.repositoryLUJenjang.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUJenjang.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjangakademikid", "jenjangakademikid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjang", "jenjang")});
            this.repositoryLUJenjang.DisplayMember = "jenjang";
            this.repositoryLUJenjang.DropDownRows = 15;
            this.repositoryLUJenjang.Name = "repositoryLUJenjang";
            this.repositoryLUJenjang.NullText = "";
            this.repositoryLUJenjang.ShowHeader = false;
            this.repositoryLUJenjang.ValueMember = "jenjangakademikid";
            // 
            // repositoryLUJurusan
            // 
            this.repositoryLUJurusan.AutoHeight = false;
            this.repositoryLUJurusan.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUJurusan.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusanid", "jurusanid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusancode", "Kode Jurusan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusandesc", 50, "Nama Jurusan")});
            this.repositoryLUJurusan.DisplayMember = "jurusandesc";
            this.repositoryLUJurusan.DropDownRows = 15;
            this.repositoryLUJurusan.Name = "repositoryLUJurusan";
            this.repositoryLUJurusan.NullText = "";
            this.repositoryLUJurusan.ValueMember = "jurusanid";
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "Teks",
            "Tandon",
            "Referensi",
            "Restricted"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // repositoryLinkPDF
            // 
            this.repositoryLinkPDF.AutoHeight = false;
            toolTipTitleItem3.Text = "Browse File..";
            toolTipItem5.LeftIndent = 6;
            toolTipItem5.Text = "Upload Pdf File ke server..";
            superToolTip5.Items.Add(toolTipTitleItem3);
            superToolTip5.Items.Add(toolTipItem5);
            toolTipTitleItem4.Text = "Hapus File.";
            toolTipItem6.LeftIndent = 6;
            toolTipItem6.Text = "Hapus Pdf file dari server";
            superToolTip6.Items.Add(toolTipTitleItem4);
            superToolTip6.Items.Add(toolTipItem6);
            this.repositoryLinkPDF.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject5, "", null, superToolTip5, true),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject6, "", null, superToolTip6, true)});
            this.repositoryLinkPDF.Image = global::DIGILIB.Properties.Resources.PDF_icon16;
            this.repositoryLinkPDF.Name = "repositoryLinkPDF";
            this.repositoryLinkPDF.OpenLink += new DevExpress.XtraEditors.Controls.OpenLinkEventHandler(this.repositoryItemHyperLinkEdit1_OpenLink);
            this.repositoryLinkPDF.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemHyperLinkEdit1_ButtonClick);
            // 
            // repositoryLinkImages
            // 
            this.repositoryLinkImages.AutoHeight = false;
            toolTipItem7.Text = "Browse File../Upload Cover ke server..";
            superToolTip7.Items.Add(toolTipItem7);
            toolTipItem8.Text = "Hapus File/Hapus Cover file dari server";
            superToolTip8.Items.Add(toolTipItem8);
            this.repositoryLinkImages.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject7, "", null, superToolTip7, true),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Delete, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject8, "", null, superToolTip8, true)});
            this.repositoryLinkImages.Image = global::DIGILIB.Properties.Resources.file_extension_jpg_icon2;
            this.repositoryLinkImages.Name = "repositoryLinkImages";
            this.repositoryLinkImages.OpenLink += new DevExpress.XtraEditors.Controls.OpenLinkEventHandler(this.repositoryItemHyperLinkEdit2_OpenLink);
            this.repositoryLinkImages.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemHyperLinkEdit2_ButtonClick);
            // 
            // btnEndEdit
            // 
            this.btnEndEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEndEdit.Enabled = false;
            this.btnEndEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEndEdit.Image")));
            this.btnEndEdit.Location = new System.Drawing.Point(168, 473);
            this.btnEndEdit.Name = "btnEndEdit";
            this.btnEndEdit.Size = new System.Drawing.Size(80, 26);
            this.btnEndEdit.TabIndex = 83;
            this.btnEndEdit.Text = "&End Edit";
            this.btnEndEdit.Click += new System.EventHandler(this.btnEndEdit_Click);
            // 
            // btnDel
            // 
            this.btnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDel.Image = ((System.Drawing.Image)(resources.GetObject("btnDel.Image")));
            this.btnDel.Location = new System.Drawing.Point(89, 473);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(73, 26);
            this.btnDel.TabIndex = 82;
            this.btnDel.Text = "Hapus";
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(7, 473);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(76, 26);
            this.btnEdit.TabIndex = 81;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(865, 473);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 26);
            this.btnClose.TabIndex = 84;
            this.btnClose.Text = "&Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(7, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.TabIndex = 85;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16F);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(86, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 25);
            this.label1.TabIndex = 86;
            this.label1.Text = "Master Data -> Multimedia";
            // 
            // btnActive
            // 
            this.btnActive.Enabled = false;
            this.btnActive.Image = ((System.Drawing.Image)(resources.GetObject("btnActive.Image")));
            this.btnActive.Location = new System.Drawing.Point(525, 81);
            this.btnActive.Name = "btnActive";
            this.btnActive.Size = new System.Drawing.Size(128, 34);
            this.btnActive.TabIndex = 88;
            this.btnActive.Text = "Set Scan Mode";
            this.btnActive.Click += new System.EventHandler(this.btnActive_Click);
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Image = ((System.Drawing.Image)(resources.GetObject("btnStop.Image")));
            this.btnStop.Location = new System.Drawing.Point(659, 81);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(128, 34);
            this.btnStop.TabIndex = 89;
            this.btnStop.Text = "Close Scan Mode";
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // timerScan
            // 
            this.timerScan.Interval = 1000;
            this.timerScan.Tick += new System.EventHandler(this.timerScan_Tick);
            // 
            // btnDownload
            // 
            this.btnDownload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDownload.Appearance.Options.UseTextOptions = true;
            this.btnDownload.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.btnDownload.ImageIndex = 11;
            this.btnDownload.Location = new System.Drawing.Point(504, 473);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(125, 26);
            this.btnDownload.TabIndex = 92;
            this.btnDownload.Text = "Download Template";
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnUpload
            // 
            this.btnUpload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpload.Appearance.Options.UseTextOptions = true;
            this.btnUpload.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.btnUpload.ImageIndex = 12;
            this.btnUpload.Location = new System.Drawing.Point(635, 473);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(125, 26);
            this.btnUpload.TabIndex = 93;
            this.btnUpload.Text = "Upload to Database";
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Appearance.Options.UseFont = true;
            this.btnPreview.Image = ((System.Drawing.Image)(resources.GetObject("btnPreview.Image")));
            this.btnPreview.Location = new System.Drawing.Point(768, 473);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(91, 26);
            this.btnPreview.TabIndex = 94;
            this.btnPreview.Text = "Preview";
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // ucMultimedia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnDownload);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnActive);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnEndEdit);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.dgData);
            this.Name = "ucMultimedia";
            this.Size = new System.Drawing.Size(948, 504);
            this.Load += new System.EventHandler(this.ucProdi_Load);
            this.Leave += new System.EventHandler(this.ucProdi_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewInventaris)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJenjang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJurusan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLinkPDF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLinkImages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public DevExpress.XtraEditors.SimpleButton btnEndEdit;
        public DevExpress.XtraEditors.SimpleButton btnDel;
        public DevExpress.XtraEditors.SimpleButton btnEdit;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        public DevExpress.XtraEditors.SimpleButton btnActive;
        public DevExpress.XtraEditors.SimpleButton btnStop;
        private System.Windows.Forms.Timer timerScan;
        public DevExpress.XtraEditors.SimpleButton btnDownload;
        public DevExpress.XtraEditors.SimpleButton btnUpload;
        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewInventaris;
        private DevExpress.XtraGrid.Columns.GridColumn inventarisid;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid2;
        private DevExpress.XtraGrid.Columns.GridColumn pengadaanid;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        private DevExpress.XtraGrid.Columns.GridColumn tglditerima;
        private DevExpress.XtraGrid.Columns.GridColumn nib;
        private DevExpress.XtraGrid.Columns.GridColumn status;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraGrid.Columns.GridColumn ket_koleksi;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraGrid.Columns.GridColumn kode_makul;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewData;
        private DevExpress.XtraGrid.Columns.GridColumn bukuid;
        private DevExpress.XtraGrid.Columns.GridColumn noinduk;
        private DevExpress.XtraGrid.Columns.GridColumn kodepanggil;
        private DevExpress.XtraGrid.Columns.GridColumn judul;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn pengarang;
        private DevExpress.XtraGrid.Columns.GridColumn badankorporat;
        private DevExpress.XtraGrid.Columns.GridColumn edisi;
        private DevExpress.XtraGrid.Columns.GridColumn penerbit;
        private DevExpress.XtraGrid.Columns.GridColumn tempatterbit;
        private DevExpress.XtraGrid.Columns.GridColumn tahunterbit;
        private DevExpress.XtraGrid.Columns.GridColumn isbn;
        private DevExpress.XtraGrid.Columns.GridColumn deskripsi;
        private DevExpress.XtraGrid.Columns.GridColumn supplemen;
        private DevExpress.XtraGrid.Columns.GridColumn lokasikoleksi;
        private DevExpress.XtraGrid.Columns.GridColumn jeniskoleksi;
        private DevExpress.XtraGrid.Columns.GridColumn keterangan;
        private DevExpress.XtraGrid.Columns.GridColumn pdffilename;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryItemHyperLinkEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn pdffolder;
        private DevExpress.XtraGrid.Columns.GridColumn coverbuku;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryItemHyperLinkEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUJenjang;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUJurusan;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryLinkPDF;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryLinkImages;
    }
}
