﻿namespace DIGILIB.MasterData
{
    partial class ucAnggota
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucAnggota));
            this.dgData = new DevExpress.XtraGrid.GridControl();
            this.gridViewData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.anggotaid2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rfid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nim = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nama = new DevExpress.XtraGrid.Columns.GridColumn();
            this.prodidesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.jeniskelamin = new DevExpress.XtraGrid.Columns.GridColumn();
            this.nohp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.statusaktif = new DevExpress.XtraGrid.Columns.GridColumn();
            this.alamat = new DevExpress.XtraGrid.Columns.GridColumn();
            this.keterangan = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryLUJenjang = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryLUJurusan = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAdd = new DevExpress.XtraEditors.SimpleButton();
            this.btnEdit = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.btnDelete = new DevExpress.XtraEditors.SimpleButton();
            this.btnPreview = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.rgJenis = new DevExpress.XtraEditors.RadioGroup();
            this.btnSync = new DevExpress.XtraEditors.SimpleButton();
            this.btnGetTrx = new DevExpress.XtraEditors.SimpleButton();
            this.dgExport = new DevExpress.XtraGrid.GridControl();
            this.gridViewExport = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJenjang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJurusan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgJenis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgExport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewExport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            this.SuspendLayout();
            // 
            // dgData
            // 
            this.dgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgData.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgData.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Location = new System.Drawing.Point(4, 107);
            this.dgData.MainView = this.gridViewData;
            this.dgData.Margin = new System.Windows.Forms.Padding(4);
            this.dgData.Name = "dgData";
            this.dgData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryLUJenjang,
            this.repositoryLUJurusan,
            this.repositoryItemComboBox1,
            this.repositoryItemMemoEdit1});
            this.dgData.Size = new System.Drawing.Size(1413, 560);
            this.dgData.TabIndex = 0;
            this.dgData.UseEmbeddedNavigator = true;
            this.dgData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewData});
            // 
            // gridViewData
            // 
            this.gridViewData.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridViewData.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewData.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewData.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewData.Appearance.Row.Options.UseTextOptions = true;
            this.gridViewData.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewData.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewData.ColumnPanelRowHeight = 35;
            this.gridViewData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.anggotaid2,
            this.rfid,
            this.nim,
            this.nama,
            this.prodidesc,
            this.jeniskelamin,
            this.nohp,
            this.statusaktif,
            this.alamat,
            this.keterangan});
            this.gridViewData.GridControl = this.dgData;
            this.gridViewData.Name = "gridViewData";
            this.gridViewData.OptionsBehavior.Editable = false;
            this.gridViewData.OptionsFind.AlwaysVisible = true;
            this.gridViewData.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewData.OptionsView.ShowAutoFilterRow = true;
            this.gridViewData.OptionsView.ShowGroupPanel = false;
            this.gridViewData.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewData_FocusedRowChanged);
            this.gridViewData.DoubleClick += new System.EventHandler(this.gridViewData_DoubleClick);
            // 
            // anggotaid2
            // 
            this.anggotaid2.Caption = "anggotaid";
            this.anggotaid2.FieldName = "anggotaid";
            this.anggotaid2.Name = "anggotaid2";
            // 
            // rfid
            // 
            this.rfid.Caption = "RFID/Tag";
            this.rfid.FieldName = "rfid";
            this.rfid.MinWidth = 150;
            this.rfid.Name = "rfid";
            this.rfid.Visible = true;
            this.rfid.VisibleIndex = 0;
            this.rfid.Width = 150;
            // 
            // nim
            // 
            this.nim.Caption = "NIK/NIM";
            this.nim.FieldName = "nim";
            this.nim.MinWidth = 150;
            this.nim.Name = "nim";
            this.nim.Visible = true;
            this.nim.VisibleIndex = 1;
            this.nim.Width = 200;
            // 
            // nama
            // 
            this.nama.Caption = "Nama";
            this.nama.FieldName = "nama";
            this.nama.MinWidth = 200;
            this.nama.Name = "nama";
            this.nama.Visible = true;
            this.nama.VisibleIndex = 2;
            this.nama.Width = 250;
            // 
            // prodidesc
            // 
            this.prodidesc.Caption = "Program Studi";
            this.prodidesc.FieldName = "prodidesc";
            this.prodidesc.MinWidth = 150;
            this.prodidesc.Name = "prodidesc";
            this.prodidesc.Visible = true;
            this.prodidesc.VisibleIndex = 3;
            this.prodidesc.Width = 150;
            // 
            // jeniskelamin
            // 
            this.jeniskelamin.Caption = "Jenis Kelamin";
            this.jeniskelamin.FieldName = "jeniskelamin";
            this.jeniskelamin.MinWidth = 100;
            this.jeniskelamin.Name = "jeniskelamin";
            this.jeniskelamin.Visible = true;
            this.jeniskelamin.VisibleIndex = 4;
            this.jeniskelamin.Width = 100;
            // 
            // nohp
            // 
            this.nohp.Caption = "No HP";
            this.nohp.FieldName = "nohp";
            this.nohp.MinWidth = 150;
            this.nohp.Name = "nohp";
            this.nohp.Visible = true;
            this.nohp.VisibleIndex = 5;
            this.nohp.Width = 150;
            // 
            // statusaktif
            // 
            this.statusaktif.Caption = "Status Aktif";
            this.statusaktif.FieldName = "statusaktif";
            this.statusaktif.MinWidth = 100;
            this.statusaktif.Name = "statusaktif";
            this.statusaktif.Visible = true;
            this.statusaktif.VisibleIndex = 6;
            this.statusaktif.Width = 100;
            // 
            // alamat
            // 
            this.alamat.Caption = "Alamat";
            this.alamat.FieldName = "alamat";
            this.alamat.MinWidth = 200;
            this.alamat.Name = "alamat";
            this.alamat.Visible = true;
            this.alamat.VisibleIndex = 7;
            this.alamat.Width = 200;
            // 
            // keterangan
            // 
            this.keterangan.Caption = "Keterangan";
            this.keterangan.FieldName = "keterangan";
            this.keterangan.MinWidth = 200;
            this.keterangan.Name = "keterangan";
            this.keterangan.Visible = true;
            this.keterangan.VisibleIndex = 8;
            this.keterangan.Width = 200;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit1.Mask.EditMask = "dd-MM-yyyy";
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryLUJenjang
            // 
            this.repositoryLUJenjang.AutoHeight = false;
            this.repositoryLUJenjang.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUJenjang.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjangakademikid", "jenjangakademikid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjang", "jenjang")});
            this.repositoryLUJenjang.DisplayMember = "jenjang";
            this.repositoryLUJenjang.DropDownRows = 15;
            this.repositoryLUJenjang.Name = "repositoryLUJenjang";
            this.repositoryLUJenjang.NullText = "";
            this.repositoryLUJenjang.ShowHeader = false;
            this.repositoryLUJenjang.ValueMember = "jenjangakademikid";
            // 
            // repositoryLUJurusan
            // 
            this.repositoryLUJurusan.AutoHeight = false;
            this.repositoryLUJurusan.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryLUJurusan.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusanid", "jurusanid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusancode", "Kode Jurusan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusandesc", 50, "Nama Jurusan")});
            this.repositoryLUJurusan.DisplayMember = "jurusandesc";
            this.repositoryLUJurusan.DropDownRows = 15;
            this.repositoryLUJurusan.Name = "repositoryLUJurusan";
            this.repositoryLUJurusan.NullText = "";
            this.repositoryLUJurusan.ValueMember = "jurusanid";
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "Teks",
            "Tandon",
            "Referensi",
            "Restricted"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 94);
            this.pictureBox1.TabIndex = 85;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16F);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(129, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(349, 36);
            this.label1.TabIndex = 86;
            this.label1.Text = "Master Data -> Anggota";
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdd.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Appearance.Options.UseFont = true;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(10, 675);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(168, 54);
            this.btnAdd.TabIndex = 88;
            this.btnAdd.Text = "&Tambah";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEdit.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnEdit.Appearance.Options.UseFont = true;
            this.btnEdit.Enabled = false;
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.Location = new System.Drawing.Point(188, 675);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(136, 54);
            this.btnEdit.TabIndex = 89;
            this.btnEdit.Text = "&Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClose.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnClose.Appearance.Options.UseFont = true;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(478, 675);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(136, 54);
            this.btnClose.TabIndex = 90;
            this.btnClose.Text = "&Tutup";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click_1);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDelete.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Appearance.Options.UseFont = true;
            this.btnDelete.Enabled = false;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(333, 675);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 54);
            this.btnDelete.TabIndex = 87;
            this.btnDelete.Text = "&Hapus";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Appearance.Options.UseFont = true;
            this.btnPreview.Image = global::DIGILIB.Properties.Resources.Actions_print_preview_icon32;
            this.btnPreview.Location = new System.Drawing.Point(1251, 675);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(166, 54);
            this.btnPreview.TabIndex = 91;
            this.btnPreview.Text = "Preview";
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // panelControl1
            // 
            this.panelControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl1.Controls.Add(this.rgJenis);
            this.panelControl1.Location = new System.Drawing.Point(904, 113);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(500, 54);
            this.panelControl1.TabIndex = 92;
            // 
            // rgJenis
            // 
            this.rgJenis.EditValue = "Mahasiswa";
            this.rgJenis.Location = new System.Drawing.Point(8, 7);
            this.rgJenis.Margin = new System.Windows.Forms.Padding(4);
            this.rgJenis.Name = "rgJenis";
            this.rgJenis.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Mahasiswa", "Mahasiswa"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Staff", "Staff")});
            this.rgJenis.Size = new System.Drawing.Size(484, 39);
            this.rgJenis.TabIndex = 0;
            this.rgJenis.EditValueChanged += new System.EventHandler(this.rgJenis_EditValueChanged);
            // 
            // btnSync
            // 
            this.btnSync.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSync.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnSync.Appearance.Options.UseFont = true;
            this.btnSync.Image = ((System.Drawing.Image)(resources.GetObject("btnSync.Image")));
            this.btnSync.Location = new System.Drawing.Point(855, 675);
            this.btnSync.Margin = new System.Windows.Forms.Padding(4);
            this.btnSync.Name = "btnSync";
            this.btnSync.Size = new System.Drawing.Size(371, 54);
            this.btnSync.TabIndex = 93;
            this.btnSync.Text = "&Sync Data Anggota ke Tripod Gate";
            this.btnSync.Click += new System.EventHandler(this.btnSync_Click);
            // 
            // btnGetTrx
            // 
            this.btnGetTrx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGetTrx.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnGetTrx.Appearance.Options.UseFont = true;
            this.btnGetTrx.Image = ((System.Drawing.Image)(resources.GetObject("btnGetTrx.Image")));
            this.btnGetTrx.Location = new System.Drawing.Point(622, 675);
            this.btnGetTrx.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetTrx.Name = "btnGetTrx";
            this.btnGetTrx.Size = new System.Drawing.Size(136, 54);
            this.btnGetTrx.TabIndex = 94;
            this.btnGetTrx.Text = "&Trx";
            this.btnGetTrx.Click += new System.EventHandler(this.btnGetTrx_Click);
            // 
            // dgExport
            // 
            this.dgExport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgExport.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.dgExport.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.dgExport.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.dgExport.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.dgExport.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.dgExport.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgExport.Location = new System.Drawing.Point(364, 282);
            this.dgExport.MainView = this.gridViewExport;
            this.dgExport.Margin = new System.Windows.Forms.Padding(4);
            this.dgExport.Name = "dgExport";
            this.dgExport.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEdit2,
            this.repositoryItemCheckEdit2,
            this.repositoryItemLookUpEdit1,
            this.repositoryItemLookUpEdit2,
            this.repositoryItemComboBox2,
            this.repositoryItemMemoEdit2});
            this.dgExport.Size = new System.Drawing.Size(577, 296);
            this.dgExport.TabIndex = 95;
            this.dgExport.UseEmbeddedNavigator = true;
            this.dgExport.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewExport});
            this.dgExport.Visible = false;
            // 
            // gridViewExport
            // 
            this.gridViewExport.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridViewExport.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewExport.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridViewExport.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridViewExport.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewExport.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewExport.Appearance.Row.Options.UseTextOptions = true;
            this.gridViewExport.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridViewExport.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridViewExport.ColumnPanelRowHeight = 35;
            this.gridViewExport.GridControl = this.dgExport;
            this.gridViewExport.Name = "gridViewExport";
            this.gridViewExport.OptionsBehavior.Editable = false;
            this.gridViewExport.OptionsFind.AlwaysVisible = true;
            this.gridViewExport.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewExport.OptionsView.ShowAutoFilterRow = true;
            this.gridViewExport.OptionsView.ShowGroupPanel = false;
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.EditFormat.FormatString = "dd-MM-yyyy";
            this.repositoryItemDateEdit2.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.repositoryItemDateEdit2.Mask.EditMask = "dd-MM-yyyy";
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            this.repositoryItemDateEdit2.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjangakademikid", "jenjangakademikid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jenjang", "jenjang")});
            this.repositoryItemLookUpEdit1.DisplayMember = "jenjang";
            this.repositoryItemLookUpEdit1.DropDownRows = 15;
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.NullText = "";
            this.repositoryItemLookUpEdit1.ShowHeader = false;
            this.repositoryItemLookUpEdit1.ValueMember = "jenjangakademikid";
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusanid", "jurusanid", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusancode", "Kode Jurusan"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("jurusandesc", 50, "Nama Jurusan")});
            this.repositoryItemLookUpEdit2.DisplayMember = "jurusandesc";
            this.repositoryItemLookUpEdit2.DropDownRows = 15;
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            this.repositoryItemLookUpEdit2.NullText = "";
            this.repositoryItemLookUpEdit2.ValueMember = "jurusanid";
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "Teks",
            "Tandon",
            "Referensi",
            "Restricted"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // ucAnggota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dgExport);
            this.Controls.Add(this.btnGetTrx);
            this.Controls.Add(this.btnSync);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dgData);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucAnggota";
            this.Size = new System.Drawing.Size(1422, 737);
            this.Load += new System.EventHandler(this.ucProdi_Load);
            this.Leave += new System.EventHandler(this.ucProdi_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJenjang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryLUJurusan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rgJenis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgExport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewExport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraGrid.GridControl dgData;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewData;
        private DevExpress.XtraGrid.Columns.GridColumn anggotaid2;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUJenjang;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryLUJurusan;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.Columns.GridColumn rfid;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn nim;
        private DevExpress.XtraGrid.Columns.GridColumn nama;
        public DevExpress.XtraEditors.SimpleButton btnAdd;
        public DevExpress.XtraEditors.SimpleButton btnEdit;
        public DevExpress.XtraEditors.SimpleButton btnClose;
        public DevExpress.XtraEditors.SimpleButton btnDelete;
        public DevExpress.XtraEditors.SimpleButton btnPreview;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.RadioGroup rgJenis;
        private DevExpress.XtraGrid.Columns.GridColumn prodidesc;
        private DevExpress.XtraGrid.Columns.GridColumn jeniskelamin;
        private DevExpress.XtraGrid.Columns.GridColumn nohp;
        private DevExpress.XtraGrid.Columns.GridColumn statusaktif;
        private DevExpress.XtraGrid.Columns.GridColumn alamat;
        private DevExpress.XtraGrid.Columns.GridColumn keterangan;
        public DevExpress.XtraEditors.SimpleButton btnSync;
        public DevExpress.XtraEditors.SimpleButton btnGetTrx;
        private DevExpress.XtraGrid.GridControl dgExport;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewExport;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
    }
}
