﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Columns;
using Npgsql;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid;
using System.Collections;
using DIGILIB.MainReport;

namespace DIGILIB.MasterData
{
    public partial class frmNewPengadaan : DevExpress.XtraEditors.XtraForm
    {

        WaitDialogForm loadDialog;
        private int intInitColumnCount;
        List<string> arrExistingDate = new List<string>();
        List<string> arrWorkpackId = new List<string>();

        public string strID = "";

        public bool bolLoading = false;
        public bool pEdit = false;
        public frmNewPengadaan()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();
            setLoadDialog(false, "");
        }

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public void loadData()
        {
            bolLoading = true;
            setLoadDialog(true, "Loading data...");
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string strSQL = @"select distinct a.*, c.bukuid
                                from tbm_pengadaandetails a
                                inner join tbm_pengadaan b on a.pengadaanid=b.pengadaanid and b.dlt='0'
                                left outer join tbm_inventaris c on c.pengadaandetailsid=a.pengadaandetailsid and c.dlt='0'
                                where a.dlt='0' and a.pengadaanid='" + strID + @"'
                                order by a.nourut";
                    dtData = oConn.GetData(strSQL);

                    dgData.DataSource = dtData;
                    dgData.Enabled = true;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                    bolLoading = false;
                }
            }
        }

        public void loadDataPetugas()
        {
            bolLoading = true;
            setLoadDialog(true, "Loading data petugas...");
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string strSQL = @"select anggotaid, rfid, nim, nama from tbm_anggota where dlt='0' order by nim;";
                    DataTable dtData1 = oConn.GetData(strSQL);
                    cboPetugas.Properties.DataSource = dtData1;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                    bolLoading = false;
                }
            }
        }

        public void loadDataBuku()
        {
            bolLoading = true;
            setLoadDialog(true, "Loading data buku...");
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string strSQL = @"select a.bukuid, a.pengadaanid, a.noinduk, a.kodepanggil, a.judul, a.pengarang, a.badankorporat, 
                                a.edisi, a.penerbit, a.tempatterbit, a.tahunterbit, a.isbn, a.deskripsi, a.supplemen, a.lokasikoleksi, a.keterangan,
                                b.status, b.harga
                                from tbm_buku a
                                left outer join 
                                (
	                                select distinct aa.bukuid, bb.status, bb.harga, bb.pengadaanid
	                                from tbm_inventaris aa
	                                inner join tbm_pengadaandetails bb on aa.pengadaandetailsid=bb.pengadaandetailsid and bb.dlt='0'
	                                where aa.dlt='0'
                                ) b on a.bukuid=b.bukuid and a.pengadaanid=b.pengadaanid
                                where a.dlt='0'
                                order by a.noinduk;";
                    DataTable dtData1 = oConn.GetData(strSQL);
                    cboNIB.Properties.DataSource = dtData1;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                    bolLoading = false;
                }
            }
        }

        private DataTable dtData;
        private DataView filteredDataView;
        private bool bolsave = true;

        private void gridViewData_ShownEditor(object sender, EventArgs e)
        {
            GridView gridView = (GridView)sender;
            LookUpEdit lookup = gridView.ActiveEditor as LookUpEdit;
            if (gridView.FocusedColumn.FieldName == "karyawanid" && lookup != null && dtData != null)
            {
                List<string> keys = new List<string>();
                for (int i = 0; i < dtData.DefaultView.Count; i++)
                {

                    object key = dtData.DefaultView[i].Row["karyawanid"];
                    if (key != null && key != DBNull.Value)
                    {
                        if (key.ToString() != Convert.ToString(gridView.FocusedValue))
                            keys.Add(key.ToString());
                    }
                }
                lookup.Properties.DataSource = filteredDataView;

                if (keys.Count > 0)
                {
                    filteredDataView.RowFilter = string.Format("karyawanid NOT IN( {0} )", "'" + String.Join("','", keys.ToArray()) + "'");
                }
            }
        }
        private void gridViewData_HiddenEditor(object sender, System.EventArgs e)
        {
            if (filteredDataView != null)
            {
                filteredDataView.Dispose();
                filteredDataView = null;
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            using (clsConnection oConn = new clsConnection())
            {
                setLoadDialog(true, "Saving data...");
                try
                {
                    if (gridViewData.RowCount <= 0)
                    {
                        XtraMessageBox.Show("Tidak ada data yang mau disimpan!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    else if (Convert.ToString(txtnopengadaan.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan isi [No Pengadaan]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtnopengadaan.Focus();
                        return;
                    }
                    else if (Convert.ToString(cboPetugas.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan pilih [ID Petugas]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cboPetugas.Focus();
                        return;
                    }
                    else if (datetglpengadaan.EditValue == null)
                    {
                        XtraMessageBox.Show("Silahkan isi tanggal pengadaan/diterima!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        datetglpengadaan.Focus();
                        return;
                    }

                    string strsql = "";
                    decimal decOut = 0;
                    string colActual_nt = "";
                    string colActual_ot = "";
                    DateTime myDate = clsGlobal.GetParseDate(datetglpengadaan.EditValue);
                    tbm_pengadaan oMaster = new tbm_pengadaan();

                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oMaster.Koneksi = oConn.Conn;
                    oMaster.pengadaanid = Convert.ToString(strID);
                    if (!string.IsNullOrEmpty(oMaster.pengadaanid))
                    {
                        oMaster.GetByPrimaryKey(oMaster.pengadaanid);
                    }

                    oMaster.anggotaid = Convert.ToString(cboPetugas.EditValue);
                    oMaster.nopengadaan = Convert.ToString(txtnopengadaan.EditValue);
                    oMaster.tglditerima = myDate;

                    if (Convert.ToString(oMaster.pengadaanid) == "" || oMaster.pengadaanid == null)
                    {
                        oMaster.nourut = clsGlobal.intNewNumber;
                        oMaster.opadd = clsGlobal.strUserName;
                        oMaster.pcadd = SystemInformation.ComputerName;
                        strID = oMaster.NewID();
                        oMaster.pengadaanid = strID;
                        oMaster.Insert();
                    }
                    else
                    {
                        oMaster.opedit = clsGlobal.strUserName;
                        oMaster.pcedit = SystemInformation.ComputerName;
                        oMaster.Update();
                    }

                    DataTable dtMdf = dgData.DataSource as DataTable;
                    if (dtMdf != null && dtMdf.GetChanges() != null)
                    {
                        tbm_pengadaandetails oObject = new tbm_pengadaandetails();
                        tbm_buku oBuku = new tbm_buku();
                        tbm_inventaris oInventaris = new tbm_inventaris();
                        oObject.Koneksi = oConn.Conn;
                        oBuku.Koneksi = oConn.Conn;
                        oInventaris.Koneksi = oConn.Conn;
                        NpgsqlCommand npcmd = new NpgsqlCommand();
                        //Modified
                        decimal nou = 1;
                        foreach (DataRow row in dtMdf.GetChanges().Rows)
                        {
                            if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                            if (row.RowState == DataRowState.Deleted)
                            {
                                row.RejectChanges();
                                oObject.pengadaandetailsid = Convert.ToString(row[pengadaandetailsid.FieldName]);
                                oObject.SoftDelete();
                                row.Delete();
                            }
                            else
                            {
                                oObject.pengadaandetailsid = Convert.ToString(row[pengadaandetailsid.FieldName]);
                                if (!string.IsNullOrEmpty(oObject.pengadaandetailsid))
                                {
                                    oObject.GetByPrimaryKey(oObject.pengadaandetailsid);
                                }
                                oObject.pengadaanid = Convert.ToString(oMaster.pengadaanid);

                                oObject.jumlah = clsGlobal.GetParseDecimal(row[jumlah.FieldName]);
                                oObject.status = Convert.ToString(row[status.FieldName]);
                                oObject.nopo = Convert.ToString(row[nopo.FieldName]);
                                oObject.judul = Convert.ToString(row[judul.FieldName]);
                                oObject.pengarang = Convert.ToString(row[pengarang.FieldName]);
                                oObject.edisi = Convert.ToString(row[edisi.FieldName]);
                                oObject.penerbit = Convert.ToString(row[penerbit.FieldName]);
                                oObject.tempatterbit = Convert.ToString(row[tempatterbit.FieldName]);
                                oObject.tahunterbit = Convert.ToString(row[tahunterbit.FieldName]);
                                oObject.isbn = Convert.ToString(row[isbn.FieldName]);
                                oObject.supplemen = Convert.ToString(row[supplemen.FieldName]);
                                oObject.pengusul = Convert.ToString(row[pengusul.FieldName]);
                                oObject.harga = clsGlobal.GetParseDecimal(row[harga.FieldName]);
                                oObject.nourut = nou;
                                if (Convert.ToString(oObject.pengadaandetailsid) == "" || oObject.pengadaandetailsid == null)
                                {
                                    oObject.opadd = clsGlobal.strUserName;
                                    oObject.pcadd = SystemInformation.ComputerName;
                                    oObject.pengadaandetailsid = oObject.NewID();
                                    row[pengadaandetailsid.FieldName] = oObject.pengadaandetailsid;
                                    oObject.Insert();

                                    if (Convert.ToString(row["bukuid"]) == "")
                                    {
                                        oBuku.bukuid = oBuku.NewID();
                                        oBuku.pengadaanid = oObject.pengadaanid;
                                        oBuku.noinduk = clsGlobal.GetNewNumber("Nomor Induk Buku");
                                        oBuku.judul = oObject.judul;
                                        oBuku.pengarang = oObject.pengarang;
                                        oBuku.edisi = oObject.edisi;
                                        oBuku.penerbit = oObject.penerbit;
                                        oBuku.tempatterbit = oObject.tempatterbit;
                                        oBuku.tahunterbit = oObject.tahunterbit;
                                        oBuku.isbn = oObject.isbn;
                                        oBuku.supplemen = oObject.supplemen;
                                        oBuku.nourut = clsGlobal.intNewNumber;
                                        oBuku.opadd = clsGlobal.strUserName;
                                        oBuku.pcadd = SystemInformation.ComputerName;
                                        oBuku.Insert();

                                        decOut = 0; decimal.TryParse(Convert.ToString(row["jumlah"]), out decOut);
                                        for (int i = 0; i < decOut; i++)
                                        {
                                            oInventaris.inventarisid = oInventaris.NewID();
                                            oInventaris.bukuid = oBuku.bukuid;
                                            oInventaris.pengadaandetailsid = oObject.pengadaandetailsid;
                                            oInventaris.tglditerima = oMaster.tglditerima;
                                            oInventaris.nib = clsGlobal.GetNewNumber("Nomor inventaris Buku");
                                            oInventaris.status = oObject.status;
                                            oInventaris.nourut = clsGlobal.intNewNumber;
                                            oInventaris.opadd = clsGlobal.strUserName;
                                            oInventaris.pcadd = SystemInformation.ComputerName;
                                            oInventaris.Insert();
                                        }
                                    }

                                }
                                else
                                {
                                    oObject.opedit = clsGlobal.strUserName;
                                    oObject.pcedit = SystemInformation.ComputerName;
                                    oObject.Update();
                                }

                                nou++;
                            }
                        }
                        oObject = null;
                        oBuku = null; oInventaris = null;
                    }
                    if (dtMdf != null)
                    {
                        dtMdf.AcceptChanges();
                        dgData.RefreshDataSource();
                    }
                    bolsave = true;
                    setLoadDialog(false, "");
                    //if (sender != null)
                    //{
                    //    if (XtraMessageBox.Show("Data berhasil disimpan\n\nApakah anda ingin menambah data yang lain?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    //    {
                    //        arrExistingDate.Clear();                        
                    //        DateTime dateEdit = Convert.ToDateTime(datetglpinjam.EditValue);

                    //        pEdit = false;
                    //        pstrpeminjamanid = "";
                    //        enableControl(true);
                    //        loadData(false);
                    //        dgData.Enabled = false;
                    //        txtnopeminjaman.Focus();

                    //    }
                    //    else
                    //    {
                    //        btnClose_Click(null, null);
                    //    }
                    //}
                    //else
                    //{
                    //XtraMessageBox.Show("Data berhasil disimpan!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //pEdit = true;
                    //}
                    bolsave = true;
                    this.DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    btnSave.Enabled = true;
                    setLoadDialog(false, "");
                }
            }
        }
        public void enableControl(bool isenabled)
        {
            txtnopengadaan.Enabled = isenabled;
            cboNIB.Enabled = isenabled;
            datetglpengadaan.Enabled = isenabled;
        }
        public void btnLoadData_Click(object sender, EventArgs e)
        {
            loadData();
        }
        private void gridViewData_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            int currentRow = e.RowHandle;
            ColumnView view = sender as ColumnView;

            //if (view == null)
            //{
            //    XtraMessageBox.Show("Data source not found.., please click button [Load Data]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    return;
            //}
            //string suserid = Convert.ToString(view.GetRowCellValue(currentRow, peminjamanid)).ToLower();
            //if (suserid == "")
            //{
            //    string strMsg = "Nama Dosen tidak boleh kosong.\n";
            //    e.Valid = false;
            //    e.ErrorText = strMsg;
            //    view.FocusedColumn = peminjamanid;
            //    view.ShowEditor();
            //    return;
            //}

            bolsave = false;
        }

        private void gridViewData_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            //if (e.Column != peminjamanid && !e.Column.FieldName.Contains("subtotal"))
            //{
            //    decimal decOut = 0;
            //    decimal.TryParse(Convert.ToString(e.CellValue), out decOut);
            //    if (decOut > 0)
            //    {
            //        e.Appearance.Font = new Font(AppearanceObject.DefaultFont, FontStyle.Bold);
            //        e.Appearance.ForeColor = Color.Black;

            //    }
            //    else
            //    {
            //        e.Appearance.Font = new Font(AppearanceObject.DefaultFont, FontStyle.Regular);
            //    }
            //}
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (bolsave == false)
            {
                if (XtraMessageBox.Show("Data sudah diubah. Apakah anda ingin menyimpan perubahan?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    btnSave_Click(null, null);
                }
            }
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void dateActual_DrawItem(object sender, DevExpress.XtraEditors.Calendar.CustomDrawDayNumberCellEventArgs e)
        {
            //if (e.Date.Month != 3)
            if (arrExistingDate.Contains(e.Date.ToString("yyyy-MM-dd")))
                e.Handled = true;
        }

        private void dateActual_QueryCloseUp(object sender, CancelEventArgs e)
        {
            DateEdit edit = sender as DateEdit;
            DevExpress.XtraEditors.Popup.PopupDateEditForm form = (sender as DevExpress.Utils.Win.IPopupControl).PopupWindow as DevExpress.XtraEditors.Popup.PopupDateEditForm;
            //if (form.Calendar.DateTime.Month != 3)
            if (arrExistingDate.Contains(form.Calendar.DateTime.Date.ToString("yyyy-MM-dd")))
            {
                e.Cancel = true;
                form.Calendar.DateTime = edit.DateTime == DateTime.MinValue ? clsGlobal.getServerDate() : edit.DateTime;
            }
        }

        private void cboTimecard_EditValueChanged(object sender, EventArgs e)
        {
            //dateBorang.EditValue = null;
            //arrExistingDate.Clear();
            //arrExistingDate.AddRange(getExistingDate(Convert.ToString(cboTimecard.EditValue)));
        }

        public void btnPreview_Click(object sender, EventArgs e)
        {

            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";
                if (bolsave == false)
                {
                    if (XtraMessageBox.Show("Data sudah diubah. Apakah anda ingin menyimpan perubahan?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        btnSave_Click(null, null);
                    }
                    else
                    {
                        loadData();
                    }
                }
                filename = Application.StartupPath + @"\reports\rptDosenWali.repx";
                reportName = "rptDosenWali";


                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();

                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                frmMainReport mainReport = new frmMainReport();
                try
                {
                    DataTable dtMaster = dgData.DataSource as DataTable;
                    if (dtMaster != null)
                    {
                        //dtReport.TableName = "dtReportSource";
                        mainReport.reportName = reportName;

                        mainReport.printReport(filename, dtMaster);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                        btnPreview.Enabled = true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        private void LookUpEditEmp_EditValueChanged(object sender, EventArgs e)
        {
            //LookUpEdit cbolookup = sender as LookUpEdit;
            //if (cbolookup != null)
            //{
            //    gridViewData.SetFocusedRowCellValue(bukuid, cbolookup.GetColumnValue("nik"));
            //    gridViewData.SetFocusedRowCellValue(status, cbolookup.GetColumnValue("namakaryawan"));
            //}
        }

        private void gridViewData_SelectionChanged(object sender, DevExpress.Data.SelectionChangedEventArgs e)
        {
            if (!bolLoading)
                gridViewData.SetMasterRowExpandedEx(gridViewData.FocusedRowHandle, 0, true);
        }

        private void gridViewData_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
        {
            //GridView view = sender as GridView;
            //if (e.IsGetData && e.Column.FieldName.Contains("subtotalnt"))
            //{
            //    DataRow row = ((view.DataSource as IList)[e.ListSourceRowIndex] as DataRowView).Row;
            //    e.Value = row.GetChildRows("subtotal_nt_dtl").Length; 
            //}
            //else if (e.IsGetData && e.Column.FieldName.Contains("subtotal_ot"))
            //{
            //    DataRow row = ((view.DataSource as IList)[e.ListSourceRowIndex] as DataRowView).Row;
            //    e.Value = row.GetChildRows("subtotal_ot_dtl").Length;
            //}

        }
        private void dgData_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        {
            try
            {
                if (e.View != null && e.View.ParentView != null)
                {
                    ColumnView view = e.View.ParentView as ColumnView;
                    view.FocusedRowHandle = e.View.SourceRowHandle;
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }
        private void gridViewData_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            //if (!bolLoading)
            //    gridViewData.SetMasterRowExpandedEx(e.FocusedRowHandle, 0, true);
        }

        private void cbo_EditValueChanged(object sender, EventArgs e)
        {
            LookUpEdit cbolookup = sender as LookUpEdit;
            if (cbolookup != null)
            {
                txtnamapetugas.Text = Convert.ToString(cbolookup.GetColumnValue("nama"));
            }
            cbolookup = null;
        }

        private void LookUpEditMhs_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
            try
            {
                //LookUpEdit cbolookup = sender as LookUpEdit;
                //if (cbolookup != null)
                //{
                //    gridViewData.SetFocusedRowCellValue(mahasiswaid, cbolookup.GetColumnValue(mahasiswaid.FieldName));
                //    gridViewData.SetFocusedRowCellValue(nim, cbolookup.GetColumnValue(nim.FieldName));
                //    gridViewData.SetFocusedRowCellValue(namamahasiswa, cbolookup.GetColumnValue(namamahasiswa.FieldName));
                //}
            }
            catch
            {
            }
        }

        private void gridViewData_ValidatingEditor(object sender, DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs e)
        {
            try
            {
                //if (gridViewData.FocusedColumn.FieldName == mahasiswaid.FieldName)
                //{
                //    LookUpEdit cbolookup = gridViewData.ActiveEditor as LookUpEdit;
                //    if (cbolookup != null)
                //    {
                //        DataRowView drSelected = cbolookup.GetSelectedDataRow() as DataRowView;
                //        if (drSelected != null)
                //        {
                //            gridViewData.SetFocusedRowCellValue(mahasiswaid, drSelected[mahasiswaid.FieldName]);
                //            gridViewData.SetFocusedRowCellValue(nim, drSelected[nim.FieldName]);
                //            gridViewData.SetFocusedRowCellValue(noinduk, drSelected[noinduk.FieldName]);

                //        }
                //    }
                //}
                //else if (gridViewData.FocusedColumn.FieldName == peminjamanid.FieldName)
                //{
                //    LookUpEdit cbolookup = gridViewData.ActiveEditor as LookUpEdit;
                //    if (cbolookup != null)
                //    {
                //        DataRowView drSelected = cbolookup.GetSelectedDataRow() as DataRowView;
                //        if (drSelected != null)
                //        {
                //            gridViewData.SetFocusedRowCellValue(peminjamanid, drSelected[peminjamanid.FieldName]);
                //            gridViewData.SetFocusedRowCellValue(tarif, drSelected[tarif.FieldName]);
                //            gridViewData.SetFocusedRowCellValue(tarif_pajak, drSelected[tarif_pajak.FieldName]);
                //        }
                //    }
                //}
            }
            catch
            {
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DataRowView drSelected = cboNIB.GetSelectedDataRow() as DataRowView;
            if (drSelected != null)
            {
                DataTable dt = dgData.DataSource as DataTable;
                if (dt != null)
                {
                    bool bolBukuExist = false;
                    DataView dv = dt.DefaultView as DataView;
                    if (dv != null)
                    {
                        dv.RowFilter = "bukuid='" + Convert.ToString(drSelected["bukuid"]) + @"'";
                        if (dv.Count > 0)
                        {
                            bolBukuExist = true;
                            dv[0]["jumlah"] = clsGlobal.GetParseInt(dv[0]["jumlah"]) + clsGlobal.GetParseInt(txtjumlah.Text);
                        }
                        dv.RowFilter = "";
                    }
                    if (bolBukuExist == false)
                    {
                        DataRow dr = dt.NewRow();
                        dr["bukuid"] = Convert.ToString(drSelected["bukuid"]);
                        dr["pengadaanid"] = Convert.ToString(drSelected["pengadaanid"]);
                        dr["judul"] = Convert.ToString(drSelected["judul"]);
                        dr["pengarang"] = Convert.ToString(drSelected["pengarang"]);
                        dr["edisi"] = Convert.ToString(drSelected["edisi"]);
                        dr["penerbit"] = Convert.ToString(drSelected["penerbit"]);
                        dr["tempatterbit"] = Convert.ToString(drSelected["tempatterbit"]);
                        dr["tahunterbit"] = Convert.ToString(drSelected["tahunterbit"]);
                        dr["isbn"] = Convert.ToString(drSelected["isbn"]);
                        dr["supplemen"] = Convert.ToString(drSelected["supplemen"]);
                        dr["status"] = Convert.ToString(drSelected["status"]);
                        dr["harga"] = drSelected["harga"];
                        dr["jumlah"] = clsGlobal.GetParseInt(txtjumlah.Text);
                        dt.Rows.Add(dr);
                    }
                }

            }
        }

        private void frmNewPengadaan_Load(object sender, EventArgs e)
        {
            loadDataPetugas();
            loadDataBuku();
            if (strID != "")
            {
                using (clsConnection oConn = new clsConnection())
                {
                    tbm_pengadaan oObject = new tbm_pengadaan();
                    oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(strID);
                    txtnopengadaan.EditValue = oObject.nopengadaan;
                    datetglpengadaan.EditValue = oObject.tglditerima;
                    cboPetugas.EditValue = oObject.anggotaid;
                    oObject = null;
                }
            }
            else
            {
                txtnopengadaan.EditValue = clsGlobal.GetNewNumber("Nomor Pengadaan");
            }
            loadData();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            DataTable dt = dgData.DataSource as DataTable;
            DataRow dr = dt.NewRow();
            dt.Rows.Add(dr);
        }
    }
}