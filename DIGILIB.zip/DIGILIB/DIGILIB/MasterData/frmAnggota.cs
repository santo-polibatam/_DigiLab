﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Columns;
using Npgsql;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid;
using System.Collections;
using DIGILIB.MainReport;
using System.IO;

namespace DIGILIB.MasterData
{
    public partial class frmAnggota : DevExpress.XtraEditors.XtraForm
    {
        delegate void EnableTexBoxDelegate(DevExpress.XtraEditors.TextEdit txtbox, string textvalue);
        WaitDialogForm loadDialog;

        public string strID = "";
        public string strJenis = "";

        public bool bolLoading = false;
        public bool pEdit = false;
        public frmAnggota()
        {
            loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            Application.DoEvents();
            InitializeComponent();

            SelectICard();
            SetupReaderList();
            LoadApduList();
            comboReader_SelectedIndexChanged(null, null);

            chkShowPwd.Visible = (clsGlobal.strUserName.ToLower() == "superadmin" || clsGlobal.strUserName.ToLower() == "administrator");

            setLoadDialog(false, "");
        }
        
        #region Smartcard
        private GemCard.CardBase m_iCard = null;
        private GemCard.APDUPlayer m_apduPlayer = null;
        private GemCard.APDUParam m_apduParam = null;
        const string DefaultReader = "Gemplus USB Smart Card Reader 0";
        private TextBox txtboxATR;
        private Label label10;
        string reader = "ACS ACR122 0";
        const string ApduListFile = "ApduList.xml";


        public string GetScardErrMsg(string ReturnCode)
        {
            string strresult = ReturnCode;
            switch (ReturnCode)
            {
                case "9000":
                    strresult = "9000 : The operation completed succesfully.";
                    break;
                case "6300":
                    strresult = "6300 : The operation failed.";
                    break;
                case "6A81":
                    strresult = "6A81 : Function not supported.";
                    break;
            }
            return strresult;
        }

        private void SelectICard()
        {
            try
            {
                if (m_iCard != null)
                    m_iCard.Disconnect(GemCard.DISCONNECT.Unpower);

                m_iCard = new GemCard.CardNative();
                //statusBarPanel_Info.Text = "CardNative implementation used";              

                m_iCard.OnCardInserted += new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved += new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);

            }
            catch (Exception ex)
            {
                //btnConnect.Enabled = false;
                //btnDisconnect.Enabled = false;
                //btnTransmit.Enabled = false;

                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        /// <summary>
        /// CardRemovedEventHandler
        /// </summary>
        private void m_iCard_OnCardRemoved(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, false });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });

        }

        protected void fillTextBox(DevExpress.XtraEditors.TextEdit txtBox, object textValue)
        {
            txtBox.Text = Convert.ToString(textValue);
        }
        protected void EnableButton(Button btn, bool enable)
        {
            btn.Enabled = enable;
        }

        /// <summary>
        /// CardInsertedEventHandler
        /// </summary>
        private void m_iCard_OnCardInserted(string reader)
        {
            //btnConnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnConnect, true });
            //btnDisconnect.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnDisconnect, false });
            //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, false });
            //if (btnConnect.Enabled)
            //{
            try
            {
                m_iCard.Connect("ACS ACR122 0", GemCard.SHARE.Shared, GemCard.PROTOCOL.T0orT1);

                try
                {
                    // Get the ATR of the card
                    byte[] atrValue = m_iCard.GetAttribute(GemCard.SCARD_ATTR_VALUE.ATR_STRING);
                    //txtboxATR.Text = ByteArrayToString(atrValue);
                }
                catch (Exception)
                {
                    //txtboxATR.Text = "Cannot get ATR";
                }

                //btnTransmit.Invoke(new EnableButtonDelegate(EnableButton), new object[] { btnTransmit, btnConnect.Enabled });

                GemCard.APDUResponse apduResp = m_apduPlayer.ProcessCommand("Get UID", BuildParam());
                if (apduResp.Data != null)
                {
                    StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                    for (int nI = 0; nI < apduResp.Data.Length; nI++)
                        sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    if (apduResp.Data != null)
                    {
                        txtRFID.Invoke(new EnableTexBoxDelegate(fillTextBox), new object[] { txtRFID, ByteArrayToString(apduResp.Data) });
                    }
                }


            }
            catch (Exception ex)
            {
                XtraMessageBox.Show(ex.Message + "\nKoneksi Card Reader bermasalah!!!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            //btnConnect_Click(btnConnect, null);
            //}
        }

        public static byte[] StrToByteArray(string str)
        {
            Dictionary<string, byte> hexindex = new Dictionary<string, byte>();
            for (int i = 0; i <= 255; i++)
                hexindex.Add(i.ToString("X2"), (byte)i);

            List<byte> hexres = new List<byte>();
            for (int i = 0; i < str.Length; i += 2)
                hexres.Add(hexindex[str.Substring(i, 2)]);

            return hexres.ToArray();
        }

        static private string ByteArrayToString(byte[] data)
        {
            StringBuilder sDataOut;

            if (data != null)
            {
                sDataOut = new StringBuilder(data.Length * 2);
                for (int nI = 0; nI < data.Length; nI++)
                    sDataOut.AppendFormat("{0:X02}", data[nI]);
            }
            else
                sDataOut = new StringBuilder();

            return sDataOut.ToString();
        }
        string textClass = "";
        string textIns = "";
        string textP1 = "";
        string textP2 = "";
        string textLe = "";
        string textData = "";
        private GemCard.APDUParam BuildParam()
        {
            //byte bP1 = byte.Parse(textP1.Text, NumberStyles.AllowHexSpecifier);
            //byte bP2 = byte.Parse(textP2.Text, NumberStyles.AllowHexSpecifier);
            //byte bLe = byte.Parse(textLe.Text);

            byte bP1 = byte.Parse(textP1, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bP2 = byte.Parse(textP2, System.Globalization.NumberStyles.AllowHexSpecifier);
            byte bLe = byte.Parse(textLe);

            GemCard.APDUParam apduParam = new GemCard.APDUParam();
            apduParam.P1 = bP1;
            apduParam.P2 = bP2;
            apduParam.Le = bLe;

            // Update Current param
            m_apduParam = apduParam.Clone();

            return apduParam;
        }
        private void DisplayAPDUCommand(GemCard.APDUCommand apduCmd)
        {
            if (apduCmd != null)
            {
                textClass = string.Format("{0:X02}", apduCmd.Class);
                textIns = string.Format("{0:X02}", apduCmd.Ins);
                textP1 = string.Format("{0:X02}", apduCmd.P1);
                textP2 = string.Format("{0:X02}", apduCmd.P2);
                textLe = apduCmd.Le.ToString();

                if (apduCmd.Data != null)
                {
                    StringBuilder sData = new StringBuilder(apduCmd.Data.Length * 2);
                    for (int nI = 0; nI < apduCmd.Data.Length; nI++)
                        sData.AppendFormat("{0:X02}", apduCmd.Data[nI]);

                    textData = sData.ToString();
                }
                else
                    textData = "";

                m_apduParam = new GemCard.APDUParam();

                m_apduParam.P1 = apduCmd.P1;
                m_apduParam.P2 = apduCmd.P2;
                m_apduParam.Le = apduCmd.Le;
            }
        }

        private void SetupReaderList()
        {
            try
            {
                string[] sListReaders = m_iCard.ListReaders();
                //comboReader.Items.Clear();

                if (sListReaders != null)
                {
                    for (int nI = 0; nI < sListReaders.Length; nI++)
                    {
                        reader = Convert.ToString(sListReaders[nI]);
                        //    comboReader.Items.Add(sListReaders[nI]);
                    }
                    //comboReader.SelectedIndex = 0;

                    //btnConnect.Enabled = false;
                    //btnDisconnect.Enabled = false;
                    //btnTransmit.Enabled = false;

                    //// Start waiting for a card
                    //string reader = (string)comboReader.SelectedItem;
                    //m_iCard.StartCardEvents(reader);

                    //statusBarPanel_Info.Text = "Waiting for a card";
                }
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        /// <summary>
        /// Loads the APDU list
        /// </summary>
        private void LoadApduList()
        {
            try
            {
                // Create the APDU player
                m_apduPlayer = new GemCard.APDUPlayer(ApduListFile, m_iCard);

                // Get the list of APDUs and setup teh combo
                //comboApdu.Items.AddRange(m_apduPlayer.APDUNames);
                //comboApdu.SelectedIndex = 0;
                DisplayAPDUCommand(m_apduPlayer.APDUByName("Get UID"));
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
            }
        }
        private void comboReader_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                m_iCard.StopCardEvents();

                // Get the current selection
                //int idx = comboReader.SelectedIndex;
                //if (idx != -1)
                //{
                // Start waiting for a card

                m_iCard.StartCardEvents(reader);

                //statusBarPanel_Info.Text = "Waiting for a card";
                //}
            }
            catch (Exception ex)
            {
                //statusBarPanel_Info.Text = ex.Message;
                //btnConnect.Enabled = false;
            }
        }

        private void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //    m_iCard.Disconnect(DISCONNECT.Unpower);

                //    m_iCard.StopCardEvents();
                m_iCard.OnCardInserted -= new GemCard.CardInsertedEventHandler(m_iCard_OnCardInserted);
                m_iCard.OnCardRemoved -= new GemCard.CardRemovedEventHandler(m_iCard_OnCardRemoved);
            }
            catch
            {
            }
        }
        #endregion
        
        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null) return;
            if (loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("Loading Components...", "Please Wait...", new Size(250, 50));
            }

            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.TopMost = false;
                loadDialog.TopLevel = true;
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public void loadDataProdi()
        {
            bolLoading = true;
            setLoadDialog(true, "Loading data prodi...");
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    string strSQL = @"select b.jurusancode, b.jurusandesc, a.prodiid, a.prodicode, a.inisial, a.prodidesc
                                from tbm_prodi a
                                inner join tbm_jurusan b on a.jurusanid=b.jurusanid and b.dlt='0'
                                where a.dlt='0'
                                order by b.jurusancode, b.jurusandesc, a.prodicode, a.inisial, a.prodidesc";
                    DataTable dtData1 = oConn.GetData(strSQL);
                    cboProdi.Properties.DataSource = dtData1;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    setLoadDialog(false, "");
                    bolLoading = false;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            using (clsConnection oConn = new clsConnection())
            {
                try
                {
                    if (Convert.ToString(txtRFID.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan isi [RFID/Tag]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtRFID.Focus();
                        return;
                    }
                    else if (Convert.ToString(txtNIK.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan isi [NIK]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtNIK.Focus();
                        return;
                    }
                    else if (Convert.ToString(txtNama.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan isi [Nama]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtNama.Focus();
                        return;
                    }
                    else if (Convert.ToString(rgJenisKelamin.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan isi [Jenis Kelamin]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        rgJenisKelamin.Focus();
                        return;
                    }
                    else if (Convert.ToString(rgStatus.EditValue) == "")
                    {
                        XtraMessageBox.Show("Silahkan isi [Status]!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        rgStatus.Focus();
                        return;
                    }

                    setLoadDialog(true, "Saving data...");

                    tbm_anggota oMaster = new tbm_anggota();
                    clsEncryption oEncryption = new clsEncryption();
                    if (oConn.Conn.State == ConnectionState.Closed) oConn.Open();
                    oMaster.Koneksi = oConn.Conn;
                    oMaster.anggotaid = Convert.ToString(strID);
                    if (!string.IsNullOrEmpty(oMaster.anggotaid))
                    {
                        oMaster.GetByPrimaryKey(oMaster.anggotaid);
                    }
                    oMaster.rfid = Convert.ToString(txtRFID.EditValue);
                    oMaster.prodiid = Convert.ToString(cboProdi.EditValue);
                    oMaster.nim = Convert.ToString(txtNIK.EditValue);
                    oMaster.nama = Convert.ToString(txtNama.EditValue);
                    oMaster.jeniskelamin = Convert.ToString(rgJenisKelamin.EditValue);
                    oMaster.nohp = Convert.ToString(txtNoHP.EditValue);
                    oMaster.statusaktif = Convert.ToString(rgStatus.EditValue);
                    oMaster.alamat = Convert.ToString(txtAlamat.EditValue);
                    oMaster.keterangan = Convert.ToString(txtKeterangan.EditValue);
                    oMaster.jenis = strJenis;
                    oMaster.username = oEncryption.Encrypt(txtusername.Text.ToUpper());
                    oMaster.passwd = oEncryption.Encrypt(txtpasswd.Text);

                    if (strRenamePhoto != "")
                    {
                        clsGlobal.Upload(clsGlobal.strFTP_host, clsGlobal.strFTP_user, clsGlobal.strFTP_passwd, clsGlobal.strftpcoverpath, strFileName, strRenamePhoto);
                        oMaster.photo = strRenamePhoto;
                    }
                    bool isInsert=false;
                    if (Convert.ToString(oMaster.anggotaid) == "" || oMaster.anggotaid == null)
                    {
                        isInsert=true;
                        oMaster.opadd = clsGlobal.strUserName;
                        oMaster.pcadd = SystemInformation.ComputerName;
                        strID = oMaster.NewID();
                        oMaster.anggotaid = strID;
                        oMaster.Insert();
                    }
                    else
                    {
                        oMaster.opedit = clsGlobal.strUserName;
                        oMaster.pcedit = SystemInformation.ComputerName;
                        oMaster.Update();
                    }
                    setLoadDialog(false, "");

                    if(!isInsert)
                    {
                        setLoadDialog(false, "");
                        this.DialogResult = System.Windows.Forms.DialogResult.OK;
                        return;
                    }
                    if (XtraMessageBox.Show(this, "Anda ingin melakukan sinkronisasi data anggota ini ke Tripod Gate?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        this.DialogResult = System.Windows.Forms.DialogResult.OK;
                        return;
                    }
                    if (txtRFID.Text.Trim() == "" || txtRFID.Text.Trim() == "-" || txtRFID.Text.Trim() == "0" || txtRFID.Text.Trim() == "o" || txtRFID.Text.Trim().Length < 8)
                    {
                        XtraMessageBox.Show(this, "Data RFID anda tidak valid!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.DialogResult = System.Windows.Forms.DialogResult.OK;
                        return;
                    }

                    #region Sync ke Gate
                    try
                    {
                        int ret = 0;        // Error ID number
                        int BUFFERSIZE = 1 * 1024 * 1024;
                        byte[] buffer = new byte[BUFFERSIZE];

                        setLoadDialog(true, "Sync Data, Please wait..");
                        btnSync.Enabled = false;
                        if (IntPtr.Zero == h)
                        {
                            h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                            if (h != IntPtr.Zero)
                            {
                                //Insert New
                                int userCount = clsC3100.GetDeviceDataCount(h, "user", "", "");
                                int iPin = userCount++;
                                string strLeft24 = txtRFID.Text;
                                strLeft24 = strLeft24.Substring(0, 8);
                                string strCardNo = clsC3100.GethexACStoDecWiegand(strLeft24);

                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                clsC3100.SetDeviceData(h, "user", "Pin=" + iPin + "\tCardNo=" + strCardNo + "\tPassword=0", "");

                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                clsC3100.SetDeviceData(h, "userauthorize", "Pin=" + iPin + "\tAuthorizeTimezoneId=1\tAuthorizeDoorId=1", "");

                                setLoadDialog(false, "");
                                XtraMessageBox.Show(this, "Sinkronisasi data anggota ke gate sukses!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }

                            clsC3100.Disconnect(h);
                            h = IntPtr.Zero;
                        }
                    }
                    catch (Exception)
                    {

                    }
                    #endregion

                    setLoadDialog(false, "");
                    this.DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    btnSave.Enabled = true;
                    setLoadDialog(false, "");
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        public void btnPreview_Click(object sender, EventArgs e)
        {
            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptDosenWali.repx";
                reportName = "rptDosenWali";


                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();

                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                frmMainReport mainReport = new frmMainReport();
                try
                {
                    DataTable dtMaster = new DataTable();
                    if (dtMaster != null)
                    {
                        //dtReport.TableName = "dtReportSource";
                        mainReport.reportName = reportName;
                        mainReport.printReport(filename, dtMaster);
                    }
                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                        btnPreview.Enabled = true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
        }

        private void frmAnggota_Load(object sender, EventArgs e)
        {
            loadDataProdi();
            if (strID != "")
            {
                using (clsConnection oConn = new clsConnection())
                {
                    tbm_anggota oObject = new tbm_anggota();
                    clsEncryption oEncryption = new clsEncryption();
                    oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(strID);
                    txtRFID.EditValue = oObject.rfid;
                    txtNIK.EditValue = oObject.nim;
                    txtNama.EditValue = oObject.nama;
                    cboProdi.EditValue = oObject.prodiid;
                    rgJenisKelamin.EditValue = oObject.jeniskelamin;
                    txtNoHP.EditValue = oObject.nohp;
                    rgStatus.EditValue = oObject.statusaktif;
                    txtAlamat.EditValue = oObject.alamat;
                    txtKeterangan.EditValue = oObject.keterangan;
                    txtusername.Text = oEncryption.Decrypt(oObject.username);
                    txtpasswd.Text = oEncryption.Decrypt(oObject.passwd);
                    if (oObject.photo != "" && oObject.photo != null)
                    {
                        pictureBox2.ImageLocation = clsGlobal.strHttp + "/" + clsGlobal.strHttp_photopath + "/" + oObject.photo;
                    }
                    oObject = null;
                }
            }
            else
            {
                btnSync.Enabled = false;                
            }
            txtRFID.Focus();
            btnSave.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
        }

        private void frmAnggota_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        public string strRenamePhoto = "";
        public string strFileName = "";

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Browse Photo...";
            fdlg.Filter = "JPEG (*.jpg)|*.jpg|PNG (*.png)|*.png|GIF (*.gif)|*.gif";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                string strYM = clsGlobal.getData1Field("select to_char(now(),'yyyymmddHH24MISS');");
                string path = Application.StartupPath + "\\photos\\";
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                string strTempPath = path + strYM + Path.GetExtension(fdlg.FileName);
                Image img1 = ScaleImage(Image.FromFile(fdlg.FileName), 114, 152); //3cm x 4cm
                img1.Save(strTempPath);
                pictureBox2.Image = img1;

                strRenamePhoto = strYM + Path.GetExtension(fdlg.FileName);
                strFileName = strTempPath;
            }
        }

        private Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(newWidth, newHeight);
            Graphics.FromImage(newImage).DrawImage(image, 0, 0, newWidth, newHeight);
            return newImage;
        }

        private void btnProdi_Click(object sender, EventArgs e)
        {
            XtraForm oForm = new XtraForm();
            ucProdi UCPopUp = new ucProdi();
            oForm.Controls.Add(UCPopUp);
            UCPopUp.Dock = DockStyle.Fill;
            oForm.Width = 650;
            oForm.Height = 680;
            oForm.FormBorderStyle = FormBorderStyle.FixedSingle;
            oForm.MaximizeBox = false;
            oForm.StartPosition = FormStartPosition.CenterParent;
            UCPopUp.btnClose.Visible = false;
            oForm.Text = "Data Jurusan dan Program Studi";
            oForm.Icon = this.Icon;
            oForm.ShowDialog();
            oForm.Close();
            oForm = null;
            UCPopUp = null;
            loadDataProdi();
        }

        private void chkShowPwd_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPwd.Checked == true)
            {
                txtpasswd.Properties.PasswordChar = '\0';
                txtpasswd.Properties.UseSystemPasswordChar = false;
                //txtConfirmPassword.Properties.PasswordChar = '\0';
                //txtConfirmPassword.Properties.UseSystemPasswordChar = false;
            }
            else
            {
                txtpasswd.Properties.UseSystemPasswordChar = true;
                txtpasswd.Properties.PasswordChar = char.Parse("*");
                //txtConfirmPassword.Properties.PasswordChar = char.Parse("*");
                //txtConfirmPassword.Properties.UseSystemPasswordChar = true;
            }

        }

        IntPtr h = IntPtr.Zero;
        private void btnSync_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show(this, "Anda yakin untuk melakukan sinkronisasi data anggota ini ke Tripod Gate?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }
            if (txtRFID.Text.Trim() == "" || txtRFID.Text.Trim() == "-" || txtRFID.Text.Trim() == "0" || txtRFID.Text.Trim() == "o" || txtRFID.Text.Trim().Length < 8)
            {
                XtraMessageBox.Show(this, "Data RFID anda tidak valid!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                int ret = 0;        // Error ID number
                int BUFFERSIZE = 1 * 1024 * 1024;
                byte[] buffer = new byte[BUFFERSIZE];

                setLoadDialog(true, "Sync Data, Please wait..");
                btnSync.Enabled = false;
                if (IntPtr.Zero == h)
                {
                    h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                    if (h != IntPtr.Zero)
                    {
                        using (clsConnection oConn = new clsConnection())
                        {
                            tbm_anggota oObject = new tbm_anggota();
                            oConn.Open();
                            oObject.Koneksi = oConn.Conn;
                            oObject.GetByPrimaryKey(strID);
                            if (oObject.rfid.Trim() == "" && oObject.rfid.Trim() == "0" || oObject.rfid.Trim() == "o" || oObject.rfid.Trim() == "-" || oObject.rfid.Trim().Length < 8)
                            {
                                //Insert New
                                int userCount = clsC3100.GetDeviceDataCount(h, "user", "", "");
                                int iPin = userCount++;
                                string strLeft24 = txtRFID.Text;
                                strLeft24 = strLeft24.Substring(0, 8);
                                string strCardNo = clsC3100.GethexACStoDecWiegand(strLeft24);

                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                clsC3100.SetDeviceData(h, "user", "Pin=" + iPin + "\tCardNo=" + strCardNo + "\tPassword=0", "");

                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                clsC3100.SetDeviceData(h, "userauthorize", "Pin=" + iPin + "\tAuthorizeTimezoneId=1\tAuthorizeDoorId=1", "");

                                setLoadDialog(false, "");
                                XtraMessageBox.Show(this, "Sinkronisasi data anggota ke gate sukses!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                //Update
                                string strLeft24 = oObject.rfid;
                                strLeft24 = strLeft24.Substring(0, 8);
                                string strCardNo = clsC3100.GethexACStoDecWiegand(strLeft24);
                                ret = clsC3100.GetDeviceData(h, ref buffer[0], BUFFERSIZE, "user", "*", "CardNo=" + strCardNo, "");
                                if (ret > 0)
                                {
                                    string strData = Encoding.Default.GetString(buffer);
                                    DataTable dtDataGate = clsC3100.strGateUsertoDatatable(strData);
                                    if (dtDataGate.Rows.Count > 0)
                                    {
                                        clsC3100.Disconnect(h);
                                        h = IntPtr.Zero;
                                        h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                        clsC3100.DeleteDeviceData(h, "user", "Pin=" + dtDataGate.Rows[0]["pin"], "");

                                        clsC3100.Disconnect(h);
                                        h = IntPtr.Zero;
                                        h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                        clsC3100.DeleteDeviceData(h, "userauthorize", "Pin=" + dtDataGate.Rows[0]["pin"], "");


                                        strLeft24 = txtRFID.Text;
                                        strLeft24 = strLeft24.Substring(0, 8);
                                        strCardNo = clsC3100.GethexACStoDecWiegand(strLeft24);

                                        clsC3100.Disconnect(h);
                                        h = IntPtr.Zero;
                                        h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                        clsC3100.SetDeviceData(h, "user", "Pin=" + dtDataGate.Rows[0]["pin"] + "\tCardNo=" + strCardNo + "\tPassword=0", "");

                                        clsC3100.Disconnect(h);
                                        h = IntPtr.Zero;
                                        h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                        clsC3100.SetDeviceData(h, "userauthorize", "Pin=" + dtDataGate.Rows[0]["pin"] + "\tAuthorizeTimezoneId=1\tAuthorizeDoorId=1", "");

                                        setLoadDialog(false, "");
                                        XtraMessageBox.Show(this, "Sinkronisasi data anggota ke gate sukses!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    }
                                }
                                else
                                {
                                    //Insert New
                                    clsC3100.Disconnect(h);
                                    h = IntPtr.Zero;
                                    h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                    int userCount = clsC3100.GetDeviceDataCount(h, "user", "", "");

                                    int iPin = userCount++;
                                    strLeft24 = txtRFID.Text;
                                    strLeft24 = strLeft24.Substring(0, 8);
                                    strCardNo = clsC3100.GethexACStoDecWiegand(strLeft24);

                                    clsC3100.Disconnect(h);
                                    h = IntPtr.Zero;
                                    h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                    clsC3100.SetDeviceData(h, "user", "Pin=" + iPin + "\tCardNo=" + strCardNo + "\tPassword=0", "");

                                    clsC3100.Disconnect(h);
                                    h = IntPtr.Zero;
                                    h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                                    clsC3100.SetDeviceData(h, "userauthorize", "Pin=" + iPin + "\tAuthorizeTimezoneId=1\tAuthorizeDoorId=1", "");

                                    setLoadDialog(false, "");
                                    XtraMessageBox.Show(this, "Sinkronisasi data anggota ke gate sukses!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }
                            oObject = null;
                            oConn.Close();
                        }
                        clsC3100.Disconnect(h);
                        h = IntPtr.Zero;
                    }
                }
            }
            catch (Exception)
            {
            }
            btnSync.Enabled = true;
        }

    }
}