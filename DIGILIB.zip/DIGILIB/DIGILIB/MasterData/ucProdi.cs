﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Base;
using Npgsql;

namespace DIGILIB.MasterData
{
    public partial class ucProdi : DevExpress.XtraEditors.XtraUserControl
    {
        public ucProdi()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        public frmMain formMain;
        WaitDialogForm loadDialog;

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null || loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public void loadData()
        {
            setLoadDialog(true, "Loading data...");
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                string strSQL = @"select b.jurusanid, b.jurusancode, b.jurusandesc, a.prodiid, a.prodicode, a.inisial, a.prodidesc
                            from tbm_prodi a
                            inner join tbm_jurusan b on a.jurusanid=b.jurusanid and b.dlt='0'
                            where a.dlt='0'
                            order by b.jurusandesc, a.prodicode, a.prodidesc;";
                NpgsqlCommand cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataSet ds = new DataSet();
                DataTable dt = ds.Tables.Add("tbldetail");
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tbldetail");

                strSQL = @"select jurusanid, jurusancode, jurusandesc from tbm_jurusan where dlt='0' order by jurusancode, jurusandesc;";
                cmd = new NpgsqlCommand(strSQL, oConn.Conn);
                DataTable dt1 = ds.Tables.Add("tblmaster");
                da = new NpgsqlDataAdapter(cmd);
                da.Fill(ds, "tblmaster");
                ds.Relations.Add(new DataRelation("detailData", dt1.Columns["jurusanid"], dt.Columns["jurusanid"]));
                dgData.DataSource = dt1;

                dgData.LevelTree.Nodes.Add("detailData", gridViewDetail);
                for (int i = 0; i < gridViewData.RowCount; i++)
                {
                    gridViewData.SetMasterRowExpandedEx(i, 0, true);
                }
                oConn.Close(); 
                gridViewData.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
                gridViewData.OptionsBehavior.Editable = false;
                gridViewDetail.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
                gridViewDetail.OptionsBehavior.Editable = false;
                btnEdit.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
                btnDel.Enabled = clsGlobal.bolDelete;
                btnEndEdit.Enabled = false;
                setLoadDialog(false, "");
                if (dt.Rows.Count == 0)
                {
                    btnDel.Enabled = false;
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            gridViewData.OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            gridViewData.OptionsBehavior.Editable = true;
            gridViewDetail.OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            gridViewDetail.OptionsBehavior.Editable = true;
            btnEndEdit.Enabled = true;
            btnEdit.Enabled = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void ucProdi_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        private void btnEndEdit_Click(object sender, EventArgs e)
        {
            gridViewData.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
            gridViewData.OptionsBehavior.Editable = false;
            gridViewDetail.OptionsView.NewItemRowPosition = NewItemRowPosition.None;
            gridViewDetail.OptionsBehavior.Editable = false;
            btnEndEdit.Enabled = false;
            btnEdit.Enabled = clsGlobal.bolAdd || clsGlobal.bolEdit;
        }

        private void ucProdi_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dgData.FocusedView.Name == gridViewData.Name)
            {
                if (Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusanid)) != "")
                {
                    if (XtraMessageBox.Show("Anda yakin menghapus data jurusan ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (clsConnection oConn = new clsConnection())
                        {
                            tbm_jurusan oObject = new tbm_jurusan();
                            oConn.Open();
                            oObject.Koneksi = oConn.Conn;
                            oObject.jurusanid = Convert.ToString(Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusanid)));
                            oObject.opedit = clsGlobal.strUserName;
                            oObject.pcedit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                            oConn.Close();
                            oObject = null;
                            gridViewData.DeleteSelectedRows();
                        }
                    }
                }
            }
            else if (dgData.FocusedView.Name == gridViewDetail.Name)
            {
                GridView gridDetail = gridViewData.GetDetailView(gridViewData.FocusedRowHandle, 0) as GridView;
                if (gridDetail == null)
                {
                    return;
                }
                if (Convert.ToString(gridDetail.GetFocusedRowCellValue(prodiid)) != "")
                {
                    if (XtraMessageBox.Show("Anda yakin menghapus data prodi ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        using (clsConnection oConn = new clsConnection())
                        {
                            tbm_prodi oObject = new tbm_prodi();
                            oConn.Open();
                            oObject.Koneksi = oConn.Conn;
                            oObject.prodiid = Convert.ToString(Convert.ToString(gridDetail.GetFocusedRowCellValue(prodiid)));
                            oObject.opedit = clsGlobal.strUserName;
                            oObject.pcedit = SystemInformation.ComputerName;
                            oObject.SoftDelete();
                            oConn.Close();
                            oObject = null;
                            gridDetail.DeleteSelectedRows();
                        }
                    }
                }
            }
        }

        private void gridViewData_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            string strID = Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusanid));
            string strCount = clsGlobal.getData1Field("select count(*) from tbm_jurusan where dlt='0' and trim(lower(jurusancode))=trim(lower('" + Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusancode)) + "')) and jurusanid<>'" + strID + "'");
            if (Convert.ToInt32(strCount) == 0)
            {
                tbm_jurusan oObject = new tbm_jurusan();
                using (clsConnection oConn = new clsConnection())
                {
                    ;
                    oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.GetByPrimaryKey(strID);
                    oObject.jurusancode = Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusancode));
                    oObject.jurusandesc = Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusandesc));
                    if (strID == "")
                    {
                        oObject.opadd = clsGlobal.strUserName;
                        oObject.pcadd = SystemInformation.ComputerName;
                        oObject.jurusanid = oObject.NewID();
                        oObject.Insert();
                        gridViewData.SetFocusedRowCellValue(jurusanid, oObject.jurusanid);
                    }
                    else
                    {
                        oObject.opedit = clsGlobal.strUserName;
                        oObject.pcedit = SystemInformation.ComputerName;
                        oObject.Update();
                    }
                    oObject = null;
                }
                e.Valid = true;
            }
            else
            {
                e.ErrorText = "Data Jurusan ini sudah pernah ada di database!";
                e.Valid = false;
                return;
            }
        }

        private void dgData_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        {
            if (e.View != null && e.View.ParentView != null)
            {
                DevExpress.XtraGrid.Views.Base.ColumnView view = e.View.ParentView as DevExpress.XtraGrid.Views.Base.ColumnView;
                view.FocusedRowHandle = e.View.SourceRowHandle;
            }
        }

        private void gridViewDetail_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            ColumnView view = sender as ColumnView;
            if (view == null)
            {
                return;
            }
            string strID = Convert.ToString(view.GetFocusedRowCellValue(prodiid));
            string strCount = clsGlobal.getData1Field("select count(*) from tbm_prodi where dlt='0' and trim(lower(prodicode))=trim(lower('" + Convert.ToString(view.GetFocusedRowCellValue(prodicode)) + "')) and prodiid<>'" + strID + "'");
            if (Convert.ToInt32(strCount) == 0)
            {
                using (clsConnection oConn = new clsConnection())
                {
                    tbm_prodi oObject = new tbm_prodi();
                    oConn.Open();
                    oObject.Koneksi = oConn.Conn;
                    oObject.prodiid = Convert.ToString(view.GetFocusedRowCellValue(prodiid));
                    oObject.GetByPrimaryKey(oObject.prodiid);

                    oObject.prodicode = Convert.ToString(view.GetFocusedRowCellValue(prodicode));
                    oObject.inisial = Convert.ToString(view.GetFocusedRowCellValue(inisial));
                    oObject.prodidesc = Convert.ToString(view.GetFocusedRowCellValue(prodidesc));
                    oObject.jurusanid = Convert.ToString(gridViewData.GetFocusedRowCellValue(jurusanid));
                    if (oObject.prodiid == "" || oObject.prodiid == null)
                    {
                        oObject.opadd = clsGlobal.strUserName;
                        oObject.pcadd = SystemInformation.ComputerName;
                        oObject.prodiid = oObject.NewID();
                        if (oObject.Insert() == false)
                        {
                            e.ErrorText = "Data Tidak Dapat Disimpan...";
                            e.Valid = false;
                        }
                        view.SetFocusedRowCellValue(prodiid, oObject.prodiid);
                        view.SetFocusedRowCellValue(jurusanid2, oObject.jurusanid);
                    }
                    else
                    {
                        oObject.opedit = clsGlobal.strUserName;
                        oObject.pcedit = SystemInformation.ComputerName;
                        if (oObject.Update() == false)
                        {
                            e.ErrorText = "Data Tidak Dapat Disimpan...";
                            e.Valid = false;
                        }
                    }
                }
            }
            else
            {
                e.ErrorText = "Data Prodi ini sudah pernah ada di database!";
                e.Valid = false;
                return;
            }
            return;
        }
    }
}
