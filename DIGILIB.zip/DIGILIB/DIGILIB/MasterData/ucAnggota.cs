﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Library;
using DevExpress.XtraGrid.Views.Grid;
using Npgsql;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Linq;

namespace DIGILIB.MasterData
{
    public partial class ucAnggota : DevExpress.XtraEditors.XtraUserControl
    {
        public ucAnggota()
        {
            loadDialog = new WaitDialogForm("Loading Components...");
            Application.DoEvents();
            InitializeComponent();
            loadDialog.Visible = false;
        }

        public frmMain formMain;
        WaitDialogForm loadDialog;

        private void setLoadDialog(bool isVisible, string caption)
        {
            if (loadDialog == null || loadDialog.IsDisposed == true)
            {
                loadDialog = new WaitDialogForm("");
            }
            loadDialog.Visible = isVisible;
            if (isVisible)
            {
                loadDialog.Caption = caption;
                Application.DoEvents();
            }
        }

        public string strID = "";

        public void loadData()
        {
            setLoadDialog(true, "Loading data...");
            using (clsConnection oConn = new clsConnection())
            {
                oConn.Open();
                string strSql = @"select 'PERPUSTAKAAN POLITEKNIK NEGERI BATAM' as header, 'Daftar Anggota Perpustakaan (" + rgJenis.Text + @")' as header2,
                            a.anggotaid, a.rfid, a.nim, a.nama, b.prodiid, b.prodicode, b.prodidesc, b.jurusandesc,
                            a.jeniskelamin, a.alamat, a.nohp, a.keterangan, a.statusaktif
                            from tbm_anggota a
                            left outer join
                            (
	                            select aa.prodiid, aa.prodicode, aa.prodidesc, bb.jurusanid, bb.jurusancode, bb.jurusandesc
	                            from tbm_prodi aa
	                            inner join tbm_jurusan bb on aa.jurusanid=bb.jurusanid and bb.dlt='0'
	                            where aa.dlt='0'
                            ) b on a.prodiid=b.prodiid
                            where a.dlt='0' and a.jenis='" + Convert.ToString(rgJenis.EditValue) + @"'
                            order by a.nim, a.nama";

                DataTable dt = oConn.GetData(strSql);
                dgData.DataSource = dt;
                xdt = dt.Copy();
                btnAdd.Enabled = clsGlobal.bolAdd;
                btnEdit.Enabled = clsGlobal.bolEdit;
                btnDelete.Enabled = clsGlobal.bolDelete;
                setLoadDialog(false, "");
                if (dt.Rows.Count == 0)
                {
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                }
                else
                {
                    btnEdit.Enabled = clsGlobal.bolEdit;
                    btnDelete.Enabled = clsGlobal.bolDelete;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void ucProdi_Leave(object sender, EventArgs e)
        {
            if (loadDialog != null)
            {
                loadDialog.Close();
                loadDialog.Dispose();
                loadDialog = null;
            }
        }

        private void ucProdi_Load(object sender, EventArgs e)
        {
            //loadData();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            //if (Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid)) != "")
            //{
            //    if (XtraMessageBox.Show("Anda yakin menghapus data ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            //    {
            //        clsConnection oConn = new clsConnection();
            //        tbp_pegawai_jenjang oObject = new tbp_pegawai_jenjang();
            //        oConn.Open();
            //        oObject.Koneksi = oConn.Conn;
            //        oObject.pegawai_jenjangid = Convert.ToString(Convert.ToString(gridViewData.GetFocusedRowCellValue(pengadaanid)));
            //        oObject.op_edit = clsGlobal.strUserName;
            //        oObject.pc_edit = SystemInformation.ComputerName;
            //        oObject.SoftDelete();
            //        oConn.Close();
            //        oObject = null; oConn = null;
            //        gridViewData.DeleteSelectedRows();
            //    }
            //}
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmAnggota frm = new frmAnggota();
            try
            {
                frm.strJenis = Convert.ToString(rgJenis.EditValue);
                frm.Icon = formMain.Icon;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    loadData();
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }

            frm.Close();
            frm.Dispose();
            frm = null;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmAnggota frm = new frmAnggota();
            try
            {
                frm.strID = Convert.ToString(gridViewData.GetFocusedRowCellValue(anggotaid2));
                frm.strJenis = Convert.ToString(rgJenis.EditValue);
                frm.Icon = formMain.Icon;
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    loadData();
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }

            frm.Close();
            frm.Dispose();
            frm = null;
        }

        private void gridViewData_DoubleClick(object sender, EventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(anggotaid2)) != "")
            {
                btnEdit_Click(sender, e);
            }
        }

        private void gridViewData_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(anggotaid2)) != "")
            {
                btnEdit.Enabled = clsGlobal.bolEdit;
                btnDelete.Enabled = clsGlobal.bolDelete;
            }
            else
            {
                btnEdit.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            formMain.closeUC();
        }

        private void rgJenis_EditValueChanged(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(gridViewData.GetFocusedRowCellValue(anggotaid2)) != "")
            {
                if (XtraMessageBox.Show(this, "Anda yakin menghapus data anggota ini?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    using (clsConnection oConn = new clsConnection())
                    {
                        tbm_anggota oObject = new tbm_anggota();
                        oConn.Open();
                        oObject.Koneksi = oConn.Conn;
                        oObject.anggotaid = Convert.ToString(Convert.ToString(gridViewData.GetFocusedRowCellValue(anggotaid2)));
                        oObject.opedit = clsGlobal.strUserName;
                        oObject.pcedit = SystemInformation.ComputerName;
                        oObject.SoftDelete();
                        oObject = null;
                        gridViewData.DeleteSelectedRows();
                    }
                }
            }
        }

        DataTable xdt;
        private void btnPreview_Click(object sender, EventArgs e)
        {
            btnPreview.Enabled = false;
            try
            {
                btnPreview.Enabled = false;
                string filename = "";
                string reportName = "";

                filename = Application.StartupPath + @"\reports\rptJumlahAnggotaMahasiswa.repx";
                reportName = "rptJumlahAnggotaMahasiswa";

                frmReportSelection fReportSelection = new frmReportSelection();
                if (fReportSelection.loadDataXml(filename))
                {
                    fReportSelection.ShowDialog();
                    if (fReportSelection.DialogResult == DialogResult.OK)
                    {
                        filename = fReportSelection.filename;
                    }
                }

                DIGILIB.MainReport.frmMainReport mainReport = new DIGILIB.MainReport.frmMainReport();
                try
                {
                    DataTable dtReport = null;

                    int rowHandle;
                    DataRow gridRow;
                    xdt.Rows.Clear();
                    for (int i = 0; i < gridViewData.RowCount; i++)
                    {
                        rowHandle = gridViewData.GetVisibleRowHandle(i);
                        if (!gridViewData.IsGroupRow(rowHandle))
                        {
                            gridRow = gridViewData.GetDataRow(rowHandle);
                            if (gridRow != null)
                                xdt.Rows.Add(gridRow.ItemArray);
                        }
                    }

                    dtReport = xdt.Copy();
                    dtReport.TableName = "tblReport";
                    mainReport.reportName = reportName;
                    mainReport.printReport(filename, dtReport);

                }
                catch (NpgsqlException ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                catch (Exception ex)
                {
                    clsGlobal.generateErrMessageAndSendmail(ex, false);
                }
                finally
                {
                    if (mainReport != null)
                    {
                        mainReport.loadDialog.Close();
                        mainReport.loadDialog.Dispose();
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            catch (Exception ex)
            {
                clsGlobal.generateErrMessageAndSendmail(ex, false);
            }
            btnPreview.Enabled = true;
        }

        IntPtr h = IntPtr.Zero;
        private void btnSync_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show(this, "Anda yakin untuk melakukan sinkronisasi data anggota ke Tripod Gate?", clsGlobal.str_ApplicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }
            try
            {
                int ret = 0;        // Error ID number
                int BUFFERSIZE = 1 * 1024 * 1024;
                byte[] buffer = new byte[BUFFERSIZE];

                setLoadDialog(true, "Sync Data, Please wait..");
                btnSync.Enabled = false;

                if (IntPtr.Zero == h)
                {
                    h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                    if (h != IntPtr.Zero)
                    {

                        DataTable dtDataAnggota = new DataTable();
                        using (clsConnection oConn = new clsConnection())
                        {
                            dtDataAnggota = oConn.GetData("select anggotaid, rfid from tbm_anggota where dlt='0' and trim(rfid) not in ('','0','-',' ','o');");
                            oConn.Close();
                        }
                        if (dtDataAnggota.Rows.Count > 0)
                        {
                            //Delete semua data user di gate
                            clsC3100.DeleteDeviceData(h, "user", "*", "");

                            clsC3100.Disconnect(h);
                            h = IntPtr.Zero;
                            h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                            clsC3100.DeleteDeviceData(h, "userauthorize", "*", "");

                            //Copy semua data user ke gate
                            int iPin = 1;
                            string strDataAllCard = "";
                            string strDataAuthorizeAllCard = "";
                            foreach (DataRow dr in dtDataAnggota.Rows)
                            {
                                try
                                {
                                    if (dr["anggotaid"] + "" == "DL012328")
                                    { }
                                    setLoadDialog(true, "Copy data anggota ke " + iPin + " dari " + dtDataAnggota.Rows.Count);
                                    string strLeft24 = dr["rfid"] + "";
                                    strLeft24 = strLeft24.Substring(0, 8);
                                    string strCardNo = clsC3100.GethexACStoDecWiegand(strLeft24);
                                    strDataAllCard += (strDataAllCard == "" ? "Pin=" + iPin + "\tCardNo=" + strCardNo + "\tPassword=0" : "\r\nPin=" + iPin + "\tCardNo=" + strCardNo + "\tPassword=0");
                                    strDataAuthorizeAllCard += (strDataAuthorizeAllCard == "" ? "Pin=" + iPin + "\tAuthorizeTimezoneId=1\tAuthorizeDoorId=1" : "\r\nPin=" + iPin + "\tAuthorizeTimezoneId=1\tAuthorizeDoorId=1");
                                    iPin++;
                                }
                                catch (Exception)
                                {
                                }
                            }
                            if (strDataAllCard != "")
                            {
                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);

                                setLoadDialog(true, "Sync Data. Please wait..");
                                clsC3100.SetDeviceData(h, "user", strDataAllCard, "");

                                clsC3100.Disconnect(h);
                                h = IntPtr.Zero;
                                h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);

                                clsC3100.SetDeviceData(h, "userauthorize", strDataAuthorizeAllCard, "");

                            }
                            setLoadDialog(false, "");
                            XtraMessageBox.Show(this, "Sinkronisasi data anggota ke gate sukses!", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            setLoadDialog(false, "");
                            clsC3100.Disconnect(h);
                            h = IntPtr.Zero;
                            XtraMessageBox.Show(this, "Tidak ada data anggota..", clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        #region Get Data
                        //clsC3100.Disconnect(h);
                        //h = IntPtr.Zero;
                        //h = clsC3100.Connect(clsGlobal.strConnectionGateC3100);
                        //ret = clsC3100.GetDeviceData(h, ref buffer[0], BUFFERSIZE, "user", "*", "", "");
                        //if (ret >= 0)
                        //{
                        //    string strData = Encoding.Default.GetString(buffer);
                        //    DataTable dtDataGate = clsC3100.strGateUsertoDatatable(strData);

                        //    DataView dvView = new DataView(dtDataGate.Copy());
                        //    dvView.RowFilter = "cardno='3300356'";

                        //    string strgsfdsf = clsC3100.GethexACStoDecWiegand("045C322A");
                        #region Set Data
                        //clsC3100.SetDeviceData(h, "user", "Pin=4\tCardNo=13375401", "");
                        //ret = clsC3100.GetDeviceData(h, ref buffer[0], BUFFERSIZE, "user", "*", "", "");
                        //if (ret >= 0)
                        //{
                        //    MessageBox.Show(this, Encoding.Default.GetString(buffer));
                        //}
                        #endregion

                        #region Delete Data
                        //clsC3100.DeleteDeviceData(h, "user", "Pin=4", "");
                        //ret = clsC3100.GetDeviceData(h, ref buffer[0], BUFFERSIZE, "user", "*", "", "");
                        //if (ret >= 0)
                        //{
                        //    MessageBox.Show(this, Encoding.Default.GetString(buffer));
                        //}
                        #endregion
                        //}
                        #endregion

                        clsC3100.Disconnect(h);
                        h = IntPtr.Zero;
                    }
                    else
                    {
                        setLoadDialog(false, "");
                        ret = clsC3100.PullLastError();
                        XtraMessageBox.Show(this, "Connect device Failed! The error id is: " + ret, clsGlobal.str_ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
            catch (Exception)
            {

            }
            setLoadDialog(false, "");
            btnSync.Enabled = true;
        }

        private void btnGetTrx_Click(object sender, EventArgs e)
        {
            
        }

    }
}
