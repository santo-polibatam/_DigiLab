﻿Option Explicit On
Option Strict On

Public Class frmUpdateApp
    Private oUpdateWorker As New clsUpdateWorker(Me)
    Private sMessage As String
    Private bIsUpdateMode As Boolean = False
    Private sOutput As String
    Private sExeName As String
    Private bIsAuto As Boolean = True
    Private isSuperadmin As Boolean = False

    Private Sub doCheckUpdate()
        Try
            btnUpdate.Enabled = False
            If clsUpdateWorker.iThreadStatus = 0 Then 'no more thread
                lblInfo.Visible = True
                lblInfo.Text = "Checking for the latest update application, please wait...."
                lblInit.Visible = True
                lblInit.Text = "Initializing..."
                clsUpdateWorker.iThreadStatus = 1
                oUpdateWorker.isSuperadmin = isSuperadmin
                oUpdateWorker.RetrieveConfiguration()

                If oUpdateWorker.IsConnect(oUpdateWorker.RemoteURI) Then
                    'oUpdateWorker.RemoteURI = oUpdateWorker.RemoteURI
                    'oUpdateWorker.ManifestFile = "ServerManifest.xml"
                    oUpdateWorker.ApplicationInstance = sExeName
                    oUpdateWorker.AppStartupPath = System.AppDomain.CurrentDomain.BaseDirectory()

                    If oUpdateWorker.IsNeedUpdate() Then

                        bIsUpdateMode = True
                        oUpdateWorker.KillAppInstance()

                        'Start Update
                        lblInit.Text = "Downloading...."
                        sOutput = oUpdateWorker.ProcessUpdate()

                        lblInfo.Visible = False
                        lblInit.Text = "Update successfully..."

                        sMessage = "============================================================================================" & vbCrLf & _
                        "Below file(s) had been updated successfully on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & vbCrLf _
                        & sOutput & vbCrLf & _
                        "============================================================================================"
                        setMessage(sMessage)
                    Else
                        sMessage = "Application latest update was not found, checking done on " & Now.ToShortDateString & " - " & Now.ToLongTimeString
                        setMessage(sMessage)
                    End If
                Else
                    sMessage = "============================================================================================" & vbCrLf & _
                                   "Warning!! - " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                                    "Unable connect to remote host, make sure the remote URI is specified correctly." & vbCrLf & _
                                    "============================================================================================"
                    setMessage(sMessage)
                End If
            End If

        Catch ex As Exception
            sMessage = ex.Message
            setMessage(sMessage)
        Finally
            If Not bIsAuto Then
                MessageBox.Show(sMessage, "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            If clsUpdateWorker.iThreadStatus = 0 Then
                If bIsUpdateMode Then
                    bIsUpdateMode = False
                End If
            End If
            btnUpdate.Enabled = True
            showMainApp()
            Application.Exit()
        End Try
    End Sub

    Private Sub setMessage(ByVal sMsg As String)
        Try
            clsUpdateWorker.iThreadStatus = 0
            'If Not bIsAuto Then
            oUpdateWorker.AppendTLog(sMsg)
            'End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub showMainApp()
        Try
            Dim startInfo As New ProcessStartInfo(Application.StartupPath & "\" & sExeName)
            Process.Start(startInfo)
            Environment.Exit(1)
        Catch ex As Exception
            sMessage = ("======================================================================================" & vbCrLf & _
                  "Error occured at '" & ex.Source & "' on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                 ex.Message.ToString & vbCrLf & "Please contact your system administrator if this problem occurs persistently." & vbCrLf & _
                 "Stack Trace: " & vbCrLf & ex.StackTrace & vbCrLf & "======================================================================================")

            setMessage(sMessage)
        End Try
        
    End Sub
    Private Sub frmUpdateApp_new_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'exs = "CPMS.exe|True|"& "GPS-TIME-MANAGEMENT"
            'exs = "VisualDisplay.exe|True|"& "GPS-TIME-MANAGEMENT"
            'exs = "SerialPortCommunication.exe|True|"& "GPS-TIME-MANAGEMENT"
            Dim envar As String = Environment.GetEnvironmentVariable("myEnv")

            If Not envar Is Nothing Then
                Dim arrString() As String = Split(envar, "|")
                sExeName = arrString(0).ToString
                bIsAuto = CBool(arrString(1))
                If arrString(3).ToString.ToLower() = "superadmin" Then
                    isSuperadmin = True
                Else
                    isSuperadmin = False
                End If

            Else
                sExeName = "DIGILIB.exe"
                bIsAuto = False
                isSuperadmin = False
            End If
            If Not Environment.GetEnvironmentVariable("myEnv") Is Nothing Then
                Environment.GetEnvironmentVariable("myEnv").Remove(0, 200)
            End If
            Timer1.Enabled = True
        Catch ex As Exception
            sMessage = ("======================================================================================" & vbCrLf & _
                  "Error occured at '" & ex.Source & "' on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                 ex.Message.ToString & vbCrLf & "Please contact your system administrator if this problem occurs persistently." & vbCrLf & _
                 "Stack Trace: " & vbCrLf & ex.StackTrace & vbCrLf & "======================================================================================")

            setMessage(sMessage)
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            doCheckUpdate()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        If MessageBox.Show("Are you sure want to abort the running operation?" & vbCrLf & vbCrLf & _
                               "Abort running operation will cause interruption during update application.", Me.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Yes Then
            showMainApp()
            Environment.Exit(1)
            Application.Exit()
        End If
        
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            Timer1.Enabled = False
            doCheckUpdate()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub frmUpdateApp_new_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Try
            If e.KeyCode = Keys.Escape Then
                Application.Exit()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class