Option Explicit On
Option Strict On

Public Class ProgressForm
    Private oUpdateWorker As New clsUpdateWorker(Me)
    Private sMessage As String
    Private bIsUpdateMode As Boolean = False
    Private sOutput As String

    Private Sub SimpleButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        doCheckUpdate()
    End Sub

    Private Sub doCheckUpdate()
        Try
            If clsUpdateWorker.iThreadStatus = 0 Then 'no more thread
                clsUpdateWorker.iThreadStatus = 1
                oUpdateWorker.RetrieveConfiguration()

                If oUpdateWorker.IsConnect(oUpdateWorker.RemoteURI) Then
                    'oUpdateWorker.RemoteURI = oUpdateWorker.RemoteURI
                    'oUpdateWorker.ManifestFile = "ServerManifest.xml"
                    'oUpdateWorker.ApplicationInstance = "MainApp.exe"
                    oUpdateWorker.AppStartupPath = System.AppDomain.CurrentDomain.BaseDirectory()

                    If oUpdateWorker.IsNeedUpdate() Then

                        bIsUpdateMode = True
                        oUpdateWorker.KillAppInstance()

                        'Start Update

                        sOutput = oUpdateWorker.ProcessUpdate()


                        sMessage = "============================================================================================" & vbCrLf & _
                        "Below file(s) had been updated successfully on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & vbCrLf _
                        & sOutput & vbCrLf & _
                        "============================================================================================"
                        setMessage(sMessage)
                    Else
                        sMessage = "Application latest update was not found, checking done on " & Now.ToShortDateString & " - " & Now.ToLongTimeString
                        setMessage(sMessage)
                    End If
                Else
                    sMessage = "============================================================================================" & vbCrLf & _
                                   "Warning!! - " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                                    "Unable connect to remote host, make sure the remote URI is specified correctly." & vbCrLf & _
                                    "============================================================================================"
                    setMessage(sMessage)
                End If
            End If

        Catch ex As Exception
            sMessage = ex.Message
            setMessage(sMessage)
        Finally
            If clsUpdateWorker.iThreadStatus = 0 Then
                If bIsUpdateMode Then
                    bIsUpdateMode = False
                    showMainApp()
                End If
            End If

        End Try
    End Sub

    Private Sub setMessage(ByVal sMsg As String)
        clsUpdateWorker.iThreadStatus = 0
        oUpdateWorker.AppendTLog(sMsg)
    End Sub

    Private Sub showMainApp()
        Dim startInfo As New ProcessStartInfo(Application.StartupPath & "\" & "MainApp.exe")
        Process.Start(startInfo)
        Environment.Exit(1)
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Application.Exit()
    End Sub
End Class
