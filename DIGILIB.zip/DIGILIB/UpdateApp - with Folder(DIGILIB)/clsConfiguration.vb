﻿Option Strict On
Option Explicit On

Imports Microsoft.Win32

Public Class clsConfiguration
    Private m_RemoteURI, m_TlogAutoUpdate As String
    Private m_AutoUpdateSecond As Integer

    Public Property TlogAutoUpdate() As String
        Get
            Return m_TlogAutoUpdate
        End Get
        Set(ByVal value As String)
            m_TlogAutoUpdate = value
        End Set
    End Property
    Public Property RemoteURI() As String
        Get
            Return m_RemoteURI
        End Get
        Set(ByVal value As String)
            m_RemoteURI = value
        End Set
    End Property

    Public Property AutoUpdateSecond() As Integer
        Get
            Return m_AutoUpdateSecond
        End Get
        Set(ByVal value As Integer)
            m_AutoUpdateSecond = value
        End Set
    End Property

    

    Public Sub RetrieveAutoUpdateConfiguration()
        Dim regKey As RegistryKey
        regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\SEMB-PEL", True)
        If Not regKey Is Nothing Then
            RemoteURI = CStr(If(regKey.GetValue("remoteuri") Is Nothing OrElse _
                           regKey.GetValue("remoteuri").ToString = "", "http://localhost/SEMB-PEL$/", regKey.GetValue("remoteuri")))
            AutoUpdateSecond = CInt(If(regKey.GetValue("autoupdatesecond") Is Nothing, 1800, regKey.GetValue("autoupdatesecond")))
            TlogAutoUpdate = CStr(If(regKey.GetValue("tlogautoupdate") Is Nothing OrElse _
                           regKey.GetValue("tlogautoupdate").ToString = "", Application.StartupPath & "\", regKey.GetValue("tlogautoupdate")))
            regKey.Close()
        Else
            RemoteURI = "http://localhost/SEMB-PEL$/"
            AutoUpdateSecond = 1800
            TlogAutoUpdate = Application.StartupPath & "\"
        End If
    End Sub

    Public Function GetTLogAutoUpdate() As String
        Dim regKey As RegistryKey
        regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\SEMB-PEL", True)
        If Not regKey Is Nothing Then
            Return CStr(If(regKey.GetValue("tlogautoupdate") Is Nothing OrElse _
                           regKey.GetValue("tlogautoupdate").ToString = "", Application.StartupPath & "\", regKey.GetValue("tlogautoupdate")))
        Else
            Return "C:\" 'by default the files will be located at here
        End If
    End Function


    Public Function GetAutoUpdateSecond() As Integer
        Dim regKey As RegistryKey
        regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\SEMB-PEL", True)
        If Not regKey Is Nothing Then
            AutoUpdateSecond = CInt(If((regKey.GetValue("autoupdatesecond") Is Nothing), 3600, regKey.GetValue("autoupdatesecond")))
            regKey.Close()
            Return AutoUpdateSecond
        Else
            Return 3600
        End If
    End Function
End Class
