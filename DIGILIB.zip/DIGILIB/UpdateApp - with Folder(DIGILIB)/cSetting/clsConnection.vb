﻿Option Strict On
Option Explicit On
Imports Npgsql
Imports Microsoft.Win32
Imports System.Security.Cryptography
Imports System.IO
Imports System.Text

Public Class clsConnection
    Private oConn As New NpgsqlConnection
    Private oTestconn As New NpgsqlConnection

    Private cmd As New NpgsqlCommand
    Private dr As NpgsqlDataReader
    Private trans As NpgsqlTransaction
    Public Shared bIsRollBack As Boolean

    Private sServer, sDatabase, sUserID, sPassword, sPort As String

    Public Sub Open()
        retrieveDatabaseConnection()
        oConn.ConnectionString = "Server=" & sServer & ";Database=" & sDatabase & ";User Id=" & sUserID & ";Password=" & sPassword & ";Port=" & Convert.ToInt32(sPort)
        oConn.Open()
    End Sub

    Public Sub Close()
        oConn.Close()
    End Sub

    Public Function ReadData(ByVal command As NpgsqlCommand) As NpgsqlDataReader
        If oConn.State = ConnectionState.Open Then
            oConn.Close()
        End If
        Open()
        command.Connection = oConn
        dr = command.ExecuteReader() 'or use this dr = command.ExecuteReader(CommandBehavior.CloseConnection)
        Return dr
    End Function

    Public Sub ExecuteCommand(ByVal command As NpgsqlCommand)
        Try
            bIsRollBack = False
            Open()
            command.Connection = oConn
            trans = oConn.BeginTransaction
            command.Transaction = trans
            command.ExecuteNonQuery()
            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
            bIsRollBack = True
            Dim smessage As String = ex.Message
            'MessageBox.Show("Error: " & ex.Message.ToString & vbCrLf & vbCrLf & "Transactions failed and have been rolled back, if you face this problem again, please contact your system administrator.", "V-Strategy", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            Close()
        End Try
    End Sub

    Public Overloads Function FillDatatable(ByVal command As NpgsqlCommand) As DataTable
        Try
            Dim ds As New DataSet
            Dim dt As DataTable = ds.Tables.Add("tblData")
            Open()
            command.Connection = oConn
            Dim da As NpgsqlDataAdapter = New NpgsqlDataAdapter(command)
            da.Fill(ds, "tblData")
            Return dt
        Finally
            Close()
        End Try
    End Function

    Public Overloads Function FillDatatable(ByVal command As NpgsqlCommand, ByVal sDBPath As String) As DataTable
        Try
            Dim ds As New DataSet
            Dim dt As DataTable = ds.Tables.Add("tblData")
            oTestconn.ConnectionString = sDBPath & ";Pooling=False"
            If oTestconn.State = ConnectionState.Open Then
                oTestconn.Close()
            End If
            oTestconn.Open()
            command.Connection = oTestconn
            Dim da As NpgsqlDataAdapter = New NpgsqlDataAdapter(command)
            da.Fill(ds, "tblData")
            Return dt
        Finally
            oTestconn.Close()
        End Try
    End Function

    Private Sub retrieveDatabaseConnection()
        Dim regKey As RegistryKey

        ''regKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\CPMS\\Versi 1", True)
        regKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\DIGILIB\\Versi 1", True)
        sServer = regKey.GetValue("Server").ToString
        sDatabase = regKey.GetValue("Database").ToString
        sUserID = Decrypt(regKey.GetValue("User").ToString)
        sPassword = Decrypt(regKey.GetValue("Password").ToString)
        'sUserID = regKey.GetValue("User").ToString
        'sPassword = regKey.GetValue("Password").ToString
        sPort = regKey.GetValue("Port").ToString
        regKey.Close()
    End Sub

    Public Sub Test(ByVal sDBPath As String)
        Try
            If oTestconn.State = ConnectionState.Open Then
                oTestconn.Close()
            End If
            oTestconn.ConnectionString = sDBPath & ";Pooling=False"
            oTestconn.Open()
        Finally
            oTestconn.Close()
        End Try
    End Sub

#Region "Decrypt"
    Private Function decryptTripleDES(ByVal sCipherString As String, ByVal bUseHashing As Boolean) As String
        Dim byteKeyArray() As Byte
        Dim byteToEncryptArray() As Byte = Convert.FromBase64String(sCipherString)

        Dim settingsReader As System.Configuration.AppSettingsReader = New Configuration.AppSettingsReader

        Dim sKey As String = "ficcifernandodfadsadasdarqweq124123<>,:Ldsf54514/*******;;'[[p[qqeq*`12121121"  '<---

        If (bUseHashing) Then
            Dim hashmd5 As MD5CryptoServiceProvider = New MD5CryptoServiceProvider
            byteKeyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(sKey))
            hashmd5.Clear()
        Else
            byteKeyArray = UTF8Encoding.UTF8.GetBytes(sKey)
        End If
        Dim tdes As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider
        tdes.Key = byteKeyArray
        tdes.Mode = CipherMode.ECB
        tdes.Padding = PaddingMode.PKCS7

        Dim cTransform As ICryptoTransform = tdes.CreateDecryptor
        Dim byteResultArray() As Byte = cTransform.TransformFinalBlock(byteToEncryptArray, 0, byteToEncryptArray.Length)

        tdes.Clear()
        Return UTF8Encoding.UTF8.GetString(byteResultArray)
    End Function

    Private Function DecryptOld(ByVal sCipherString As String) As String
        Dim sStringToBeDecrypted As String = decryptTripleDES(sCipherString, True)

        Dim byteDataToBeDecrypted() As Byte
        Dim byteTemp() As Byte
        Dim byteIV() As Byte = {22, 240, 1, 8, 13, 174, 11, 39, 255, 91, 44, 77, 15, 201, 72, 63}
        Dim objRijndaelManaged As New RijndaelManaged()
        Dim objMemoryStream As MemoryStream
        Dim objCryptoStream As CryptoStream
        Dim byteDecryptionKey() As Byte
        Dim iLength As Integer
        Dim iRemaining As Integer
        Dim sReturnString As String = String.Empty

        '   *****************************************************************
        '   ******   Convert base64 encrypted value to byte array      ******
        '   *****************************************************************
        byteDataToBeDecrypted = Convert.FromBase64String(sStringToBeDecrypted)

        '   ********************************************************************
        '   ******   Encryption Key must be 256 bits long (32 bytes)      ******
        '   ******   If it is longer than 32 bytes it will be truncated.  ******
        '   ******   If it is shorter than 32 bytes it will be padded     ******
        '   ******   with upper-case Xs.                                  ****** 
        '   ********************************************************************
        Dim vstrDecryptionKey As String = "3378rqklwo$52#$hhklppppp55698qwklgsxcbm,<=-)534*-\dasow@1"

        iLength = Len(vstrDecryptionKey)

        If iLength >= 32 Then
            vstrDecryptionKey = Strings.Left(vstrDecryptionKey, 32)
        Else
            iLength = Len(vstrDecryptionKey)
            iRemaining = 32 - iLength
            vstrDecryptionKey = vstrDecryptionKey & Strings.StrDup(iRemaining, "OFF")
        End If

        byteDecryptionKey = Encoding.ASCII.GetBytes(vstrDecryptionKey.ToCharArray)
        ReDim byteTemp(byteDataToBeDecrypted.Length)
        objMemoryStream = New MemoryStream(byteDataToBeDecrypted)

        '   ***********************************************************************
        '   ******  Create the decryptor and write value to it after it is   ******
        '   ******  converted into a byte array                              ******
        '   ***********************************************************************

        Try
            objCryptoStream = New CryptoStream(objMemoryStream, _
               objRijndaelManaged.CreateDecryptor(byteDecryptionKey, byteIV), _
               CryptoStreamMode.Read)

            objCryptoStream.Read(byteTemp, 0, byteTemp.Length)

            objCryptoStream.FlushFinalBlock()
            objMemoryStream.Close()
            objCryptoStream.Close()
        Catch

        End Try

        '   *****************************************
        '   ******   Return decypted value     ******
        '   *****************************************
        Return stripNullCharacters(Encoding.ASCII.GetString(byteTemp))
    End Function


    Public Function Decrypt(ByVal Text As String) As String
        Try

            Dim byteKey() As Byte
            Dim byteIV() As Byte = {22, 240, 1, 8, 13, 174, 11, 39, 255, 91, 44, 77, 15, 201, 72, 63}

            Dim vstrEncryptionKey As String = "3378rqklwo$52#$hhklppppp55698qwklgsxcbm,<=-)534*-\dasow@1"
            Dim iLength As Integer = vstrEncryptionKey.Length
            If (iLength >= 32) Then
                vstrEncryptionKey = vstrEncryptionKey.Substring(0, 32)
            End If
            byteKey = Encoding.ASCII.GetBytes(vstrEncryptionKey.ToCharArray())

            Dim TextBytes() = Convert.FromBase64String(Text)
            Dim rijKey As RijndaelManaged = New RijndaelManaged()
            rijKey.Mode = CipherMode.CBC
            Dim decryptor As ICryptoTransform = rijKey.CreateDecryptor(byteKey, byteIV)
            Dim MemoryStream As MemoryStream = New MemoryStream(TextBytes)
            Dim CryptoStream As CryptoStream = New CryptoStream(MemoryStream, decryptor, CryptoStreamMode.Read)
            Dim pTextBytes() As Byte
            ReDim pTextBytes(TextBytes.Length)

            Dim decryptedByteCount As Integer = CryptoStream.Read(pTextBytes, 0, pTextBytes.Length)
            MemoryStream.Close()
            CryptoStream.Close()
            Dim plainText As String = Encoding.UTF8.GetString(pTextBytes, 0, decryptedByteCount)
            Return plainText

        Catch ex As Exception
            Dim t = ""
            Return t
        End Try
    End Function


    Private Function stripNullCharacters(ByVal vstrStringWithNulls As String) As String
        
        Dim intPosition As Integer
        Dim strStringWithOutNulls As String

        intPosition = 1
        strStringWithOutNulls = vstrStringWithNulls

        Do While intPosition > 0
            intPosition = InStr(intPosition, vstrStringWithNulls, vbNullChar)

            If intPosition > 0 Then
                strStringWithOutNulls = Left$(strStringWithOutNulls, intPosition - 1) & _
                                  Right$(strStringWithOutNulls, Len(strStringWithOutNulls) - intPosition)
            End If

            If intPosition > strStringWithOutNulls.Length Then
                Exit Do
            End If
        Loop

        Return strStringWithOutNulls
    End Function

#End Region

End Class
