Option Explicit On
Option Strict On

Public Class frmUpdateApp_new
    Private oUpdateWorker As New clsUpdateWorker(Me)
    Private sMessage As String
    Private bIsUpdateMode As Boolean = False
    Private sOutput As String
    Private sExeName As String
    Private bIsAuto As Boolean = True
    Private Sub doCheckUpdate()
        Try
            If clsUpdateWorker.iThreadStatus = 0 Then 'no more thread
                lblInfo.Visible = True
                lblInfo.Text = "Checking for the latest update application, please wait...."
                lblInit.Visible = True
                lblInit.Text = "Initializing..."
                clsUpdateWorker.iThreadStatus = 1
                oUpdateWorker.RetrieveConfiguration()

                If oUpdateWorker.IsConnect(oUpdateWorker.RemoteURI) Then
                    'oUpdateWorker.RemoteURI = oUpdateWorker.RemoteURI
                    'oUpdateWorker.ManifestFile = "ServerManifest.xml"
                    oUpdateWorker.ApplicationInstance = sExeName
                    oUpdateWorker.AppStartupPath = System.AppDomain.CurrentDomain.BaseDirectory()

                    If oUpdateWorker.IsNeedUpdate() Then

                        bIsUpdateMode = True
                        oUpdateWorker.KillAppInstance()

                        'Start Update
                        lblInit.Text = "Downloading...."
                        sOutput = oUpdateWorker.ProcessUpdate()

                        lblInfo.Visible = False
                        lblInit.Text = "Update successfully..."

                        sMessage = "============================================================================================" & vbCrLf & _
                        "Below file(s) had been updated successfully on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & vbCrLf _
                        & sOutput & vbCrLf & _
                        "============================================================================================"
                        setMessage(sMessage)
                    Else
                        sMessage = "Application latest update was not found, checking done on " & Now.ToShortDateString & " - " & Now.ToLongTimeString
                        setMessage(sMessage)
                    End If
                Else
                    sMessage = "============================================================================================" & vbCrLf & _
                                   "Warning!! - " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                                    "Unable connect to remote host, make sure the remote URI is specified correctly." & vbCrLf & _
                                    "============================================================================================"
                    setMessage(sMessage)
                End If
            End If

        Catch ex As Exception
            sMessage = ex.Message
            setMessage(sMessage)
        Finally
            If Not bIsAuto Then
                MessageBox.Show(sMessage)
            End If
            If clsUpdateWorker.iThreadStatus = 0 Then
                If bIsUpdateMode Then
                    bIsUpdateMode = False
                End If
            End If
            showMainApp()
            Application.Exit()
        End Try
    End Sub

    Private Sub setMessage(ByVal sMsg As String)
        clsUpdateWorker.iThreadStatus = 0
        If Not bIsAuto Then
            oUpdateWorker.AppendTLog(sMsg)
        End If
    End Sub

    Private Sub showMainApp()
        Dim startInfo As New ProcessStartInfo(Application.StartupPath & "\" & sExeName)
        Process.Start(startInfo)
        Environment.Exit(1)
    End Sub
    Private Sub frmUpdateApp_new_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'exs = "GPS Time Manager.exe|True|"& "GPS-TIME-MANAGEMENT"
        'exs = "VisualDisplay.exe|True|"& "GPS-TIME-MANAGEMENT"
        'exs = "SerialPortCommunication.exe|True|"& "GPS-TIME-MANAGEMENT"
        Dim envar As String = Environment.GetEnvironmentVariable("myEnv")

        If Not envar Is Nothing Then
            Dim arrString() As String = Split(envar, "|")
            sExeName = arrString(0).ToString
            bIsAuto = CBool(arrString(1))
        Else
            sExeName = "GPS Time Manager.exe"
            bIsAuto = False
        End If
        Timer1.Enabled = True
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        doCheckUpdate()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Application.Exit()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        doCheckUpdate()
    End Sub

    Private Sub frmUpdateApp_new_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            Application.Exit()
        End If
    End Sub
End Class