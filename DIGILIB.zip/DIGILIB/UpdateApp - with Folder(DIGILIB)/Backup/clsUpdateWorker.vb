﻿'Option Strict On
Option Explicit On

Imports System.Net
Imports System.Xml
Imports System.IO
''Imports cSetting
Imports Npgsql
Imports System.Data
Imports Microsoft.Win32
Imports System.Reflection

Public Class clsUpdateWorker
    Private frmUpdateApp As frmUpdateApp
    Private oConnection As New clsConnection
    Private dr As NpgsqlDataReader

    Public Shared iThreadStatus As Integer
    Private m_RemoteURI, m_ManifestFile As String
    Private m_ApplicationInstance As String
    Private m_TotalUpdatedFile As Integer
    Private m_AppStartupPath As String = Environment.CurrentDirectory.ToString()

    Public Delegate Sub ProgressChange(ByVal Progress As Integer)
    Public ProgressChangeHandler As ProgressChange

    Private m_isSuperadmin As Boolean

    'Private m_IsUpdatedAppInstance As Boolean
    'Public Property IsUpdatedAppInstance() As Boolean
    '    Get
    '        Return m_IsUpdatedAppInstance
    '    End Get
    '    Set(ByVal value As Boolean)
    '        m_IsUpdatedAppInstance = value
    '    End Set
    'End Property
    'Private m_AppStartupPath As String
    Public Property AppStartupPath() As String
        Get
            Return m_AppStartupPath
        End Get
        Set(ByVal value As String)
            m_AppStartupPath = value
        End Set
    End Property
    Public Property ApplicationInstance() As String
        Get
            Return m_ApplicationInstance
        End Get
        Set(ByVal value As String)
            m_ApplicationInstance = value
        End Set
    End Property
    Public Property RemoteURI() As String
        Get
            Return m_RemoteURI
        End Get
        Set(ByVal value As String)
            m_RemoteURI = value
        End Set
    End Property

    Public Property ManifestFile() As String
        Get
            Return m_ManifestFile
        End Get
        Set(ByVal value As String)
            m_ManifestFile = value
        End Set
    End Property

    Private Function getVersion(ByVal sVersion As String) As String
        If (sVersion = String.Empty) Then sVersion = "0.0.0.0"
        Dim arrString() As String = Split(sVersion, ".")
        Return String.Format("{0:00000}{1:00000}{2:00000}{3:00000}", Int(arrString(0)), Int(arrString(1)), Int(arrString(2)), Int(arrString(3)))
    End Function

    Public Property isSuperadmin() As Boolean
        Get
            Return m_isSuperadmin
        End Get
        Set(ByVal value As Boolean)
            m_isSuperadmin = value
        End Set
    End Property

    Public Sub RetrieveConfiguration()
        Dim cmd As New NpgsqlCommand
        cmd.CommandText = "select remoteuri, manifestfile, applicationinstance, remoteuri_user from epms_tserverinfo"
        dr = oConnection.ReadData(cmd)
        dr.Read()

        If m_isSuperadmin = True Then
            RemoteURI = dr("remoteuri").ToString
        Else
            RemoteURI = dr("remoteuri_user").ToString
        End If

        ManifestFile = dr("manifestfile").ToString
        If ApplicationInstance Is Nothing OrElse ApplicationInstance = "" Then
            ApplicationInstance = dr("applicationinstance").ToString
        End If
        oConnection.Close()

    End Sub

    Public Function IsConnect(ByVal sRemoteURI As String) As Boolean
        Dim oRequest As WebRequest = Nothing
        Try
            '===========================================================
            ' CHECK the URI path :D
            oRequest = WebRequest.Create(sRemoteURI)
            oRequest.Method = WebRequestMethods.Http.Head
            oRequest.Timeout = 20000
            oRequest.GetResponse()
            '===========================================================
            Return True
        Catch ex As Exception
            Return False
        Finally
            'updated 16June09
            If Not oRequest Is Nothing Then
                oRequest.Abort()
            End If
        End Try
    End Function
     
    Public Function IsNeedUpdate() As Boolean
        '-note : only for 4 level directory
        'for more level please customize

        Dim oWebClient As New WebClient
        Dim sOutput As String = ""
        Try
            ' Download manifest file
            ' get the update file content in manifest file
            oWebClient.DownloadFile(RemoteURI & ManifestFile, m_AppStartupPath & ManifestFile)
            Dim m_xmld As XmlDocument
            Dim m_nodelist As XmlNodeList
            Dim m_nodelist2 As XmlNodeList
            Dim m_nodelist3 As XmlNodeList
            Dim m_nodelist4 As XmlNodeList

            Dim m_node As XmlNode
            Dim m_node2 As XmlNode
            Dim m_node3 As XmlNode
            Dim m_node4 As XmlNode

            'Create the XML Document
            m_xmld = New XmlDocument
            'Load the Xml file
            m_xmld.Load(m_AppStartupPath & ManifestFile)

            'Get the list of name nodes 
            m_nodelist = m_xmld.SelectNodes("/update/name")
            Dim iLoop As Integer = 0
            Dim bIsNeedUpdate As Boolean = False
            'Loop through the nodes

            Dim sFileAttribute As String = ""
            Dim sFileAttribute2 As String = ""
            Dim sFileAttribute3 As String = ""
            Dim sFileAttribute4 As String = ""

            Dim sDir As String = ""
            Dim sDir2 As String = ""
            Dim sDir3 As String = ""
            Dim sDir4 As String = ""

            'Get the isdir Element Value
            Dim bIsDir As String = ""
            'Get the fileName Element Value
            Dim sFileNameValue As String = ""

            'Get the fileVersion Element Value
            Dim sFileVersionValue As String = ""
            'Get the fileLastModified Value
            Dim sFileLastModiValue As String = ""

            'Temp file name
            Dim sTempFileName As String = ""
            Dim bIsToUpgrade As Boolean = False
            Dim sRealFileName As String = ""
            Dim dtLastModified As Date

            Dim bIsFileExists As Boolean = False

            For Each m_node In m_nodelist
                'Get the file Attribute Value
                sFileAttribute = m_node.Attributes.GetNamedItem("file").Value
                If (sFileAttribute.ToLower() <> ApplicationInstance.ToLower()) Then
                    Continue For
                End If
                'Get the isdir Element Value
                bIsDir = m_node.ChildNodes.Item(3).InnerText

                If (LCase(bIsDir) = "true") Then
                    m_nodelist2 = m_xmld.SelectNodes("/update/name/name")
                    sDir2 = sFileAttribute
                    For Each m_node2 In m_nodelist2
                        If m_node2.ParentNode.Attributes.GetNamedItem("file").Value = sDir2 Then
                            sFileAttribute2 = m_node2.Attributes.GetNamedItem("file").Value
                            bIsDir = m_node2.ChildNodes.Item(3).InnerText
                            If (LCase(bIsDir) = "true") Then
                                sDir3 = sFileAttribute2
                                m_nodelist3 = m_xmld.SelectNodes("/update/name/name/name")

                                For Each m_node3 In m_nodelist3

                                    If m_node3.ParentNode.Attributes.GetNamedItem("file").Value = sDir3 Then
                                        sFileAttribute3 = m_node3.Attributes.GetNamedItem("file").Value
                                        bIsDir = m_node3.ChildNodes.Item(3).InnerText
                                        If (LCase(bIsDir) = "true") Then

                                            sDir4 = sFileAttribute3
                                            m_nodelist4 = m_xmld.SelectNodes("/update/name/name/name/name")

                                            For Each m_node4 In m_nodelist4

                                                If m_node4.ParentNode.Attributes.GetNamedItem("file").Value = sDir4 Then
                                                    sFileAttribute4 = m_node4.Attributes.GetNamedItem("file").Value
                                                    bIsDir = m_node4.ChildNodes.Item(3).InnerText
                                                    If (LCase(bIsDir) = "true") Then
                                                        ''sDir5 = sFileAttribute4
                                                    Else
                                                        'Get the fileName Element Value
                                                        sFileNameValue = m_node4.ChildNodes.Item(0).InnerText
                                                        'Get the fileVersion Element Value
                                                        sFileVersionValue = m_node4.ChildNodes.Item(1).InnerText
                                                        'Get the fileLastModified Value
                                                        sFileLastModiValue = m_node4.ChildNodes.Item(2).InnerText

                                                        sRealFileName = m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4 & "\" & sFileNameValue
                                                        dtLastModified = CDate(sFileLastModiValue)

                                                        'Download upgrade file
                                                        If isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput) Then
                                                            iLoop += 1
                                                            bIsNeedUpdate = True
                                                            Return True
                                                        End If

                                                    End If
                                                End If
                                            Next

                                        Else
                                            'Get the fileName Element Value
                                            sFileNameValue = m_node3.ChildNodes.Item(0).InnerText
                                            'Get the fileVersion Element Value
                                            sFileVersionValue = m_node3.ChildNodes.Item(1).InnerText
                                            'Get the fileLastModified Value
                                            sFileLastModiValue = m_node3.ChildNodes.Item(2).InnerText

                                            sRealFileName = m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sFileNameValue
                                            dtLastModified = CDate(sFileLastModiValue)

                                            'Download upgrade file
                                            If isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput) Then
                                                iLoop += 1
                                                bIsNeedUpdate = True
                                                Return True
                                            End If

                                        End If
                                    End If
                                Next
                            Else
                                'Get the fileName Element Value
                                sFileNameValue = m_node2.ChildNodes.Item(0).InnerText
                                'Get the fileVersion Element Value
                                sFileVersionValue = m_node2.ChildNodes.Item(1).InnerText
                                'Get the fileLastModified Value
                                sFileLastModiValue = m_node2.ChildNodes.Item(2).InnerText

                                'Temp file name
                                sTempFileName = m_AppStartupPath & sDir2 & "\" & Now.TimeOfDay.TotalMilliseconds
                                bIsToUpgrade = False
                                sRealFileName = m_AppStartupPath & sDir2 & "\" & sFileNameValue
                                dtLastModified = CDate(sFileLastModiValue)

                                If isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput) Then
                                    iLoop += 1
                                    bIsNeedUpdate = True
                                    Return True
                                End If
                            End If
                        End If
                    Next
                Else
                    'Get the fileName Element Value
                    sFileNameValue = m_node.ChildNodes.Item(0).InnerText
                    'Get the fileVersion Element Value
                    sFileVersionValue = m_node.ChildNodes.Item(1).InnerText
                    'Get the fileLastModified Value
                    sFileLastModiValue = m_node.ChildNodes.Item(2).InnerText

                    'Temp file name
                    sTempFileName = m_AppStartupPath & Now.TimeOfDay.TotalMilliseconds
                    bIsToUpgrade = False
                    sRealFileName = m_AppStartupPath & sFileNameValue
                    dtLastModified = CDate(sFileLastModiValue)

                    If isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput) Then
                        iLoop += 1
                        bIsNeedUpdate = True
                        Return True
                    End If
                End If
            Next

            If bIsNeedUpdate Then
                m_TotalUpdatedFile = iLoop
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Throw (New Exception("======================================================================================" & vbCrLf & _
                  "Error occured at '" & ex.Source & "' on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                 ex.Message.ToString & vbCrLf & "Please contact your system administrator if this problem occurs persistently." & vbCrLf & _
                 "Stack Trace: " & vbCrLf & ex.StackTrace & vbCrLf & "======================================================================================"))
        Finally
            If File.Exists(m_AppStartupPath & ManifestFile) Then
                File.Delete(m_AppStartupPath & ManifestFile)
            End If
            If Not oWebClient Is Nothing Then
                oWebClient.Dispose()
            End If
        End Try
    End Function

    Private Function isFileUpdated(ByVal sRealFileName As String, ByVal dtLastModified As Date, ByVal sFileVersionValue As String, ByVal sFileNameValue As String, ByRef sOutput As String)
        Dim bIsToUpgrade As Boolean = False
        Dim bIsFileExists As Boolean = False
         
        Dim sfileversion As String = ""
        'If file not exist then download file
        bIsFileExists = File.Exists(sRealFileName)
        If Not bIsFileExists Then
            bIsToUpgrade = True
        ElseIf sFileVersionValue <> "" Or sFileVersionValue <> "0.0.0.0" Then
            'verify the file version'
            If Not sFileNameValue.ToLower.Contains("setup") Then
                sfileversion = getAssemblyInfo(sRealFileName)
                If (sfileversion = "") Then sfileversion = getVersionInfo(sRealFileName)

                bIsToUpgrade = (getVersion(sFileVersionValue) > getVersion(sfileversion))
            Else
                bIsToUpgrade = False
            End If
                'check if version not upgrade then check last modified
                If Not bIsToUpgrade Then
                    bIsToUpgrade = (dtLastModified > File.GetLastWriteTimeUtc(sRealFileName))
                End If

            Else
                'check last modified file
                bIsToUpgrade = (dtLastModified > File.GetLastWriteTimeUtc(sRealFileName))
        End If
        If bIsToUpgrade Then

            If Not bIsFileExists Then
                sOutput &= "Filename: " & sFileNameValue & " - " & _
                 "(Missing File) - V " & sFileVersionValue & " (New)"
            Else
                sfileversion = getAssemblyInfo(sRealFileName)
                If (sfileversion = "") Then sfileversion = getVersionInfo(sRealFileName)

                bIsToUpgrade = (getVersion(sFileVersionValue) > getVersion(sfileversion))
                 
                sOutput &= "Filename: " & sFileNameValue & " - V " & _
                sfileversion & _
                " (Old) - V " & sFileVersionValue & " (New)"

            End If
        End If
        Return bIsToUpgrade

    End Function

    Public Function ProcessUpdate() As String
        '-note : only for 4 level directory
        'for more level please customize

        Dim sOutput As String = ""
        'Dim oWebClient As New WebClient
        Dim oWebClient As WebClient = New WebClient()
        ' Download manifest file
        Try
            ' get the update file content in manifest file
            oWebClient.DownloadFile(RemoteURI & ManifestFile, m_AppStartupPath & ManifestFile)

            Dim m_xmld As XmlDocument
            Dim m_nodelist As XmlNodeList
            Dim m_nodelist2 As XmlNodeList
            Dim m_nodelist3 As XmlNodeList
            Dim m_nodelist4 As XmlNodeList

            Dim m_node As XmlNode
            Dim m_node2 As XmlNode
            Dim m_node3 As XmlNode
            Dim m_node4 As XmlNode

            'Create the XML Document
            m_xmld = New XmlDocument
            'Load the Xml file
            m_xmld.Load(m_AppStartupPath & ManifestFile)

            'Get the list of name nodes 
            m_nodelist = m_xmld.SelectNodes("/update/name")

            Dim iTotalRow As Integer = CInt(m_nodelist.Count)
            Dim iLoop As Integer = 1
             
            Dim bIsNeedUpdate As Boolean = False
            'Loop through the nodes

            Dim sFileAttribute As String = ""
            Dim sFileAttribute2 As String = ""
            Dim sFileAttribute3 As String = ""
            Dim sFileAttribute4 As String = ""

            Dim sDir As String = ""
            Dim sDir2 As String = ""
            Dim sDir3 As String = ""
            Dim sDir4 As String = ""

            'Get the isdir Element Value
            Dim bIsDir As String = ""
            'Get the fileName Element Value
            Dim sFileNameValue As String = ""

            'Get the fileVersion Element Value
            Dim sFileVersionValue As String = ""
            'Get the fileLastModified Value
            Dim sFileLastModiValue As String = ""

            'Temp file name
            Dim sTempFileName As String = ""
            'new rule update all file
            Dim bIsToUpgrade As Boolean = True
            Dim sRealFileName As String = ""
            Dim dtLastModified As Date

            Dim bIsFileExists As Boolean = False

            For Each m_node In m_nodelist
                'Get the file Attribute Value
                sFileAttribute = m_node.Attributes.GetNamedItem("file").Value

                'Get the isdir Element Value
                bIsDir = m_node.ChildNodes.Item(3).InnerText

                If (LCase(bIsDir) = "true") Then
                    m_nodelist2 = m_xmld.SelectNodes("/update/name/name")
                    'iTotalRow += CInt(m_nodelist2.Count)

                    sDir2 = sFileAttribute
                    If Not Directory.Exists(m_AppStartupPath & sDir2) Then
                        Directory.CreateDirectory(m_AppStartupPath & sDir2)
                    End If

                    For Each m_node2 In m_nodelist2

                        If m_node2.ParentNode.Attributes.GetNamedItem("file").Value = sDir2 Then

                            iTotalRow += 1
                            sFileAttribute2 = m_node2.Attributes.GetNamedItem("file").Value
                            bIsDir = m_node2.ChildNodes.Item(3).InnerText

                            If (LCase(bIsDir) = "true") Then

                                sDir3 = sFileAttribute2
                                If Not Directory.Exists(m_AppStartupPath & sDir2 & "\" & sDir3) Then
                                    Directory.CreateDirectory(m_AppStartupPath & sDir2 & "\" & sDir3)
                                End If

                                m_nodelist3 = m_xmld.SelectNodes("/update/name/name/name")

                                'iTotalRow += CInt(m_nodelist3.Count)

                                For Each m_node3 In m_nodelist3

                                    If m_node3.ParentNode.Attributes.GetNamedItem("file").Value = sDir3 Then

                                        iTotalRow += 1
                                        sFileAttribute3 = m_node3.Attributes.GetNamedItem("file").Value
                                        bIsDir = m_node3.ChildNodes.Item(3).InnerText
                                        If (LCase(bIsDir) = "true") Then

                                            '====Start directory 4
                                            sDir4 = sFileAttribute3
                                            If Not Directory.Exists(m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4) Then
                                                Directory.CreateDirectory(m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4)
                                            End If

                                            m_nodelist4 = m_xmld.SelectNodes("/update/name/name/name/name")

                                            'iTotalRow += CInt(m_nodelist4.Count)

                                            For Each m_node4 In m_nodelist4
                                                If m_node4.ParentNode.Attributes.GetNamedItem("file").Value = sDir4 Then

                                                    iTotalRow += 1

                                                    sFileAttribute4 = m_node4.Attributes.GetNamedItem("file").Value
                                                    bIsDir = m_node4.ChildNodes.Item(3).InnerText
                                                    If (LCase(bIsDir) = "true") Then

                                                        ''sDir5 = sFileAttribute4
                                                        ''If Not Directory.Exists(m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4) Then
                                                        ''Directory.CreateDirectory(m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4)
                                                        ''End If

                                                    Else

                                                        'Get the fileName Element Value
                                                        sFileNameValue = m_node4.ChildNodes.Item(0).InnerText
                                                        'Get the fileVersion Element Value
                                                        sFileVersionValue = m_node4.ChildNodes.Item(1).InnerText
                                                        'Get the fileLastModified Value
                                                        sFileLastModiValue = m_node4.ChildNodes.Item(2).InnerText

                                                        'Temp file name
                                                        sTempFileName = m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4 & "\" & Now.TimeOfDay.TotalMilliseconds
                                                        'new rule
                                                        bIsToUpgrade = True
                                                        sRealFileName = m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sDir4 & "\" & sFileNameValue
                                                        dtLastModified = CDate(sFileLastModiValue)

                                                        'old rule
                                                        'bIsToUpgrade = isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput)
                                                        'Download upgrade file
                                                        If bIsToUpgrade Then
                                                            ' Download file and name it with temporary name
                                                            frmUpdateApp.ProgressBarControl1.Value = 0

                                                            If DownloadWithProgress(RemoteURI, sDir2 & "/" & sDir3 & "/" & sDir4 & "/" & sFileNameValue, frmUpdateApp.ProgressBarControl1, sRealFileName, sTempFileName, dtLastModified) Then

                                                                If Not (iLoop = m_TotalUpdatedFile) And (iLoop Mod 2) Then
                                                                    sOutput &= vbCrLf & "Filename: "
                                                                End If
                                                                sOutput &= "   |   " & sFileNameValue
                                                                iLoop += 1
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            Next

                                            '====End directory 4

                                        Else
                                            sDir4 = ""
                                            'Get the fileName Element Value
                                            sFileNameValue = m_node3.ChildNodes.Item(0).InnerText
                                            'Get the fileVersion Element Value
                                            sFileVersionValue = m_node3.ChildNodes.Item(1).InnerText
                                            'Get the fileLastModified Value
                                            sFileLastModiValue = m_node3.ChildNodes.Item(2).InnerText

                                            'Temp file name
                                            sTempFileName = m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & Now.TimeOfDay.TotalMilliseconds
                                            'new rule
                                            bIsToUpgrade = True
                                            sRealFileName = m_AppStartupPath & sDir2 & "\" & sDir3 & "\" & sFileNameValue
                                            dtLastModified = CDate(sFileLastModiValue)

                                            'old rule
                                            'bIsToUpgrade = isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput)
                                            'Download upgrade file
                                            If bIsToUpgrade Then
                                                ' Download file and name it with temporary name
                                                frmUpdateApp.ProgressBarControl1.Value = 0

                                                If DownloadWithProgress(RemoteURI, sDir2 & "/" & sDir3 & "/" & sFileNameValue, frmUpdateApp.ProgressBarControl1, sRealFileName, sTempFileName, dtLastModified) Then

                                                    If Not (iLoop = m_TotalUpdatedFile) And (iLoop Mod 2) Then
                                                        sOutput &= vbCrLf & "Filename: "
                                                    End If
                                                    sOutput &= "   |   " & sFileNameValue
                                                    iLoop += 1
                                                End If
                                            End If
                                        End If
                                    End If
                                Next

                            Else
                                sDir3 = ""
                                'Get the fileName Element Value
                                sFileNameValue = m_node2.ChildNodes.Item(0).InnerText
                                'Get the fileVersion Element Value
                                sFileVersionValue = m_node2.ChildNodes.Item(1).InnerText
                                'Get the fileLastModified Value
                                sFileLastModiValue = m_node2.ChildNodes.Item(2).InnerText

                                'Temp file name
                                sTempFileName = m_AppStartupPath & sDir2 & "\" & Now.TimeOfDay.TotalMilliseconds
                                'new rule
                                bIsToUpgrade = True
                                sRealFileName = m_AppStartupPath & sDir2 & "\" & sFileNameValue
                                dtLastModified = CDate(sFileLastModiValue)

                                'old rule
                                'bIsToUpgrade = isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput)
                                'Download upgrade file
                                If bIsToUpgrade Then
                                    ' Download file and name it with temporary name
                                    frmUpdateApp.ProgressBarControl1.Value = 0

                                    If DownloadWithProgress(RemoteURI, sDir2 & "/" & sFileNameValue, frmUpdateApp.ProgressBarControl1, sRealFileName, sTempFileName, dtLastModified) Then

                                        If Not (iLoop = m_TotalUpdatedFile) And (iLoop Mod 2) Then
                                            sOutput &= vbCrLf & "Filename: "
                                        End If
                                        sOutput &= "   |   " & sFileNameValue
                                        iLoop += 1
                                    End If
                                End If
                            End If
                        End If
                    Next
                Else
                    'Get the fileName Element Value
                    sFileNameValue = m_node.ChildNodes.Item(0).InnerText
                    'Get the fileVersion Element Value
                    sFileVersionValue = m_node.ChildNodes.Item(1).InnerText
                    'Get the fileLastModified Value
                    sFileLastModiValue = m_node.ChildNodes.Item(2).InnerText

                    'Temp file name
                    sTempFileName = m_AppStartupPath & Now.TimeOfDay.TotalMilliseconds
                    'update all (new rule) 
                    bIsToUpgrade = True
                    sRealFileName = m_AppStartupPath & sFileNameValue
                    dtLastModified = CDate(sFileLastModiValue)

                    '(all rule) 
                    'bIsToUpgrade = isFileUpdated(sRealFileName, dtLastModified, sFileVersionValue, sFileNameValue, sOutput)
                    'Download upgrade file
                    If bIsToUpgrade Then
                        ' Download file and name it with temporary name
                        frmUpdateApp.ProgressBarControl1.Value = 0

                        If DownloadWithProgress(RemoteURI, sFileNameValue, frmUpdateApp.ProgressBarControl1, sRealFileName, sTempFileName, dtLastModified) Then

                            If Not (iLoop = m_TotalUpdatedFile) And (iLoop Mod 2) Then
                                sOutput &= vbCrLf & "Filename: "
                            End If
                            sOutput &= "   |   " & sFileNameValue
                            iLoop += 1
                        End If
                    End If
                End If
            Next

            Return sOutput
        Catch ex As Exception
            Throw (New Exception("======================================================================================" & vbCrLf & _
                  "Error occured at '" & ex.Source & "' on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
                 ex.Message.ToString & vbCrLf & "Please contact your system administrator if this problem occurs persistently." & vbCrLf & _
                 "Stack Trace: " & vbCrLf & ex.StackTrace & vbCrLf & "======================================================================================"))
        Finally
            'Delete server manifest file
            File.Delete(m_AppStartupPath & ManifestFile)
            If Not oWebClient Is Nothing Then
                oWebClient.Dispose()
            End If
        End Try
    End Function

    Private Function DownloadWithProgress(ByVal sURL As String, ByVal OriFilename As String, ByVal pProgress As ProgressBar, ByVal sRealFileName As String, ByVal sTempFileName As String, ByVal dtLastModified As Date) As Boolean

        Dim strMyExePath = Application.ExecutablePath
        If OriFilename.ToLower() = Path.GetFileName(strMyExePath).ToLower() Then Return True

        Dim URLReq As HttpWebRequest
        Dim URLRes As HttpWebResponse
        Dim FileStreamer As New FileStream(sTempFileName, FileMode.Create)
        Dim bBuffer(4095) As Byte
        Dim iBytesRead As Integer

        Try


            sURL = sURL & OriFilename
            URLReq = WebRequest.Create(sURL)
            URLReq.Timeout = 20000
            URLRes = URLReq.GetResponse
            Dim rStream As Stream = URLReq.GetResponse.GetResponseStream
            pProgress.Maximum = URLRes.ContentLength

            Dim length As Long = pProgress.Maximum 'Size of the response (in bytes)
            Dim nRead As Integer

            'To calculate the download speed
            Dim speedtimer As New Stopwatch
            Dim currentspeed As Double = -1
            Dim currentspeedMB As Double
            Dim readings As Integer = 0

            Dim FileSize As Double
            Dim Downloaded As Double
            Dim percent As Short

            Do
                speedtimer.Start()
                iBytesRead = rStream.Read(bBuffer, 0, 4096)

                nRead += iBytesRead
                If length > 0 Then
                    percent = (nRead * 100) / length
                Else
                    percent = 100
                End If

                FileStreamer.Write(bBuffer, 0, iBytesRead)
                If pProgress.Value + iBytesRead <= pProgress.Maximum Then
                    pProgress.Value += iBytesRead
                Else
                    pProgress.Value = pProgress.Maximum
                End If

                FileSize = Math.Round((length / 1024), 2)
                Downloaded = Math.Round((nRead / 1024), 2)

                frmUpdateApp.lblInit.Text = "Downloading: " & OriFilename

                frmUpdateApp.Label6.Text = "File Size: " & FileSize & " KB"

                frmUpdateApp.Label9.Text = "Downloaded " & Downloaded & " KB of " & FileSize & " KB (" & percent & "%)"
                If currentspeed = -1 Then
                    frmUpdateApp.Label7.Text = "Speed: calculating..."
                Else
                    currentspeedMB = Math.Round((currentspeed / 1024), 2)
                    If (currentspeedMB > 1028) Then
                        currentspeedMB = Math.Round((currentspeedMB / 1024), 2)
                        frmUpdateApp.Label7.Text = "Speed: " & currentspeedMB & " MB/s"
                    Else
                        frmUpdateApp.Label7.Text = "Speed: " & currentspeedMB & " KB/s"
                    End If

                End If

                speedtimer.Stop()

                readings += 1
                If readings >= 5 Then 'For increase precision, the speed it's calculated only every five cicles
                    currentspeed = 20480 / (speedtimer.ElapsedMilliseconds / 1000)
                    speedtimer.Reset()
                    readings = 0
                End If

                Application.DoEvents()
            Loop Until iBytesRead = 0
            rStream.Close()
            FileStreamer.Close()

            ' Rename temporary file to real file name
            File.Copy(sTempFileName, sRealFileName, True)
            ' Set Last modified 
            File.SetLastWriteTimeUtc(sRealFileName, dtLastModified)
            ' Delete temporary file
            File.Delete(sTempFileName)

            pProgress.Value = pProgress.Maximum

            Return True
            'Return sResponseData
        Catch
            'MsgBox(Err.Description)
            File.Delete(sTempFileName)

            pProgress.Value = pProgress.Maximum
            Return False
        Finally
            'updated 16June09
            If Not URLReq Is Nothing Then
                URLReq.Abort()
            End If
        End Try
    End Function


    Public Sub New(ByRef m_form As Form)
        frmUpdateApp = m_form
    End Sub
    Private Sub InitProgressBar(ByVal i As Integer)
        If Not frmUpdateApp.ProgressBarControl1 Is Nothing Then
            frmUpdateApp.ProgressBarControl1.Maximum = i
            frmUpdateApp.ProgressBarControl1.Value = 0
            frmUpdateApp.ProgressBarControl1.Minimum = 0
            'frmUpdateApp.ProgressBarControl1.PercentView = True

        End If
    End Sub

    Private Sub ValueProgressBar()
        If Not frmUpdateApp.ProgressBarControl1 Is Nothing Then
            frmUpdateApp.ProgressBarControl1.Update()
            frmUpdateApp.ProgressBarControl1.Value = frmUpdateApp.ProgressBarControl1.Value + 1
            'frmUpdateApp.ProgressBarControl1.PerformStep()

        End If
    End Sub

    Public Sub KillAppInstance()
        ' Get MainApp exe name without extension
        Dim AppExe As String = m_ApplicationInstance.Replace(".exe", "")

        Dim local As Process() = Process.GetProcesses
        Dim i As Integer
        ' Search MainApp process in windows process
        For i = 0 To local.Length - 1
            ' If MainApp process found then close or kill MainApp
            If Strings.UCase(local(i).ProcessName) = Strings.UCase(AppExe) Then
                local(i).Kill()
            End If
        Next
    End Sub

    Public Sub AppendTLog(ByVal sMessage As String)
        Try
            Dim sDirectoryPath As String = ""
            Dim sFilePath As String

            sDirectoryPath = GetTLogAutoUpdate() & "GPS-TIME-MANAGEMENT Update TLog - " & Format(Now, "MMM") & " " & Format(Now, "yyyy")

            If Not Directory.Exists(sDirectoryPath) Then
                Directory.CreateDirectory(sDirectoryPath)
            End If

            'the directory exists
            Dim sCurrentDate As String
            sCurrentDate = Format(Today, "dd MMM yyyy")

            sFilePath = sCurrentDate
            sFilePath = sDirectoryPath & "\" & sFilePath & ".txt"

            If Not File.Exists(sFilePath) Then
                Dim oCreator As StreamWriter = File.CreateText(sFilePath)
                oCreator.Close()
            End If

            Dim oWriter As StreamWriter = File.AppendText(sFilePath)
            oWriter.WriteLine(sMessage)
            oWriter.Close()
        Catch ex As Exception
            sMessage = "======================================================================================" & vbCrLf & _
              "Error occured at '" & ex.Source & "' on " & Now.ToShortDateString & " - " & Now.ToLongTimeString & ": " & vbCrLf & _
             ex.Message.ToString & vbCrLf & "Please contact your system administrator if this problem occurs persistently." & vbCrLf & _
             "Stack Trace: " & vbCrLf & ex.StackTrace & vbCrLf & "======================================================================================"
            AppendTLog(sMessage)
        End Try
    End Sub

    Public Function GetTLogAutoUpdate() As String
        Dim regKey As RegistryKey
        regKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\EPMS\\Versi 1", True)
        If Not regKey Is Nothing Then
            Return CStr(If(regKey.GetValue("tlogautoupdate") Is Nothing OrElse _
                           regKey.GetValue("tlogautoupdate").ToString = "", Application.StartupPath & "\", regKey.GetValue("tlogautoupdate")))
        Else
            Return Application.StartupPath & "\" 'by default the files will be located at here
        End If
    End Function

    Private Function getVersionInfo(ByVal assemblyFile As String) As String

        Dim strVersion As String = ""
        Try
            Dim asbInfo As AssemblyName = AssemblyName.GetAssemblyName(assemblyFile)
            strVersion = asbInfo.Version.Major & "." & asbInfo.Version.MajorRevision & "." & asbInfo.Version.Minor & "." & asbInfo.Version.MinorRevision
        Catch
            strVersion = ""
        End Try
        Return strVersion
    End Function

    Private Function getAssemblyInfo(ByVal fileName As String) As String

        Dim strVersion As String = ""
        Try
            Dim fvInfo As FileVersionInfo = FileVersionInfo.GetVersionInfo(fileName)
            strVersion = fvInfo.FileMajorPart & "." & fvInfo.FileMinorPart & "." & fvInfo.FileBuildPart & "." & fvInfo.FilePrivatePart
        Catch
            strVersion = ""
        End Try
        Return strVersion
    End Function

End Class
